// @lovable.dev/vite-tanstack-config already includes the following — do NOT add them manually
// or the app will break with duplicate plugins:
//   - tanstackStart, viteReact, tailwindcss, tsConfigPaths, nitro (build-only using cloudflare as a default target),
//     componentTagger (dev-only), VITE_* env injection, @ path alias, React/TanStack dedupe,
//     error logger plugins, and sandbox detection (port/host/strictPort).
// You can pass additional config via defineConfig({ vite: { ... }, etc... }) if needed.
import { defineConfig } from "@lovable.dev/vite-tanstack-config";
import type { ModuleNode, Plugin } from "vite";
import { mcpPlugin } from "@lovable.dev/mcp-js/stacks/tanstack/vite";

// HMR-friendly invalidation for route-critical modules. Instead of restarting
// the dev server, we surgically invalidate the changed module + its importers
// and ask the client to hot-reload. Avoids stale "Duplicate declaration" /
// phantom binding errors after refactors without the cost of a full restart.
function routerHmrInvalidator(): Plugin {
  const ROUTER_PATTERNS = [
    /\/src\/routes\//,
    /\/src\/lib\/(sectors|countries)\.ts$/,
    /\/src\/router\.tsx$/,
    /routeTree\.gen\.ts$/,
  ];
  const isRouterModule = (file: string) =>
    ROUTER_PATTERNS.some((re) => re.test(file.replace(/\\/g, "/")));

  return {
    name: "lovable:router-hmr-invalidator",
    apply: "serve",
    enforce: "post",
    handleHotUpdate({ file, server, modules }) {
      const log = (msg: string) => {
        if (process.env.ENABLE_ROUTER_HMR_LOGS === "true") {
          console.log(`[router-hmr] ${msg}`);
        }
      };

      if (!isRouterModule(file)) return;

      log(`"${file}" is a route-critical module — invalidating dependent graph`);

      // Invalidate the changed module and every importer transitively so any
      // cached binding (e.g. re-exported SECTORS) gets re-evaluated.
      const seen = new Set<string>();
      const invalidated: string[] = [];
      const walk = (mods: Iterable<ModuleNode>) => {
        for (const mod of mods) {
          if (!mod.id || seen.has(mod.id)) continue;
          seen.add(mod.id);
          server.moduleGraph.invalidateModule(mod);
          invalidated.push(mod.id);
          walk(mod.importers);
        }
      };
      walk(modules);

      log(`invalidated ${invalidated.length} module(s): ${invalidated.join(", ")}`);

      // Tell the client to reload the page rather than try to patch — route
      // modules are not React-Refresh boundaries and partial HMR can desync.
      server.ws.send({ type: "full-reload", path: "*" });
      return [];
    },
  };
}

export default defineConfig({
  tanstackStart: {
    // Redirect TanStack Start's bundled server entry to src/server.ts (our SSR error wrapper).
    // nitro/vite builds from this
    server: { entry: "server" },
  },
  vite: {
    plugins: [routerHmrInvalidator(), mcpPlugin()],
  },
});
