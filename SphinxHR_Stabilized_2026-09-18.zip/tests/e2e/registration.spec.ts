import { test, expect, type Page } from "@playwright/test";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

/**
 * End-to-end registration coverage: registers a Job Seeker and a Company
 * account through the real /auth form and verifies every entered field is
 * actually persisted in the database, plus that a failed profile write shows
 * an error instead of a success message.
 */

function env(name: string): string {
  if (process.env[name]) return process.env[name] as string;
  const file = readFileSync(resolve(process.cwd(), ".env"), "utf8");
  const line = file.split("\n").find((l) => l.trim().startsWith(`${name}=`));
  const value = line
    ?.slice(line.indexOf("=") + 1)
    .trim()
    .replace(/^["']|["']$/g, "");
  if (!value) throw new Error(`Missing ${name} (set it in the environment or .env)`);
  return value;
}

const SUPABASE_URL = env("VITE_SUPABASE_URL");
const SUPABASE_KEY = env("VITE_SUPABASE_PUBLISHABLE_KEY");

type SignUpData = {
  accountType: "job_seeker" | "company";
  full_name: string;
  company_name?: string;
  email: string;
  phone: string;
  country: string;
  password: string;
};

function makeData(accountType: "job_seeker" | "company"): SignUpData {
  const stamp = `${Date.now()}${Math.floor(Math.random() * 1000)}`;
  return {
    accountType,
    full_name: accountType === "company" ? `E2E Contact ${stamp}` : `E2E Seeker ${stamp}`,
    company_name: accountType === "company" ? `E2E Company ${stamp}` : undefined,
    email: `e2e.${accountType}.${stamp}@sphinx-e2e.test`,
    phone: "+966500000001",
    country: "Egypt",
    password: "E2ePassw0rd!x",
  };
}

/** Fills and submits the signup form inside the tab for the given account type. */
async function submitSignUp(page: Page, data: SignUpData) {
  await page.goto("/auth", { waitUntil: "domcontentloaded" });
  // The page is server-rendered: wait for hydration before interacting, otherwise
  // clicks land on inert markup and the account-type/mode toggles do nothing.
  await page.getByRole("tab").first().waitFor();
  await expect
    .poll(
      async () => {
        await page
          .getByRole("tab")
          .nth(data.accountType === "company" ? 1 : 0)
          .click();
        await page
          .getByRole("button", { name: /^(Create account|إنشاء حساب)$/ })
          .first()
          .click();
        return page.locator('input[name="confirm"]').count();
      },
      { timeout: 30_000, intervals: [500] },
    )
    .toBeGreaterThan(0);

  const form = page
    .locator("form")
    .filter({ has: page.locator('input[name="confirm"]') })
    .first();
  await form.waitFor();

  if (data.company_name) {
    await form.locator('input[name="company_name"]').fill(data.company_name);
  }
  await form.locator('input[name="full_name"]').fill(data.full_name);
  await form.locator('input[name="email"]').fill(data.email);
  await form.locator('input[name="phone"]').fill(data.phone);
  await form.locator('select[name="country"]').selectOption(data.country);
  await form.locator('input[name="password"]').fill(data.password);
  await form.locator('input[name="confirm"]').fill(data.password);

  const submit = form.getByRole("button", {
    name: /Create account|Create company account|إنشاء حساب/,
  });
  await expect(submit).toBeEnabled();
  await submit.click();
}

/** Reads the persisted profile + role rows as the freshly signed-in user. */
async function readPersisted(page: Page) {
  return page.evaluate(
    async ({ url, key }) => {
      const raw = Object.keys(localStorage)
        .filter((k) => k.startsWith("sb-") && k.endsWith("-auth-token"))
        .map((k) => localStorage.getItem(k))
        .find(Boolean);
      if (!raw) return null;
      const session = JSON.parse(raw);
      const token: string = session.access_token;
      const userId: string = session.user.id;
      const headers = { apikey: key, Authorization: `Bearer ${token}` };
      const [profileRes, rolesRes] = await Promise.all([
        fetch(`${url}/rest/v1/profiles?id=eq.${userId}&select=*`, { headers }),
        fetch(`${url}/rest/v1/user_roles?user_id=eq.${userId}&select=role`, { headers }),
      ]);
      const profile = (await profileRes.json())[0] ?? null;
      const roles = (await rolesRes.json()) as { role: string }[];
      return { profile, roles: roles.map((r) => r.role) };
    },
    { url: SUPABASE_URL, key: SUPABASE_KEY },
  );
}

const emailConfirmation = /Check your email|تأكيد بريدك/;

test.describe("registration persists every profile field", () => {
  for (const accountType of ["job_seeker", "company"] as const) {
    test(`${accountType} signup saves all entered fields`, async ({ page }) => {
      const data = makeData(accountType);
      await submitSignUp(page, data);

      const success = page.getByText(/You're signed in|تم تسجيل الدخول/);
      const pending = page.getByText(emailConfirmation);
      await expect(success.or(pending)).toBeVisible({ timeout: 30_000 });

      // No error toast may appear alongside success.
      await expect(page.getByText(/could not be saved|تعذر حفظ بياناتك/)).toHaveCount(0);

      if (await pending.isVisible()) {
        test.info().annotations.push({
          type: "note",
          description:
            "Email confirmation is required, so no session exists to read the profile row.",
        });
        return;
      }

      const persisted = await readPersisted(page);
      expect(persisted?.profile).toBeTruthy();
      expect(persisted!.profile).toMatchObject({
        account_type: accountType,
        full_name: data.full_name,
        email: data.email,
        phone: data.phone,
        country: data.country,
        company_name: data.company_name ?? null,
      });
      expect(persisted!.roles).toContain(accountType);
    });
  }

  test("a failed profile write surfaces an error instead of success", async ({ page }) => {
    const data = makeData("job_seeker");
    // Break every profiles read/write so the post-signup verification fails.
    await page.route("**/rest/v1/profiles*", (route) =>
      route.fulfill({
        status: 500,
        contentType: "application/json",
        body: '{"message":"forced failure"}',
      }),
    );

    await submitSignUp(page, data);

    const pending = page.getByText(emailConfirmation);
    const failure = page.getByText(/could not be saved|تعذر حفظ بياناتك/);
    await expect(failure.or(pending)).toBeVisible({ timeout: 30_000 });

    if (await pending.isVisible()) return;
    await expect(page.getByText(/You're signed in|تم تسجيل الدخول/)).toHaveCount(0);
  });
});
