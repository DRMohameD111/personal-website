# E2E tests

Playwright tests asserting SSR + hydration behavior, including the EN ↔ AR
language switch.

## Run

The Lovable sandbox does not ship Chromium's system libraries, so on Lovable
you need to install Playwright's browser and resolve a few `LD_LIBRARY_PATH`
entries before running. On a normal dev machine (Mac/Linux with a desktop
environment), you only need:

```bash
bunx playwright install chromium
bun run dev   # in another terminal
bunx playwright test
```

## What's verified

`tests/e2e/hydration.spec.ts`:

1. **No hydration mismatch on SSR → CSR handoff.** The page is loaded, the
   raw SSR HTML is asserted to contain the English hero copy and
   `<html lang="en">`, and we listen for any console message or page error
   matching React's hydration warning patterns (including minified error
   codes `#418`, `#423`, `#425`).
2. **No hydration mismatch when toggling EN → AR → EN.** After each toggle
   we assert `<html lang/dir>` updates and the hero copy swaps, then re-check
   the console for hydration warnings.
3. **localStorage-stored Arabic preference survives reload** with no
   hydration warnings. The client swap from the SSR-default English to
   stored Arabic happens inside a `useEffect`, which React does not treat
   as a mismatch.
