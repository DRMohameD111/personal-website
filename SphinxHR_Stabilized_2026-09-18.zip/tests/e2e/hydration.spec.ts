import { test, expect, type ConsoleMessage } from "@playwright/test";

// React's hydration mismatch warnings always include one of these substrings.
const HYDRATION_PATTERNS = [
  /hydration/i,
  /did not match/i,
  /server-rendered HTML/i,
  /Minified React error #(418|423|425)/i, // hydration error codes
];

function isHydrationMessage(msg: ConsoleMessage) {
  const text = msg.text();
  return HYDRATION_PATTERNS.some((re) => re.test(text));
}

test.describe("Homepage hydration & language switching", () => {
  test("SSR ships English, hydrates without mismatch, toggles to Arabic without mismatch", async ({
    page,
  }) => {
    const hydrationLogs: string[] = [];
    const pageErrors: string[] = [];

    page.on("console", (msg) => {
      if (isHydrationMessage(msg)) hydrationLogs.push(`[${msg.type()}] ${msg.text()}`);
    });
    page.on("pageerror", (err) => {
      if (HYDRATION_PATTERNS.some((re) => re.test(err.message))) {
        pageErrors.push(err.message);
      }
    });

    // 1. SSR -> initial English render
    const response = await page.goto("/", { waitUntil: "networkidle" });
    expect(response?.status()).toBe(200);

    // Raw SSR HTML must contain the English hero (proves SSR ran, not a CSR shell)
    const ssrHtml = (await response!.text()) ?? "";
    expect(ssrHtml).toContain("We deliver skilled");
    expect(ssrHtml).toMatch(/<html[^>]*lang="en"/);

    // Hydrated DOM still shows English
    await expect(page.locator("h1").first()).toContainText("We deliver skilled");

    // 2. Toggle to Arabic
    await page.click('button[aria-label="Toggle language"]');

    // Hero swaps to the Arabic string
    await expect(page.locator("h1").first()).toContainText("نوفر العمالة");

    // <html> attributes flip to ar / rtl
    await expect.poll(() => page.evaluate(() => document.documentElement.lang)).toBe("ar");
    await expect.poll(() => page.evaluate(() => document.documentElement.dir)).toBe("rtl");

    // 3. Toggle back to English
    await page.click('button[aria-label="Toggle language"]');
    await expect(page.locator("h1").first()).toContainText("We deliver skilled");
    await expect.poll(() => page.evaluate(() => document.documentElement.lang)).toBe("en");
    await expect.poll(() => page.evaluate(() => document.documentElement.dir)).toBe("ltr");

    // 4. No hydration warnings emitted at any point
    expect(hydrationLogs, "React hydration warnings in console").toEqual([]);
    expect(pageErrors, "React hydration errors thrown").toEqual([]);
  });

  test("Arabic preference in localStorage survives reload without hydration mismatch", async ({
    page,
  }) => {
    const hydrationLogs: string[] = [];
    page.on("console", (msg) => {
      if (isHydrationMessage(msg)) hydrationLogs.push(msg.text());
    });
    page.on("pageerror", (err) => {
      if (HYDRATION_PATTERNS.some((re) => re.test(err.message))) {
        hydrationLogs.push(err.message);
      }
    });

    // Seed Arabic preference, then load fresh
    await page.goto("/");
    await page.evaluate(() => localStorage.setItem("sphinx:lang", "ar"));
    await page.reload({ waitUntil: "networkidle" });

    // SSR still ships English (no cookie-based negotiation), client swaps to Arabic post-mount
    await expect(page.locator("h1").first()).toContainText("نوفر العمالة");
    await expect.poll(() => page.evaluate(() => document.documentElement.dir)).toBe("rtl");

    expect(hydrationLogs, "no hydration warnings on stored-preference rehydrate").toEqual([]);
  });
});
