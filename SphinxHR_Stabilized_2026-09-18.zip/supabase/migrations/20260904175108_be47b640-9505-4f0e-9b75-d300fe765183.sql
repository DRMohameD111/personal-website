ALTER TYPE public.job_posting_status ADD VALUE IF NOT EXISTS 'pending_approval';
ALTER TYPE public.job_posting_status ADD VALUE IF NOT EXISTS 'rejected';
ALTER TYPE public.job_posting_status ADD VALUE IF NOT EXISTS 'expired';

ALTER TABLE public.job_postings ADD COLUMN IF NOT EXISTS views integer NOT NULL DEFAULT 0;

CREATE OR REPLACE FUNCTION public.increment_job_views(_job_posting_id uuid)
RETURNS void
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  UPDATE public.job_postings
     SET views = views + 1
   WHERE id = _job_posting_id
     AND status::text = 'published';
$$;

GRANT EXECUTE ON FUNCTION public.increment_job_views(uuid) TO anon, authenticated;

DROP FUNCTION IF EXISTS public.job_listing_meta();
CREATE FUNCTION public.job_listing_meta()
RETURNS TABLE(
  job_posting_id uuid,
  applicant_count integer,
  portal_valuation smallint,
  company_type smallint,
  branches_count integer,
  published_at timestamp with time zone,
  closes_at timestamp with time zone,
  status text,
  views integer,
  is_direct_ad boolean
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT jp.id,
         (SELECT count(*)::int FROM public.job_applications ja WHERE ja.job_posting_id = jp.id),
         p.portal_valuation,
         p.company_type,
         p.branches_count,
         jp.published_at,
         jp.closes_at,
         jp.status::text,
         jp.views,
         COALESCE((jp.data->>'direct_ad')::boolean, false)
    FROM public.job_postings jp
    LEFT JOIN public.profiles p ON p.id = jp.user_id
$$;

GRANT EXECUTE ON FUNCTION public.job_listing_meta() TO anon, authenticated;

CREATE OR REPLACE FUNCTION public.close_expired_job_postings()
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE n integer;
BEGIN
  UPDATE public.job_postings
     SET status = CASE
           WHEN COALESCE((data->>'direct_ad')::boolean, false) THEN 'expired'::public.job_posting_status
           ELSE 'closed'::public.job_posting_status
         END
   WHERE status IN ('published', 'paused')
     AND closes_at IS NOT NULL
     AND closes_at <= now();
  GET DIAGNOSTICS n = ROW_COUNT;
  RETURN n;
END;
$$;

DROP POLICY IF EXISTS "Admins can read all postings" ON public.job_postings;
CREATE POLICY "Admins can read all postings"
ON public.job_postings
FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));