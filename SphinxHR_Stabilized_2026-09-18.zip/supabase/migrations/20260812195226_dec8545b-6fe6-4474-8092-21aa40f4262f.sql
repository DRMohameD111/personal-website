-- 1) Duplicate-application protection (non-destructive, partial unique indexes)
CREATE UNIQUE INDEX IF NOT EXISTS job_applications_candidate_posting_uidx
  ON public.job_applications (candidate_id, job_posting_id)
  WHERE job_posting_id IS NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS job_applications_candidate_external_uidx
  ON public.job_applications (candidate_id, external_job_id)
  WHERE external_job_id IS NOT NULL;

-- 2) Real aggregate platform statistics for the public home page (no PII exposed)
CREATE OR REPLACE FUNCTION public.platform_stats()
RETURNS jsonb
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT jsonb_build_object(
    'job_seekers', (SELECT count(*) FROM public.profiles WHERE account_type = 'job_seeker'),
    'companies',   (SELECT count(*) FROM public.profiles WHERE account_type = 'company'),
    'jobs',        (SELECT count(*) FROM public.job_postings WHERE status = 'published'),
    'hires',       (SELECT count(*) FROM public.job_applications WHERE status = 'hired')
  )
$$;

GRANT EXECUTE ON FUNCTION public.platform_stats() TO anon, authenticated, service_role;