CREATE UNIQUE INDEX IF NOT EXISTS job_applications_candidate_posting_uidx
  ON public.job_applications (candidate_id, job_posting_id)
  WHERE job_posting_id IS NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS job_applications_candidate_external_uidx
  ON public.job_applications (candidate_id, external_job_id)
  WHERE external_job_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS public.candidate_documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  doc_type text NOT NULL DEFAULT 'other',
  title text,
  storage_path text NOT NULL,
  file_name text,
  size_bytes integer,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.candidate_documents TO authenticated;
GRANT ALL ON public.candidate_documents TO service_role;

ALTER TABLE public.candidate_documents ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Own documents" ON public.candidate_documents;
CREATE POLICY "Own documents" ON public.candidate_documents FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Employer reads applicant documents" ON public.candidate_documents;
CREATE POLICY "Employer reads applicant documents" ON public.candidate_documents FOR SELECT TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.job_applications ja
    WHERE ja.candidate_id = public.candidate_documents.user_id
      AND ja.employer_id = auth.uid()
  ));

DROP TRIGGER IF EXISTS set_candidate_documents_updated_at ON public.candidate_documents;
CREATE TRIGGER set_candidate_documents_updated_at BEFORE UPDATE ON public.candidate_documents
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();