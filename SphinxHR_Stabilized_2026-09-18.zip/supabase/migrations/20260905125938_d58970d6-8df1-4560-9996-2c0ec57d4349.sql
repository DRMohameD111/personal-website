-- 1. Administrator accounts -------------------------------------------------
CREATE TABLE public.admin_accounts (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  is_main boolean NOT NULL DEFAULT false,
  is_disabled boolean NOT NULL DEFAULT false,
  display_name text,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.admin_accounts TO authenticated;
GRANT ALL ON public.admin_accounts TO service_role;
ALTER TABLE public.admin_accounts ENABLE ROW LEVEL SECURITY;

CREATE TRIGGER set_admin_accounts_updated_at
BEFORE UPDATE ON public.admin_accounts
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- 2. Per-module permissions --------------------------------------------------
CREATE TABLE public.admin_permissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  module text NOT NULL,
  action text NOT NULL,
  granted_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, module, action),
  CONSTRAINT admin_permissions_module_chk CHECK (module IN (
    'companies','job_seekers','jobs','applications','packages',
    'payments','direct_ads','cvs','reports')),
  CONSTRAINT admin_permissions_action_chk CHECK (action IN (
    'view','edit','verify','print','export','approve'))
);

CREATE INDEX admin_permissions_user_idx ON public.admin_permissions (user_id);

GRANT SELECT ON public.admin_permissions TO authenticated;
GRANT ALL ON public.admin_permissions TO service_role;
ALTER TABLE public.admin_permissions ENABLE ROW LEVEL SECURITY;

-- 3. Administrative audit trail ---------------------------------------------
CREATE TABLE public.admin_audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  actor_email text,
  action text NOT NULL,
  target_type text,
  target_id text,
  changes jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX admin_audit_log_created_idx ON public.admin_audit_log (created_at DESC);

GRANT SELECT ON public.admin_audit_log TO authenticated;
GRANT ALL ON public.admin_audit_log TO service_role;
ALTER TABLE public.admin_audit_log ENABLE ROW LEVEL SECURITY;

-- 4. Helper checks -----------------------------------------------------------
CREATE OR REPLACE FUNCTION public.is_main_admin(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.admin_accounts a
     WHERE a.user_id = _user_id AND a.is_main AND NOT a.is_disabled
  ) AND public.has_role(_user_id, 'admin')
$$;

CREATE OR REPLACE FUNCTION public.admin_can(_user_id uuid, _module text, _action text)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT public.has_role(_user_id, 'admin')
     AND NOT EXISTS (
       SELECT 1 FROM public.admin_accounts a
        WHERE a.user_id = _user_id AND a.is_disabled
     )
     AND (
       public.is_main_admin(_user_id)
       OR EXISTS (
         SELECT 1 FROM public.admin_permissions p
          WHERE p.user_id = _user_id AND p.module = _module AND p.action = _action
       )
     )
$$;

REVOKE ALL ON FUNCTION public.is_main_admin(uuid) FROM anon;
REVOKE ALL ON FUNCTION public.admin_can(uuid, text, text) FROM anon;
GRANT EXECUTE ON FUNCTION public.is_main_admin(uuid) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.admin_can(uuid, text, text) TO authenticated, service_role;

-- 5. Policies ---------------------------------------------------------------
CREATE POLICY "Admins read their own row; main admins read all"
ON public.admin_accounts FOR SELECT TO authenticated
USING (user_id = auth.uid() OR public.is_main_admin(auth.uid()));

CREATE POLICY "Admins read their own permissions; main admins read all"
ON public.admin_permissions FOR SELECT TO authenticated
USING (user_id = auth.uid() OR public.is_main_admin(auth.uid()));

CREATE POLICY "Main admins read the audit log"
ON public.admin_audit_log FOR SELECT TO authenticated
USING (public.is_main_admin(auth.uid()));

-- 6. Existing administrators become main admins ------------------------------
INSERT INTO public.admin_accounts (user_id, is_main)
SELECT r.user_id, true FROM public.user_roles r WHERE r.role = 'admin'
ON CONFLICT (user_id) DO UPDATE SET is_main = true;