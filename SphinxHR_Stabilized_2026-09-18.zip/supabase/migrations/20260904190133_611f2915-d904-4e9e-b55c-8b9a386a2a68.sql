GRANT SELECT ON public.job_postings TO anon;

DROP POLICY IF EXISTS "Guests can browse published direct ads" ON public.job_postings;
CREATE POLICY "Guests can browse published direct ads"
ON public.job_postings FOR SELECT TO anon
USING (status = 'published'::job_posting_status AND (data->>'direct_ad')::boolean IS TRUE);

GRANT EXECUTE ON FUNCTION public.job_listing_meta() TO anon;
GRANT EXECUTE ON FUNCTION public.increment_job_views(uuid) TO anon;