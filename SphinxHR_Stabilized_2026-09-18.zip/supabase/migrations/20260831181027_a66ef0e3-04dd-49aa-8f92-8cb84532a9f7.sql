-- ============ packages ============
CREATE TABLE public.packages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  name_en text NOT NULL,
  name_ar text NOT NULL,
  short_desc_en text,
  short_desc_ar text,
  full_desc_en text,
  full_desc_ar text,
  price numeric NOT NULL DEFAULT 0,
  promo_price numeric,
  price_after_trial numeric,
  currency text NOT NULL DEFAULT 'SAR',
  vat_note_en text,
  vat_note_ar text,
  billing_period text NOT NULL DEFAULT 'monthly',
  duration_months integer,
  duration_label_en text,
  duration_label_ar text,
  trial_enabled boolean NOT NULL DEFAULT false,
  trial_days integer NOT NULL DEFAULT 0,
  trial_starts_at timestamptz,
  trial_ends_at timestamptz,
  trial_new_companies_only boolean NOT NULL DEFAULT true,
  promo_starts_at timestamptz,
  promo_ends_at timestamptz,
  discount_percent numeric,
  discount_amount numeric,
  display_start_at timestamptz,
  display_end_at timestamptz,
  is_free boolean NOT NULL DEFAULT false,
  is_active boolean NOT NULL DEFAULT true,
  is_recommended boolean NOT NULL DEFAULT false,
  badge_text_en text,
  badge_text_ar text,
  cta_text_en text,
  cta_text_ar text,
  cta_url text,
  is_enterprise boolean NOT NULL DEFAULT false,
  show_price boolean NOT NULL DEFAULT true,
  contact_instead_of_price boolean NOT NULL DEFAULT false,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.packages TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.packages TO authenticated;
GRANT ALL ON public.packages TO service_role;

ALTER TABLE public.packages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public reads visible packages" ON public.packages
  FOR SELECT TO anon, authenticated
  USING (
    is_active
    AND (display_start_at IS NULL OR display_start_at <= now())
    AND (display_end_at IS NULL OR display_end_at >= now())
  );

CREATE POLICY "Admins manage packages" ON public.packages
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER set_packages_updated_at BEFORE UPDATE ON public.packages
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ============ package_features ============
CREATE TABLE public.package_features (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  package_id uuid NOT NULL REFERENCES public.packages(id) ON DELETE CASCADE,
  feature_key text NOT NULL,
  label_en text NOT NULL,
  label_ar text NOT NULL,
  value_type text NOT NULL DEFAULT 'boolean',
  value_bool boolean,
  value_number numeric,
  value_text_en text,
  value_text_ar text,
  enabled boolean NOT NULL DEFAULT true,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.package_features TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.package_features TO authenticated;
GRANT ALL ON public.package_features TO service_role;

ALTER TABLE public.package_features ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public reads features of visible packages" ON public.package_features
  FOR SELECT TO anon, authenticated
  USING (
    enabled AND EXISTS (
      SELECT 1 FROM public.packages p
      WHERE p.id = package_features.package_id
        AND p.is_active
        AND (p.display_start_at IS NULL OR p.display_start_at <= now())
        AND (p.display_end_at IS NULL OR p.display_end_at >= now())
    )
  );

CREATE POLICY "Admins manage package features" ON public.package_features
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER set_package_features_updated_at BEFORE UPDATE ON public.package_features
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE INDEX package_features_package_id_idx ON public.package_features (package_id, sort_order);

-- ============ package_audit_log ============
CREATE TABLE public.package_audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  package_id uuid REFERENCES public.packages(id) ON DELETE SET NULL,
  package_slug text,
  admin_user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  admin_email text,
  action text NOT NULL,
  changes jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT ON public.package_audit_log TO authenticated;
GRANT ALL ON public.package_audit_log TO service_role;

ALTER TABLE public.package_audit_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins read package audit log" ON public.package_audit_log
  FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins write package audit log" ON public.package_audit_log
  FOR INSERT TO authenticated
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- ============ subscriptions ============
CREATE TABLE public.subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  package_id uuid REFERENCES public.packages(id) ON DELETE SET NULL,
  package_snapshot jsonb NOT NULL DEFAULT '{}'::jsonb,
  price_paid numeric NOT NULL DEFAULT 0,
  currency text NOT NULL DEFAULT 'SAR',
  is_trial boolean NOT NULL DEFAULT false,
  started_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz,
  status text NOT NULL DEFAULT 'active',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT ON public.subscriptions TO authenticated;
GRANT ALL ON public.subscriptions TO service_role;

ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users read own subscriptions" ON public.subscriptions
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Users create own subscriptions" ON public.subscriptions
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE TRIGGER set_subscriptions_updated_at BEFORE UPDATE ON public.subscriptions
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE INDEX subscriptions_user_id_idx ON public.subscriptions (user_id);

-- ============ seed starter packages ============
INSERT INTO public.packages (
  slug, name_en, name_ar, short_desc_en, short_desc_ar,
  price, price_after_trial, currency, billing_period,
  duration_months, trial_enabled, trial_days, trial_new_companies_only,
  is_free, is_active, is_recommended, badge_text_en, badge_text_ar,
  cta_text_en, cta_text_ar, cta_url, sort_order
) VALUES
(
  'main', 'Main Package', 'الباقة الأساسية',
  'Free for 3 months', 'مجانية لمدة 3 أشهر',
  0, 499, 'SAR', 'monthly', 3, true, 90, true,
  true, true, true, 'Most Popular', 'الأكثر شيوعاً',
  'Start free', 'ابدأ مجاناً', '/get-started', 1
),
(
  'premium', 'Premium', 'الباقة المتقدمة',
  'For growing hiring teams', 'لفرق التوظيف المتنامية',
  999, NULL, 'SAR', 'monthly', 3, false, 0, true,
  false, true, false, NULL, NULL,
  'Subscribe', 'اشترك الآن', '/get-started', 2
),
(
  'enterprise', 'Enterprise', 'باقة المؤسسات',
  'Custom workforce solutions', 'حلول قوى عاملة مخصصة',
  0, NULL, 'SAR', 'custom', NULL, false, 0, true,
  false, true, false, NULL, NULL,
  'Contact us', 'تواصل معنا', '/contact', 3
);

UPDATE public.packages SET show_price = false, contact_instead_of_price = true, is_enterprise = true,
  duration_label_en = 'Custom', duration_label_ar = 'مخصصة'
WHERE slug = 'enterprise';

INSERT INTO public.package_features (package_id, feature_key, label_en, label_ar, value_type, value_bool, value_number, value_text_en, value_text_ar, sort_order)
SELECT p.id, f.feature_key, f.label_en, f.label_ar, f.value_type, f.value_bool, f.value_number, f.value_text_en, f.value_text_ar, f.sort_order
FROM public.packages p
JOIN (VALUES
  ('main','job_posts','Job posts','عدد الإعلانات الوظيفية','number',NULL::boolean,10::numeric,NULL::text,NULL::text,1),
  ('main','cv_access','CV access','الوصول للسير الذاتية','number',NULL,50,NULL,NULL,2),
  ('main','contacts','Candidate contacts','التواصل مع المرشحين','number',NULL,25,NULL,NULL,3),
  ('main','users','Users allowed','عدد المستخدمين','number',NULL,2,NULL,NULL,4),
  ('main','advanced_filtering','Advanced filtering','فلترة متقدمة','boolean',true,NULL,NULL,NULL,5),
  ('main','video_cv','Video CV','السيرة الذاتية المرئية','boolean',false,NULL,NULL,NULL,6),
  ('main','support','Support level','مستوى الدعم','text',NULL,NULL,'Standard support','دعم قياسي',7),
  ('premium','job_posts','Job posts','عدد الإعلانات الوظيفية','number',NULL,50,NULL,NULL,1),
  ('premium','cv_access','CV access','الوصول للسير الذاتية','unlimited',NULL,NULL,NULL,NULL,2),
  ('premium','contacts','Candidate contacts','التواصل مع المرشحين','number',NULL,150,NULL,NULL,3),
  ('premium','users','Users allowed','عدد المستخدمين','number',NULL,5,NULL,NULL,4),
  ('premium','advanced_filtering','Advanced filtering','فلترة متقدمة','boolean',true,NULL,NULL,NULL,5),
  ('premium','video_cv','Video CV','السيرة الذاتية المرئية','boolean',true,NULL,NULL,NULL,6),
  ('premium','featured_jobs','Featured job promotion','ترويج الوظائف','boolean',true,NULL,NULL,NULL,7),
  ('premium','verification','Company verification badge','شارة توثيق الشركة','boolean',true,NULL,NULL,NULL,8),
  ('premium','support','Support level','مستوى الدعم','text',NULL,NULL,'Priority support','دعم ذو أولوية',9),
  ('enterprise','job_posts','Job posts','عدد الإعلانات الوظيفية','unlimited',NULL,NULL,NULL,NULL,1),
  ('enterprise','cv_access','CV access','الوصول للسير الذاتية','unlimited',NULL,NULL,NULL,NULL,2),
  ('enterprise','contacts','Candidate contacts','التواصل مع المرشحين','unlimited',NULL,NULL,NULL,NULL,3),
  ('enterprise','users','Users allowed','عدد المستخدمين','text',NULL,NULL,'Custom','مخصص',4),
  ('enterprise','reports','Reports & dashboards','التقارير ولوحات المتابعة','boolean',true,NULL,NULL,NULL,5),
  ('enterprise','support','Support level','مستوى الدعم','text',NULL,NULL,'Dedicated account manager','مدير حساب مخصص',6)
) AS f(slug, feature_key, label_en, label_ar, value_type, value_bool, value_number, value_text_en, value_text_ar, sort_order)
ON f.slug = p.slug;