-- Direct Vacancy Ad: reuse the existing packages table as the single price source.
INSERT INTO public.packages (
  slug, name_en, name_ar, short_desc_en, short_desc_ar,
  price, currency, billing_period, duration_months,
  is_free, is_active, show_price, sort_order, rank, code_prefix
) VALUES (
  'direct-ad',
  'Direct Vacancy Ad',
  'إعلان مباشر عن وظيفة',
  'Post a single vacancy without a subscription.',
  'انشر وظيفة واحدة بدون اشتراك.',
  0, 'SAR', 'one_time', 1,
  true, true, true, 99, 0, 'DA'
)
ON CONFLICT (slug) DO NOTHING;