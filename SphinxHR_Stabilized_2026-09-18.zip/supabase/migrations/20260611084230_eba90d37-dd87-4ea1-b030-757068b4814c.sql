
DROP POLICY IF EXISTS "Users manage own CVs" ON storage.objects;
CREATE POLICY "Users manage own CVs" ON storage.objects
  FOR ALL TO authenticated
  USING (bucket_id = 'cvs' AND auth.uid()::text = (storage.foldername(name))[1])
  WITH CHECK (bucket_id = 'cvs' AND auth.uid()::text = (storage.foldername(name))[1]);
