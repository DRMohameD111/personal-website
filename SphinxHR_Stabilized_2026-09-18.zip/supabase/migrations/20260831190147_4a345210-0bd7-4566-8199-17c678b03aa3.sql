-- =========================================================================
-- Secure company package management (extends existing packages/subscriptions)
-- Non-destructive: only additive DDL.
-- =========================================================================

-- ---- 1. Company code on the existing profiles table ---------------------
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS company_code text;
CREATE UNIQUE INDEX IF NOT EXISTS profiles_company_code_key
  ON public.profiles (company_code) WHERE company_code IS NOT NULL;

-- ---- 2. Stable package configuration (rank + code prefix) ---------------
ALTER TABLE public.packages ADD COLUMN IF NOT EXISTS rank integer NOT NULL DEFAULT 0;
ALTER TABLE public.packages ADD COLUMN IF NOT EXISTS code_prefix text;

UPDATE public.packages SET rank = sort_order WHERE rank = 0;
UPDATE public.packages
   SET code_prefix = upper(left(regexp_replace(slug, '[^a-zA-Z]', '', 'g'), 1))
 WHERE code_prefix IS NULL;

-- ---- 3. Admin-configurable commercial policy (single row) ---------------
CREATE TABLE IF NOT EXISTS public.subscription_policy (
  id boolean PRIMARY KEY DEFAULT true CHECK (id),
  upgrade_timing text NOT NULL DEFAULT 'after_payment'
    CHECK (upgrade_timing IN ('immediate', 'after_payment')),
  downgrade_timing text NOT NULL DEFAULT 'end_of_term'
    CHECK (downgrade_timing IN ('end_of_term', 'immediate')),
  prorate_credit boolean NOT NULL DEFAULT true,
  require_admin_approval boolean NOT NULL DEFAULT false,
  allow_same_package_renewal boolean NOT NULL DEFAULT true,
  tax_percent numeric(6,3) NOT NULL DEFAULT 0 CHECK (tax_percent >= 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.subscription_policy TO authenticated;
GRANT ALL ON public.subscription_policy TO service_role;
ALTER TABLE public.subscription_policy ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Authenticated read subscription policy" ON public.subscription_policy;
CREATE POLICY "Authenticated read subscription policy"
  ON public.subscription_policy FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "Admins manage subscription policy" ON public.subscription_policy;
CREATE POLICY "Admins manage subscription policy"
  ON public.subscription_policy FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP TRIGGER IF EXISTS set_subscription_policy_updated_at ON public.subscription_policy;
CREATE TRIGGER set_subscription_policy_updated_at BEFORE UPDATE ON public.subscription_policy
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

INSERT INTO public.subscription_policy (id) VALUES (true) ON CONFLICT (id) DO NOTHING;

-- ---- 4. Controlled status / change-type models -------------------------
DO $$ BEGIN
  CREATE TYPE public.package_change_status AS ENUM
    ('pending', 'awaiting_payment', 'scheduled', 'active', 'expired', 'cancelled', 'failed');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.package_change_type AS ENUM ('new', 'upgrade', 'downgrade', 'renewal');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- ---- 5. Package change requests ----------------------------------------
CREATE TABLE IF NOT EXISTS public.package_change_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  requested_by uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  old_package_id uuid REFERENCES public.packages(id),
  old_subscription_id uuid REFERENCES public.subscriptions(id),
  new_package_id uuid NOT NULL REFERENCES public.packages(id),
  change_type public.package_change_type NOT NULL,
  status public.package_change_status NOT NULL DEFAULT 'pending',
  effective_date timestamptz NOT NULL,
  currency text NOT NULL DEFAULT 'SAR',
  amount_before_credit numeric(12,2) NOT NULL DEFAULT 0 CHECK (amount_before_credit >= 0),
  discount numeric(12,2) NOT NULL DEFAULT 0 CHECK (discount >= 0),
  credit_applied numeric(12,2) NOT NULL DEFAULT 0 CHECK (credit_applied >= 0),
  amount_due numeric(12,2) NOT NULL DEFAULT 0 CHECK (amount_due >= 0),
  amount_paid numeric(12,2) NOT NULL DEFAULT 0 CHECK (amount_paid >= 0),
  payment_reference text,
  idempotency_key text NOT NULL,
  policy_snapshot jsonb NOT NULL DEFAULT '{}'::jsonb,
  package_snapshot jsonb NOT NULL DEFAULT '{}'::jsonb,
  activated_subscription_id uuid REFERENCES public.subscriptions(id),
  activated_at timestamptz,
  cancelled_at timestamptz,
  failure_reason text,
  requested_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS pcr_idempotency_key ON public.package_change_requests (idempotency_key);
CREATE UNIQUE INDEX IF NOT EXISTS pcr_payment_reference_key
  ON public.package_change_requests (payment_reference) WHERE payment_reference IS NOT NULL;
-- At most one unresolved change request per company.
CREATE UNIQUE INDEX IF NOT EXISTS pcr_one_open_per_user
  ON public.package_change_requests (user_id)
  WHERE status IN ('pending', 'awaiting_payment', 'scheduled');
CREATE INDEX IF NOT EXISTS pcr_user_created ON public.package_change_requests (user_id, created_at DESC);

GRANT SELECT, INSERT ON public.package_change_requests TO authenticated;
GRANT ALL ON public.package_change_requests TO service_role;
ALTER TABLE public.package_change_requests ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Companies read own change requests" ON public.package_change_requests;
CREATE POLICY "Companies read own change requests"
  ON public.package_change_requests FOR SELECT TO authenticated
  USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));

-- Companies may only file a request for themselves, in a non-activated state,
-- with no payment/activation fields pre-set from the browser.
DROP POLICY IF EXISTS "Companies create own change requests" ON public.package_change_requests;
CREATE POLICY "Companies create own change requests"
  ON public.package_change_requests FOR INSERT TO authenticated
  WITH CHECK (
    auth.uid() = user_id
    AND auth.uid() = requested_by
    AND status IN ('pending', 'awaiting_payment')
    AND amount_paid = 0
    AND payment_reference IS NULL
    AND activated_subscription_id IS NULL
    AND activated_at IS NULL
  );

DROP POLICY IF EXISTS "Admins manage change requests" ON public.package_change_requests;
CREATE POLICY "Admins manage change requests"
  ON public.package_change_requests FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP TRIGGER IF EXISTS set_pcr_updated_at ON public.package_change_requests;
CREATE TRIGGER set_pcr_updated_at BEFORE UPDATE ON public.package_change_requests
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ---- 6. Subscription commercial + code columns -------------------------
ALTER TABLE public.subscriptions ADD COLUMN IF NOT EXISTS package_code text;
ALTER TABLE public.subscriptions ADD COLUMN IF NOT EXISTS package_serial integer;
ALTER TABLE public.subscriptions ADD COLUMN IF NOT EXISTS change_type public.package_change_type;
ALTER TABLE public.subscriptions ADD COLUMN IF NOT EXISTS change_request_id uuid REFERENCES public.package_change_requests(id);
ALTER TABLE public.subscriptions ADD COLUMN IF NOT EXISTS discount numeric(12,2) NOT NULL DEFAULT 0;
ALTER TABLE public.subscriptions ADD COLUMN IF NOT EXISTS credit_applied numeric(12,2) NOT NULL DEFAULT 0;
ALTER TABLE public.subscriptions ADD COLUMN IF NOT EXISTS amount_due numeric(12,2) NOT NULL DEFAULT 0;
ALTER TABLE public.subscriptions ADD COLUMN IF NOT EXISTS outstanding_amount numeric(12,2) NOT NULL DEFAULT 0;
ALTER TABLE public.subscriptions ADD COLUMN IF NOT EXISTS payment_reference text;
ALTER TABLE public.subscriptions ADD COLUMN IF NOT EXISTS activated_at timestamptz;
ALTER TABLE public.subscriptions ADD COLUMN IF NOT EXISTS cancelled_at timestamptz;

CREATE UNIQUE INDEX IF NOT EXISTS subscriptions_package_code_key
  ON public.subscriptions (package_code) WHERE package_code IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS subscriptions_package_serial_key
  ON public.subscriptions (package_serial) WHERE package_serial IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS subscriptions_payment_reference_key
  ON public.subscriptions (payment_reference) WHERE payment_reference IS NOT NULL;
-- One active primary subscription per company.
CREATE UNIQUE INDEX IF NOT EXISTS subscriptions_one_active_per_user
  ON public.subscriptions (user_id) WHERE status = 'active';
CREATE INDEX IF NOT EXISTS subscriptions_user_started ON public.subscriptions (user_id, started_at DESC);

DO $$ BEGIN
  ALTER TABLE public.subscriptions ADD CONSTRAINT subscriptions_status_allowed
    CHECK (status IN ('pending','awaiting_payment','scheduled','active','expired','cancelled','failed'));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  ALTER TABLE public.subscriptions ADD CONSTRAINT subscriptions_amounts_non_negative
    CHECK (price_paid >= 0 AND discount >= 0 AND credit_applied >= 0
           AND amount_due >= 0 AND outstanding_amount >= 0);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  ALTER TABLE public.subscriptions ADD CONSTRAINT subscriptions_dates_ordered
    CHECK (expires_at IS NULL OR expires_at >= started_at);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- ---- 7. Dedicated, concurrency-safe package serial ---------------------
CREATE SEQUENCE IF NOT EXISTS public.package_serial_seq AS integer START 1;

CREATE OR REPLACE FUNCTION public.next_package_serial()
RETURNS integer LANGUAGE sql SECURITY DEFINER SET search_path = public AS $$
  SELECT nextval('public.package_serial_seq')::integer
$$;
REVOKE ALL ON FUNCTION public.next_package_serial() FROM PUBLIC, anon, authenticated;

-- ---- 8. Company code generator (server-side only) ---------------------
CREATE OR REPLACE FUNCTION public.assign_company_code(_user_id uuid)
RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  _existing text;
  _base text;
  _candidate text;
  _n integer := 0;
BEGIN
  SELECT company_code, upper(regexp_replace(coalesce(company_name, full_name, 'CMP'), '[^a-zA-Z]', '', 'g'))
    INTO _existing, _base
    FROM public.profiles WHERE id = _user_id FOR UPDATE;
  IF _existing IS NOT NULL THEN RETURN _existing; END IF;
  IF _base IS NULL OR length(_base) < 3 THEN
    _base := rpad(coalesce(nullif(_base, ''), 'CMP'), 3, 'X');
  END IF;
  _base := left(_base, 3);
  LOOP
    _candidate := CASE WHEN _n = 0 THEN _base ELSE _base || _n::text END;
    EXIT WHEN NOT EXISTS (SELECT 1 FROM public.profiles WHERE company_code = _candidate);
    _n := _n + 1;
  END LOOP;
  UPDATE public.profiles SET company_code = _candidate WHERE id = _user_id;
  RETURN _candidate;
END; $$;
REVOKE ALL ON FUNCTION public.assign_company_code(uuid) FROM PUBLIC, anon, authenticated;

-- ---- 9. Atomic, idempotent activation --------------------------------
CREATE OR REPLACE FUNCTION public.activate_package_change(
  _request_id uuid,
  _payment_reference text DEFAULT NULL,
  _amount_paid numeric DEFAULT 0,
  _actor uuid DEFAULT NULL
) RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  r public.package_change_requests;
  pkg public.packages;
  _company_code text;
  _serial integer;
  _code text;
  _start timestamptz;
  _end timestamptz;
  _status text;
  _sub_id uuid;
  _existing uuid;
  _snapshot jsonb;
BEGIN
  SELECT * INTO r FROM public.package_change_requests WHERE id = _request_id FOR UPDATE;
  IF r.id IS NULL THEN RAISE EXCEPTION 'request_not_found'; END IF;

  -- Idempotency: already activated, or this payment already activated something.
  IF r.activated_subscription_id IS NOT NULL THEN RETURN r.activated_subscription_id; END IF;
  IF _payment_reference IS NOT NULL THEN
    SELECT id INTO _existing FROM public.subscriptions WHERE payment_reference = _payment_reference;
    IF _existing IS NOT NULL THEN RETURN _existing; END IF;
  END IF;

  IF r.status NOT IN ('pending', 'awaiting_payment') THEN RAISE EXCEPTION 'request_not_activatable'; END IF;

  -- Payment amount validation against the backend-calculated amount due.
  IF r.amount_due > 0 AND coalesce(_amount_paid, 0) < r.amount_due THEN
    UPDATE public.package_change_requests
       SET status = 'failed', failure_reason = 'amount_mismatch', amount_paid = coalesce(_amount_paid, 0)
     WHERE id = r.id;
    RAISE EXCEPTION 'amount_mismatch';
  END IF;

  SELECT * INTO pkg FROM public.packages WHERE id = r.new_package_id;
  IF pkg.id IS NULL OR NOT pkg.is_active THEN RAISE EXCEPTION 'package_unavailable'; END IF;

  _start := greatest(now(), r.effective_date);
  _end := CASE WHEN pkg.duration_months IS NULL THEN NULL
               ELSE _start + (pkg.duration_months || ' months')::interval END;
  _status := CASE WHEN _start > now() + interval '1 minute' THEN 'scheduled' ELSE 'active' END;

  _company_code := public.assign_company_code(r.user_id);
  _serial := public.next_package_serial();
  _code := coalesce(pkg.code_prefix, upper(left(pkg.slug, 1))) || '-' || _company_code || '-'
           || to_char(_start, 'MMYY') || '-' || lpad(_serial::text, 4, '0');

  _snapshot := jsonb_build_object(
    'package_id', pkg.id, 'slug', pkg.slug, 'name_en', pkg.name_en, 'name_ar', pkg.name_ar,
    'price', pkg.price, 'promo_price', pkg.promo_price, 'currency', pkg.currency,
    'duration_months', pkg.duration_months, 'trial_enabled', pkg.trial_enabled,
    'trial_days', pkg.trial_days, 'rank', pkg.rank, 'code_prefix', pkg.code_prefix,
    'features', coalesce((SELECT jsonb_agg(to_jsonb(f)) FROM public.package_features f
                          WHERE f.package_id = pkg.id AND f.enabled), '[]'::jsonb),
    'policy', r.policy_snapshot
  );

  -- Close the current subscription only when the new one starts now.
  IF _status = 'active' THEN
    UPDATE public.subscriptions
       SET status = 'expired', expires_at = least(coalesce(expires_at, _start), _start)
     WHERE user_id = r.user_id AND status = 'active';
  END IF;

  INSERT INTO public.subscriptions (
    user_id, package_id, package_snapshot, price_paid, currency, is_trial,
    started_at, expires_at, status, package_code, package_serial, change_type,
    change_request_id, discount, credit_applied, amount_due, outstanding_amount,
    payment_reference, activated_at
  ) VALUES (
    r.user_id, pkg.id, _snapshot, coalesce(_amount_paid, 0), r.currency,
    (pkg.trial_enabled AND pkg.trial_days > 0 AND r.amount_due = 0),
    _start, _end, _status, _code, _serial, r.change_type,
    r.id, r.discount, r.credit_applied, r.amount_due,
    greatest(r.amount_due - coalesce(_amount_paid, 0), 0),
    _payment_reference, now()
  ) RETURNING id INTO _sub_id;

  UPDATE public.package_change_requests
     SET status = CASE WHEN _status = 'active' THEN 'active'::public.package_change_status
                       ELSE 'scheduled'::public.package_change_status END,
         amount_paid = coalesce(_amount_paid, 0),
         payment_reference = coalesce(_payment_reference, payment_reference),
         activated_subscription_id = _sub_id,
         activated_at = now()
   WHERE id = r.id;

  INSERT INTO public.package_audit_log (package_id, package_slug, admin_user_id, action, changes)
  VALUES (pkg.id, pkg.slug, _actor,
          CASE WHEN _status = 'active' THEN 'subscription_activated' ELSE 'subscription_scheduled' END,
          jsonb_build_object(
            'request_id', r.id, 'user_id', r.user_id, 'subscription_id', _sub_id,
            'package_code', _code, 'change_type', r.change_type,
            'amount_due', r.amount_due, 'amount_paid', coalesce(_amount_paid, 0),
            'credit_applied', r.credit_applied, 'started_at', _start, 'expires_at', _end));

  RETURN _sub_id;
END; $$;
REVOKE ALL ON FUNCTION public.activate_package_change(uuid, text, numeric, uuid) FROM PUBLIC, anon, authenticated;

-- ---- 10. Scheduled -> active / expiry maintenance --------------------
CREATE OR REPLACE FUNCTION public.roll_due_subscriptions()
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE n integer := 0;
BEGIN
  UPDATE public.subscriptions SET status = 'expired'
   WHERE status = 'active' AND expires_at IS NOT NULL AND expires_at <= now();

  UPDATE public.subscriptions s SET status = 'active'
   WHERE s.status = 'scheduled' AND s.started_at <= now()
     AND NOT EXISTS (SELECT 1 FROM public.subscriptions a
                      WHERE a.user_id = s.user_id AND a.status = 'active');
  GET DIAGNOSTICS n = ROW_COUNT;

  UPDATE public.package_change_requests r SET status = 'active'
   WHERE r.status = 'scheduled'
     AND EXISTS (SELECT 1 FROM public.subscriptions s
                  WHERE s.id = r.activated_subscription_id AND s.status = 'active');
  RETURN n;
END; $$;
REVOKE ALL ON FUNCTION public.roll_due_subscriptions() FROM PUBLIC, anon, authenticated;
