CREATE OR REPLACE FUNCTION public.platform_stats()
RETURNS jsonb
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT jsonb_build_object(
    'job_seekers', (SELECT count(*) FROM public.profiles WHERE account_type = 'job_seeker'),
    'companies',   (SELECT count(*) FROM public.profiles WHERE account_type = 'company'),
    'jobs',        (SELECT count(*) FROM public.job_postings WHERE status = 'published'),
    'hires',       (SELECT count(*) FROM public.job_applications WHERE status = 'hired'),
    'cvs',         (
      (
        SELECT count(*) FROM public.profiles
        WHERE account_type = 'job_seeker' AND cv_url IS NOT NULL
      )
      +
      (
        SELECT count(*) FROM public.external_candidates
        WHERE status != 'merged'
          AND cv_storage_path IS NOT NULL
          AND (
            email_norm IS NULL
            OR email_norm NOT IN (
              SELECT public.normalize_email(email)
              FROM public.profiles
              WHERE account_type = 'job_seeker' AND email IS NOT NULL
            )
          )
          AND (
            phone_norm IS NULL
            OR phone_norm NOT IN (
              SELECT public.normalize_phone(phone)
              FROM public.profiles
              WHERE account_type = 'job_seeker' AND phone IS NOT NULL
            )
          )
      )
    )
  )
$$;

GRANT EXECUTE ON FUNCTION public.platform_stats() TO anon, authenticated, service_role;