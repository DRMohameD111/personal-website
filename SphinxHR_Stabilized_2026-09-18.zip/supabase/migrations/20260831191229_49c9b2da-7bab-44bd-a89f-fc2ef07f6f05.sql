CREATE OR REPLACE FUNCTION public.activate_package_change(
  _request_id uuid,
  _payment_reference text DEFAULT NULL,
  _amount_paid numeric DEFAULT 0,
  _actor uuid DEFAULT NULL
) RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  r public.package_change_requests;
  pkg public.packages;
  _company_code text;
  _serial integer;
  _code text;
  _start timestamptz;
  _end timestamptz;
  _status text;
  _sub_id uuid;
  _existing uuid;
  _snapshot jsonb;
BEGIN
  SELECT * INTO r FROM public.package_change_requests WHERE id = _request_id FOR UPDATE;
  IF r.id IS NULL THEN RAISE EXCEPTION 'request_not_found'; END IF;

  IF r.activated_subscription_id IS NOT NULL THEN RETURN r.activated_subscription_id; END IF;
  IF _payment_reference IS NOT NULL THEN
    SELECT id INTO _existing FROM public.subscriptions WHERE payment_reference = _payment_reference;
    IF _existing IS NOT NULL THEN RETURN _existing; END IF;
  END IF;

  IF r.status NOT IN ('pending', 'awaiting_payment') THEN RAISE EXCEPTION 'request_not_activatable'; END IF;

  -- Payment amount validation. The failure is RECORDED (not raised) so that the
  -- request cannot silently stay open and be retried into an activation.
  IF r.amount_due > 0 AND coalesce(_amount_paid, 0) < r.amount_due THEN
    UPDATE public.package_change_requests
       SET status = 'failed', failure_reason = 'amount_mismatch',
           amount_paid = coalesce(_amount_paid, 0),
           payment_reference = coalesce(_payment_reference, payment_reference)
     WHERE id = r.id;
    INSERT INTO public.package_audit_log (package_id, admin_user_id, action, changes)
    VALUES (r.new_package_id, _actor, 'payment_amount_mismatch',
            jsonb_build_object('request_id', r.id, 'user_id', r.user_id,
                               'amount_due', r.amount_due, 'amount_paid', coalesce(_amount_paid, 0),
                               'payment_reference', _payment_reference));
    RETURN NULL;
  END IF;

  SELECT * INTO pkg FROM public.packages WHERE id = r.new_package_id;
  IF pkg.id IS NULL OR NOT pkg.is_active THEN RAISE EXCEPTION 'package_unavailable'; END IF;

  _start := greatest(now(), r.effective_date);
  _end := CASE WHEN pkg.duration_months IS NULL THEN NULL
               ELSE _start + (pkg.duration_months || ' months')::interval END;
  _status := CASE WHEN _start > now() + interval '1 minute' THEN 'scheduled' ELSE 'active' END;

  _company_code := public.assign_company_code(r.user_id);
  _serial := public.next_package_serial();
  _code := coalesce(pkg.code_prefix, upper(left(pkg.slug, 1))) || '-' || _company_code || '-'
           || to_char(_start, 'MMYY') || '-' || lpad(_serial::text, 4, '0');

  _snapshot := jsonb_build_object(
    'package_id', pkg.id, 'slug', pkg.slug, 'name_en', pkg.name_en, 'name_ar', pkg.name_ar,
    'price', pkg.price, 'promo_price', pkg.promo_price, 'currency', pkg.currency,
    'duration_months', pkg.duration_months, 'trial_enabled', pkg.trial_enabled,
    'trial_days', pkg.trial_days, 'rank', pkg.rank, 'code_prefix', pkg.code_prefix,
    'features', coalesce((SELECT jsonb_agg(to_jsonb(f)) FROM public.package_features f
                          WHERE f.package_id = pkg.id AND f.enabled), '[]'::jsonb),
    'policy', r.policy_snapshot
  );

  IF _status = 'active' THEN
    UPDATE public.subscriptions
       SET status = 'expired', expires_at = least(coalesce(expires_at, _start), _start)
     WHERE user_id = r.user_id AND status = 'active';
  END IF;

  INSERT INTO public.subscriptions (
    user_id, package_id, package_snapshot, price_paid, currency, is_trial,
    started_at, expires_at, status, package_code, package_serial, change_type,
    change_request_id, discount, credit_applied, amount_due, outstanding_amount,
    payment_reference, activated_at
  ) VALUES (
    r.user_id, pkg.id, _snapshot, coalesce(_amount_paid, 0), r.currency,
    (pkg.trial_enabled AND pkg.trial_days > 0 AND r.amount_due = 0),
    _start, _end, _status, _code, _serial, r.change_type,
    r.id, r.discount, r.credit_applied, r.amount_due,
    greatest(r.amount_due - coalesce(_amount_paid, 0), 0),
    _payment_reference, now()
  ) RETURNING id INTO _sub_id;

  UPDATE public.package_change_requests
     SET status = CASE WHEN _status = 'active' THEN 'active'::public.package_change_status
                       ELSE 'scheduled'::public.package_change_status END,
         amount_paid = coalesce(_amount_paid, 0),
         payment_reference = coalesce(_payment_reference, payment_reference),
         activated_subscription_id = _sub_id,
         activated_at = now()
   WHERE id = r.id;

  INSERT INTO public.package_audit_log (package_id, package_slug, admin_user_id, action, changes)
  VALUES (pkg.id, pkg.slug, _actor,
          CASE WHEN _status = 'active' THEN 'subscription_activated' ELSE 'subscription_scheduled' END,
          jsonb_build_object(
            'request_id', r.id, 'user_id', r.user_id, 'subscription_id', _sub_id,
            'package_code', _code, 'change_type', r.change_type,
            'amount_due', r.amount_due, 'amount_paid', coalesce(_amount_paid, 0),
            'credit_applied', r.credit_applied, 'started_at', _start, 'expires_at', _end));

  RETURN _sub_id;
END; $$;
REVOKE ALL ON FUNCTION public.activate_package_change(uuid, text, numeric, uuid) FROM PUBLIC, anon, authenticated;
