REVOKE EXECUTE ON FUNCTION public.close_expired_job_postings() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.roll_due_subscriptions() FROM PUBLIC, anon, authenticated;