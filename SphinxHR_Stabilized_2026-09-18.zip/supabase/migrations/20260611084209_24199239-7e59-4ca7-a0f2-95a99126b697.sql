
DO $$ BEGIN
  CREATE TYPE public.application_status AS ENUM ('submitted','cv_sent','employer_reviewed','shortlisted','rejected','hired');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS nationality text,
  ADD COLUMN IF NOT EXISTS profession text,
  ADD COLUMN IF NOT EXISTS sector text,
  ADD COLUMN IF NOT EXISTS education text,
  ADD COLUMN IF NOT EXISTS languages text,
  ADD COLUMN IF NOT EXISTS cv_url text,
  ADD COLUMN IF NOT EXISTS cv_uploaded_at timestamptz;

CREATE TABLE IF NOT EXISTS public.job_applications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  candidate_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  employer_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  job_posting_id uuid REFERENCES public.job_postings(id) ON DELETE SET NULL,
  external_job_id text,
  job_snapshot jsonb NOT NULL DEFAULT '{}'::jsonb,
  candidate_snapshot jsonb NOT NULL DEFAULT '{}'::jsonb,
  cv_url text,
  status public.application_status NOT NULL DEFAULT 'submitted',
  status_history jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.job_applications TO authenticated;
GRANT ALL ON public.job_applications TO service_role;
ALTER TABLE public.job_applications ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "View own or employer applications" ON public.job_applications;
CREATE POLICY "View own or employer applications" ON public.job_applications
  FOR SELECT TO authenticated USING (auth.uid() = candidate_id OR auth.uid() = employer_id);

DROP POLICY IF EXISTS "Candidate creates application" ON public.job_applications;
CREATE POLICY "Candidate creates application" ON public.job_applications
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = candidate_id);

DROP POLICY IF EXISTS "Employer updates application" ON public.job_applications;
CREATE POLICY "Employer updates application" ON public.job_applications
  FOR UPDATE TO authenticated USING (auth.uid() = employer_id) WITH CHECK (auth.uid() = employer_id);

DROP TRIGGER IF EXISTS set_job_applications_updated_at ON public.job_applications;
CREATE TRIGGER set_job_applications_updated_at BEFORE UPDATE ON public.job_applications
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE IF NOT EXISTS public.app_notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  type text NOT NULL,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  read_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.app_notifications TO authenticated;
GRANT ALL ON public.app_notifications TO service_role;
ALTER TABLE public.app_notifications ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Own notifications" ON public.app_notifications;
CREATE POLICY "Own notifications" ON public.app_notifications
  FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
