CREATE POLICY "Own photo read" ON storage.objects FOR SELECT TO authenticated
USING (
  bucket_id = 'candidate-media'
  AND (storage.foldername(name))[1] = auth.uid()::text
);

CREATE POLICY "Own photo insert" ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
  bucket_id = 'candidate-media'
  AND (storage.foldername(name))[1] = auth.uid()::text
  AND (storage.filename(name)) LIKE 'photo-%'
);

CREATE POLICY "Own photo update" ON storage.objects FOR UPDATE TO authenticated
USING (
  bucket_id = 'candidate-media'
  AND (storage.foldername(name))[1] = auth.uid()::text
  AND (storage.filename(name)) LIKE 'photo-%'
)
WITH CHECK (
  bucket_id = 'candidate-media'
  AND (storage.foldername(name))[1] = auth.uid()::text
  AND (storage.filename(name)) LIKE 'photo-%'
);

CREATE POLICY "Own photo delete" ON storage.objects FOR DELETE TO authenticated
USING (
  bucket_id = 'candidate-media'
  AND (storage.foldername(name))[1] = auth.uid()::text
  AND (storage.filename(name)) LIKE 'photo-%'
);

CREATE POLICY "Admins manage candidate media" ON storage.objects FOR ALL TO authenticated
USING (bucket_id = 'candidate-media' AND public.has_role(auth.uid(), 'admin'))
WITH CHECK (bucket_id = 'candidate-media' AND public.has_role(auth.uid(), 'admin'));