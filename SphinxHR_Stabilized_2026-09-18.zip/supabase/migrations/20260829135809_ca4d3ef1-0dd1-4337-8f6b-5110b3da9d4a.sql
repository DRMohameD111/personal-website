CREATE TYPE public.client_legal_structure AS ENUM ('joint_stock','limited_partnership','general_partnership','sole_proprietorship');
CREATE TYPE public.manpower_request_status AS ENUM ('draft','submitted','in_progress','fulfilled','cancelled');

CREATE TABLE public.clients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  client_code text,
  name text NOT NULL,
  nature_of_business text NOT NULL,
  nature_of_business_other text,
  nationality_code text NOT NULL,
  legal_structure public.client_legal_structure NOT NULL,
  hq_country_code text NOT NULL,
  hq_city text,
  branches_count text NOT NULL,
  official_email text NOT NULL,
  website text,
  cr_number text,
  contact_person text,
  contact_phone text,
  notes text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.clients TO authenticated;
GRANT ALL ON public.clients TO service_role;
ALTER TABLE public.clients ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Own clients" ON public.clients FOR ALL TO authenticated USING (auth.uid() = owner_id) WITH CHECK (auth.uid() = owner_id);

CREATE UNIQUE INDEX clients_owner_email_key ON public.clients (owner_id, lower(official_email));
CREATE INDEX clients_owner_idx ON public.clients (owner_id, created_at DESC);
CREATE TRIGGER set_clients_updated_at BEFORE UPDATE ON public.clients FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.manpower_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  client_id uuid NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  job_category text NOT NULL,
  required_quantity integer NOT NULL DEFAULT 1,
  nationality_required text,
  salary_range text,
  work_location text,
  contract_duration text,
  required_experience text,
  notes text,
  status public.manpower_request_status NOT NULL DEFAULT 'submitted',
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.manpower_requests TO authenticated;
GRANT ALL ON public.manpower_requests TO service_role;
ALTER TABLE public.manpower_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Own manpower requests" ON public.manpower_requests FOR ALL TO authenticated USING (auth.uid() = owner_id) WITH CHECK (auth.uid() = owner_id);

CREATE INDEX manpower_requests_owner_idx ON public.manpower_requests (owner_id, created_at DESC);
CREATE TRIGGER set_manpower_requests_updated_at BEFORE UPDATE ON public.manpower_requests FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();