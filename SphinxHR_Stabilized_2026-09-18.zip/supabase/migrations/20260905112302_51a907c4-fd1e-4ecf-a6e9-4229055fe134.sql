-- normalization helpers ------------------------------------------------------
CREATE OR REPLACE FUNCTION public.normalize_email(_v text)
RETURNS text LANGUAGE sql IMMUTABLE SET search_path = public AS $$
  SELECT nullif(lower(btrim(coalesce(_v, ''))), '')
$$;

CREATE OR REPLACE FUNCTION public.normalize_phone(_v text)
RETURNS text LANGUAGE sql IMMUTABLE SET search_path = public AS $$
  SELECT nullif(regexp_replace(regexp_replace(coalesce(_v, ''), '[^0-9]', '', 'g'), '^0+', ''), '')
$$;

-- profiles source flag (reused single candidate structure) --------------------
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS candidate_source text NOT NULL DEFAULT 'registered';

-- imported external CVs ------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.external_candidates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  candidate_source text NOT NULL DEFAULT 'external_cv',
  status text NOT NULL DEFAULT 'active',
  full_name text,
  email text,
  phone text,
  email_norm text GENERATED ALWAYS AS (public.normalize_email(email)) STORED,
  phone_norm text GENERATED ALWAYS AS (public.normalize_phone(phone)) STORED,
  nationality text,
  location text,
  job_title text,
  career_level text,
  experience_years numeric,
  experience_text text,
  education text,
  skills text[] NOT NULL DEFAULT '{}',
  languages text[] NOT NULL DEFAULT '{}',
  certifications text[] NOT NULL DEFAULT '{}',
  cv_storage_path text,
  cv_file_name text,
  extract_notes jsonb NOT NULL DEFAULT '{}'::jsonb,
  imported_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  source_updated_at timestamptz NOT NULL DEFAULT now(),
  merged_profile_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  merged_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS external_candidates_email_uq
  ON public.external_candidates (email_norm) WHERE email_norm IS NOT NULL AND status = 'active';
CREATE UNIQUE INDEX IF NOT EXISTS external_candidates_phone_uq
  ON public.external_candidates (phone_norm) WHERE phone_norm IS NOT NULL AND status = 'active';
CREATE INDEX IF NOT EXISTS external_candidates_status_idx ON public.external_candidates (status);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.external_candidates TO authenticated;
GRANT ALL ON public.external_candidates TO service_role;
ALTER TABLE public.external_candidates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins manage imported CVs" ON public.external_candidates
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER set_external_candidates_updated_at
  BEFORE UPDATE ON public.external_candidates
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- merge audit ----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.candidate_merge_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  external_candidate_id uuid,
  profile_id uuid,
  matched_on text,
  changes jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.candidate_merge_log TO authenticated;
GRANT ALL ON public.candidate_merge_log TO service_role;
ALTER TABLE public.candidate_merge_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins read merge audit" ON public.candidate_merge_log
  FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

-- CV access usage ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.cv_access_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  profile_id uuid,
  external_candidate_id uuid,
  job_posting_id uuid REFERENCES public.job_postings(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS cv_access_log_company_idx ON public.cv_access_log (company_id, created_at DESC);

GRANT SELECT ON public.cv_access_log TO authenticated;
GRANT ALL ON public.cv_access_log TO service_role;
ALTER TABLE public.cv_access_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Companies read their own CV access history" ON public.cv_access_log
  FOR SELECT TO authenticated
  USING (company_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));

-- merge imported CVs into a registered job seeker -----------------------------
CREATE OR REPLACE FUNCTION public.merge_external_candidates(_user_id uuid)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  p public.profiles;
  ec public.external_candidates;
  n integer := 0;
  _matched text;
  _changes jsonb;
BEGIN
  SELECT * INTO p FROM public.profiles WHERE id = _user_id;
  IF p.id IS NULL OR p.account_type <> 'job_seeker' THEN RETURN 0; END IF;

  FOR ec IN
    SELECT * FROM public.external_candidates
     WHERE status = 'active'
       AND merged_profile_id IS NULL
       AND (
         (email_norm IS NOT NULL AND email_norm = public.normalize_email(p.email))
         OR (phone_norm IS NOT NULL AND phone_norm = public.normalize_phone(p.phone))
       )
     ORDER BY source_updated_at DESC
  LOOP
    _matched := CASE
      WHEN ec.email_norm IS NOT NULL AND ec.email_norm = public.normalize_email(p.email) THEN 'email'
      ELSE 'phone' END;

    -- registered / user-confirmed data always wins: only fill empty fields
    UPDATE public.profiles SET
      full_name   = coalesce(nullif(btrim(coalesce(full_name, '')), ''), ec.full_name),
      phone       = coalesce(nullif(btrim(coalesce(phone, '')), ''), ec.phone),
      nationality = coalesce(nullif(btrim(coalesce(nationality, '')), ''), ec.nationality),
      country     = coalesce(nullif(btrim(coalesce(country, '')), ''), ec.location),
      profession  = coalesce(nullif(btrim(coalesce(profession, '')), ''), ec.job_title),
      education   = coalesce(nullif(btrim(coalesce(education, '')), ''), ec.education),
      languages   = coalesce(nullif(btrim(coalesce(languages, '')), ''), array_to_string(ec.languages, ', ')),
      cv_url      = coalesce(cv_url, ec.cv_storage_path),
      cv_uploaded_at = CASE WHEN cv_url IS NULL AND ec.cv_storage_path IS NOT NULL
                            THEN coalesce(cv_uploaded_at, ec.source_updated_at) ELSE cv_uploaded_at END,
      candidate_source = 'registered'
    WHERE id = _user_id
    RETURNING * INTO p;

    UPDATE public.external_candidates
       SET status = 'merged', merged_profile_id = _user_id, merged_at = now()
     WHERE id = ec.id;

    _changes := jsonb_build_object(
      'external_candidate', jsonb_build_object('email', ec.email, 'phone', ec.phone,
        'job_title', ec.job_title, 'cv_storage_path', ec.cv_storage_path),
      'profile_after', jsonb_build_object('profession', p.profession, 'cv_url', p.cv_url));

    INSERT INTO public.candidate_merge_log (external_candidate_id, profile_id, matched_on, changes)
    VALUES (ec.id, _user_id, _matched, _changes);

    n := n + 1;
  END LOOP;

  RETURN n;
END; $$;

REVOKE ALL ON FUNCTION public.merge_external_candidates(uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.merge_external_candidates(uuid) TO service_role;