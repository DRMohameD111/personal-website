ALTER TYPE public.account_type RENAME VALUE 'individual' TO 'job_seeker';
ALTER TYPE public.app_role RENAME VALUE 'individual' TO 'job_seeker';

CREATE OR REPLACE FUNCTION public.handle_new_user()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  _raw text;
  _account_type public.account_type;
BEGIN
  _raw := COALESCE(NEW.raw_user_meta_data->>'account_type', 'job_seeker');
  IF _raw NOT IN ('job_seeker', 'company') THEN
    _raw := 'job_seeker';
  END IF;
  _account_type := _raw::public.account_type;

  INSERT INTO public.profiles (id, account_type, full_name, company_name, phone, country, email)
  VALUES (
    NEW.id,
    _account_type,
    NEW.raw_user_meta_data->>'full_name',
    NEW.raw_user_meta_data->>'company_name',
    NEW.raw_user_meta_data->>'phone',
    NEW.raw_user_meta_data->>'country',
    NEW.email
  );

  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, _account_type::text::public.app_role)
  ON CONFLICT DO NOTHING;

  RETURN NEW;
END; $function$;