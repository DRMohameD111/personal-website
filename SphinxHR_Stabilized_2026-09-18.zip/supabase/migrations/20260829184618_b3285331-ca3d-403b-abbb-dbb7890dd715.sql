-- Ensure the singleton valuation config row exists
INSERT INTO public.valuation_config (id) VALUES (true) ON CONFLICT (id) DO NOTHING;

-- Admin management of the valuation configuration
CREATE POLICY "Admins manage valuation config"
ON public.valuation_config FOR ALL TO authenticated
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Admin management of salary benchmarks
CREATE POLICY "Admins manage salary benchmarks"
ON public.salary_benchmarks FOR ALL TO authenticated
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

GRANT SELECT, INSERT, UPDATE, DELETE ON public.valuation_config TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.salary_benchmarks TO authenticated;
GRANT ALL ON public.valuation_config TO service_role;
GRANT ALL ON public.salary_benchmarks TO service_role;