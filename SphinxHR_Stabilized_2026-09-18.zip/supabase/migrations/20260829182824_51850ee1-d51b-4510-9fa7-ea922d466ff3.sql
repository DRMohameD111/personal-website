-- 1) Job posting statuses: add Draft + Archived to the existing enum
ALTER TYPE public.job_posting_status ADD VALUE IF NOT EXISTS 'draft';
ALTER TYPE public.job_posting_status ADD VALUE IF NOT EXISTS 'archived';

-- 2) Publication / closing dates on the existing job_postings table
ALTER TABLE public.job_postings
  ADD COLUMN IF NOT EXISTS published_at timestamptz,
  ADD COLUMN IF NOT EXISTS closes_at timestamptz,
  ADD COLUMN IF NOT EXISTS closed_at timestamptz;

UPDATE public.job_postings
   SET published_at = COALESCE(published_at, created_at)
 WHERE published_at IS NULL;

UPDATE public.job_postings
   SET closes_at = published_at + interval '1 month'
 WHERE closes_at IS NULL AND published_at IS NOT NULL;

CREATE OR REPLACE FUNCTION public.set_job_posting_dates()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  IF NEW.status = 'published' AND NEW.published_at IS NULL THEN
    NEW.published_at := now();
  END IF;
  IF NEW.published_at IS NOT NULL AND NEW.closes_at IS NULL THEN
    NEW.closes_at := NEW.published_at + interval '1 month';
  END IF;
  IF NEW.status = 'closed' AND NEW.closed_at IS NULL THEN
    NEW.closed_at := now();
  END IF;
  IF NEW.status <> 'closed' THEN
    NEW.closed_at := NULL;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS job_postings_set_dates ON public.job_postings;
CREATE TRIGGER job_postings_set_dates
BEFORE INSERT OR UPDATE ON public.job_postings
FOR EACH ROW EXECUTE FUNCTION public.set_job_posting_dates();

-- 3) Backend routine that closes expired jobs (called by the scheduler)
CREATE OR REPLACE FUNCTION public.close_expired_job_postings()
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE n integer;
BEGIN
  UPDATE public.job_postings
     SET status = 'closed'
   WHERE status IN ('published', 'paused')
     AND closes_at IS NOT NULL
     AND closes_at <= now();
  GET DIAGNOSTICS n = ROW_COUNT;
  RETURN n;
END;
$$;

REVOKE ALL ON FUNCTION public.close_expired_job_postings() FROM anon, authenticated;
GRANT EXECUTE ON FUNCTION public.close_expired_job_postings() TO service_role;

-- 4) Company evaluation inputs on the existing profiles table (admin controlled)
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS portal_valuation smallint NOT NULL DEFAULT 3,
  ADD COLUMN IF NOT EXISTS company_type smallint NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS branches_count integer NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS branches_verified boolean NOT NULL DEFAULT false;

ALTER TABLE public.profiles
  ADD CONSTRAINT profiles_portal_valuation_range CHECK (portal_valuation BETWEEN 1 AND 5),
  ADD CONSTRAINT profiles_company_type_range CHECK (company_type BETWEEN 1 AND 3),
  ADD CONSTRAINT profiles_branches_count_range CHECK (branches_count BETWEEN 0 AND 100000);

-- Companies may only edit their own descriptive fields, never evaluation fields
REVOKE UPDATE ON public.profiles FROM authenticated;
GRANT UPDATE (full_name, company_name, phone, country, email, nationality,
              profession, sector, education, languages, cv_url, cv_uploaded_at,
              updated_at) ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;

-- 5) Salary benchmarks (admin maintained, publicly readable)
CREATE TABLE IF NOT EXISTS public.salary_benchmarks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_category text NOT NULL,
  sector text,
  career_level text,
  country text,
  currency text NOT NULL DEFAULT 'SAR',
  benchmark_amount numeric NOT NULL,
  salary_period text NOT NULL DEFAULT 'monthly',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.salary_benchmarks TO anon, authenticated;
GRANT ALL ON public.salary_benchmarks TO service_role;
ALTER TABLE public.salary_benchmarks ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Read salary benchmarks" ON public.salary_benchmarks;
CREATE POLICY "Read salary benchmarks" ON public.salary_benchmarks
  FOR SELECT TO anon, authenticated USING (true);

DROP TRIGGER IF EXISTS set_salary_benchmarks_updated_at ON public.salary_benchmarks;
CREATE TRIGGER set_salary_benchmarks_updated_at
BEFORE UPDATE ON public.salary_benchmarks
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- 6) Valuation configuration (single row, admin maintained)
CREATE TABLE IF NOT EXISTS public.valuation_config (
  id boolean PRIMARY KEY DEFAULT true CHECK (id),
  salary_weight numeric NOT NULL DEFAULT 0.60,
  company_weight numeric NOT NULL DEFAULT 0.40,
  excellent_threshold numeric NOT NULL DEFAULT 85,
  very_good_threshold numeric NOT NULL DEFAULT 70,
  show_applicant_count_public boolean NOT NULL DEFAULT false,
  show_portal_valuation_public boolean NOT NULL DEFAULT false,
  default_benchmark_amount numeric NOT NULL DEFAULT 12000,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.valuation_config TO anon, authenticated;
GRANT ALL ON public.valuation_config TO service_role;
ALTER TABLE public.valuation_config ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Read valuation config" ON public.valuation_config;
CREATE POLICY "Read valuation config" ON public.valuation_config
  FOR SELECT TO anon, authenticated USING (true);

DROP TRIGGER IF EXISTS set_valuation_config_updated_at ON public.valuation_config;
CREATE TRIGGER set_valuation_config_updated_at
BEFORE UPDATE ON public.valuation_config
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

INSERT INTO public.valuation_config (id) VALUES (true) ON CONFLICT (id) DO NOTHING;

-- 7) Safe per-job listing meta: real applicant count + company evaluation inputs
CREATE OR REPLACE FUNCTION public.job_listing_meta()
RETURNS TABLE (
  job_posting_id uuid,
  applicant_count integer,
  portal_valuation smallint,
  company_type smallint,
  branches_count integer,
  published_at timestamptz,
  closes_at timestamptz,
  status text
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT jp.id,
         (SELECT count(*)::int FROM public.job_applications ja WHERE ja.job_posting_id = jp.id),
         p.portal_valuation,
         p.company_type,
         p.branches_count,
         jp.published_at,
         jp.closes_at,
         jp.status::text
    FROM public.job_postings jp
    LEFT JOIN public.profiles p ON p.id = jp.user_id
$$;

GRANT EXECUTE ON FUNCTION public.job_listing_meta() TO anon, authenticated;