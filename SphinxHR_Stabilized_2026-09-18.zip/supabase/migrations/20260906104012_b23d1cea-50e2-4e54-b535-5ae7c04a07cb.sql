CREATE OR REPLACE FUNCTION public.merge_external_candidates(_user_id uuid)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  p public.profiles;
  ec public.external_candidates;
  n integer := 0;
  _matched text;
  _changes jsonb;
BEGIN
  SELECT * INTO p FROM public.profiles WHERE id = _user_id;
  IF p.id IS NULL OR p.account_type <> 'job_seeker' THEN RETURN 0; END IF;

  FOR ec IN
    SELECT * FROM public.external_candidates
     WHERE status = 'active'
       AND merged_profile_id IS NULL
       AND (
         (email_norm IS NOT NULL AND email_norm = public.normalize_email(p.email))
         OR (phone_norm IS NOT NULL AND phone_norm = public.normalize_phone(p.phone))
       )
     ORDER BY source_updated_at DESC
  LOOP
    _matched := CASE
      WHEN ec.email_norm IS NOT NULL AND ec.email_norm = public.normalize_email(p.email) THEN 'email'
      ELSE 'phone' END;

    UPDATE public.profiles SET
      full_name   = coalesce(nullif(btrim(coalesce(full_name, '')), ''), ec.full_name),
      phone       = coalesce(nullif(btrim(coalesce(phone, '')), ''), ec.phone),
      nationality = coalesce(nullif(btrim(coalesce(nationality, '')), ''), ec.nationality),
      country     = coalesce(nullif(btrim(coalesce(country, '')), ''), ec.location),
      profession  = coalesce(nullif(btrim(coalesce(profession, '')), ''), ec.job_title),
      education   = coalesce(nullif(btrim(coalesce(education, '')), ''), ec.education),
      languages   = coalesce(nullif(btrim(coalesce(languages, '')), ''), array_to_string(ec.languages, ', ')),
      cv_url      = coalesce(cv_url, ec.cv_storage_path),
      cv_uploaded_at = CASE WHEN cv_url IS NULL AND ec.cv_storage_path IS NOT NULL
                            THEN coalesce(cv_uploaded_at, ec.source_updated_at) ELSE cv_uploaded_at END,
      -- admin verification must survive a merge
      candidate_source = CASE WHEN candidate_source = 'verified' THEN 'verified' ELSE 'registered' END
    WHERE id = _user_id
    RETURNING * INTO p;

    UPDATE public.external_candidates
       SET status = 'merged', merged_profile_id = _user_id, merged_at = now()
     WHERE id = ec.id;

    _changes := jsonb_build_object(
      'external_candidate', jsonb_build_object('email', ec.email, 'phone', ec.phone,
        'job_title', ec.job_title, 'cv_storage_path', ec.cv_storage_path),
      'profile_after', jsonb_build_object('profession', p.profession, 'cv_url', p.cv_url));

    INSERT INTO public.candidate_merge_log (external_candidate_id, profile_id, matched_on, changes)
    VALUES (ec.id, _user_id, _matched, _changes);

    n := n + 1;
  END LOOP;

  RETURN n;
END; $$;

REVOKE ALL ON FUNCTION public.merge_external_candidates(uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.merge_external_candidates(uuid) TO service_role;