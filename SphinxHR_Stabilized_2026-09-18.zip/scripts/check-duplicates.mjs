#!/usr/bin/env node
/**
 * Pre-flight duplicate check / فحص تلقائي قبل إنشاء أو تعديل أي صفحة أو جدول أو دالة.
 *
 * Enforces the project rule: reuse and extend what already exists instead of
 * creating a second page, route, component, server function, type/enum,
 * validation schema, translation key, table or column.
 *
 * Usage:
 *   bun run check:duplicates            # full report, exits 1 on duplicates
 *   bun run check:duplicates --json     # machine readable
 *   bun run check:duplicates --find auth login profile   # "does this already exist?" lookup
 */
import { readdirSync, readFileSync, statSync, existsSync } from "node:fs";
import { join, relative, basename, extname } from "node:path";

const ROOT = process.cwd();
const SRC = join(ROOT, "src");
const MIGRATIONS = join(ROOT, "supabase", "migrations");
const IGNORED_DIRS = new Set(["node_modules", "dist", ".git", ".output", ".vite", "coverage"]);
// Generated or intentionally-shared files that legitimately repeat names.
const IGNORED_FILES = [
  /routeTree\.gen\.ts$/,
  /integrations\/supabase\/types\.ts$/,
  /\.test\.tsx?$/,
];
// shadcn/ui primitives are a vendored design system: same-name exports are expected.
const VENDOR_DIRS = [/src\/components\/ui\//];

function walk(dir, out = []) {
  if (!existsSync(dir)) return out;
  for (const entry of readdirSync(dir)) {
    if (IGNORED_DIRS.has(entry)) continue;
    const full = join(dir, entry);
    if (statSync(full).isDirectory()) walk(full, out);
    else out.push(full);
  }
  return out;
}

const rel = (f) => relative(ROOT, f).replaceAll("\\", "/");
const isIgnored = (f) => IGNORED_FILES.some((r) => r.test(rel(f)));
const isVendor = (f) => VENDOR_DIRS.some((r) => r.test(rel(f)));

const codeFiles = walk(SRC)
  .filter((f) => [".ts", ".tsx"].includes(extname(f)))
  .filter((f) => !isIgnored(f));

const sources = new Map(codeFiles.map((f) => [f, readFileSync(f, "utf8")]));
const migrations = walk(MIGRATIONS)
  .filter((f) => f.endsWith(".sql"))
  .sort();

/** collect(map, key, file) */
function collect(map, key, file) {
  if (!key) return;
  const list = map.get(key) ?? [];
  if (!list.includes(rel(file))) list.push(rel(file));
  map.set(key, list);
}

const findings = [];
const add = (kind, key, files, hint) => findings.push({ kind, key, files, hint });

/* 1. Duplicate route paths -------------------------------------------------- */
const routes = new Map();
for (const [file, code] of sources) {
  if (!rel(file).startsWith("src/routes/")) continue;
  for (const m of code.matchAll(/createFileRoute\(\s*["'`]([^"'`]+)["'`]\s*\)/g)) {
    collect(routes, m[1], file);
  }
}
for (const [path, files] of routes) {
  if (files.length > 1) {
    add(
      "route",
      path,
      files,
      "Two files claim the same route path. Keep one and delete the other.",
    );
  }
}

/* 2. Duplicate top-level exported symbols ----------------------------------- */
const EXPORT_RE =
  /^export\s+(?:async\s+)?(?:const|let|function|class|type|interface|enum)\s+([A-Za-z_$][\w$]*)/gm;
const exports_ = new Map();
for (const [file, code] of sources) {
  if (isVendor(file)) continue;
  for (const m of code.matchAll(EXPORT_RE)) collect(exports_, m[1], file);
}
const GENERIC_NAMES = new Set(["Route", "default", "Component", "loader", "meta", "head"]);
for (const [name, files] of exports_) {
  if (files.length > 1 && !GENERIC_NAMES.has(name)) {
    add(
      "export",
      name,
      files,
      "Same exported name defined in several modules — import the existing one instead of redeclaring it.",
    );
  }
}

/* 3. Duplicate server functions --------------------------------------------- */
const serverFns = new Map();
for (const [file, code] of sources) {
  for (const m of code.matchAll(/export\s+const\s+([A-Za-z_$][\w$]*)\s*=\s*createServerFn/g)) {
    collect(serverFns, m[1], file);
  }
}
for (const [name, files] of serverFns) {
  if (files.length > 1) {
    add("server-function", name, files, "Duplicate server function — extend the existing one.");
  }
}

/* 4. Duplicate component / module basenames --------------------------------- */
const basenames = new Map();
for (const file of codeFiles) {
  if (isVendor(file)) continue;
  if (rel(file).startsWith("src/routes/")) continue; // route files are path-scoped
  const base = basename(file, extname(file)).toLowerCase();
  if (base === "index") continue; // barrel modules legitimately repeat
  collect(basenames, base, file);
}
for (const [name, files] of basenames) {
  if (files.length > 1) {
    add("filename", name, files, "Two modules share a name — likely a copied component or helper.");
  }
}

/* 5. Migrations: repeated CREATE TABLE / duplicate columns ------------------- */
const createdTables = new Map();
const columns = new Map();
const enums = new Map();
for (const file of migrations) {
  const sql = readFileSync(file, "utf8");
  for (const m of sql.matchAll(
    /create\s+table\s+(?:if\s+not\s+exists\s+)?(?:public\.)?"?([a-z0-9_]+)"?/gi,
  )) {
    collect(createdTables, m[1].toLowerCase(), file);
  }
  for (const m of sql.matchAll(
    /alter\s+table\s+(?:only\s+)?(?:public\.)?"?([a-z0-9_]+)"?\s+add\s+column\s+(?:if\s+not\s+exists\s+)?"?([a-z0-9_]+)"?/gi,
  )) {
    collect(columns, `${m[1].toLowerCase()}.${m[2].toLowerCase()}`, file);
  }
  for (const m of sql.matchAll(/create\s+type\s+(?:public\.)?"?([a-z0-9_]+)"?\s+as\s+enum/gi)) {
    collect(enums, m[1].toLowerCase(), file);
  }
  for (const m of sql.matchAll(/\b(drop\s+table|truncate|delete\s+from)\b/gi)) {
    findings.push({
      kind: "destructive-sql",
      key: m[1].toLowerCase().replace(/\s+/g, " "),
      files: [rel(file)],
      hint: "Destructive statement in a migration — migrations must be non-destructive.",
    });
  }
}
for (const [table, files] of createdTables) {
  if (files.length > 1) {
    add(
      "table",
      table,
      files,
      "Table created in more than one migration — reuse the existing table.",
    );
  }
}
for (const [col, files] of columns) {
  if (files.length > 1)
    add("column", col, files, "Column added twice — reuse the existing column.");
}
for (const [name, files] of enums) {
  if (files.length > 1)
    add("enum", name, files, "Enum type created twice — extend the existing one.");
}

/* 6. Lookup mode: "does something like X already exist?" --------------------- */
const args = process.argv.slice(2);
const jsonMode = args.includes("--json");
const findIdx = args.indexOf("--find");
if (findIdx !== -1) {
  const terms = args.slice(findIdx + 1).filter((a) => !a.startsWith("--"));
  const matches = [];
  for (const term of terms) {
    const needle = term.toLowerCase();
    const files = codeFiles.filter((f) => rel(f).toLowerCase().includes(needle));
    const routeHits = [...routes.keys()].filter((r) => r.toLowerCase().includes(needle));
    const exportHits = [...exports_.keys()].filter((e) => e.toLowerCase().includes(needle));
    const tableHits = [...createdTables.keys()].filter((t) => t.includes(needle));
    matches.push({
      term,
      files: files.map(rel),
      routes: routeHits,
      exports: exportHits,
      tables: tableHits,
    });
  }
  if (jsonMode) {
    console.log(JSON.stringify(matches, null, 2));
  } else {
    for (const m of matches) {
      console.log(`\n🔎 "${m.term}" — reuse these before creating anything new:`);
      console.log(`   routes:  ${m.routes.join(", ") || "—"}`);
      console.log(`   files:   ${m.files.join(", ") || "—"}`);
      console.log(`   exports: ${m.exports.slice(0, 15).join(", ") || "—"}`);
      console.log(`   tables:  ${m.tables.join(", ") || "—"}`);
    }
    console.log("");
  }
  process.exit(0);
}

/* Report -------------------------------------------------------------------- */
if (jsonMode) {
  console.log(JSON.stringify({ ok: findings.length === 0, findings }, null, 2));
} else {
  console.log(
    `Duplicate check: ${codeFiles.length} source files, ${routes.size} routes, ${migrations.length} migrations.`,
  );
  if (findings.length === 0) {
    console.log(
      "✅ No duplicate pages, routes, exports, server functions, tables, columns or enums.",
    );
  } else {
    console.log(`\n❌ ${findings.length} possible duplicate(s) — reuse instead of recreating:\n`);
    for (const f of findings) {
      console.log(`  [${f.kind}] ${f.key}`);
      for (const file of f.files) console.log(`      ${file}`);
      console.log(`      → ${f.hint}\n`);
    }
  }
}
process.exit(findings.length === 0 ? 0 : 1);
