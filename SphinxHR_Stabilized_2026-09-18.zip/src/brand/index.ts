// Single source of truth for SPHINX Workforce brand assets.
// Every page/component imports from "@/brand" — never reference asset paths directly.

import logoMark from "@/assets/logo-sphinx-mark.png";
import heroWorkforce from "@/assets/hero-workforce.jpg";
import aboutLeadership from "@/assets/about-leadership.jpg";
import ctaBand from "@/assets/cta-band.jpg";
import ornamentDivider from "@/assets/ornament-egyptian-divider.png";
import patternHieroglyph from "@/assets/pattern-hieroglyph.png";
import ornamentCorner from "@/assets/ornament-corner.png";
import laborForceAsset from "@/assets/pharaonic-labor-force.jpg.asset.json";
import sphinxBgAsset from "@/assets/sphinx-bg.png.asset.json";

import iconOutsourcing from "@/assets/icon-outsourcing.png";
import iconManpower from "@/assets/icon-manpower.png";
import iconBluecollar from "@/assets/icon-bluecollar.png";
import iconTechnical from "@/assets/icon-technical.png";
import iconLeasing from "@/assets/icon-leasing.png";
import iconTemporary from "@/assets/icon-temporary.png";
import iconFacility from "@/assets/icon-facility.png";
import iconIndustrial from "@/assets/icon-industrial.png";

export const brand = {
  name: "SPHINX Workforce",
  tagline: {
    ar: "القوة . الحكمة . المعرفة ",
    en: "Power.Judjement.knowlge ",
  },
  colors: {
    gold: "#D4AF37",
    black: "#0B0B0B",
    white: "#FFFFFF",
  },
} as const;

export const logos = {
  mark: logoMark,
} as const;

export const imagery = {
  /** Approved Pharaonic "LABOR FORCE" artwork — main page / services backdrop. */
  laborForce: laborForceAsset.url,
  /** Cinematic Sphinx landscape — used as a subtle card/section backdrop. */
  sphinxBackdrop: sphinxBgAsset.url,
  heroWorkforce,
  aboutLeadership,
  ctaBand,
} as const;

export const ornaments = {
  divider: ornamentDivider,
  pattern: patternHieroglyph,
  corner: ornamentCorner,
} as const;

export type ServiceSlug =
  | "outsourcing"
  | "manpower"
  | "bluecollar"
  | "technical"
  | "leasing"
  | "temporary"
  | "facility"
  | "industrial";

export const serviceIcons: Record<ServiceSlug, string> = {
  outsourcing: iconOutsourcing,
  manpower: iconManpower,
  bluecollar: iconBluecollar,
  technical: iconTechnical,
  leasing: iconLeasing,
  temporary: iconTemporary,
  facility: iconFacility,
  industrial: iconIndustrial,
};
