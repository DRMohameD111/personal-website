/**
 * Lightweight form draft autosave (localStorage only).
 *
 * Single shared implementation reused by every important data-entry form
 * (job seeker + company/customer pages). Do not create a second autosave system.
 *
 * Rules:
 *  - key = draft:<formId>:<authenticated user id | anon>, so drafts never leak between accounts
 *  - never store passwords / OTP / payment / credential fields or file inputs
 *  - drafts are cleared ONLY after the backend confirms a successful save
 */
import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

const SENSITIVE = /(pass|pwd|otp|code|token|secret|cvv|cvc|card|iban|credit|security)/i;

export const DRAFT_RESTORED = {
  en: "Your saved data has been restored.",
  ar: "تم استعادة البيانات المحفوظة.",
};

function isSensitive(name: string) {
  return !name || SENSITIVE.test(name);
}

function read(key: string): Record<string, unknown> | null {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as Record<string, unknown>) : null;
  } catch {
    return null;
  }
}

function write(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* storage full / disabled — drafts are best-effort */
  }
}

/** Resolves the per-user draft storage key (null until known). */
function useDraftKey(formId: string) {
  const [key, setKey] = useState<string | null>(null);
  useEffect(() => {
    let alive = true;
    supabase.auth
      .getUser()
      .then(({ data }) => {
        if (alive) setKey(`draft:${formId}:${data?.user?.id ?? "anon"}`);
      })
      .catch(() => {
        if (alive) setKey(`draft:${formId}:anon`);
      });
    return () => {
      alive = false;
    };
  }, [formId]);
  return key;
}

function announce(lang: string) {
  toast.info(lang === "ar" ? DRAFT_RESTORED.ar : DRAFT_RESTORED.en);
}

/**
 * Autosave for uncontrolled forms (FormData based).
 * Attach the returned ref to the <form> element.
 */
export function useFormDraft(formId: string, lang: string, enabled = true) {
  const key = useDraftKey(formId);
  const formRef = useRef<HTMLFormElement | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    const form = formRef.current;
    if (!key || !form || !enabled) return;

    // 1) restore
    const saved = read(key);
    if (saved && Object.keys(saved).length > 0) {
      let applied = false;
      for (const el of Array.from(form.elements) as HTMLInputElement[]) {
        const name = el.name;
        if (!name || isSensitive(name) || el.type === "file") continue;
        const value = saved[name];
        if (value === undefined || value === null) continue;
        if (el.type === "checkbox" || el.type === "radio") {
          if (typeof value === "boolean") el.checked = value;
        } else if (typeof value === "string" && value !== "") {
          el.value = value;
          applied = true;
        }
      }
      if (applied) announce(lang);
    }

    // 2) save changed values (debounced)
    const save = () => {
      if (timer.current) clearTimeout(timer.current);
      timer.current = setTimeout(() => {
        const data: Record<string, unknown> = {};
        for (const el of Array.from(form.elements) as HTMLInputElement[]) {
          const name = el.name;
          if (!name || isSensitive(name) || el.type === "file") continue;
          if (el.type === "checkbox" || el.type === "radio") data[name] = el.checked;
          else if (el.value) data[name] = el.value;
        }
        write(key, data);
      }, 400);
    };
    form.addEventListener("input", save);
    form.addEventListener("change", save);
    return () => {
      form.removeEventListener("input", save);
      form.removeEventListener("change", save);
      if (timer.current) clearTimeout(timer.current);
    };
  }, [key, lang, enabled]);

  const clearDraft = useCallback(() => {
    if (key) localStorage.removeItem(key);
  }, [key]);

  return { formRef, clearDraft };
}

/**
 * Autosave for controlled forms held in React state.
 * Restores the saved draft into existing state via `apply`.
 */
export function useStateDraft<T extends Record<string, unknown>>(
  formId: string,
  value: T,
  apply: (draft: Partial<T>) => void,
  lang: string,
  options?: { enabled?: boolean; omit?: (keyof T)[]; dirty?: boolean },
) {
  const key = useDraftKey(formId);
  const enabled = options?.enabled ?? true;
  // When `dirty` is supplied, only persist after the user actually edited something,
  // so simply viewing a pre-filled form never creates a draft.
  const canPersist = options?.dirty ?? true;
  const restored = useRef(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const applyRef = useRef(apply);
  applyRef.current = apply;

  useEffect(() => {
    if (!key || !enabled || restored.current) return;
    restored.current = true;
    const saved = read(key);
    if (saved && Object.keys(saved).length > 0) {
      applyRef.current(saved as Partial<T>);
      announce(lang);
    }
  }, [key, enabled, lang]);

  useEffect(() => {
    if (!key || !enabled || !restored.current || !canPersist) return;

    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => {
      const data: Record<string, unknown> = {};
      for (const [k, v] of Object.entries(value)) {
        if (isSensitive(k)) continue;
        if (options?.omit?.includes(k as keyof T)) continue;
        if (v === undefined || v === null || v === "") continue;
        if (typeof v === "object" && !Array.isArray(v)) continue;
        data[k] = v;
      }
      write(key, data);
    }, 400);
    return () => {
      if (timer.current) clearTimeout(timer.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, enabled, canPersist, JSON.stringify(value)]);

  const clearDraft = useCallback(() => {
    if (key) localStorage.removeItem(key);
  }, [key]);

  return { clearDraft };
}
