import { describe, expect, it } from "vitest";
import {
  PACKAGE_CODE_RE,
  buildPackageCode,
  classifyChange,
  expectedEndDate,
  isPackageStatus,
  packagePrefix,
  proratedCredit,
  quoteChange,
  remainingDays,
  type PackageRow,
  type SubscriptionPolicy,
  type SubscriptionRow,
} from "./subscriptions";

const pkg = (over: Partial<PackageRow> = {}): PackageRow =>
  ({
    id: "00000000-0000-0000-0000-000000000001",
    slug: "premium",
    name_en: "Premium",
    name_ar: "بريميوم",
    price: 1500,
    promo_price: null,
    promo_starts_at: null,
    promo_ends_at: null,
    price_after_trial: null,
    currency: "SAR",
    duration_months: 3,
    trial_enabled: false,
    trial_days: 0,
    rank: 2,
    code_prefix: "P",
    is_active: true,
    is_free: false,
    ...over,
  }) as unknown as PackageRow;

const policy = (over: Partial<SubscriptionPolicy> = {}): SubscriptionPolicy =>
  ({
    id: true,
    upgrade_timing: "after_payment",
    downgrade_timing: "end_of_term",
    prorate_credit: true,
    require_admin_approval: false,
    allow_same_package_renewal: true,
    tax_percent: 0,
    ...over,
  }) as unknown as SubscriptionPolicy;

const NOW = Date.parse("2026-08-15T00:00:00Z");

const sub = (over: Partial<SubscriptionRow> = {}): SubscriptionRow =>
  ({
    id: "sub-1",
    user_id: "u1",
    package_id: pkg().id,
    price_paid: 900,
    currency: "SAR",
    started_at: "2026-08-01T00:00:00Z",
    expires_at: "2026-08-31T00:00:00Z",
    status: "active",
    ...over,
  }) as unknown as SubscriptionRow;

describe("change classification", () => {
  it("treats a higher rank as an upgrade and a lower rank as a downgrade", () => {
    expect(classifyChange(1, 2, true)).toEqual({ type: "upgrade" });
    expect(classifyChange(3, 1, true)).toEqual({ type: "downgrade" });
  });
  it("classifies a first subscription as new", () => {
    expect(classifyChange(null, 2, true)).toEqual({ type: "new" });
  });
  it("rejects the same package when renewal is disabled", () => {
    expect(classifyChange(2, 2, false)).toEqual({ error: "same_package" });
    expect(classifyChange(2, 2, true)).toEqual({ type: "renewal" });
  });
});

describe("package codes", () => {
  it("uses the stable prefix, not the display name", () => {
    expect(packagePrefix({ code_prefix: "C", slug: "classic" } as PackageRow)).toBe("C");
    expect(packagePrefix({ code_prefix: "P", slug: "renamed-package" } as PackageRow)).toBe("P");
    expect(packagePrefix({ code_prefix: "A", slug: "advanced" } as PackageRow)).toBe("A");
    expect(packagePrefix({ code_prefix: null, slug: "premium" } as PackageRow)).toBe("P");
  });
  it("formats {PREFIX}-{COMPANY}-{MMYY}-{SERIAL}", () => {
    const code = buildPackageCode("P", "TEST01", new Date("2026-08-15T00:00:00Z"), 7);
    expect(code).toBe("P-TEST01-0826-0007");
    expect(PACKAGE_CODE_RE.test(code)).toBe(true);
  });
  it("keeps serials distinct in the generated code", () => {
    const at = new Date("2026-08-15T00:00:00Z");
    const codes = new Set([1, 2, 3].map((s) => buildPackageCode("C", "YAQ", at, s)));
    expect(codes.size).toBe(3);
  });
});

describe("statuses", () => {
  it("only accepts the controlled status model", () => {
    expect(isPackageStatus("awaiting_payment")).toBe(true);
    expect(isPackageStatus("whatever")).toBe(false);
  });
});

describe("dates", () => {
  it("derives the expected end date from the package duration", () => {
    expect(expectedEndDate(new Date("2026-08-15T00:00:00Z"), 3)?.toISOString()).toBe(
      "2026-11-15T00:00:00.000Z",
    );
    expect(expectedEndDate(new Date("2026-08-15T00:00:00Z"), null)).toBeNull();
  });
  it("computes remaining days", () => {
    expect(remainingDays("2026-08-31T00:00:00Z", NOW)).toBe(16);
    expect(remainingDays(null, NOW)).toBeNull();
  });
});

describe("credit and pricing", () => {
  it("prorates the unused value of the current package", () => {
    expect(proratedCredit(sub(), NOW)).toBe(480); // 16/30 of 900
    expect(proratedCredit(null, NOW)).toBe(0);
  });

  it("uses the database price and ignores any client-supplied amount", () => {
    const q = quoteChange({
      pkg: pkg(),
      current: null,
      policy: policy(),
      changeType: "new",
      now: NOW,
    });
    expect(q.amountBeforeCredit).toBe(1500);
    expect(q.amountDue).toBe(1500);
    expect(q.requiresPayment).toBe(true);
  });

  it("applies the promotional discount inside its window only", () => {
    const promo = pkg({
      promo_price: 1200,
      promo_starts_at: "2026-08-01T00:00:00Z",
      promo_ends_at: "2026-09-01T00:00:00Z",
    });
    const q = quoteChange({
      pkg: promo,
      current: null,
      policy: policy(),
      changeType: "new",
      now: NOW,
    });
    expect(q.discount).toBe(300);
    expect(q.amountDue).toBe(1200);

    const expired = pkg({ promo_price: 1200, promo_ends_at: "2026-07-01T00:00:00Z" });
    expect(
      quoteChange({ pkg: expired, current: null, policy: policy(), changeType: "new", now: NOW })
        .amountDue,
    ).toBe(1500);
  });

  it("credits the unused value on an upgrade when prorating is enabled", () => {
    const q = quoteChange({
      pkg: pkg(),
      current: sub(),
      policy: policy(),
      changeType: "upgrade",
      now: NOW,
    });
    expect(q.creditApplied).toBe(480);
    expect(q.amountDue).toBe(1020);
  });

  it("does not credit when the admin policy disables prorating", () => {
    const q = quoteChange({
      pkg: pkg(),
      current: sub(),
      policy: policy({ prorate_credit: false }),
      changeType: "upgrade",
      now: NOW,
    });
    expect(q.creditApplied).toBe(0);
    expect(q.amountDue).toBe(1500);
  });

  it("adds tax on top of the net amount", () => {
    const q = quoteChange({
      pkg: pkg({ price: 1000 }),
      current: null,
      policy: policy({ tax_percent: 15 }),
      changeType: "new",
      now: NOW,
    });
    expect(q.amountDue).toBe(1150);
  });

  it("schedules a downgrade for the end of the current term", () => {
    const q = quoteChange({
      pkg: pkg({ rank: 1 }),
      current: sub(),
      policy: policy(),
      changeType: "downgrade",
      now: NOW,
    });
    expect(q.effectiveDate).toBe("2026-08-31T00:00:00.000Z");
    expect(q.proposedStart).toBe("2026-08-31T00:00:00.000Z");
    expect(q.proposedEnd).toBe("2026-11-30T00:00:00.000Z");
    expect(q.creditApplied).toBe(0);
  });

  it("applies an immediate downgrade when the admin policy allows it", () => {
    const q = quoteChange({
      pkg: pkg({ rank: 1 }),
      current: sub(),
      policy: policy({ downgrade_timing: "immediate" }),
      changeType: "downgrade",
      now: NOW,
    });
    expect(q.effectiveDate).toBe(new Date(NOW).toISOString());
  });

  it("marks a free trial package as payment-free", () => {
    const trial = pkg({ price: 0, trial_enabled: true, trial_days: 90, is_free: true });
    const q = quoteChange({
      pkg: trial,
      current: null,
      policy: policy(),
      changeType: "new",
      now: NOW,
    });
    expect(q.amountDue).toBe(0);
    expect(q.requiresPayment).toBe(false);
    expect(q.isTrial).toBe(true);
  });

  it("never produces a negative amount due", () => {
    const q = quoteChange({
      pkg: pkg({ price: 100 }),
      current: sub({ price_paid: 100000 }),
      policy: policy(),
      changeType: "upgrade",
      now: NOW,
    });
    expect(q.amountDue).toBe(0);
    expect(q.creditApplied).toBeLessThanOrEqual(100);
  });
});
