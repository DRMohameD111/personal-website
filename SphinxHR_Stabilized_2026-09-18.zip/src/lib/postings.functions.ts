import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { assertCompanyAccount } from "./account-type.server";

// ---- Public lookups (read-only via RLS allow-all) ----

export const listProfessions = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("professions")
      .select(
        "id, slug, name_en, name_ar, group_id, job_groups(id, slug, name_en, name_ar, category_id)",
      )
      .order("sort_order", { ascending: true });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const listExperienceLevels = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("experience_levels")
      .select("id, slug, name_en, name_ar")
      .order("sort_order", { ascending: true });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

// ---- Posting schema (shared between manual + import) ----

const postingSchema = z.object({
  profession_id: z.string().uuid(),
  title_en: z.string().min(2),
  title_ar: z.string().min(2),
  country_en: z.string().min(2),
  country_ar: z.string().min(2),
  city_en: z.string().min(2),
  city_ar: z.string().min(2),
  level_id: z.string().uuid().optional(),
  level_en: z.string().optional(),
  level_ar: z.string().optional(),
  employment_type: z.enum(["full_time", "part_time", "hourly", "hybrid", "remote"]).optional(),
  type_en: z.string().min(2),
  type_ar: z.string().min(2),
  salary_en: z.string().optional(),
  salary_ar: z.string().optional(),
  summary_en: z.string().optional(),
  summary_ar: z.string().optional(),
  skills: z.array(z.string()).default([]),
});

export type PostingInput = z.infer<typeof postingSchema>;

// ---- Create single posting ----

export const createJobPosting = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => postingSchema.parse(input))
  .handler(async ({ data, context }) => {
    await assertCompanyAccount(context.supabase, context.userId);
    const { profession_id, ...rest } = data;
    // Look up group_id from profession (FK requires both)
    const { data: prof, error: profErr } = await context.supabase
      .from("professions")
      .select("group_id")
      .eq("id", profession_id)
      .maybeSingle();
    if (profErr) throw new Error(profErr.message);
    if (!prof) throw new Error("Profession not found");

    const { data: inserted, error } = await context.supabase
      .from("job_postings")
      .insert({
        user_id: context.userId,
        profession_id,
        group_id: prof.group_id,
        status: "published",
        data: { ...rest, posted_at: new Date().toISOString() },
      })
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    return { id: inserted.id };
  });

// ---- Bulk import ----

const bulkSchema = z.object({
  postings: z.array(postingSchema).min(1).max(500),
});

export const bulkCreateJobPostings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => bulkSchema.parse(input))
  .handler(async ({ data, context }) => {
    await assertCompanyAccount(context.supabase, context.userId);
    const profIds = Array.from(new Set(data.postings.map((p) => p.profession_id)));
    const { data: profs, error: profErr } = await context.supabase
      .from("professions")
      .select("id, group_id")
      .in("id", profIds);
    if (profErr) throw new Error(profErr.message);
    const profMap = new Map((profs ?? []).map((p) => [p.id, p.group_id]));

    const rows = data.postings.map((p) => {
      const groupId = profMap.get(p.profession_id);
      if (!groupId) throw new Error(`Unknown profession_id: ${p.profession_id}`);
      const { profession_id, ...rest } = p;
      return {
        user_id: context.userId,
        profession_id,
        group_id: groupId,
        status: "published" as const,
        data: { ...rest, posted_at: new Date().toISOString() },
      };
    });

    const { data: inserted, error } = await context.supabase
      .from("job_postings")
      .insert(rows)
      .select("id");
    if (error) throw new Error(error.message);
    return { count: inserted?.length ?? 0 };
  });

// ---- List own postings ----

export const listMyPostings = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("job_postings")
      .select("id, data, status, created_at, published_at, closes_at")
      .eq("user_id", context.userId)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

// ---- Update / Delete / Status ----

const updateSchema = z.object({
  id: z.string().uuid(),
  patch: z.object({
    title_en: z.string().min(2).optional(),
    title_ar: z.string().min(2).optional(),
    country_en: z.string().optional(),
    country_ar: z.string().optional(),
    city_en: z.string().optional(),
    city_ar: z.string().optional(),
    employment_type: z.enum(["full_time", "part_time", "hourly", "hybrid", "remote"]).optional(),
    type_en: z.string().optional(),
    type_ar: z.string().optional(),
    salary_en: z.string().optional(),
    salary_ar: z.string().optional(),
    summary_en: z.string().optional(),
    summary_ar: z.string().optional(),
    skills: z.array(z.string()).optional(),
  }),
});

export const updateJobPosting = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => updateSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { data: row, error: getErr } = await context.supabase
      .from("job_postings")
      .select("data, user_id")
      .eq("id", data.id)
      .maybeSingle();
    if (getErr) throw new Error(getErr.message);
    if (!row) throw new Error("Posting not found");
    if (row.user_id !== context.userId) throw new Error("Forbidden");

    const merged = { ...(row.data as Record<string, unknown>), ...data.patch };
    const { error } = await context.supabase
      .from("job_postings")
      .update({ data: merged })
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const setJobPostingStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        id: z.string().uuid(),
        status: z.enum(["published", "paused", "closed"]),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("job_postings")
      .update({ status: data.status })
      .eq("id", data.id)
      .eq("user_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteJobPosting = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("job_postings")
      .delete()
      .eq("id", data.id)
      .eq("user_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
