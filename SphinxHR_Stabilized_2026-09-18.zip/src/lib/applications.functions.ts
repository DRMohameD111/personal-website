import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { Database } from "@/integrations/supabase/types";

// Fields required on the profile to be considered "100% complete".
export const REQUIRED_PROFILE_FIELDS = [
  "full_name",
  "phone",
  "country",
  "nationality",
  "profession",
  "education",
  "languages",
] as const;

export type RequiredProfileField = (typeof REQUIRED_PROFILE_FIELDS)[number];

export type ProfileReadiness = {
  signedIn: true;
  hasProfile: boolean;
  hasCv: boolean;
  cvUrl: string | null;
  completion: number; // 0-100
  missingFields: RequiredProfileField[];
  ready: boolean;
  profile: {
    full_name: string | null;
    email: string | null;
    phone: string | null;
    country: string | null;
    nationality: string | null;
    profession: string | null;
    education: string | null;
    languages: string | null;
  } | null;
};

export const getProfileReadiness = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<ProfileReadiness> => {
    const { supabase, userId } = context;
    const { data, error } = await supabase
      .from("profiles")
      .select(
        "full_name, email, phone, country, nationality, profession, education, languages, cv_url",
      )
      .eq("id", userId)
      .maybeSingle();
    if (error) throw new Error(error.message);

    const profile = data ?? null;
    const missingFields: RequiredProfileField[] = [];
    for (const f of REQUIRED_PROFILE_FIELDS) {
      const v = (profile as Record<string, unknown> | null)?.[f];
      if (typeof v !== "string" || v.trim() === "") missingFields.push(f);
    }
    const filled = REQUIRED_PROFILE_FIELDS.length - missingFields.length;
    const completion = Math.round((filled / REQUIRED_PROFILE_FIELDS.length) * 100);
    const cvUrl = (profile?.cv_url as string | null) ?? null;
    const hasCv = !!cvUrl;

    return {
      signedIn: true,
      hasProfile: !!profile,
      hasCv,
      cvUrl,
      completion,
      missingFields,
      ready: missingFields.length === 0 && hasCv,
      profile: profile
        ? {
            full_name: profile.full_name ?? null,
            email: profile.email ?? null,
            phone: profile.phone ?? null,
            country: profile.country ?? null,
            nationality: profile.nationality ?? null,
            profession: profile.profession ?? null,
            education: profile.education ?? null,
            languages: profile.languages ?? null,
          }
        : null,
    };
  });

// Candidate-editable fields only. Verified status, featured flag and the
// interview video are administrator-controlled and are additionally protected
// by a database rule, so they can never be written from here.
const updateProfileSchema = z.object({
  full_name: z.string().trim().max(200).optional(),
  company_name: z.string().trim().max(200).optional(),
  phone: z.string().trim().max(40).optional(),
  country: z.string().trim().max(120).optional(),
  nationality: z.string().trim().max(120).optional(),
  profession: z.string().trim().max(160).optional(),
  sector: z.string().trim().max(80).optional(),
  education: z.string().trim().max(400).optional(),
  languages: z.string().trim().max(400).optional(),
  cv_url: z.string().trim().max(800).optional(),
  gender: z.enum(["male", "female"]).optional(),
  photo_url: z.string().trim().max(800).optional(),
  availability: z.string().trim().max(160).optional(),
  job_title: z.string().trim().max(200).optional(),
  experience: z.string().trim().max(600).optional(),
  skills: z.array(z.string().trim().max(80)).max(40).optional(),
});

export const updateCandidateProfile = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => updateProfileSchema.parse(data))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const patch: Database["public"]["Tables"]["profiles"]["Update"] = { ...data };
    if (patch.cv_url) patch.cv_uploaded_at = new Date().toISOString();

    const { error } = await supabase.from("profiles").update(patch).eq("id", userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

const applySchema = z.object({
  jobPostingId: z.string().uuid().optional(),
  externalJobId: z.string().trim().max(120).optional(),
  jobSnapshot: z
    .object({
      title: z.string().max(300).optional(),
      title_ar: z.string().max(300).optional(),
      country: z.string().max(120).optional(),
      city: z.string().max(120).optional(),
      profession: z.string().max(160).optional(),
      level: z.string().max(80).optional(),
      type: z.string().max(80).optional(),
      salary: z.string().max(120).optional(),
      sector: z.string().max(80).optional(),
    })
    .partial()
    .default({}),
});

export type ApplyResult =
  | { ok: true; applicationId: string; status: string; appliedAt: string }
  | {
      ok: false;
      reason: "profile_incomplete";
      missingFields: RequiredProfileField[];
      hasCv: boolean;
    }
  | {
      ok: false;
      reason: "already_applied";
      applicationId: string;
      status: string;
      appliedAt: string;
    };

export const applyToJob = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => applySchema.parse(data))
  .handler(async ({ data, context }): Promise<ApplyResult> => {
    const { supabase, userId } = context;

    // 1) Load profile & verify readiness
    const { data: profile, error: pErr } = await supabase
      .from("profiles")
      .select(
        "full_name, email, phone, country, nationality, profession, sector, education, languages, cv_url",
      )
      .eq("id", userId)
      .maybeSingle();
    if (pErr) throw new Error(pErr.message);

    const missing: RequiredProfileField[] = [];
    for (const f of REQUIRED_PROFILE_FIELDS) {
      const v = (profile as Record<string, unknown> | null)?.[f];
      if (typeof v !== "string" || v.trim() === "") missing.push(f);
    }
    const cvUrl = (profile?.cv_url as string | null) ?? null;
    if (missing.length > 0 || !cvUrl) {
      return { ok: false, reason: "profile_incomplete", missingFields: missing, hasCv: !!cvUrl };
    }

    // 2) Resolve employer id from job posting (if present)
    let employerId: string | null = null;
    if (data.jobPostingId) {
      const { data: post } = await supabase
        .from("job_postings")
        .select("user_id")
        .eq("id", data.jobPostingId)
        .maybeSingle();
      employerId = (post?.user_id as string | undefined) ?? null;
    }

    // 3) Prevent duplicate applications for the same job (frontend + backend +
    //    unique index). The ORIGINAL application date is returned to the UI.
    const dupQuery = supabase
      .from("job_applications")
      .select("id, status, created_at")
      .eq("candidate_id", userId);
    const { data: existing } = data.jobPostingId
      ? await dupQuery.eq("job_posting_id", data.jobPostingId).maybeSingle()
      : data.externalJobId
        ? await dupQuery.eq("external_job_id", data.externalJobId).maybeSingle()
        : { data: null };
    if (existing) {
      return {
        ok: false,
        reason: "already_applied",
        applicationId: existing.id as string,
        status: existing.status as string,
        appliedAt: existing.created_at as string,
      };
    }

    // 4) Insert application

    const now = new Date().toISOString();
    const history = [
      { status: "submitted", at: now },
      { status: "cv_sent", at: now },
    ];
    const { data: inserted, error: insErr } = await supabase
      .from("job_applications")
      .insert({
        candidate_id: userId,
        employer_id: employerId,
        job_posting_id: data.jobPostingId ?? null,
        external_job_id: data.externalJobId ?? null,
        job_snapshot: data.jobSnapshot ?? {},
        candidate_snapshot: profile ?? {},
        cv_url: cvUrl,
        status: "cv_sent",
        status_history: history,
      })
      .select("id, status, created_at")
      .single();
    if (insErr) {
      // Database-level duplicate guard (unique index) — surface the original one.
      if ((insErr as { code?: string }).code === "23505") {
        const q = supabase
          .from("job_applications")
          .select("id, status, created_at")
          .eq("candidate_id", userId);
        const { data: dup } = data.jobPostingId
          ? await q.eq("job_posting_id", data.jobPostingId).maybeSingle()
          : await q.eq("external_job_id", data.externalJobId ?? "").maybeSingle();
        if (dup) {
          return {
            ok: false,
            reason: "already_applied",
            applicationId: dup.id as string,
            status: dup.status as string,
            appliedAt: dup.created_at as string,
          };
        }
      }
      throw new Error(insErr.message);
    }

    // 5) Notifications (in-app inbox; email delivery is handled separately)
    //    The candidate's own row goes through RLS; the employer's row must use
    //    the service role because "Own notifications" only allows self-inserts.
    const { error: ownNotifErr } = await supabase.from("app_notifications").insert({
      user_id: userId,
      type: "application_submitted",
      payload: {
        applicationId: inserted.id,
        job: data.jobSnapshot,
      },
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    } as any);
    if (ownNotifErr)
      console.error("[applyToJob] candidate notification failed", ownNotifErr.message);

    if (employerId) {
      try {
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const { error: empNotifErr } = await supabaseAdmin.from("app_notifications").insert({
          user_id: employerId,
          type: "new_applicant",
          payload: {
            applicationId: inserted.id,
            job: data.jobSnapshot,
            candidate: {
              full_name: profile?.full_name ?? null,
              email: profile?.email ?? null,
              profession: profile?.profession ?? null,
              country: profile?.country ?? null,
              cv_url: cvUrl,
            },
          },
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
        } as any);
        if (empNotifErr)
          console.error("[applyToJob] employer notification failed", empNotifErr.message);
      } catch (e) {
        console.error("[applyToJob] employer notification failed", (e as Error).message);
      }
    }

    return {
      ok: true,
      applicationId: inserted.id as string,
      status: inserted.status as string,
      appliedAt: (inserted.created_at as string) ?? now,
    };
  });
