import { describe, expect, it } from "vitest";
import { execFileSync } from "node:child_process";

/**
 * Guard test: fails when a duplicate page, route, exported symbol, server
 * function, table, column or enum is introduced instead of reusing the
 * existing implementation. Run `bun run check:duplicates` for the report.
 */
describe("duplicate prevention", () => {
  it("finds no duplicate routes, modules, functions or database objects", () => {
    let output = "";
    let failed = false;
    try {
      output = execFileSync("node", ["scripts/check-duplicates.mjs"], { encoding: "utf8" });
    } catch (err) {
      failed = true;
      output = `${(err as { stdout?: string }).stdout ?? ""}`;
    }
    expect(failed, output).toBe(false);
  });
});
