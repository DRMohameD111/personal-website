import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { isAccountType, type AccountType } from "./account-type";

// ---------------------------------------------------------------------------
// Account overview (reuses the existing `profiles` table — no new user tables)
// ---------------------------------------------------------------------------

export type MyAccount = {
  userId: string;
  email: string | null;
  accountType: AccountType;
  profile: {
    full_name: string | null;
    company_name: string | null;
    email: string | null;
    phone: string | null;
    country: string | null;
    nationality: string | null;
    profession: string | null;
    sector: string | null;
    education: string | null;
    languages: string | null;
    cv_url: string | null;
    cv_uploaded_at: string | null;
    created_at: string | null;
    gender: string | null;
    photo_url: string | null;
    availability: string | null;
    job_title: string | null;
    experience: string | null;
    skills: string[];
    is_featured: boolean;
    candidate_source: string | null;
  } | null;
};

export const getMyAccount = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<MyAccount> => {
    const { supabase, userId, claims } = context;

    // Silent, verified merge of any external CV imported before this person
    // registered. Registered/user-confirmed data always wins (see
    // public.merge_external_candidates). The user is never interrupted.
    try {
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
      await supabaseAdmin.rpc("merge_external_candidates", { _user_id: userId });
    } catch {
      /* merging is best-effort and must never block the account page */
    }

    const { data, error } = await supabase
      .from("profiles")
      .select(
        "account_type, full_name, company_name, email, phone, country, nationality, profession, sector, education, languages, cv_url, cv_uploaded_at, created_at, gender, photo_url, availability, job_title, experience, skills, is_featured, candidate_source",
      )
      .eq("id", userId)
      .maybeSingle();

    if (error) throw new Error(error.message);
    const email = (claims as { email?: string } | null)?.email ?? data?.email ?? null;
    return {
      userId,
      email,
      accountType: isAccountType(data?.account_type) ? data.account_type : "job_seeker",
      profile: data
        ? {
            full_name: data.full_name ?? null,
            company_name: data.company_name ?? null,
            email: data.email ?? email,
            phone: data.phone ?? null,
            country: data.country ?? null,
            nationality: data.nationality ?? null,
            profession: data.profession ?? null,
            sector: data.sector ?? null,
            education: data.education ?? null,
            languages: data.languages ?? null,
            cv_url: data.cv_url ?? null,
            cv_uploaded_at: data.cv_uploaded_at ?? null,
            created_at: data.created_at ?? null,
            gender: data.gender ?? null,
            photo_url: data.photo_url ?? null,
            availability: data.availability ?? null,
            job_title: data.job_title ?? null,
            experience: data.experience ?? null,
            skills: Array.isArray(data.skills) ? (data.skills as string[]) : [],
            is_featured: !!data.is_featured,
            candidate_source: data.candidate_source ?? null,
          }
        : null,
    };
  });

// ---------------------------------------------------------------------------
// Job seeker — my applications report (reuses `job_applications`)
// ---------------------------------------------------------------------------

export type MyApplication = {
  id: string;
  jobTitleEn: string;
  jobTitleAr: string;
  jobCode: string;
  company: string | null;
  appliedAt: string;
  status: string;
  jobPostingId: string | null;
  externalJobId: string | null;
};

function jobCodeFor(row: { job_posting_id: string | null; external_job_id: string | null }) {
  if (row.external_job_id) return row.external_job_id.toUpperCase();
  if (row.job_posting_id) return `SPX-${row.job_posting_id.slice(0, 8).toUpperCase()}`;
  return "—";
}

export const listMyApplications = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<MyApplication[]> => {
    const { supabase, userId } = context;
    const { data, error } = await supabase
      .from("job_applications")
      .select("id, job_posting_id, external_job_id, job_snapshot, status, created_at, employer_id")
      .eq("candidate_id", userId)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    const rows = data ?? [];

    // Employer display names: read-only lookup of company names for the
    // candidate's own applications (profiles RLS is owner-scoped).
    const employerIds = Array.from(
      new Set(rows.map((r) => r.employer_id).filter((v): v is string => !!v)),
    );
    const names = new Map<string, string>();
    if (employerIds.length > 0) {
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
      const { data: emp } = await supabaseAdmin
        .from("profiles")
        .select("id, company_name, full_name")
        .in("id", employerIds);
      for (const e of emp ?? []) names.set(e.id, e.company_name || e.full_name || "");
    }

    return rows.map((r) => {
      const snap = (r.job_snapshot ?? {}) as Record<string, string | undefined>;
      return {
        id: r.id,
        jobTitleEn: snap.title ?? "—",
        jobTitleAr: snap.title_ar ?? snap.title ?? "—",
        jobCode: jobCodeFor(r),
        company: (r.employer_id && names.get(r.employer_id)) || null,
        appliedAt: r.created_at,
        status: r.status,
        jobPostingId: r.job_posting_id,
        externalJobId: r.external_job_id,
      };
    });
  });

/** Lightweight map used by the Jobs page to flag already-applied roles. */
export const getMyAppliedJobs = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<Record<string, { appliedAt: string; status: string }>> => {
    const { supabase, userId } = context;
    const { data, error } = await supabase
      .from("job_applications")
      .select("job_posting_id, external_job_id, created_at, status")
      .eq("candidate_id", userId);
    if (error) throw new Error(error.message);
    const map: Record<string, { appliedAt: string; status: string }> = {};
    for (const r of data ?? []) {
      const key = r.external_job_id ?? r.job_posting_id;
      if (key) map[key] = { appliedAt: r.created_at, status: r.status };
    }
    return map;
  });

// ---------------------------------------------------------------------------
// Company — jobs with applicant counts, and applicants per job
// ---------------------------------------------------------------------------

export type CompanyJobSummary = {
  id: string;
  titleEn: string;
  titleAr: string;
  jobCode: string;
  status: string;
  postedAt: string;
  deadline: string | null;
  applicants: number;
  cvs: number;
  verified: number;
};

export const listMyJobsWithApplicants = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<CompanyJobSummary[]> => {
    const { supabase, userId } = context;
    const { data: postings, error } = await supabase
      .from("job_postings")
      .select("id, data, status, created_at")
      .eq("user_id", userId)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);

    const { data: apps, error: aErr } = await supabase
      .from("job_applications")
      .select("job_posting_id, cv_url, candidate_id")
      .eq("employer_id", userId);
    if (aErr) throw new Error(aErr.message);

    // Verified candidates: applicants whose profile is marked verified (reuses candidate_source).
    const candidateIds = [
      ...new Set((apps ?? []).map((a) => a.candidate_id).filter(Boolean)),
    ] as string[];
    const verifiedIds = new Set<string>();
    if (candidateIds.length) {
      const { data: profs } = await supabase
        .from("profiles")
        .select("id, candidate_source")
        .in("id", candidateIds)
        .eq("candidate_source", "verified");
      for (const pr of profs ?? []) verifiedIds.add(pr.id);
    }

    const counts = new Map<string, { applicants: number; cvs: number; verified: number }>();
    for (const a of apps ?? []) {
      if (!a.job_posting_id) continue;
      const c = counts.get(a.job_posting_id) ?? { applicants: 0, cvs: 0, verified: 0 };
      c.applicants += 1;
      if (a.cv_url) c.cvs += 1;
      if (a.candidate_id && verifiedIds.has(a.candidate_id)) c.verified += 1;
      counts.set(a.job_posting_id, c);
    }

    return (postings ?? []).map((p) => {
      const d = (p.data ?? {}) as Record<string, string | undefined>;
      const c = counts.get(p.id) ?? { applicants: 0, cvs: 0, verified: 0 };
      return {
        id: p.id,
        titleEn: d.title_en ?? "—",
        titleAr: d.title_ar ?? d.title_en ?? "—",
        jobCode: `SPX-${p.id.slice(0, 8).toUpperCase()}`,
        status: p.status,
        postedAt: d.posted_at ?? p.created_at,
        deadline: d.deadline ?? null,
        applicants: c.applicants,
        cvs: c.cvs,
        verified: c.verified,
      };
    });
  });

export type Applicant = {
  id: string;
  candidateId: string | null;
  name: string | null;
  appliedAt: string;
  status: string;
  profession: string | null;
  level: string | null;
  education: string | null;
  country: string | null;
  hasCv: boolean;
};

export const listApplicantsForJob = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ jobPostingId: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }): Promise<Applicant[]> => {
    const { supabase, userId } = context;
    // Ownership is derived from the session, never from the client payload.
    const { data: posting, error: pErr } = await supabase
      .from("job_postings")
      .select("id, user_id")
      .eq("id", data.jobPostingId)
      .maybeSingle();
    if (pErr) throw new Error(pErr.message);
    if (!posting || posting.user_id !== userId) throw new Error("Forbidden");

    const { data: apps, error } = await supabase
      .from("job_applications")
      .select("id, candidate_id, candidate_snapshot, status, created_at, cv_url")
      .eq("job_posting_id", data.jobPostingId)
      .eq("employer_id", userId)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);

    return (apps ?? []).map((a) => {
      const s = (a.candidate_snapshot ?? {}) as Record<string, string | undefined>;
      return {
        id: a.id,
        candidateId: a.candidate_id ?? null,
        name: s.full_name ?? null,
        appliedAt: a.created_at,
        status: a.status,
        profession: s.profession ?? null,
        level: s.level ?? s.sector ?? null,
        education: s.education ?? null,
        country: s.country ?? null,
        hasCv: !!a.cv_url,
      };
    });
  });

/** Time-limited CV link, only for the employer who owns the vacancy. */
export const getApplicantCvUrl = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ applicationId: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }): Promise<{ url: string; fileName: string }> => {
    const { supabase, userId } = context;
    const { data: app, error } = await supabase
      .from("job_applications")
      .select("id, cv_url, employer_id, candidate_id")
      .eq("id", data.applicationId)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!app || !app.cv_url) throw new Error("CV not available");
    if (app.employer_id !== userId && app.candidate_id !== userId) throw new Error("Forbidden");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const path = app.cv_url as string;
    const fileName = path.substring(path.lastIndexOf("/") + 1);
    const { isInlineViewable } = await import("@/lib/open-file");
    const { data: signed, error: sErr } = await supabaseAdmin.storage
      .from("cvs")
      .createSignedUrl(path, 300, isInlineViewable(fileName) ? undefined : { download: fileName });
    if (sErr || !signed) throw new Error(sErr?.message ?? "Could not create CV link");
    return { url: signed.signedUrl, fileName };
  });

// ---------------------------------------------------------------------------
// Public, aggregate-only platform statistics for the home page
// ---------------------------------------------------------------------------

export type PlatformStats = {
  job_seekers: number;
  companies: number;
  jobs: number;
  hires: number;
  cvs: number;
};

export const getPlatformStats = createServerFn({ method: "GET" }).handler(
  async (): Promise<PlatformStats | null> => {
    const { createClient } = await import("@supabase/supabase-js");
    const key = process.env["SUPABASE_PUBLISHABLE_KEY"]!;
    const url = process.env["SUPABASE_URL"]!;
    if (!key || !url) return null;
    const client = createClient(url, key, {
      auth: { persistSession: false, autoRefreshToken: false },
      global: {
        fetch: (input: RequestInfo | URL, init?: RequestInit) => {
          const h = new Headers(init?.headers);
          if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) {
            h.delete("Authorization");
          }
          h.set("apikey", key);
          return fetch(input, { ...init, headers: h });
        },
      },
    });
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { data, error } = await (client as any).rpc("platform_stats");
    if (error || !data) return null;
    const d = data as Record<string, number>;
    return {
      job_seekers: Number(d.job_seekers ?? 0),
      companies: Number(d.companies ?? 0),
      jobs: Number(d.jobs ?? 0),
      hires: Number(d.hires ?? 0),
      cvs: Number(d.cvs ?? 0),
    };
  },
);

// ---------------------------------------------------------------------------
// Company — link an incoming application to one of my vacancies + set status
// (reuses job_applications; no new tables)
// ---------------------------------------------------------------------------

export type EmployerApplication = {
  id: string;
  candidateName: string | null;
  profession: string | null;
  appliedAt: string;
  status: string;
  hasCv: boolean;
  jobPostingId: string | null;
  externalJobId: string | null;
  jobTitleEn: string;
  jobTitleAr: string;
};

export const listEmployerApplications = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<EmployerApplication[]> => {
    const { supabase, userId } = context;
    const { data, error } = await supabase
      .from("job_applications")
      .select(
        "id, candidate_snapshot, job_snapshot, status, created_at, cv_url, job_posting_id, external_job_id",
      )
      .eq("employer_id", userId)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);

    return (data ?? []).map((a) => {
      const c = (a.candidate_snapshot ?? {}) as Record<string, string | undefined>;
      const j = (a.job_snapshot ?? {}) as Record<string, string | undefined>;
      return {
        id: a.id,
        candidateName: c.full_name ?? null,
        profession: c.profession ?? null,
        appliedAt: a.created_at,
        status: a.status,
        hasCv: !!a.cv_url,
        jobPostingId: a.job_posting_id,
        externalJobId: a.external_job_id,
        jobTitleEn: j.title ?? "—",
        jobTitleAr: j.title_ar ?? j.title ?? "—",
      };
    });
  });

const linkSchema = z.object({
  applicationId: z.string().uuid(),
  jobPostingId: z.string().uuid(),
  status: z.enum(["submitted", "cv_sent", "employer_reviewed", "shortlisted", "rejected", "hired"]),
});

export const linkApplicationToJob = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => linkSchema.parse(input))
  .handler(async ({ data, context }): Promise<{ ok: true }> => {
    const { supabase, userId } = context;

    // The vacancy must belong to the signed-in company.
    const { data: posting, error: pErr } = await supabase
      .from("job_postings")
      .select("id, user_id, data")
      .eq("id", data.jobPostingId)
      .maybeSingle();
    if (pErr) throw new Error(pErr.message);
    if (!posting || posting.user_id !== userId) throw new Error("Forbidden");

    // The application must already be addressed to this company.
    const { data: app, error: aErr } = await supabase
      .from("job_applications")
      .select("id, employer_id, job_snapshot, status_history")
      .eq("id", data.applicationId)
      .maybeSingle();
    if (aErr) throw new Error(aErr.message);
    if (!app || app.employer_id !== userId) throw new Error("Forbidden");

    const pd = (posting.data ?? {}) as Record<string, string | undefined>;
    const snapshot = {
      ...((app.job_snapshot ?? {}) as Record<string, unknown>),
      title: pd.title_en ?? undefined,
      title_ar: pd.title_ar ?? pd.title_en ?? undefined,
      country: pd.country ?? undefined,
      city: pd.city ?? undefined,
    };
    const history = [
      ...((app.status_history ?? []) as Array<Record<string, unknown>>),
      { status: data.status, at: new Date().toISOString(), by: "employer" },
    ];

    const { error } = await supabase
      .from("job_applications")
      .update({
        job_posting_id: data.jobPostingId,
        status: data.status,
        job_snapshot: snapshot,
        status_history: history,
        updated_at: new Date().toISOString(),
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
      } as any)
      .eq("id", data.applicationId)
      .eq("employer_id", userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
