import { describe, it, expect } from "vitest";
import { yearsToCategory } from "./experience";

describe("yearsToCategory boundary tests", () => {
  // ─── fresh ───
  it("returns fresh for 0 years", () => {
    expect(yearsToCategory(0)).toBe("fresh");
  });

  it("returns fresh for 1 year", () => {
    expect(yearsToCategory(1)).toBe("fresh");
  });

  it("returns fresh just below the boundary (1.99)", () => {
    expect(yearsToCategory(1.99)).toBe("fresh");
  });

  // ─── fresh → expert boundary ───
  it("returns expert at the lower boundary (2)", () => {
    expect(yearsToCategory(2)).toBe("expert");
  });

  // ─── expert ───
  it("returns expert for 3 years", () => {
    expect(yearsToCategory(3)).toBe("expert");
  });

  it("returns expert for 5 years", () => {
    expect(yearsToCategory(5)).toBe("expert");
  });

  it("returns expert for 7 years", () => {
    expect(yearsToCategory(7)).toBe("expert");
  });

  // ─── expert → professional boundary ───
  it("returns professional just above the boundary (7.01)", () => {
    expect(yearsToCategory(7.01)).toBe("professional");
  });

  it("returns professional at the upper boundary (8)", () => {
    expect(yearsToCategory(8)).toBe("professional");
  });

  // ─── professional ───
  it("returns professional for 10 years", () => {
    expect(yearsToCategory(10)).toBe("professional");
  });

  it("returns professional for 20 years", () => {
    expect(yearsToCategory(20)).toBe("professional");
  });
});
