/** Detect whether free text is primarily Arabic or English. */
export function detectLang(text: string): "ar" | "en" | "unknown" {
  const arabic = (text.match(/[\u0600-\u06FF\u0750-\u077F]/g) || []).length;
  const latin = (text.match(/[A-Za-z]/g) || []).length;
  if (arabic === 0 && latin === 0) return "unknown";
  return arabic >= latin ? "ar" : "en";
}
