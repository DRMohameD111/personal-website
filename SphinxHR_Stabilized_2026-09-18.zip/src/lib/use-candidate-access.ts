import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { NO_ACCESS } from "./entitlements";
import { getMyCandidateAccess } from "./candidate-profile.functions";

/**
 * Which candidate-profile features the signed-in viewer's active package
 * allows. Display only — the server re-checks the same rules on every
 * protected read.
 */
export function useCandidateAccess() {
  const fetchAccess = useServerFn(getMyCandidateAccess);
  const q = useQuery({
    queryKey: ["my-candidate-access"],
    queryFn: () => fetchAccess({}),
    staleTime: 60_000,
    retry: false,
  });
  return q.data?.access ?? NO_ACCESS;
}
