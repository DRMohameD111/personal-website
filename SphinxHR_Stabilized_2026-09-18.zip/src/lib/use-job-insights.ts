import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import type { Job } from "@/lib/jobs";
import {
  buildInsight,
  fetchJobMeta,
  fetchSalaryBenchmarks,
  fetchValuationConfig,
  DEFAULT_VALUATION_CONFIG,
  type JobInsight,
} from "@/lib/valuation";

/**
 * Applicant counts, job status and the automatic Job Valuation for a list of
 * jobs. Single shared hook — every jobs surface reuses it.
 */
export function useJobInsights(jobs: Job[]) {
  const { data: meta = {} } = useQuery({
    queryKey: ["job-meta"],
    queryFn: fetchJobMeta,
    staleTime: 30_000,
  });
  const { data: config = DEFAULT_VALUATION_CONFIG } = useQuery({
    queryKey: ["valuation-config"],
    queryFn: fetchValuationConfig,
    staleTime: 300_000,
  });
  const { data: benchmarks = [] } = useQuery({
    queryKey: ["salary-benchmarks"],
    queryFn: fetchSalaryBenchmarks,
    staleTime: 300_000,
  });

  const insights = useMemo(() => {
    const now = Date.now();
    const map: Record<string, JobInsight> = {};
    for (const j of jobs) map[j.id] = buildInsight(j, meta[j.id], benchmarks, config, now);
    return map;
  }, [jobs, meta, benchmarks, config]);

  return { insights, config, benchmarks, meta };
}
