import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { getMyAppliedJobs } from "./account.functions";

export type AppliedMap = Record<string, { appliedAt: string; status: string }>;

/**
 * Jobs the signed-in candidate already applied to, keyed by external job id or
 * job posting id. Empty for visitors.
 */
export function useAppliedJobs() {
  const [applied, setApplied] = useState<AppliedMap>({});

  useEffect(() => {
    let mounted = true;
    const load = async (hasSession: boolean) => {
      if (!mounted) return;
      if (!hasSession) {
        setApplied({});
        return;
      }
      try {
        const map = await getMyAppliedJobs();
        if (mounted) setApplied(map);
      } catch {
        if (mounted) setApplied({});
      }
    };
    supabase.auth.getSession().then(({ data }) => void load(!!data.session));
    const { data } = supabase.auth.onAuthStateChange((_e, session) => void load(!!session));
    return () => {
      mounted = false;
      data.subscription.unsubscribe();
    };
  }, []);

  return applied;
}
