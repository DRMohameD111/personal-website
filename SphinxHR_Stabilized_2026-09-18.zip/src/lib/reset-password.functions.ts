import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const passwordSchema = z
  .string()
  .min(8, "Password must be at least 8 characters")
  .max(72, "Password must be at most 72 characters")
  .regex(/[A-Z]/, "Password must contain at least one uppercase letter")
  .regex(/[a-z]/, "Password must contain at least one lowercase letter")
  .regex(/[0-9]/, "Password must contain at least one number")
  .regex(/[^A-Za-z0-9]/, "Password must contain at least one special character");

const inputSchema = z
  .object({
    password: passwordSchema,
    confirm: z.string().min(8).max(72),
  })
  .refine((d) => d.password === d.confirm, {
    message: "Passwords do not match",
    path: ["confirm"],
  });

/**
 * Server-side validation for password reset.
 *
 * The `requireSupabaseAuth` middleware re-validates the bearer token
 * against Supabase Auth on every call. This enforces:
 *   - Token signature is valid (issued by our project)
 *   - Token is not expired (Supabase rejects expired JWTs)
 *   - The session still exists server-side (revoked / one-time-used
 *     recovery tokens fail here)
 *
 * After updating the password we additionally revoke any other active
 * sessions belonging to this user via the admin client, which guarantees
 * the recovery link can only successfully reset the password once and
 * does not leave background sessions authenticated as the account.
 */
export const resetPasswordWithToken = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => inputSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId, claims } = context;

    // Account matching: confirm the JWT's subject resolves to a real,
    // current user via the Auth server (not just a cached session).
    const { data: userData, error: userError } = await supabase.auth.getUser();
    if (userError || !userData.user) {
      throw new Error("Invalid or expired reset link. Please request a new one.");
    }
    if (userData.user.id !== userId) {
      throw new Error("Reset link does not match the requested account.");
    }

    // Reject obviously stale tokens defensively (Supabase already enforces
    // exp; this is belt-and-suspenders in case middleware skips it).
    const exp = (claims as { exp?: number } | undefined)?.exp;
    if (typeof exp === "number" && exp * 1000 < Date.now()) {
      throw new Error("Reset link has expired. Please request a new one.");
    }

    // Apply the new password. The server-side client is bearer-only (no
    // persisted session), so `auth.updateUser` fails with
    // "Auth session missing!" — use the Auth Admin API scoped to the
    // already-verified user id instead.
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error: updateError } = await supabaseAdmin.auth.admin.updateUserById(userId, {
      password: data.password,
    });
    if (updateError) {
      throw new Error(updateError.message);
    }

    // Enforce one-time use: revoke every other session for this account so
    // the recovery link cannot be replayed and any lingering tabs are
    // forced to re-authenticate with the new password.
    try {
      await supabaseAdmin.auth.admin.signOut(userId, "others");
    } catch (err) {
      // Non-fatal: password was already rotated. Log for observability.
      console.error("Failed to revoke other sessions after password reset", err);
    }

    return { ok: true } as const;
  });
