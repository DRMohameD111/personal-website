/**
 * Server-only helpers for the external CV import.
 * Reuses the Lovable AI Gateway (same gateway as translate.server.ts) to read a
 * CV file and map it onto the EXISTING job-seeker fields. No new candidate
 * database: the parsed result is stored in `external_candidates` and merged into
 * `profiles` once the person registers.
 */

const GATEWAY = "https://ai.gateway.lovable.dev/v1/chat/completions";

export type ExtractedCv = {
  full_name: string | null;
  email: string | null;
  phone: string | null;
  nationality: string | null;
  location: string | null;
  job_title: string | null;
  career_level: string | null;
  experience_years: number | null;
  experience_text: string | null;
  education: string | null;
  skills: string[];
  languages: string[];
  certifications: string[];
};

const EMPTY: ExtractedCv = {
  full_name: null,
  email: null,
  phone: null,
  nationality: null,
  location: null,
  job_title: null,
  career_level: null,
  experience_years: null,
  experience_text: null,
  education: null,
  skills: [],
  languages: [],
  certifications: [],
};

const SYSTEM = `You extract recruitment data from a CV for an HR platform.
Return ONLY compact JSON with exactly these keys:
full_name, email, phone, nationality, location, job_title, career_level,
experience_years, experience_text, education, skills, languages, certifications.
Rules:
- skills, languages and certifications are arrays of short strings (max 15 each).
- experience_years is a number or null. career_level is one of:
  "Entry", "Junior", "Mid", "Senior", "Manager", "Director", "Executive" or null.
- Use null for anything not clearly stated. Never invent data.
- Extract ONLY job-relevant information. Never extract age, gender, marital status,
  religion, photos, family details or any other protected/sensitive attribute.`;

const str = (v: unknown): string | null => {
  const s = typeof v === "string" ? v.trim() : "";
  return s ? s.slice(0, 400) : null;
};

const arr = (v: unknown): string[] =>
  Array.isArray(v)
    ? v
        .map((x) => (typeof x === "string" ? x.trim() : ""))
        .filter(Boolean)
        .slice(0, 15)
    : [];

function toBase64(bytes: Uint8Array): string {
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

/** Reads a CV file (PDF / DOC / DOCX / text) and returns recruitment fields. */
export async function extractCvFields(
  bytes: Uint8Array,
  mimeType: string,
  fileName: string,
): Promise<ExtractedCv> {
  const key = process.env["LOVABLE_API_KEY"];
  if (!key) throw new Error("CV extraction service is not configured");

  const isText = /^text\//.test(mimeType) || /\.(txt|csv|md)$/i.test(fileName);
  const userContent = isText
    ? [
        {
          type: "text",
          text: `Extract the recruitment fields from this CV text:\n\n${new TextDecoder().decode(
            bytes.subarray(0, 60_000),
          )}`,
        },
      ]
    : [
        { type: "text", text: `Extract the recruitment fields from this CV file (${fileName}).` },
        {
          type: "file",
          file: {
            filename: fileName,
            file_data: `data:${mimeType || "application/pdf"};base64,${toBase64(bytes)}`,
          },
        },
      ];

  const res = await fetch(GATEWAY, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: "google/gemini-2.5-flash",
      messages: [
        { role: "system", content: SYSTEM },
        { role: "user", content: userContent },
      ],
      response_format: { type: "json_object" },
    }),
  });

  if (!res.ok) {
    const body = await res.text().catch(() => "");
    if (res.status === 429) throw new Error("AI rate limit reached, try again shortly");
    if (res.status === 402) throw new Error("AI credits exhausted for this workspace");
    throw new Error(body || `CV extraction failed (${res.status})`);
  }

  const json = (await res.json()) as { choices?: Array<{ message?: { content?: string } }> };
  const raw = json.choices?.[0]?.message?.content ?? "";
  let parsed: Record<string, unknown> = {};
  try {
    parsed = JSON.parse(raw.replace(/^```(?:json)?|```$/g, "").trim()) as Record<string, unknown>;
  } catch {
    throw new Error("Could not read the CV content");
  }

  const years = Number(parsed["experience_years"]);
  return {
    ...EMPTY,
    full_name: str(parsed["full_name"]),
    email: str(parsed["email"])?.toLowerCase() ?? null,
    phone: str(parsed["phone"]),
    nationality: str(parsed["nationality"]),
    location: str(parsed["location"]),
    job_title: str(parsed["job_title"]),
    career_level: str(parsed["career_level"]),
    experience_years: Number.isFinite(years) && years >= 0 ? Math.min(years, 60) : null,
    experience_text: str(parsed["experience_text"]),
    education: str(parsed["education"]),
    skills: arr(parsed["skills"]),
    languages: arr(parsed["languages"]),
    certifications: arr(parsed["certifications"]),
  };
}
