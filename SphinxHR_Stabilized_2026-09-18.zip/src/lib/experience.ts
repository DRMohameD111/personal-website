/**
 * Map years of experience to the three candidate profile tiers.
 *
 * Boundaries (gap-free):
 *   fresh       → years < 2
 *   expert      → 2 ≤ years ≤ 7   (labelled "3 – 7" on the UI)
 *   professional→ years > 7
 */
export type ExperienceCategory = "fresh" | "expert" | "professional";

export function yearsToCategory(years: number): ExperienceCategory {
  if (years < 2) return "fresh";
  if (years <= 7) return "expert";
  return "professional";
}
