import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import {
  CANDIDATE_FEATURES,
  FULL_ACCESS,
  NO_ACCESS,
  PACKAGE_REQUIRED,
  candidateAccessFrom,
  type CandidateAccess,
  type CandidateFeature,
  type SnapshotFeature,
} from "./entitlements";

/**
 * Professional candidate profile.
 *
 * Reuses the existing `profiles` record (candidate data, verified state,
 * interview video), `candidate_documents` (certificates), the private storage
 * buckets and `cv_access_log`. Company access is decided ONLY here, on the
 * server, from the active subscription's stored package snapshot — the buttons
 * in the UI merely mirror what this file already allows.
 */

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type Sb = any;

const PHOTO_BUCKET = "candidate-media";

type Viewer =
  | { role: "self"; access: CandidateAccess }
  | { role: "admin"; access: CandidateAccess }
  | { role: "company"; access: CandidateAccess };

/** Features granted by the viewer's active subscription snapshot. */
async function companyAccess(admin: Sb, userId: string): Promise<CandidateAccess> {
  const { data: sub } = await admin
    .from("subscriptions")
    .select("package_snapshot, status, expires_at")
    .eq("user_id", userId)
    .eq("status", "active")
    .order("started_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  if (!sub) return NO_ACCESS;
  if (sub.expires_at && new Date(sub.expires_at) <= new Date()) return NO_ACCESS;
  const features = (sub.package_snapshot?.features ?? []) as SnapshotFeature[];
  return candidateAccessFrom(features);
}

async function resolveViewer(
  supabase: Sb,
  admin: Sb,
  userId: string,
  candidateId: string,
): Promise<Viewer> {
  if (userId === candidateId) return { role: "self", access: FULL_ACCESS };
  const { data: isAdmin } = await supabase.rpc("has_role", { _user_id: userId, _role: "admin" });
  if (isAdmin === true) return { role: "admin", access: FULL_ACCESS };

  const { data: me } = await admin
    .from("profiles")
    .select("account_type")
    .eq("id", userId)
    .maybeSingle();
  if (me?.account_type !== "company") throw new Error("Forbidden");
  return { role: "company", access: await companyAccess(admin, userId) };
}

function assertFeature(viewer: Viewer, feature: CandidateFeature) {
  if (viewer.role !== "company") return;
  if (!viewer.access[feature]) throw new Error(PACKAGE_REQUIRED);
}

// ---------------------------------------------------------------------------
// What may the signed-in viewer open? (drives the locked / upgrade states)
// ---------------------------------------------------------------------------

export const getMyCandidateAccess = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(
    async ({
      context,
    }): Promise<{ role: "admin" | "company" | "other"; access: CandidateAccess }> => {
      const { supabase, userId } = context;
      const { data: isAdmin } = await supabase.rpc("has_role", {
        _user_id: userId,
        _role: "admin",
      });
      if (isAdmin === true) return { role: "admin", access: FULL_ACCESS };

      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
      const { data: me } = await supabaseAdmin
        .from("profiles")
        .select("account_type")
        .eq("id", userId)
        .maybeSingle();
      if (me?.account_type !== "company") return { role: "other", access: NO_ACCESS };
      return { role: "company", access: await companyAccess(supabaseAdmin, userId) };
    },
  );

// ---------------------------------------------------------------------------
// The professional profile itself
// ---------------------------------------------------------------------------

export type CandidateCertificate = {
  id: string;
  title: string;
  docType: string;
  createdAt: string;
};

export type CandidateProfileView = {
  id: string;
  name: string | null;
  jobTitle: string | null;
  experience: string | null;
  skills: string[];
  education: string | null;
  languages: string | null;
  country: string | null;
  nationality: string | null;
  availability: string | null;
  verified: boolean;
  featured: boolean;
  photoUrl: string | null;
  gender: string | null;
  hasCv: boolean;
  hasVideo: boolean;
  certificates: CandidateCertificate[];
  contact: { email: string | null; phone: string | null } | null;
  viewerRole: "self" | "admin" | "company";
  access: CandidateAccess;
};

export const getCandidateProfile = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ candidateId: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }): Promise<CandidateProfileView> => {
    const { supabase, userId } = context;
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const viewer = await resolveViewer(supabase, supabaseAdmin, userId, data.candidateId);

    // Companies need the professional-profile feature on their active package.
    assertFeature(viewer, "professional_profile");

    const { data: p, error } = await supabaseAdmin
      .from("profiles")
      .select(
        "id, account_type, full_name, job_title, profession, experience, skills, education, languages, country, nationality, availability, candidate_source, is_featured, photo_url, gender, cv_url, interview_video_url, email, phone",
      )
      .eq("id", data.candidateId)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!p || p.account_type !== "job_seeker") throw new Error("Candidate not found");

    const { data: docs } = await supabaseAdmin
      .from("candidate_documents")
      .select("id, doc_type, title, file_name, created_at")
      .eq("user_id", data.candidateId)
      .order("created_at", { ascending: false });

    // Photo links are short-lived signed links from the private bucket.
    let photoUrl: string | null = null;
    if (p.photo_url) {
      const signed = await supabaseAdmin.storage
        .from(PHOTO_BUCKET)
        .createSignedUrl(p.photo_url, 600);
      photoUrl = signed.data?.signedUrl ?? null;
    }

    const showContact = viewer.role !== "company" || viewer.access.candidate_contact;
    const showCerts = viewer.role !== "company" || viewer.access.certificates;

    // NOTE: opening a profile is NOT logged in `cv_access_log` — that log is the
    // CV download quota, so browsing profiles must never consume it. Only the
    // actual CV open (getCandidateMediaUrl, kind === "cv") is recorded.

    return {
      id: p.id,
      name: p.full_name ?? null,
      jobTitle: p.job_title ?? p.profession ?? null,
      experience: p.experience ?? null,
      skills: Array.isArray(p.skills) ? (p.skills as string[]) : [],
      education: p.education ?? null,
      languages: p.languages ?? null,
      country: p.country ?? null,
      nationality: p.nationality ?? null,
      availability: p.availability ?? null,
      verified: p.candidate_source === "verified",
      featured: !!p.is_featured,
      photoUrl,
      gender: p.gender ?? null,
      hasCv: !!p.cv_url,
      hasVideo: !!p.interview_video_url,
      certificates: showCerts
        ? (docs ?? []).map(
            (d: {
              id: string;
              doc_type: string;
              title: string | null;
              file_name: string | null;
              created_at: string;
            }) => ({
              id: d.id,
              title: d.title || d.file_name || d.doc_type,
              docType: d.doc_type,
              createdAt: d.created_at,
            }),
          )
        : [],
      contact: showContact ? { email: p.email ?? null, phone: p.phone ?? null } : null,
      viewerRole: viewer.role,
      access: viewer.access,
    };
  });

// ---------------------------------------------------------------------------
// Protected media (CV, interview video, certificate) — verified per request
// ---------------------------------------------------------------------------

export const getCandidateMediaUrl = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        candidateId: z.string().uuid(),
        kind: z.enum(["cv", "video", "certificate"]),
        documentId: z.string().uuid().optional(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }): Promise<{ url: string; fileName: string }> => {
    const { supabase, userId } = context;
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const viewer = await resolveViewer(supabase, supabaseAdmin, userId, data.candidateId);
    assertFeature(viewer, "professional_profile");

    const { isInlineViewable } = await import("@/lib/open-file");
    let bucket = "cvs";
    let path: string | null = null;

    if (data.kind === "cv") {
      assertFeature(viewer, "cv_download");
      const { data: p } = await supabaseAdmin
        .from("profiles")
        .select("cv_url")
        .eq("id", data.candidateId)
        .maybeSingle();
      path = p?.cv_url ?? null;
    } else if (data.kind === "video") {
      assertFeature(viewer, "interview_video");
      const { data: p } = await supabaseAdmin
        .from("profiles")
        .select("interview_video_url")
        .eq("id", data.candidateId)
        .maybeSingle();
      bucket = PHOTO_BUCKET;
      path = p?.interview_video_url ?? null;
    } else {
      assertFeature(viewer, "certificates");
      if (!data.documentId) throw new Error("Document not specified");
      const { data: doc } = await supabaseAdmin
        .from("candidate_documents")
        .select("storage_path, file_name, user_id")
        .eq("id", data.documentId)
        .eq("user_id", data.candidateId)
        .maybeSingle();
      path = doc?.storage_path ?? null;
    }

    if (!path) throw new Error("File not available");
    const fileName = path.substring(path.lastIndexOf("/") + 1);
    const download =
      data.kind === "video"
        ? undefined
        : isInlineViewable(fileName)
          ? undefined
          : { download: fileName };
    const signed = await supabaseAdmin.storage.from(bucket).createSignedUrl(path, 300, download);
    if (signed.error || !signed.data?.signedUrl) throw new Error("Could not open the file");

    if (data.kind === "cv" && viewer.role === "company") {
      await supabaseAdmin
        .from("cv_access_log")
        .insert({ company_id: userId, profile_id: data.candidateId });
    }

    return { url: signed.data.signedUrl, fileName };
  });

// ---------------------------------------------------------------------------
// Admin only — interview video and featured state
// ---------------------------------------------------------------------------

async function assertAdminEdit(supabase: Sb, userId: string) {
  const { data, error } = await supabase.rpc("admin_can", {
    _user_id: userId,
    _module: "job_seekers",
    _action: "edit",
  });
  if (error) throw new Error(error.message);
  if (data !== true) throw new Error("Forbidden");
}

export const setCandidateInterviewVideo = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        candidateId: z.string().uuid(),
        storagePath: z.string().trim().max(800).nullable(),
        featured: z.boolean().optional(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }): Promise<{ ok: true }> => {
    const { supabase, userId, claims } = context;
    await assertAdminEdit(supabase, userId);

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const patch: { interview_video_url: string | null; is_featured?: boolean } = {
      interview_video_url: data.storagePath,
    };
    if (data.featured !== undefined) patch.is_featured = data.featured;

    const { error } = await supabaseAdmin.from("profiles").update(patch).eq("id", data.candidateId);
    if (error) throw new Error(error.message);

    await supabaseAdmin.from("admin_audit_log").insert({
      actor_id: userId,
      actor_email: (claims as { email?: string } | null)?.email ?? null,
      action: data.storagePath ? "interview_video_set" : "interview_video_removed",
      target_type: "job_seeker",
      target_id: data.candidateId,
      changes: { ...patch } as unknown as Record<string, never>,
    });
    return { ok: true };
  });

/** Admin/candidate helper: which feature keys drive candidate access. */
export const CANDIDATE_FEATURE_KEYS = CANDIDATE_FEATURES;
