// Client master data — shared model, option lists and validation.
// Reuses the existing SECTORS (business activities) and COUNTRIES master lists.
import { z } from "zod";
import { SECTORS } from "./sectors";
import { COUNTRIES, type Bi } from "./countries";

export type { Bi };

/** Nature of business options = existing sectors master list + "Other". */
export const NATURE_OF_BUSINESS: { value: string; label: Bi }[] = [
  ...SECTORS.map((s) => ({ value: s.id, label: s.label })),
  { value: "other", label: { en: "Other", ar: "أخرى" } },
];

export const natureOfBusinessLabel = (value: string): Bi =>
  NATURE_OF_BUSINESS.find((n) => n.value === value)?.label ?? { en: value, ar: value };

/** Countries / nationalities reuse the existing dataset; the English name is the stored key. */
export const COUNTRY_OPTIONS: { value: string; label: Bi }[] = COUNTRIES.map((c) => ({
  value: c.en,
  label: c,
}));

export const countryLabel = (value: string): Bi =>
  COUNTRIES.find((c) => c.en === value) ?? { en: value, ar: value };

export const LEGAL_STRUCTURES = [
  { value: "joint_stock", label: { en: "Joint Stock Company", ar: "مساهمة" } },
  { value: "limited_partnership", label: { en: "Limited Partnership", ar: "توصية" } },
  { value: "general_partnership", label: { en: "General Partnership", ar: "تضامن" } },
  { value: "sole_proprietorship", label: { en: "Sole Proprietorship", ar: "فردي" } },
] as const;

export type LegalStructure = (typeof LEGAL_STRUCTURES)[number]["value"];

export const legalStructureLabel = (value: string): Bi =>
  LEGAL_STRUCTURES.find((l) => l.value === value)?.label ?? { en: value, ar: value };

const arDigits = (n: string) => n.replace(/\d/g, (d) => "٠١٢٣٤٥٦٧٨٩"[Number(d)]!);

export const BRANCH_OPTIONS: { value: string; label: Bi }[] = [
  ...Array.from({ length: 10 }, (_, i) => String(i + 1)).map((n) => ({
    value: n,
    label: { en: n, ar: arDigits(n) },
  })),
  { value: "11-20", label: { en: "11–20", ar: `${arDigits("11")}–${arDigits("20")}` } },
  { value: "21-50", label: { en: "21–50", ar: `${arDigits("21")}–${arDigits("50")}` } },
  { value: "50+", label: { en: "More than 50", ar: `أكثر من ${arDigits("50")}` } },
];

export const branchesLabel = (value: string): Bi =>
  BRANCH_OPTIONS.find((b) => b.value === value)?.label ?? { en: value, ar: value };

/** Normalisation helpers reused by the form and the server. */
export const normalizeEmail = (v: string) => v.trim().toLowerCase();

export function normalizeWebsite(v: string): string {
  const raw = v.trim();
  if (!raw) return "";
  return /^https?:\/\//i.test(raw) ? raw : `https://${raw.replace(/^\/+/, "")}`;
}

const WEBSITE_RE = /^https?:\/\/([\w-]+\.)+[a-z]{2,}(\/\S*)?$/i;

/** Single validation schema shared by the client form and the server function. */
export const clientSchema = z.object({
  id: z.string().uuid().optional(),
  name: z.string().trim().min(2).max(160),
  client_code: z.string().trim().max(40).optional().or(z.literal("")),
  nature_of_business: z.string().trim().min(1).max(60),
  nature_of_business_other: z.string().trim().max(160).optional().or(z.literal("")),
  nationality_code: z.string().trim().min(1).max(80),
  legal_structure: z.enum([
    "joint_stock",
    "limited_partnership",
    "general_partnership",
    "sole_proprietorship",
  ]),
  hq_country_code: z.string().trim().min(1).max(80),
  hq_city: z.string().trim().max(120).optional().or(z.literal("")),
  branches_count: z.string().trim().min(1).max(20),
  official_email: z.string().trim().toLowerCase().email().max(255),
  website: z
    .string()
    .trim()
    .max(255)
    .optional()
    .or(z.literal(""))
    .refine((v) => !v || WEBSITE_RE.test(normalizeWebsite(v)), "invalid_url"),
  cr_number: z.string().trim().max(60).optional().or(z.literal("")),
  contact_person: z.string().trim().max(160).optional().or(z.literal("")),
  contact_phone: z.string().trim().max(40).optional().or(z.literal("")),
  notes: z.string().trim().max(2000).optional().or(z.literal("")),
});

export type ClientInput = z.infer<typeof clientSchema>;

export type ClientRecord = ClientInput & {
  id: string;
  created_at: string;
  updated_at: string;
};

export const emptyClient: ClientInput = {
  name: "",
  client_code: "",
  nature_of_business: "",
  nature_of_business_other: "",
  nationality_code: "",
  legal_structure: "sole_proprietorship",
  hq_country_code: "",
  hq_city: "",
  branches_count: "",
  official_email: "",
  website: "",
  cr_number: "",
  contact_person: "",
  contact_phone: "",
  notes: "",
};

/** Field-level bilingual validation messages (no generic-only errors). */
export function validateClient(v: ClientInput): Partial<Record<keyof ClientInput, Bi>> {
  const e: Partial<Record<keyof ClientInput, Bi>> = {};
  if (v.name.trim().length < 2)
    e.name = {
      en: "Please enter the client / company name.",
      ar: "يرجى إدخال اسم العميل أو الشركة.",
    };
  if (!v.nature_of_business)
    e.nature_of_business = {
      en: "Please select the Nature of Business.",
      ar: "يرجى اختيار طبيعة النشاط.",
    };
  if (v.nature_of_business === "other" && !v.nature_of_business_other?.trim())
    e.nature_of_business_other = {
      en: "Please specify the business activity.",
      ar: "يرجى تحديد طبيعة النشاط.",
    };
  if (!v.nationality_code)
    e.nationality_code = {
      en: "Please select the company nationality.",
      ar: "يرجى اختيار جنسية الشركة.",
    };
  if (!v.legal_structure)
    e.legal_structure = {
      en: "Please select the legal / investment structure.",
      ar: "يرجى اختيار نوع الاستثمار.",
    };
  if (!v.hq_country_code)
    e.hq_country_code = {
      en: "Please select the headquarters country.",
      ar: "يرجى اختيار دولة المقر الرئيسي.",
    };
  if (!v.branches_count)
    e.branches_count = {
      en: "Please select the number of branches.",
      ar: "يرجى اختيار عدد الفروع.",
    };
  const email = normalizeEmail(v.official_email ?? "");
  if (!email)
    e.official_email = {
      en: "Please enter the official email.",
      ar: "يرجى إدخال البريد الإلكتروني الرسمي.",
    };
  else if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email))
    e.official_email = {
      en: "Please enter a valid email address.",
      ar: "يرجى إدخال بريد إلكتروني صحيح.",
    };
  if (v.website && !WEBSITE_RE.test(normalizeWebsite(v.website)))
    e.website = { en: "Please enter a valid website URL.", ar: "يرجى إدخال رابط موقع صحيح." };
  return e;
}
