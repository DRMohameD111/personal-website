import { auth, defineMcp } from "@lovable.dev/mcp-js";
import listProfessionsTool from "./tools/list-professions";
import searchJobsTool from "./tools/search-jobs";
import listMyJobPostingsTool from "./tools/list-my-job-postings";
import createJobPostingTool from "./tools/create-job-posting";

// Must be the direct Supabase host: SUPABASE_URL becomes the .lovable.cloud
// proxy on publish, which fails RFC 8414 issuer matching.
const projectRef = import.meta.env["VITE_SUPABASE_PROJECT_ID"] ?? "project-ref-unset";

export default defineMcp({
  name: "sphinx-gold-standard",
  title: "Sphinx Gold Standard",
  version: "0.1.0",
  instructions:
    "Tools for the SPHINX Workforce platform. Use `list_professions` to resolve profession ids, `search_jobs` to browse published bilingual job postings, and `list_my_job_postings` / `create_job_posting` to manage the signed-in employer's own postings.",
  auth: auth.oauth.issuer({
    issuer: `https://${projectRef}.supabase.co/auth/v1`,
    acceptedAudiences: "authenticated",
  }),
  tools: [listProfessionsTool, searchJobsTool, listMyJobPostingsTool, createJobPostingTool],
});
