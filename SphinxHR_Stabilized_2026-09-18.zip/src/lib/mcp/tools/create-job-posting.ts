import { defineTool, ToolError } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { supabaseForUser } from "../supabase";

export default defineTool({
  name: "create_job_posting",
  title: "Create job posting",
  description:
    "Publish a bilingual (English + Arabic) job posting owned by the signed-in employer.",
  inputSchema: {
    profession_id: z.string().uuid().describe("Profession id from list_professions."),
    title_en: z.string().min(2),
    title_ar: z.string().min(2),
    country_en: z.string().min(2),
    country_ar: z.string().min(2),
    city_en: z.string().min(2),
    city_ar: z.string().min(2),
    type_en: z.string().min(2).describe("Employment type in English, e.g. Full-time."),
    type_ar: z.string().min(2).describe("Employment type in Arabic."),
    salary_en: z.string().optional(),
    salary_ar: z.string().optional(),
    summary_en: z.string().optional(),
    summary_ar: z.string().optional(),
    skills: z.array(z.string()).optional(),
  },
  annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: false },
  handler: async ({ profession_id, skills, ...rest }, ctx) => {
    if (!ctx.isAuthenticated()) {
      return { content: [{ type: "text", text: "Not authenticated" }], isError: true };
    }
    const supabase = supabaseForUser(ctx);

    const { data: profession, error: professionError } = await supabase
      .from("professions")
      .select("group_id")
      .eq("id", profession_id)
      .maybeSingle();
    if (professionError) throw new ToolError(professionError.message);
    if (!profession) throw new ToolError(`Unknown profession_id: ${profession_id}`);

    const { data, error } = await supabase
      .from("job_postings")
      .insert({
        user_id: ctx.getUserId()!,
        profession_id,
        group_id: profession.group_id,
        status: "published",
        data: { ...rest, skills: skills ?? [], posted_at: new Date().toISOString() },
      })
      .select("id, status")
      .single();

    return error
      ? { content: [{ type: "text", text: error.message }], isError: true }
      : {
          content: [{ type: "text", text: `Created job posting ${data.id}` }],
          structuredContent: { posting: data },
        };
  },
});
