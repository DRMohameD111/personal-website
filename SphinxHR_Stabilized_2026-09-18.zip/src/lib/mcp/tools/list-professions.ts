import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { supabaseForUser } from "../supabase";

export default defineTool({
  name: "list_professions",
  title: "List professions",
  description: "List the bilingual professions and their job groups available for job postings.",
  inputSchema: {
    search: z
      .string()
      .optional()
      .describe("Optional case-insensitive filter on the English profession name."),
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async ({ search }, ctx) => {
    if (!ctx.isAuthenticated()) {
      return { content: [{ type: "text", text: "Not authenticated" }], isError: true };
    }
    const supabase = supabaseForUser(ctx);
    let query = supabase
      .from("professions")
      .select("id, slug, name_en, name_ar, group_id")
      .order("sort_order", { ascending: true });
    if (search) query = query.ilike("name_en", `%${search}%`);
    const { data, error } = await query;
    return error
      ? { content: [{ type: "text", text: error.message }], isError: true }
      : {
          content: [{ type: "text", text: JSON.stringify(data ?? []) }],
          structuredContent: { professions: data ?? [] },
        };
  },
});
