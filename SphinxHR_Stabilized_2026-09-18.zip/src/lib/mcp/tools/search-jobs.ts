import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { supabaseForUser } from "../supabase";

export default defineTool({
  name: "search_jobs",
  title: "Search published jobs",
  description:
    "Search published job postings by free text, country, city or employment type. Matches Arabic and English fields.",
  inputSchema: {
    query: z
      .string()
      .optional()
      .describe("Free text matched against title, city, country and skills."),
    limit: z
      .number()
      .int()
      .optional()
      .describe("Maximum number of postings to return. Defaults to 20."),
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async ({ query, limit }, ctx) => {
    if (!ctx.isAuthenticated()) {
      return { content: [{ type: "text", text: "Not authenticated" }], isError: true };
    }
    const supabase = supabaseForUser(ctx);
    const max = Math.min(Math.max(limit ?? 20, 1), 100);
    const { data, error } = await supabase
      .from("job_postings")
      .select("id, data, status, created_at")
      .eq("status", "published")
      .order("created_at", { ascending: false })
      .limit(500);
    if (error) {
      return { content: [{ type: "text", text: error.message }], isError: true };
    }
    const needle = query?.trim().toLowerCase();
    const rows = (data ?? [])
      .filter((row) => {
        if (!needle) return true;
        return JSON.stringify(row.data ?? {})
          .toLowerCase()
          .includes(needle);
      })
      .slice(0, max);

    return {
      content: [{ type: "text", text: JSON.stringify(rows) }],
      structuredContent: { jobs: rows, count: rows.length },
    };
  },
});
