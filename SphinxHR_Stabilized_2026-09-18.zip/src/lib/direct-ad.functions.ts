import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { Database } from "@/integrations/supabase/types";
import { assertCompanyAccount } from "./account-type.server";

/**
 * Direct Vacancy Ad — publish one vacancy without a subscription.
 * Reuses: packages (price source), job_postings (data.direct_ad marker),
 * job_applications, profiles, the `cvs` bucket and app_notifications.
 */

export const DIRECT_AD_SLUG = "direct-ad";

export type DirectAdPricing = {
  available: boolean;
  currency: string;
  basePrice: number;
  promoPrice: number | null;
  taxPercent: number;
  /** Price after promotion window, before VAT. */
  netPrice: number;
  /** Final amount the client must pay (VAT included). */
  amountDue: number;
  validityMonths: number | null;
  vatNoteEn: string | null;
  vatNoteAr: string | null;
  nameEn: string;
  nameAr: string;
};

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function readPricing(supabase: any): Promise<DirectAdPricing> {
  const { data: pkg } = await supabase
    .from("packages")
    .select(
      "name_en, name_ar, price, promo_price, promo_starts_at, promo_ends_at, currency, duration_months, is_free, is_active, vat_note_en, vat_note_ar",
    )
    .eq("slug", DIRECT_AD_SLUG)
    .maybeSingle();
  const { data: policy } = await supabase
    .from("subscription_policy")
    .select("tax_percent")
    .maybeSingle();

  const taxPercent = Number(policy?.tax_percent ?? 0);
  if (!pkg || !pkg.is_active) {
    return {
      available: false,
      currency: "SAR",
      basePrice: 0,
      promoPrice: null,
      taxPercent,
      netPrice: 0,
      amountDue: 0,
      validityMonths: null,
      vatNoteEn: null,
      vatNoteAr: null,
      nameEn: "Direct Vacancy Ad",
      nameAr: "إعلان مباشر عن وظيفة",
    };
  }

  const now = Date.now();
  const promoOpen =
    pkg.promo_price != null &&
    (!pkg.promo_starts_at || Date.parse(pkg.promo_starts_at) <= now) &&
    (!pkg.promo_ends_at || Date.parse(pkg.promo_ends_at) >= now);
  const netPrice = pkg.is_free ? 0 : Number(promoOpen ? pkg.promo_price : pkg.price);
  const amountDue = Math.round(netPrice * (1 + taxPercent / 100) * 100) / 100;

  return {
    available: true,
    currency: pkg.currency ?? "SAR",
    basePrice: Number(pkg.price ?? 0),
    promoPrice: pkg.promo_price == null ? null : Number(pkg.promo_price),
    taxPercent,
    netPrice,
    amountDue,
    validityMonths: pkg.duration_months ?? null,
    vatNoteEn: pkg.vat_note_en ?? null,
    vatNoteAr: pkg.vat_note_ar ?? null,
    nameEn: pkg.name_en,
    nameAr: pkg.name_ar,
  };
}

/** Price shown before publishing — always read from the Admin Control Panel. */
export const getDirectAdPricing = createServerFn({ method: "GET" }).handler(
  async (): Promise<DirectAdPricing> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    return readPricing(supabaseAdmin);
  },
);

// ---------------------------------------------------------------------------
// Eligibility — Direct Ads are for UNREGISTERED clients only
// ---------------------------------------------------------------------------

const normEmail = (v: string) => v.trim().toLowerCase();
const normDigits = (v: string) => v.replace(/[^\d]/g, "").replace(/^0+/, "");

const eligibilitySchema = z.object({
  email: z.string().trim().email().max(200),
  mobile: z.string().trim().max(40).optional(),
  cr_number: z.string().trim().max(60).optional(),
});

export type DirectAdEligibility = { allowed: boolean; reason?: "already_registered" };

/**
 * Finds an existing account/client using normalized email, mobile or CR number.
 * Returns the owner id when found, plus whether that account is a real
 * (already used) registration rather than an invited direct-ad shell.
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function findExistingClient(admin: any, input: z.infer<typeof eligibilitySchema>) {
  const email = normEmail(input.email);
  const mobile = input.mobile ? normDigits(input.mobile) : "";
  const cr = input.cr_number?.trim();

  let ownerId: string | null = null;

  const { data: byEmail } = await admin
    .from("profiles")
    .select("id")
    .eq("email", email)
    .maybeSingle();
  if (byEmail) ownerId = byEmail.id as string;

  if (!ownerId && mobile) {
    const { data: rows } = await admin
      .from("profiles")
      .select("id, phone")
      .not("phone", "is", null)
      .limit(2000);
    const match = (rows ?? []).find(
      (p: { phone: string | null }) => normDigits(String(p.phone ?? "")) === mobile,
    );
    if (match) ownerId = match.id as string;
  }

  if (!ownerId && (cr || mobile || email)) {
    // Client master data (registered company records created by the team).
    const or = [`official_email.eq.${email}`];
    if (cr) or.push(`cr_number.eq.${cr}`);
    const { data: client } = await admin
      .from("clients")
      .select("owner_id, cr_number, contact_phone")
      .or(or.join(","))
      .maybeSingle();
    if (client?.owner_id) ownerId = client.owner_id as string;
  }

  if (!ownerId) return { ownerId: null, registered: false };

  const { data: authUser } = await admin.auth.admin.getUserById(ownerId);
  const u = authUser?.user;
  const registered = !!(u?.last_sign_in_at || u?.email_confirmed_at);
  return { ownerId, registered };
}

/** Public pre-check before a guest fills in the Direct Ad form. */
export const checkDirectAdEligibility = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => eligibilitySchema.parse(input))
  .handler(async ({ data }): Promise<DirectAdEligibility> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const found = await findExistingClient(supabaseAdmin, data);
    return found.registered ? { allowed: false, reason: "already_registered" } : { allowed: true };
  });

const directAdSchema = eligibilitySchema.extend({
  // Client / company data — a guest client, no account required
  company_name: z.string().trim().min(2).max(200),
  contact_person: z.string().trim().min(2).max(200),
  mobile: z.string().trim().min(5).max(40),
  cv_email: z.string().trim().email().max(200),
  company_country: z.string().trim().max(120).optional(),
  company_city: z.string().trim().max(120).optional(),
  company_info: z.string().trim().max(2000).optional(),
  // Job details (same shape as the existing posting form)
  profession_id: z.string().uuid(),
  title_en: z.string().trim().min(2),
  title_ar: z.string().trim().min(2),
  country_en: z.string().trim().min(2),
  country_ar: z.string().trim().min(2),
  city_en: z.string().trim().min(2),
  city_ar: z.string().trim().min(2),
  level_id: z.string().uuid().optional(),
  level_en: z.string().optional(),
  level_ar: z.string().optional(),
  employment_type: z.enum(["full_time", "part_time", "hourly", "hybrid", "remote"]).optional(),
  type_en: z.string().trim().min(2),
  type_ar: z.string().trim().min(2),
  salary_en: z.string().optional(),
  salary_ar: z.string().optional(),
  summary_en: z.string().optional(),
  summary_ar: z.string().optional(),
  skills: z.array(z.string()).default([]),
});

export type DirectAdResult =
  | {
      ok: true;
      id: string;
      status: "pending_approval" | "draft";
      amountDue: number;
      currency: string;
    }
  | { ok: false; reason: "already_registered" };

/**
 * Saves one guest vacancy. No subscription and no registration is created —
 * the ad is owned by a non-registered client record (no invitation, no
 * password, cannot sign in) so the existing Jobs / Applications / CV systems
 * keep working unchanged. Publication happens only after admin approval.
 */
export const createDirectAd = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => directAdSchema.parse(input))
  .handler(async ({ data }): Promise<DirectAdResult> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // Price and payment status are decided on the server only.
    const pricing = await readPricing(supabaseAdmin);
    if (!pricing.available) throw new Error("Direct ads are currently unavailable.");

    // Server-side eligibility: registered companies must use their account.
    const found = await findExistingClient(supabaseAdmin, {
      email: data.email,
      mobile: data.mobile,
      cr_number: data.cr_number,
    });
    if (found.registered) return { ok: false, reason: "already_registered" };

    const { data: prof, error: profErr } = await supabaseAdmin
      .from("professions")
      .select("group_id")
      .eq("id", data.profession_id)
      .maybeSingle();
    if (profErr) throw new Error(profErr.message);
    if (!prof) throw new Error("Profession not found");

    const email = normEmail(data.email);
    // Duplicate clients are reused (matched by email / mobile / CR above).
    let ownerId = found.ownerId;
    if (!ownerId) {
      const { data: created, error: crErr } = await supabaseAdmin.auth.admin.createUser({
        email,
        email_confirm: false,
        user_metadata: {
          account_type: "company",
          full_name: data.company_name,
          direct_ad_client: true,
        },
      });
      if (crErr || !created?.user)
        throw new Error(crErr?.message ?? "Could not create the client record");
      ownerId = created.user.id;
    }

    const {
      profession_id,
      company_name,
      contact_person,
      mobile,
      cv_email,
      company_country,
      company_city,
      company_info,
      cr_number,
      email: _email,
      ...job
    } = data;

    const paid = pricing.amountDue <= 0;
    const { data: inserted, error } = await supabaseAdmin
      .from("job_postings")
      .insert({
        user_id: ownerId,
        profession_id,
        group_id: prof.group_id,
        // Nothing is published before an admin approves it.
        status: paid ? "pending_approval" : "draft",
        data: {
          ...job,
          submitted_at: new Date().toISOString(),
          direct_ad: true,
          approval: { status: "pending_approval" },
          client: {
            company_name,
            contact_person,
            mobile,
            cv_email,
            account_email: email,
            cr_number: cr_number ?? null,
            country: company_country ?? null,
            city: company_city ?? null,
            info: company_info ?? null,
          },
          payment: {
            amount: pricing.amountDue,
            currency: pricing.currency,
            tax_percent: pricing.taxPercent,
            status: paid ? "not_required" : "pending",
          },
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
      } as any)
      .select("id, status")
      .single();
    if (error) throw new Error(error.message);

    return {
      ok: true,
      id: inserted.id as string,
      status: inserted.status as "pending_approval" | "draft",
      amountDue: pricing.amountDue,
      currency: pricing.currency,
    };
  });

// ---------------------------------------------------------------------------
// Admin approval queue (reuses the existing admin role check + job_postings)
// ---------------------------------------------------------------------------

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function assertAdmin(supabase: any, userId: string) {
  const { data: isAdmin } = await supabase.rpc("has_role", { _user_id: userId, _role: "admin" });
  if (!isAdmin) throw new Error("Forbidden");
}

export type DirectAdRow = {
  id: string;
  status: string;
  created_at: string;
  published_at: string | null;
  closes_at: string | null;
  views: number;
  title_en: string;
  title_ar: string;
  city: string;
  country: string;
  salary: string;
  company_name: string;
  contact_person: string;
  contact_email: string;
  cv_email: string;
  mobile: string;
  payment_status: string;
  payment_amount: number;
  payment_currency: string;
  rejection_reason: string | null;
};

const str = (v: unknown) => (typeof v === "string" ? v : "");

/** Every direct ad, newest first — admin only. */
export const listDirectAds = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<DirectAdRow[]> => {
    await assertAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin
      .from("job_postings")
      .select("id, status, created_at, published_at, closes_at, views, data")
      .order("created_at", { ascending: false })
      .limit(300);
    if (error) throw new Error(error.message);
    return (data ?? [])
      .filter((r) => (r.data as Record<string, unknown> | null)?.["direct_ad"] === true)
      .map((r) => {
        const d = (r.data ?? {}) as Record<string, unknown>;
        const client = (d["client"] ?? {}) as Record<string, unknown>;
        const payment = (d["payment"] ?? {}) as Record<string, unknown>;
        const approval = (d["approval"] ?? {}) as Record<string, unknown>;
        return {
          id: r.id as string,
          status: String(r.status),
          created_at: r.created_at as string,
          published_at: r.published_at as string | null,
          closes_at: r.closes_at as string | null,
          views: Number(r.views ?? 0),
          title_en: str(d["title_en"]),
          title_ar: str(d["title_ar"]),
          city: str(d["city_en"]) || str(d["city_ar"]),
          country: str(d["country_en"]) || str(d["country_ar"]),
          salary: str(d["salary_en"]) || str(d["salary_ar"]),
          company_name: str(client["company_name"]),
          contact_person: str(client["contact_person"]),
          contact_email: str(client["account_email"]),
          cv_email: str(client["cv_email"]),
          mobile: str(client["mobile"]),
          payment_status: str(payment["status"]) || "pending",
          payment_amount: Number(payment["amount"] ?? 0),
          payment_currency: str(payment["currency"]) || "SAR",
          rejection_reason: str(approval["reason"]) || null,
        };
      });
  });

/**
 * Approve (publish) or reject a direct ad. The publication date is the
 * approval date and the ad expires after the configured Direct Ad duration.
 */
export const reviewDirectAd = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        jobPostingId: z.string().uuid(),
        decision: z.enum(["approve", "reject"]),
        reason: z.string().trim().max(500).optional(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: row, error: getErr } = await supabaseAdmin
      .from("job_postings")
      .select("data, user_id")
      .eq("id", data.jobPostingId)
      .maybeSingle();
    if (getErr) throw new Error(getErr.message);
    if (!row) throw new Error("Ad not found");
    const adData = (row.data ?? {}) as Record<string, unknown>;
    if (!adData["direct_ad"]) throw new Error("Not a direct ad");
    const payment = (adData["payment"] ?? {}) as Record<string, unknown>;
    if (
      data.decision === "approve" &&
      !["paid", "not_required"].includes(String(payment["status"]))
    ) {
      throw new Error("Payment is not verified yet.");
    }

    const now = new Date();
    const pricing = await readPricing(supabaseAdmin);
    const months = pricing.validityMonths ?? 1;
    const closes = new Date(now);
    closes.setMonth(closes.getMonth() + months);

    const approval = {
      status: data.decision === "approve" ? "approved" : "rejected",
      at: now.toISOString(),
      by: context.userId,
      reason: data.reason ?? null,
    };

    const patch =
      data.decision === "approve"
        ? {
            status: "published",
            published_at: now.toISOString(),
            closes_at: closes.toISOString(),
            data: { ...adData, approval },
          }
        : { status: "rejected", data: { ...adData, approval } };

    const { error } = await supabaseAdmin
      .from("job_postings")
      .update(patch as Database["public"]["Tables"]["job_postings"]["Update"])
      .eq("id", data.jobPostingId);
    if (error) throw new Error(error.message);

    await supabaseAdmin.from("app_notifications").insert({
      user_id: row.user_id as string,
      type: data.decision === "approve" ? "direct_ad_approved" : "direct_ad_rejected",
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      payload: { jobPostingId: data.jobPostingId, approval } as any,
    });

    return { ok: true, status: patch.status };
  });

/**
 * Publishes a paid direct ad after the payment is verified.
 * Only an admin (or an internal payment webhook using the same check) may call
 * this — the frontend can never mark its own ad as paid.
 */
export const confirmDirectAdPayment = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        jobPostingId: z.string().uuid(),
        paymentReference: z.string().trim().min(3).max(120),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: isAdmin } = await supabase.rpc("has_role", {
      _user_id: userId,
      _role: "admin",
    });
    if (!isAdmin) throw new Error("Forbidden");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: row, error: getErr } = await supabaseAdmin
      .from("job_postings")
      .select("data, user_id")
      .eq("id", data.jobPostingId)
      .maybeSingle();
    if (getErr) throw new Error(getErr.message);
    if (!row) throw new Error("Ad not found");
    const adData = (row.data ?? {}) as Record<string, unknown>;
    if (!adData.direct_ad) throw new Error("Not a direct ad");

    const payment = { ...((adData.payment as Record<string, unknown>) ?? {}) };
    payment.status = "paid";
    payment.reference = data.paymentReference;
    payment.paid_at = new Date().toISOString();

    const { error } = await supabaseAdmin
      .from("job_postings")
      // Verified payment only moves the ad into the approval queue.
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      .update({ status: "pending_approval", data: { ...adData, payment } as any })
      .eq("id", data.jobPostingId);
    if (error) throw new Error(error.message);

    await supabaseAdmin.from("app_notifications").insert({
      user_id: row.user_id as string,
      type: "direct_ad_payment_verified",
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      payload: { jobPostingId: data.jobPostingId, payment } as any,
    });
    return { ok: true };
  });

// ---------------------------------------------------------------------------
// Client uploads a CV received outside the platform
// ---------------------------------------------------------------------------

const normalizePhone = (v: string) => v.replace(/[^\d]/g, "").replace(/^0+/, "");

const addCvSchema = z.object({
  jobPostingId: z.string().uuid(),
  fullName: z.string().trim().min(2).max(200),
  email: z.string().trim().email().max(200),
  phone: z.string().trim().min(5).max(40),
  profession: z.string().trim().max(160).optional(),
  cvStoragePath: z.string().trim().min(1).max(800),
  cvFileName: z.string().trim().max(300).optional(),
});

export type AddCvResult =
  | { ok: true; applicationId: string; candidateCreated: boolean; invited: boolean }
  | { ok: false; reason: "already_applied"; applicationId: string };

export const addReceivedCvToMyJob = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => addCvSchema.parse(input))
  .handler(async ({ data, context }): Promise<AddCvResult> => {
    const { supabase, userId } = context;
    await assertCompanyAccount(supabase, userId);

    // Ownership is verified server-side (RLS also scopes this read).
    const { data: job, error: jErr } = await supabase
      .from("job_postings")
      .select("id, user_id, data")
      .eq("id", data.jobPostingId)
      .eq("user_id", userId)
      .maybeSingle();
    if (jErr) throw new Error(jErr.message);
    if (!job) throw new Error("Forbidden");

    const email = data.email.trim().toLowerCase();
    const phone = normalizePhone(data.phone);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // --- Candidate de-duplication: email first, then normalized mobile ---
    let candidateId: string | null = null;
    const { data: byEmail } = await supabaseAdmin
      .from("profiles")
      .select("id, cv_url")
      .eq("email", email)
      .maybeSingle();
    if (byEmail) candidateId = byEmail.id as string;

    if (!candidateId && phone) {
      const { data: phoneRows } = await supabaseAdmin
        .from("profiles")
        .select("id, phone")
        .not("phone", "is", null)
        .limit(2000);
      const match = (phoneRows ?? []).find((p) => normalizePhone(String(p.phone ?? "")) === phone);
      if (match) candidateId = match.id as string;
    }

    let candidateCreated = false;
    let invited = false;
    if (!candidateId) {
      // Minimum onboarding record + secure invitation. No password is ever created.
      const { data: created, error: invErr } = await supabaseAdmin.auth.admin.inviteUserByEmail(
        email,
        {
          data: { account_type: "job_seeker", full_name: data.fullName },
        },
      );
      if (invErr || !created?.user)
        throw new Error(invErr?.message ?? "Could not invite candidate");
      candidateId = created.user.id;
      candidateCreated = true;
      invited = true;
    }

    // Prefill / complete the reused job-seeker profile without overwriting data.
    const patch: Record<string, unknown> = { email };
    const { data: existingProfile } = await supabaseAdmin
      .from("profiles")
      .select("full_name, phone, profession, cv_url")
      .eq("id", candidateId)
      .maybeSingle();
    if (!existingProfile?.full_name) patch.full_name = data.fullName;
    if (!existingProfile?.phone) patch.phone = data.phone.trim();
    if (!existingProfile?.profession && data.profession) patch.profession = data.profession;
    if (!existingProfile?.cv_url) {
      patch.cv_url = data.cvStoragePath;
      patch.cv_uploaded_at = new Date().toISOString();
    }

    await supabaseAdmin
      .from("profiles")
      .update(patch as Database["public"]["Tables"]["profiles"]["Update"])
      .eq("id", candidateId);

    // --- Duplicate application guard for the same vacancy ---
    const { data: existingApp } = await supabaseAdmin
      .from("job_applications")
      .select("id")
      .eq("candidate_id", candidateId)
      .eq("job_posting_id", data.jobPostingId)
      .maybeSingle();
    if (existingApp) {
      return { ok: false, reason: "already_applied", applicationId: existingApp.id as string };
    }

    const jobData = (job.data ?? {}) as Record<string, unknown>;
    const now = new Date().toISOString();
    const { data: app, error: appErr } = await supabaseAdmin
      .from("job_applications")
      .insert({
        candidate_id: candidateId,
        employer_id: userId,
        job_posting_id: data.jobPostingId,
        job_snapshot: {
          title: (jobData.title_en as string | undefined) ?? null,
          title_ar: (jobData.title_ar as string | undefined) ?? null,
          country: (jobData.country_en as string | undefined) ?? null,
          city: (jobData.city_en as string | undefined) ?? null,
        },
        candidate_snapshot: {
          full_name: data.fullName,
          email,
          phone: data.phone.trim(),
          profession: data.profession ?? null,
          added_by_employer: true,
        },
        cv_url: data.cvStoragePath,
        status: "cv_sent",
        status_history: [{ status: "cv_sent", at: now, by: "employer" }],
      })
      .select("id")
      .single();
    if (appErr) throw new Error(appErr.message);

    await supabaseAdmin.from("app_notifications").insert([
      {
        user_id: userId,
        type: "cv_added_by_employer",
        payload: {
          applicationId: app.id,
          jobPostingId: data.jobPostingId,
          candidate: { full_name: data.fullName, email },
          cvFileName: data.cvFileName ?? null,
        },
      },
      {
        user_id: candidateId,
        type: invited ? "profile_invitation" : "application_added_for_you",
        payload: { applicationId: app.id, jobPostingId: data.jobPostingId },
      },
    ]);

    return { ok: true, applicationId: app.id as string, candidateCreated, invited };
  });
