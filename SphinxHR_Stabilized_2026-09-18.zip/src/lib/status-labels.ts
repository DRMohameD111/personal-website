import { tx } from "@/i18n";

/** Bilingual labels for the existing `application_status` enum values. */
export const APPLICATION_STATUS_LABELS: Record<string, ReturnType<typeof tx>> = {
  submitted: tx("Submitted", "تم التقديم"),
  cv_sent: tx("CV Sent", "تم إرسال السيرة الذاتية"),
  employer_reviewed: tx("Under Review", "قيد المراجعة"),
  shortlisted: tx("Shortlisted", "القائمة المختصرة"),
  rejected: tx("Rejected", "مرفوض"),
  hired: tx("Hired", "تم التعيين"),
};

export const applicationStatusLabel = (status: string) =>
  APPLICATION_STATUS_LABELS[status] ?? tx(status, status);

/** Bilingual labels for the existing `job_posting_status` enum values. */
export const JOB_STATUS_LABELS: Record<string, ReturnType<typeof tx>> = {
  published: tx("Published", "منشورة"),
  paused: tx("Paused", "متوقفة مؤقتاً"),
  closed: tx("Closed", "مغلقة"),
};

export const jobStatusLabel = (status: string) => JOB_STATUS_LABELS[status] ?? tx(status, status);
