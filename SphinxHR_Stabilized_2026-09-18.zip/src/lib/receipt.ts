// ---------------------------------------------------------------------------
// Package Confirmation Card / Receipt — pure presentation logic.
// Every value shown on a card, ticket or receipt is produced by the server
// from stored subscription data. This module only formats and labels it; it
// never computes a commercial amount and never trusts browser input.
// ---------------------------------------------------------------------------
import { tx, type Lang } from "@/i18n";
import { formatDate, formatMoney } from "./subscriptions";

export type PaymentState = "paid" | "partial" | "awaiting_payment" | "free";

export interface ReceiptFeature {
  labelEn: string;
  labelAr: string;
  valueEn: string;
  valueAr: string;
}

/** Verified receipt payload — produced only by `getPackageReceipt`. */
export interface PackageReceipt {
  subscriptionId: string;
  receiptNumber: string;
  packageCode: string | null;
  companyName: string | null;
  companyCode: string | null;
  contactName: string | null;
  email: string | null;
  nameEn: string;
  nameAr: string;
  status: string;
  changeType: string | null;
  isTrial: boolean;
  durationMonths: number | null;
  currency: string;
  listPrice: number;
  discount: number;
  creditApplied: number;
  amountDue: number;
  amountPaid: number;
  outstanding: number;
  paymentState: PaymentState;
  paymentReference: string | null;
  paymentDate: string | null;
  startedAt: string;
  expiresAt: string | null;
  remainingDays: number | null;
  features: ReceiptFeature[];
  generatedAt: string;
}

/**
 * Receipt number is derived from the immutable package code, so the same
 * subscription always yields the same receipt reference (no duplicates, no
 * renumbering on reprint). Subscriptions without a code fall back to the id.
 */
export function receiptNumber(packageCode: string | null, subscriptionId: string): string {
  return `RCPT-${(packageCode ?? subscriptionId.replace(/-/g, "").slice(0, 12)).toUpperCase()}`;
}

export function paymentState(amountDue: number, amountPaid: number): PaymentState {
  if (amountDue <= 0) return "free";
  if (amountPaid >= amountDue) return "paid";
  return amountPaid > 0 ? "partial" : "awaiting_payment";
}

export function paymentStateLabel(state: PaymentState) {
  switch (state) {
    case "paid":
      return tx("Paid", "مدفوعة");
    case "partial":
      return tx("Partially paid", "مدفوعة جزئياً");
    case "free":
      return tx("No payment required", "لا يتطلب سداد");
    default:
      return tx("Awaiting payment", "بانتظار السداد");
  }
}

export const receiptFileName = (r: PackageReceipt, lang: Lang) =>
  `${lang === "ar" ? "ايصال" : "receipt"}-${r.receiptNumber}`;

const esc = (s: string) =>
  s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

/**
 * Email-safe (table based, inline styles) version of the confirmation card.
 * Financial figures are already verified when they reach this function.
 */
export function receiptEmailHtml(r: PackageReceipt, lang: Lang, link?: string): string {
  const isAr = lang === "ar";
  const pick = (en: string, ar: string) => (isAr ? ar : en);
  const money = (n: number) => formatMoney(n, r.currency, lang);
  const ps = paymentStateLabel(r.paymentState);
  const rows: Array<[string, string]> = [
    [pick("Package", "الباقة"), pick(r.nameEn, r.nameAr)],
    [pick("Package code", "كود الباقة"), r.packageCode ?? "—"],
    [pick("Receipt number", "رقم الإيصال"), r.receiptNumber],
    [pick("Start date", "تاريخ البداية"), formatDate(r.startedAt, lang)],
    [pick("End date", "تاريخ الانتهاء"), formatDate(r.expiresAt, lang)],
    [pick("Package value", "قيمة الباقة"), money(r.amountDue)],
    [pick("Amount paid", "المبلغ المدفوع"), money(r.amountPaid)],
    [pick("Outstanding", "المبلغ المتبقي"), money(r.outstanding)],
    [pick("Payment status", "حالة السداد"), pick(ps.en, ps.ar)],
    [pick("Payment reference", "مرجع السداد"), r.paymentReference ?? "—"],
  ];
  return `<!doctype html><html lang="${lang}" dir="${isAr ? "rtl" : "ltr"}"><body style="margin:0;background:#F7F4EC;padding:24px;font-family:Arial,Helvetica,sans-serif;color:#1F2933;">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;margin:0 auto;background:#FFFFFF;border:1px solid #E5C875;border-radius:12px;overflow:hidden;">
<tr><td style="background:#172033;padding:20px 24px;color:#FFFFFF;">
<div style="font-size:12px;letter-spacing:3px;color:#E5C875;text-transform:uppercase;">SPHINX WORKFORCE</div>
<div style="font-size:20px;font-weight:bold;margin-top:6px;">${esc(pick("Package Confirmation", "تأكيد الباقة"))}</div>
</td></tr>
<tr><td style="padding:20px 24px;">
<p style="margin:0 0 16px;font-size:14px;">${esc(
    pick(
      `Dear ${r.companyName ?? "customer"}, your package has been confirmed.`,
      `عميلنا ${r.companyName ?? "الكريم"}، تم تأكيد باقتك بنجاح.`,
    ),
  )}</p>
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="font-size:13px;border-collapse:collapse;">
${rows
  .map(
    ([k, v], i) =>
      `<tr style="background:${i % 2 ? "#FAF8F2" : "#FFFFFF"};"><td style="padding:8px 10px;color:#6B7280;">${esc(k)}</td><td style="padding:8px 10px;font-weight:bold;text-align:${isAr ? "left" : "right"};">${esc(v)}</td></tr>`,
  )
  .join("")}
</table>
${
  link
    ? `<p style="margin:20px 0 0;"><a href="${esc(link)}" style="background:#C89B3C;color:#FFFFFF;text-decoration:none;padding:10px 18px;border-radius:8px;font-size:13px;display:inline-block;">${esc(
        pick("View / print receipt", "عرض / طباعة الإيصال"),
      )}</a></p>`
    : ""
}
<p style="margin:18px 0 0;font-size:11px;color:#6B7280;">${esc(
    pick(
      "This confirmation reflects verified payment data recorded in your account.",
      "يعكس هذا التأكيد بيانات السداد الموثقة والمسجلة في حسابك.",
    ),
  )}</p>
</td></tr></table></body></html>`;
}
