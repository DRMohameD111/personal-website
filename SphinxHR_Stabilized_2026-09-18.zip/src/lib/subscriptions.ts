// ---------------------------------------------------------------------------
// Subscription / package-change domain logic.
// Pure functions only — shared by the server functions (source of truth) and
// by the UI for display. The server ALWAYS recomputes with database values;
// nothing here is trusted when it arrives from the browser.
// ---------------------------------------------------------------------------
import { tx, type Lang } from "@/i18n";
import type { Database } from "@/integrations/supabase/types";
import { effectivePrice, type PackageRow } from "./packages";

export type { PackageRow };
export type SubscriptionRow = Database["public"]["Tables"]["subscriptions"]["Row"];
export type ChangeRequestRow = Database["public"]["Tables"]["package_change_requests"]["Row"];
export type SubscriptionPolicy = Database["public"]["Tables"]["subscription_policy"]["Row"];

export type ChangeType = "new" | "upgrade" | "downgrade" | "renewal";
export type PackageStatus =
  | "pending"
  | "awaiting_payment"
  | "scheduled"
  | "active"
  | "expired"
  | "cancelled"
  | "failed";

export const PACKAGE_STATUSES: PackageStatus[] = [
  "pending",
  "awaiting_payment",
  "scheduled",
  "active",
  "expired",
  "cancelled",
  "failed",
];

export const isPackageStatus = (v: unknown): v is PackageStatus =>
  typeof v === "string" && (PACKAGE_STATUSES as string[]).includes(v);

export function statusLabel(status: string) {
  switch (status) {
    case "pending":
      return tx("Pending", "قيد الانتظار");
    case "awaiting_payment":
      return tx("Awaiting payment", "بانتظار السداد");
    case "scheduled":
      return tx("Scheduled", "مجدولة");
    case "active":
      return tx("Active", "سارية");
    case "expired":
      return tx("Expired", "منتهية");
    case "cancelled":
      return tx("Cancelled", "ملغاة");
    case "failed":
      return tx("Failed", "فاشلة");
    default:
      return tx(status, status);
  }
}

export function changeTypeLabel(type: string) {
  switch (type) {
    case "upgrade":
      return tx("Upgrade", "ترقية الباقة");
    case "downgrade":
      return tx("Downgrade", "تخفيض الباقة");
    case "renewal":
      return tx("Renewal", "تجديد الباقة");
    default:
      return tx("New subscription", "اشتراك جديد");
  }
}

/**
 * Upgrade / downgrade is decided from the stable internal package rank,
 * never from a client-supplied `change_type` nor from a translated name.
 */
export function classifyChange(
  currentRank: number | null,
  newRank: number,
  allowSamePackageRenewal: boolean,
): { type: ChangeType } | { error: "same_package" } {
  if (currentRank == null) return { type: "new" };
  if (newRank > currentRank) return { type: "upgrade" };
  if (newRank < currentRank) return { type: "downgrade" };
  return allowSamePackageRenewal ? { type: "renewal" } : { error: "same_package" };
}

/** Package code prefix comes from stable configuration, not display names. */
export const packagePrefix = (p: Pick<PackageRow, "code_prefix" | "slug">): string =>
  (p.code_prefix || p.slug.charAt(0)).toUpperCase();

export const PACKAGE_CODE_RE = /^[A-Z]{1,4}-[A-Z0-9]{2,12}-\d{4}-\d{4,}$/;

/** Mirrors the database generator — used by tests and for display only. */
export function buildPackageCode(
  prefix: string,
  companyCode: string,
  at: Date,
  serial: number,
): string {
  const mm = String(at.getUTCMonth() + 1).padStart(2, "0");
  const yy = String(at.getUTCFullYear() % 100).padStart(2, "0");
  return `${prefix.toUpperCase()}-${companyCode.toUpperCase()}-${mm}${yy}-${String(serial).padStart(4, "0")}`;
}

/** Month arithmetic that clamps the day like Postgres does (31 Aug + 3m = 30 Nov). */
export function addMonths(from: Date, months: number): Date {
  const day = from.getUTCDate();
  const d = new Date(from.getTime());
  d.setUTCDate(1);
  d.setUTCMonth(d.getUTCMonth() + months);
  const lastDay = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 0)).getUTCDate();
  d.setUTCDate(Math.min(day, lastDay));
  return d;
}

export function expectedEndDate(start: Date, durationMonths: number | null): Date | null {
  return durationMonths == null ? null : addMonths(start, durationMonths);
}

export function remainingDays(expiresAt: string | null, now = Date.now()): number | null {
  if (!expiresAt) return null;
  return Math.max(0, Math.ceil((Date.parse(expiresAt) - now) / 86_400_000));
}

const round2 = (n: number) => Math.round(n * 100) / 100;

/** Unused value of the current subscription, prorated by remaining time. */
export function proratedCredit(
  sub: Pick<SubscriptionRow, "price_paid" | "started_at" | "expires_at"> | null,
  now = Date.now(),
): number {
  if (!sub || !sub.expires_at) return 0;
  const start = Date.parse(sub.started_at);
  const end = Date.parse(sub.expires_at);
  const total = end - start;
  if (!(total > 0)) return 0;
  const left = Math.min(Math.max(end - now, 0), total);
  return round2(Math.max(Number(sub.price_paid) || 0, 0) * (left / total));
}

export interface QuoteInput {
  pkg: PackageRow;
  current: SubscriptionRow | null;
  policy: Pick<
    SubscriptionPolicy,
    "prorate_credit" | "tax_percent" | "downgrade_timing" | "upgrade_timing"
  >;
  changeType: ChangeType;
  now?: number;
}

export interface Quote {
  changeType: ChangeType;
  currency: string;
  listPrice: number;
  amountBeforeCredit: number;
  discount: number;
  creditApplied: number;
  tax: number;
  amountDue: number;
  effectiveDate: string;
  proposedStart: string;
  proposedEnd: string | null;
  currentEnd: string | null;
  requiresPayment: boolean;
  isTrial: boolean;
}

/**
 * Single commercial calculator. Amounts are derived only from the database
 * package row, the stored subscription and the admin policy.
 */
export function quoteChange({
  pkg,
  current,
  policy,
  changeType,
  now = Date.now(),
}: QuoteInput): Quote {
  const listPrice = Math.max(Number(pkg.price) || 0, 0);
  const effective = Math.max(effectivePrice(pkg, now), 0);
  const discount = round2(Math.max(listPrice - effective, 0));

  const scheduleAtEndOfTerm =
    changeType === "downgrade" &&
    policy.downgrade_timing === "end_of_term" &&
    !!current?.expires_at;

  const effectiveDate = scheduleAtEndOfTerm
    ? new Date(Date.parse(current!.expires_at!))
    : new Date(now);
  const start = new Date(Math.max(effectiveDate.getTime(), now));

  // Credit only makes sense when the new package replaces unused paid time.
  const creditApplied =
    policy.prorate_credit && changeType === "upgrade" ? proratedCredit(current, now) : 0;

  const net = Math.max(round2(effective - Math.min(creditApplied, effective)), 0);
  const tax = round2((net * (Number(policy.tax_percent) || 0)) / 100);
  const amountDue = round2(net + tax);
  const isTrial = pkg.trial_enabled && pkg.trial_days > 0 && amountDue === 0;
  const end = expectedEndDate(start, pkg.duration_months);

  return {
    changeType,
    currency: pkg.currency,
    listPrice,
    amountBeforeCredit: round2(effective),
    discount,
    creditApplied: round2(Math.min(creditApplied, effective)),
    tax,
    amountDue,
    effectiveDate: effectiveDate.toISOString(),
    proposedStart: start.toISOString(),
    proposedEnd: end ? end.toISOString() : null,
    currentEnd: current?.expires_at ?? null,
    requiresPayment: amountDue > 0,
    isTrial,
  };
}

export function formatMoney(amount: number, currency: string, lang: Lang): string {
  return `${Number(amount).toLocaleString(lang === "ar" ? "ar-SA" : "en-US", {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  })} ${currency}`;
}

export function formatDate(value: string | null | undefined, lang: Lang): string {
  if (!value) return "—";
  return new Date(value).toLocaleDateString(lang === "ar" ? "ar-EG" : "en-GB", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}
