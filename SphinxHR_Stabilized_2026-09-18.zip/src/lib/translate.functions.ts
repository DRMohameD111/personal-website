import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { translateText } from "./translate.server";

const TranslateInput = z.object({
  text: z.string().min(1).max(4000),
  direction: z.enum(["ar->en", "en->ar"]),
});

export const translateField = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => TranslateInput.parse(input))
  .handler(async ({ data }) => ({
    text: await translateText(data.text, data.direction),
  }));
