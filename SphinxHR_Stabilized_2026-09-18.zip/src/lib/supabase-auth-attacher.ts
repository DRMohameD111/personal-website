import { createMiddleware } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";

// Skew (seconds) before actual expiry at which we proactively refresh the
// session. Without this, a token that expires while the tab is idle is sent
// as-is and the server rejects it with:
//   {"error":"InvalidJWT","message":"\"exp\" claim timestamp check failed"}
const EXPIRY_SKEW_SECONDS = 60;

async function freshAccessToken(): Promise<string | undefined> {
  const { data } = await supabase.auth.getSession();
  const session = data.session;
  if (!session) return undefined;

  const expiresAt = session.expires_at ?? 0;
  const nowSeconds = Math.floor(Date.now() / 1000);

  if (expiresAt - nowSeconds > EXPIRY_SKEW_SECONDS) {
    return session.access_token;
  }

  const { data: refreshed, error } = await supabase.auth.refreshSession();
  if (error || !refreshed.session) {
    // Refresh token is dead too — drop the stale session so the auth gate
    // sends the user to /auth instead of looping on 400 InvalidJWT.
    await supabase.auth.signOut();
    return undefined;
  }
  return refreshed.session.access_token;
}

/**
 * Client-side bearer attacher that guarantees a non-expired access token.
 * Registered as a global `functionMiddleware` in `src/start.ts`.
 */
export const attachFreshSupabaseAuth = createMiddleware({ type: "function" }).client(
  async ({ next }) => {
    const token = await freshAccessToken();
    return next({
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    });
  },
);
