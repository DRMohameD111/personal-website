const GATEWAY = "https://ai.gateway.lovable.dev/v1/chat/completions";

export type TranslateDirection = "ar->en" | "en->ar";

const SYSTEM = `You are a professional HR/recruitment translator for a Gulf-region workforce platform.
Translate the user's text between Arabic and English.
Rules:
- Produce natural, professional recruitment/HR wording — never a literal word-for-word rendering.
- Preserve exactly: numbers, salary amounts, dates, job codes, abbreviations, company names,
  product/technology names (e.g. SAP S/4HANA, AutoCAD, React), certification names and proper names.
- Keep the same structure (line breaks, bullet markers, commas as separators).
- Return ONLY the translated text. No quotes, no notes, no explanations.`;

export async function translateText(text: string, direction: TranslateDirection): Promise<string> {
  const key = process.env["LOVABLE_API_KEY"];
  if (!key) throw new Error("Translation service is not configured");

  const target = direction === "ar->en" ? "English" : "Arabic";
  const res = await fetch(GATEWAY, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: "google/gemini-2.5-flash",
      messages: [
        { role: "system", content: SYSTEM },
        { role: "user", content: `Translate into ${target}:\n\n${text}` },
      ],
    }),
  });

  if (!res.ok) {
    const body = await res.text().catch(() => "");
    let message = body;
    try {
      message = JSON.parse(body)?.error?.message || JSON.parse(body)?.message || body;
    } catch {
      /* keep raw body */
    }
    if (res.status === 429)
      throw new Error(message || "Translation rate limit reached, try again shortly");
    if (res.status === 402) throw new Error(message || "AI credits exhausted for this workspace");
    if (res.status === 403)
      throw new Error(message || "Translation is blocked by workspace policy");
    throw new Error(message || `Translation failed (${res.status})`);
  }

  const json = (await res.json()) as {
    choices?: Array<{ message?: { content?: string } }>;
  };
  const out = json.choices?.[0]?.message?.content?.trim();
  if (!out) throw new Error("Translation service returned an empty result");
  return out;
}
