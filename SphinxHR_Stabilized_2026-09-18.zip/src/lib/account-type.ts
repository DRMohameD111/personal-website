import { redirect } from "@tanstack/react-router";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { tx } from "@/i18n";

/**
 * The platform supports exactly two account types.
 * `job_seeker` = اصحاب المهارات, `company` = دخول الشركات.
 */
export type AccountType = "job_seeker" | "company";

export const ACCOUNT_TYPES: AccountType[] = ["job_seeker", "company"];

export const ACCOUNT_TYPE_LABELS: Record<AccountType, ReturnType<typeof tx>> = {
  job_seeker: tx("Individual – Job Seeker", "اصحاب المهارات"),
  company: tx("Company Client – Job Poster", "دخول الشركات"),
};

export const COMPANY_ONLY_MESSAGE = tx(
  "This page is available to company accounts only.",
  "هذه الصفحة متاحة لحسابات الشركات فقط.",
);

export function isAccountType(value: unknown): value is AccountType {
  return value === "job_seeker" || value === "company";
}

/** Reads the signed-in user's account type from their profile. */
export async function getMyAccountType(): Promise<AccountType | null> {
  const { data: userData } = await supabase.auth.getUser();
  if (!userData.user) return null;
  const { data } = await supabase
    .from("profiles")
    .select("account_type")
    .eq("id", userData.user.id)
    .maybeSingle();
  return isAccountType(data?.account_type) ? data.account_type : null;
}

/** True when the signed-in user holds the `admin` role (user_roles table). */
export async function isAdminUser(): Promise<boolean> {
  const { data: userData } = await supabase.auth.getUser();
  if (!userData.user) return false;
  const { data } = await supabase
    .from("user_roles")
    .select("role")
    .eq("user_id", userData.user.id)
    .eq("role", "admin")
    .maybeSingle();
  return !!data;
}

export const ADMIN_ONLY_MESSAGE = tx(
  "This page is available to administrators only.",
  "هذه الصفحة متاحة للمشرفين فقط.",
);

/** Route guard for the admin control panel. */
export async function requireAdminAccount() {
  if (!(await isAdminUser())) {
    toast.error(
      typeof document !== "undefined" && document.documentElement.lang === "ar"
        ? ADMIN_ONLY_MESSAGE.ar
        : ADMIN_ONLY_MESSAGE.en,
    );
    throw redirect({ to: "/account" });
  }
  return true;
}

/**
 * Route guard for company-only pages. Job seekers are sent back to their own area.
 */
export async function requireCompanyAccount() {
  const accountType = await getMyAccountType();
  if (accountType !== "company") {
    toast.error(
      typeof document !== "undefined" && document.documentElement.lang === "ar"
        ? COMPANY_ONLY_MESSAGE.ar
        : COMPANY_ONLY_MESSAGE.en,
    );
    throw redirect({ to: "/job-seekers" });
  }
  return accountType;
}
