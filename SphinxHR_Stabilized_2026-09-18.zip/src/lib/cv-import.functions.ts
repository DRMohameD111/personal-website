import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { assertCompanyAccount } from "./account-type.server";

/**
 * External CV import, candidate de-duplication and candidate recommendations.
 * Everything reuses the existing structures: the private `cvs` storage bucket,
 * `profiles` (registered job seekers), `external_candidates` (imported CVs that
 * merge into `profiles` on registration), `job_postings`, `subscriptions`
 * (package limits) and `cv_access_log` (download usage).
 */

const normEmail = (v: string | null | undefined) => (v ?? "").trim().toLowerCase() || null;
const normPhone = (v: string | null | undefined) =>
  (v ?? "").replace(/[^\d]/g, "").replace(/^0+/, "") || null;

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function assertAdmin(supabase: any, userId: string) {
  const { data } = await supabase.rpc("has_role", { _user_id: userId, _role: "admin" });
  if (data !== true) throw new Error("Forbidden");
}

// ---------------------------------------------------------------------------
// 1. Admin — import an external CV
// ---------------------------------------------------------------------------

export type ImportResult = {
  outcome: "created" | "updated" | "linked_registered";
  candidateId: string;
  name: string | null;
  email: string | null;
  jobTitle: string | null;
  skills: string[];
};

export const importExternalCv = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        storagePath: z.string().trim().min(1).max(800),
        fileName: z.string().trim().min(1).max(300),
        mimeType: z.string().trim().max(200).default("application/pdf"),
      })
      .parse(input),
  )
  .handler(async ({ data, context }): Promise<ImportResult> => {
    const { supabase, userId } = context;
    await assertAdmin(supabase, userId);

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { extractCvFields } = await import("./cv-import.server");

    const file = await supabaseAdmin.storage.from("cvs").download(data.storagePath);
    if (file.error || !file.data) throw new Error(file.error?.message ?? "CV file not found");
    const bytes = new Uint8Array(await file.data.arrayBuffer());
    const cv = await extractCvFields(bytes, data.mimeType, data.fileName);

    const email = normEmail(cv.email);
    const phone = normPhone(cv.phone);
    const now = new Date().toISOString();

    // --- de-duplication against REGISTERED job seekers first ----------------
    let registered: { id: string; cv_url: string | null } | null = null;
    if (email) {
      const { data: p } = await supabaseAdmin
        .from("profiles")
        .select("id, cv_url")
        .eq("account_type", "job_seeker")
        .ilike("email", email)
        .maybeSingle();
      if (p) registered = { id: p.id, cv_url: p.cv_url };
    }
    if (!registered && phone) {
      const { data: rows } = await supabaseAdmin
        .from("profiles")
        .select("id, phone, cv_url")
        .eq("account_type", "job_seeker")
        .not("phone", "is", null)
        .limit(5000);
      const hit = (rows ?? []).find((r) => normPhone(r.phone) === phone);
      if (hit) registered = { id: hit.id, cv_url: hit.cv_url };
    }

    if (registered) {
      // A registered profile always wins. Only fill what is still empty.
      if (!registered.cv_url) {
        await supabaseAdmin
          .from("profiles")
          .update({ cv_url: data.storagePath, cv_uploaded_at: now })
          .eq("id", registered.id);
      }
      await supabaseAdmin.from("candidate_merge_log").insert({
        profile_id: registered.id,
        matched_on: email ? "email" : "phone",
        changes: { imported_cv: data.fileName, linked_cv: !registered.cv_url },
      });
      return {
        outcome: "linked_registered",
        candidateId: registered.id,
        name: cv.full_name,
        email: cv.email,
        jobTitle: cv.job_title,
        skills: cv.skills,
      };
    }

    // --- de-duplication against previously imported CVs ---------------------
    let existingId: string | null = null;
    if (email) {
      const { data: e } = await supabaseAdmin
        .from("external_candidates")
        .select("id")
        .eq("status", "active")
        .eq("email_norm", email)
        .maybeSingle();
      if (e) existingId = e.id;
    }
    if (!existingId && phone) {
      const { data: e } = await supabaseAdmin
        .from("external_candidates")
        .select("id")
        .eq("status", "active")
        .eq("phone_norm", phone)
        .maybeSingle();
      if (e) existingId = e.id;
    }

    const row = {
      candidate_source: "external_cv",
      status: "active",
      full_name: cv.full_name,
      email: cv.email,
      phone: cv.phone,
      nationality: cv.nationality,
      location: cv.location,
      job_title: cv.job_title,
      career_level: cv.career_level,
      experience_years: cv.experience_years,
      experience_text: cv.experience_text,
      education: cv.education,
      skills: cv.skills,
      languages: cv.languages,
      certifications: cv.certifications,
      cv_storage_path: data.storagePath,
      cv_file_name: data.fileName,
      imported_by: userId,
      source_updated_at: now,
    };

    if (existingId) {
      // Keep the latest imported version — one record per candidate.
      const { error } = await supabaseAdmin
        .from("external_candidates")
        .update(row)
        .eq("id", existingId);
      if (error) throw new Error(error.message);
      return {
        outcome: "updated",
        candidateId: existingId,
        name: cv.full_name,
        email: cv.email,
        jobTitle: cv.job_title,
        skills: cv.skills,
      };
    }

    const { data: created, error } = await supabaseAdmin
      .from("external_candidates")
      .insert(row)
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    return {
      outcome: "created",
      candidateId: created.id,
      name: cv.full_name,
      email: cv.email,
      jobTitle: cv.job_title,
      skills: cv.skills,
    };
  });

// ---------------------------------------------------------------------------
// 2. Admin — imported CV list
// ---------------------------------------------------------------------------

export type ExternalCandidateRow = {
  id: string;
  name: string | null;
  email: string | null;
  phone: string | null;
  jobTitle: string | null;
  careerLevel: string | null;
  experienceYears: number | null;
  location: string | null;
  skills: string[];
  status: string;
  importedAt: string;
  hasCv: boolean;
};

export const listExternalCandidates = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<ExternalCandidateRow[]> => {
    const { supabase, userId } = context;
    await assertAdmin(supabase, userId);
    const { data, error } = await supabase
      .from("external_candidates")
      .select(
        "id, full_name, email, phone, job_title, career_level, experience_years, location, skills, status, created_at, cv_storage_path",
      )
      .order("created_at", { ascending: false })
      .limit(200);
    if (error) throw new Error(error.message);
    return (data ?? []).map((r) => ({
      id: r.id,
      name: r.full_name,
      email: r.email,
      phone: r.phone,
      jobTitle: r.job_title,
      careerLevel: r.career_level,
      experienceYears: r.experience_years,
      location: r.location,
      skills: r.skills ?? [],
      status: r.status,
      importedAt: r.created_at,
      hasCv: !!r.cv_storage_path,
    }));
  });

// ---------------------------------------------------------------------------
// 4. Company — candidate recommendations for one of its jobs
// ---------------------------------------------------------------------------

export type CandidateSuggestion = {
  key: string;
  kind: "registered" | "external";
  name: string | null;
  jobTitle: string | null;
  careerLevel: string | null;
  experience: string | null;
  skills: string[];
  location: string | null;
  education: string | null;
  hasCv: boolean;
  score: number;
};

export type RecommendationResult = {
  jobTitle: string | null;
  limit: number;
  total: number;
  candidates: CandidateSuggestion[];
  downloadsUsed: number;
  downloadLimit: number;
};

type Limits = { recommendations: number; downloads: number };

const DEFAULT_LIMITS: Limits = { recommendations: 5, downloads: 3 };

/** Package limits come from the verified active subscription snapshot. */
async function packageLimits(
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  admin: any,
  userId: string,
): Promise<Limits> {
  const { data: sub } = await admin
    .from("subscriptions")
    .select("package_snapshot, status, expires_at")
    .eq("user_id", userId)
    .eq("status", "active")
    .order("started_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  if (!sub) return DEFAULT_LIMITS;
  const features = (sub.package_snapshot?.features ?? []) as Array<Record<string, unknown>>;
  const read = (key: string, fallback: number) => {
    const f = features.find((x) => x["feature_key"] === key);
    if (!f) return fallback;
    if (f["value_type"] === "unlimited") return Number.MAX_SAFE_INTEGER;
    const n = Number(f["value_number"]);
    return Number.isFinite(n) && n > 0 ? n : fallback;
  };
  return {
    recommendations: read("cv_recommendations", 20),
    downloads: read("cv_downloads", 20),
  };
}

const words = (v: unknown) =>
  String(v ?? "")
    .toLowerCase()
    .split(/[^a-z0-9\u0600-\u06FF]+/)
    .filter((w) => w.length > 2);

function scoreCandidate(
  req: {
    title: string[];
    skills: string[];
    level: string[];
    location: string[];
    education: string[];
  },
  c: {
    jobTitle: string | null;
    skills: string[];
    careerLevel: string | null;
    location: string | null;
    education: string | null;
  },
) {
  const overlap = (a: string[], b: string[]) => a.filter((x) => b.includes(x)).length;
  let s = 0;
  s += overlap(req.title, words(c.jobTitle)) * 3;
  s += overlap(req.skills, c.skills.flatMap(words)) * 2;
  s += overlap(req.level, words(c.careerLevel)) * 2;
  s += overlap(req.location, words(c.location));
  s += overlap(req.education, words(c.education));
  return s;
}

export const recommendCandidatesForJob = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ jobPostingId: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }): Promise<RecommendationResult> => {
    const { supabase, userId } = context;
    await assertCompanyAccount(supabase, userId);

    // Ownership is verified server-side, never trusted from the client.
    const { data: job, error: jErr } = await supabase
      .from("job_postings")
      .select("id, user_id, data")
      .eq("id", data.jobPostingId)
      .eq("user_id", userId)
      .maybeSingle();
    if (jErr) throw new Error(jErr.message);
    if (!job) throw new Error("Forbidden");

    const jd = (job.data ?? {}) as Record<string, unknown>;
    const req = {
      title: [...words(jd["title_en"]), ...words(jd["title_ar"])],
      skills: (Array.isArray(jd["skills"]) ? (jd["skills"] as string[]) : []).flatMap(words),
      level: [...words(jd["level_en"]), ...words(jd["level_ar"])],
      location: [...words(jd["city_en"]), ...words(jd["country_en"])],
      education: words(jd["education_en"] ?? jd["education"]),
    };

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const limits = await packageLimits(supabaseAdmin, userId);

    const [{ data: seekers }, { data: externals }] = await Promise.all([
      supabaseAdmin
        .from("profiles")
        .select("id, full_name, profession, country, education, languages, cv_url")
        .eq("account_type", "job_seeker")
        .limit(1000),
      supabaseAdmin
        .from("external_candidates")
        .select(
          "id, full_name, job_title, career_level, experience_years, experience_text, location, education, skills, cv_storage_path",
        )
        .eq("status", "active")
        .limit(1000),
    ]);

    const pool: CandidateSuggestion[] = [
      ...(seekers ?? []).map((p) => ({
        key: `registered:${p.id}`,
        kind: "registered" as const,
        name: p.full_name,
        jobTitle: p.profession,
        careerLevel: null,
        experience: null,
        skills: [],
        location: p.country,
        education: p.education,
        hasCv: !!p.cv_url,
        score: 0,
      })),
      ...(externals ?? []).map((e) => ({
        key: `external:${e.id}`,
        kind: "external" as const,
        name: e.full_name,
        jobTitle: e.job_title,
        careerLevel: e.career_level,
        experience:
          e.experience_years != null ? `${e.experience_years}` : (e.experience_text ?? null),
        skills: e.skills ?? [],
        location: e.location,
        education: e.education,
        hasCv: !!e.cv_storage_path,
        score: 0,
      })),
    ].map((c) => ({ ...c, score: scoreCandidate(req, c) }));

    const ranked = pool.filter((c) => c.score > 0).sort((a, b) => b.score - a.score);

    const since = new Date(Date.now() - 30 * 24 * 3600 * 1000).toISOString();
    const { count } = await supabaseAdmin
      .from("cv_access_log")
      .select("id", { count: "exact", head: true })
      .eq("company_id", userId)
      .gte("created_at", since);

    return {
      jobTitle: (jd["title_en"] as string | undefined) ?? null,
      limit: limits.recommendations,
      total: ranked.length,
      candidates: ranked.slice(0, limits.recommendations),
      downloadsUsed: count ?? 0,
      downloadLimit: limits.downloads,
    };
  });

// ---------------------------------------------------------------------------
// 5. Company — open a recommended candidate CV (package + validity enforced)
// ---------------------------------------------------------------------------

export const getRecommendedCandidateCv = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        jobPostingId: z.string().uuid(),
        candidateKey: z.string().regex(/^(registered|external):[0-9a-f-]{36}$/),
      })
      .parse(input),
  )
  .handler(async ({ data, context }): Promise<{ url: string; fileName: string }> => {
    const { supabase, userId } = context;
    await assertCompanyAccount(supabase, userId);

    const { data: job } = await supabase
      .from("job_postings")
      .select("id, user_id, status, closes_at")
      .eq("id", data.jobPostingId)
      .eq("user_id", userId)
      .maybeSingle();
    if (!job) throw new Error("Forbidden");
    const expired =
      job.status !== "published" || (job.closes_at ? new Date(job.closes_at) <= new Date() : false);
    if (expired) throw new Error("This vacancy is no longer active, CV access is closed.");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const limits = await packageLimits(supabaseAdmin, userId);
    const since = new Date(Date.now() - 30 * 24 * 3600 * 1000).toISOString();
    const { count } = await supabaseAdmin
      .from("cv_access_log")
      .select("id", { count: "exact", head: true })
      .eq("company_id", userId)
      .gte("created_at", since);
    if ((count ?? 0) >= limits.downloads)
      throw new Error("Your package CV download limit is reached.");

    const [kind, id] = data.candidateKey.split(":") as ["registered" | "external", string];
    let path: string | null = null;
    if (kind === "registered") {
      const { data: p } = await supabaseAdmin
        .from("profiles")
        .select("cv_url")
        .eq("id", id)
        .maybeSingle();
      path = p?.cv_url ?? null;
    } else {
      const { data: e } = await supabaseAdmin
        .from("external_candidates")
        .select("cv_storage_path")
        .eq("id", id)
        .eq("status", "active")
        .maybeSingle();
      path = e?.cv_storage_path ?? null;
    }
    if (!path) throw new Error("CV not available");

    const fileName = path.substring(path.lastIndexOf("/") + 1);
    const { isInlineViewable } = await import("@/lib/open-file");
    const signed = await supabaseAdmin.storage
      .from("cvs")
      .createSignedUrl(path, 300, isInlineViewable(fileName) ? undefined : { download: fileName });
    if (signed.error || !signed.data?.signedUrl) throw new Error("Could not open the CV");

    await supabaseAdmin.from("cv_access_log").insert({
      company_id: userId,
      profile_id: kind === "registered" ? id : null,
      external_candidate_id: kind === "external" ? id : null,
      job_posting_id: data.jobPostingId,
    });

    return { url: signed.data.signedUrl, fileName };
  });
