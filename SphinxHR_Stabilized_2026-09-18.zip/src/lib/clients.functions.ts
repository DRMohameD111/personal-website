import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { clientSchema, normalizeEmail, normalizeWebsite, type ClientRecord } from "./clients";

const COLUMNS =
  "id, client_code, name, nature_of_business, nature_of_business_other, nationality_code, legal_structure, hq_country_code, hq_city, branches_count, official_email, website, cr_number, contact_person, contact_phone, notes, created_at, updated_at";

export const listClients = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<ClientRecord[]> => {
    const { data, error } = await context.supabase
      .from("clients")
      .select(COLUMNS)
      .eq("owner_id", context.userId)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return (data ?? []) as unknown as ClientRecord[];
  });

/** Duplicate detection before creating a client (name / email / CR / code). */
export const findClientDuplicates = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z
      .object({
        name: z.string().trim().default(""),
        official_email: z.string().trim().default(""),
        cr_number: z.string().trim().default(""),
        client_code: z.string().trim().default(""),
      })
      .parse(d),
  )
  .handler(async ({ context, data }): Promise<ClientRecord[]> => {
    const or: string[] = [];
    if (data.name) or.push(`name.ilike.${data.name.replace(/[,()]/g, "")}`);
    if (data.official_email) or.push(`official_email.eq.${normalizeEmail(data.official_email)}`);
    if (data.cr_number) or.push(`cr_number.eq.${data.cr_number}`);
    if (data.client_code) or.push(`client_code.eq.${data.client_code}`);
    if (or.length === 0) return [];
    const { data: rows, error } = await context.supabase
      .from("clients")
      .select(COLUMNS)
      .eq("owner_id", context.userId)
      .or(or.join(","));
    if (error) throw new Error(error.message);
    return (rows ?? []) as unknown as ClientRecord[];
  });

/** Create or update a client — one save function for every client surface. */
export const saveClient = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => clientSchema.parse(d))
  .handler(async ({ context, data }): Promise<ClientRecord> => {
    const payload = {
      owner_id: context.userId,
      client_code: data.client_code || null,
      name: data.name.trim(),
      nature_of_business: data.nature_of_business,
      nature_of_business_other: data.nature_of_business_other || null,
      nationality_code: data.nationality_code,
      legal_structure: data.legal_structure,
      hq_country_code: data.hq_country_code,
      hq_city: data.hq_city || null,
      branches_count: data.branches_count,
      official_email: normalizeEmail(data.official_email),
      website: data.website ? normalizeWebsite(data.website) : null,
      cr_number: data.cr_number || null,
      contact_person: data.contact_person || null,
      contact_phone: data.contact_phone || null,
      notes: data.notes || null,
    };

    const query = data.id
      ? context.supabase
          .from("clients")
          .update(payload)
          .eq("id", data.id)
          .eq("owner_id", context.userId)
          .select(COLUMNS)
          .single()
      : context.supabase.from("clients").insert(payload).select(COLUMNS).single();

    const { data: row, error } = await query;
    if (error) {
      if (
        error.code === "23505" ||
        error.code === "23000" ||
        /duplicate key/i.test(error.message)
      ) {
        throw new Error("duplicate_client");
      }
      throw new Error(error.message);
    }
    return row as unknown as ClientRecord;
  });

export type ManpowerRequest = {
  id: string;
  client_id: string;
  client_name: string;
  job_category: string;
  required_quantity: number;
  nationality_required: string | null;
  salary_range: string | null;
  work_location: string | null;
  contract_duration: string | null;
  required_experience: string | null;
  notes: string | null;
  status: string;
  created_at: string;
};

export const listManpowerRequests = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<ManpowerRequest[]> => {
    const { data, error } = await context.supabase
      .from("manpower_requests")
      .select(
        "id, client_id, job_category, required_quantity, nationality_required, salary_range, work_location, contract_duration, required_experience, notes, status, created_at, clients(name)",
      )
      .eq("owner_id", context.userId)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return (data ?? []).map((r) => {
      const { clients, ...rest } = r as typeof r & { clients: { name: string } | null };
      return { ...rest, client_name: clients?.name ?? "—" } as ManpowerRequest;
    });
  });

export const createManpowerRequest = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z
      .object({
        client_id: z.string().uuid(),
        job_category: z.string().trim().min(1).max(120),
        required_quantity: z.coerce.number().int().min(1).max(100000),
        nationality_required: z.string().trim().max(120).optional().or(z.literal("")),
        salary_range: z.string().trim().max(120).optional().or(z.literal("")),
        work_location: z.string().trim().max(160).optional().or(z.literal("")),
        contract_duration: z.string().trim().max(120).optional().or(z.literal("")),
        required_experience: z.string().trim().max(160).optional().or(z.literal("")),
        notes: z.string().trim().max(2000).optional().or(z.literal("")),
      })
      .parse(d),
  )
  .handler(async ({ context, data }) => {
    const { error, data: row } = await context.supabase
      .from("manpower_requests")
      .insert({
        owner_id: context.userId,
        client_id: data.client_id,
        job_category: data.job_category,
        required_quantity: data.required_quantity,
        nationality_required: data.nationality_required || null,
        salary_range: data.salary_range || null,
        work_location: data.work_location || null,
        contract_duration: data.contract_duration || null,
        required_experience: data.required_experience || null,
        notes: data.notes || null,
      })
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    return { id: row!.id as string };
  });
