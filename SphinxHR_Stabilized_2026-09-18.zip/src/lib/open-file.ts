/**
 * Shared file-opening helper for signed storage links (CVs, documents).
 *
 * A script-called `window.open()` after an `await` loses the user gesture and is
 * silently blocked by browsers. Clicking a real anchor is never blocked.
 * Office files cannot be rendered in a tab, so they are delivered as downloads.
 */

/** Extensions a browser can display inline. */
const INLINE_EXT = ["pdf", "png", "jpg", "jpeg", "gif", "webp", "svg", "txt"];

export function fileExtension(nameOrPath: string | null | undefined): string {
  if (!nameOrPath) return "";
  const clean = nameOrPath.split("?")[0]!.split("#")[0]!;
  const base = clean.substring(clean.lastIndexOf("/") + 1);
  const dot = base.lastIndexOf(".");
  return dot === -1 ? "" : base.slice(dot + 1).toLowerCase();
}

/** True when the browser can show the file in a tab instead of downloading it. */
export function isInlineViewable(nameOrPath: string | null | undefined): boolean {
  return INLINE_EXT.includes(fileExtension(nameOrPath));
}

/** Open a signed URL: new tab for viewable types, download otherwise. */
export function openSignedFile(url: string, fileName?: string | null) {
  const inline = isInlineViewable(fileName ?? url);
  const a = document.createElement("a");
  a.href = url;
  a.rel = "noopener noreferrer";
  if (inline) {
    a.target = "_blank";
  } else if (fileName) {
    a.download = fileName;
  }
  a.style.display = "none";
  document.body.appendChild(a);
  a.click();
  a.remove();
}
