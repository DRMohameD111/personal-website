// ---------------------------------------------------------------------------
// Package-controlled candidate features.
// Pure, client-safe helpers. The stored package snapshot on the active
// subscription is the single source of truth (the same `package_features`
// records the admin edits and the pricing page shows) — nothing here is
// trusted when it arrives from the browser; every protected read re-checks
// these values on the server.
// ---------------------------------------------------------------------------
import { tx } from "@/i18n";

export const CANDIDATE_FEATURES = [
  "professional_profile",
  "interview_video",
  "certificates",
  "cv_download",
  "candidate_contact",
] as const;

export type CandidateFeature = (typeof CANDIDATE_FEATURES)[number];

export const CANDIDATE_FEATURE_LABELS: Record<CandidateFeature, ReturnType<typeof tx>> = {
  professional_profile: tx("Professional Candidate Profile", "الملف الاحترافي للمرشح"),
  interview_video: tx("Interview Video", "فيديو المقابلة"),
  certificates: tx("Certificates", "الشهادات"),
  cv_download: tx("CV Download", "تنزيل السيرة الذاتية"),
  candidate_contact: tx("Candidate Contact", "بيانات التواصل مع المرشح"),
};

/** Shape of one feature row inside a package snapshot (or `package_features`). */
export type SnapshotFeature = {
  feature_key?: unknown;
  value_type?: unknown;
  value_bool?: unknown;
  value_number?: unknown;
  enabled?: unknown;
};

export type CandidateAccess = Record<CandidateFeature, boolean>;

export const NO_ACCESS: CandidateAccess = {
  professional_profile: false,
  interview_video: false,
  certificates: false,
  cv_download: false,
  candidate_contact: false,
};

export const FULL_ACCESS: CandidateAccess = {
  professional_profile: true,
  interview_video: true,
  certificates: true,
  cv_download: true,
  candidate_contact: true,
};

function find(features: SnapshotFeature[], key: string): SnapshotFeature | undefined {
  return features.find((f) => String(f.feature_key ?? "") === key);
}

/** A feature is granted only when it exists, is enabled and carries a positive value. */
export function featureAllowed(features: SnapshotFeature[], key: CandidateFeature): boolean {
  const f = find(features, key);
  if (!f) return false;
  if (f.enabled === false) return false;
  switch (String(f.value_type ?? "boolean")) {
    case "boolean":
      return f.value_bool === true;
    case "number":
      return Number(f.value_number) > 0;
    case "unlimited":
      return true;
    default:
      return true;
  }
}

export function candidateAccessFrom(features: SnapshotFeature[]): CandidateAccess {
  return {
    professional_profile: featureAllowed(features, "professional_profile"),
    interview_video: featureAllowed(features, "interview_video"),
    certificates: featureAllowed(features, "certificates"),
    cv_download: featureAllowed(features, "cv_download"),
    candidate_contact: featureAllowed(features, "candidate_contact"),
  };
}

/** Thrown/returned message used by the UI to show the upgrade state. */
export const PACKAGE_REQUIRED = "PACKAGE_REQUIRED";

export const GENDERS = ["male", "female"] as const;
export type Gender = (typeof GENDERS)[number];

export const GENDER_LABELS: Record<Gender, ReturnType<typeof tx>> = {
  male: tx("Male", "ذكر"),
  female: tx("Female", "أنثى"),
};

export const isGender = (v: unknown): v is Gender =>
  typeof v === "string" && (GENDERS as readonly string[]).includes(v);
