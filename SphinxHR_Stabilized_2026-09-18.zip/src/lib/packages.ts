// ---------------------------------------------------------------------------
// Packages / Pricing — single source of truth.
// The public Pricing page and the Admin Control Panel both read and write the
// same `packages` + `package_features` tables (no hard-coded pricing anywhere).
// ---------------------------------------------------------------------------
import { supabase } from "@/integrations/supabase/client";
import { tx, type Lang } from "@/i18n";
import type { Database } from "@/integrations/supabase/types";

export type PackageRow = Database["public"]["Tables"]["packages"]["Row"];
export type PackageFeatureRow = Database["public"]["Tables"]["package_features"]["Row"];
export type FeatureValueType = "boolean" | "number" | "unlimited" | "text";

export interface PackageWithFeatures extends PackageRow {
  features: PackageFeatureRow[];
}

export const BILLING_PERIODS = [
  { value: "monthly", label: tx("Monthly", "شهرياً") },
  { value: "quarterly", label: tx("Quarterly", "كل 3 أشهر") },
  { value: "yearly", label: tx("Yearly", "سنوياً") },
  { value: "one_time", label: tx("One time", "دفعة واحدة") },
  { value: "custom", label: tx("Custom", "مخصص") },
] as const;

export const FEATURE_VALUE_TYPES = [
  { value: "boolean", label: tx("Yes / No", "نعم / لا") },
  { value: "number", label: tx("Number", "رقم") },
  { value: "unlimited", label: tx("Unlimited", "غير محدود") },
  { value: "text", label: tx("Text", "نص") },
] as const;

// ---- reads ---------------------------------------------------------------

/** Public reads: RLS already hides inactive / out-of-window packages. */
export async function fetchPublicPackages(): Promise<PackageWithFeatures[]> {
  const [pkgs, feats] = await Promise.all([
    supabase.from("packages").select("*").order("sort_order", { ascending: true }),
    supabase.from("package_features").select("*").order("sort_order", { ascending: true }),
  ]);
  if (pkgs.error) throw pkgs.error;
  if (feats.error) throw feats.error;
  return (pkgs.data ?? []).map((p) => ({
    ...p,
    features: (feats.data ?? []).filter((f) => f.package_id === p.id),
  }));
}

/** Admin reads: the admin policy returns every row, including inactive ones. */
export const fetchAllPackages = fetchPublicPackages;

// ---- writes (admin only — enforced by RLS) --------------------------------

export type PackageInput = Database["public"]["Tables"]["packages"]["Insert"];
export type FeatureInput = Database["public"]["Tables"]["package_features"]["Insert"];

export async function savePackage(input: PackageInput): Promise<PackageRow> {
  const previous = input.id
    ? (await supabase.from("packages").select("*").eq("id", input.id).maybeSingle()).data
    : null;

  const { data, error } = await supabase
    .from("packages")
    .upsert(input, { onConflict: "id" })
    .select("*")
    .single();
  if (error) throw error;

  // Only one primary recommended package.
  if (data.is_recommended) {
    await supabase.from("packages").update({ is_recommended: false }).neq("id", data.id);
  }

  await logPackageChange(data, previous ? "update" : "create", previous);
  return data;
}

export async function setPackageActive(pkg: PackageRow, active: boolean) {
  const { error } = await supabase.from("packages").update({ is_active: active }).eq("id", pkg.id);
  if (error) throw error;
  await logPackageChange({ ...pkg, is_active: active }, active ? "activate" : "deactivate", pkg);
}

export async function saveFeature(input: FeatureInput) {
  const { error } = await supabase.from("package_features").upsert(input, { onConflict: "id" });
  if (error) throw error;
}

export async function deleteFeature(id: string) {
  const { error } = await supabase.from("package_features").delete().eq("id", id);
  if (error) throw error;
}

// ---- audit trail (admin-only reads) --------------------------------------

const AUDITED_FIELDS: (keyof PackageRow)[] = [
  "price",
  "promo_price",
  "price_after_trial",
  "currency",
  "duration_months",
  "trial_enabled",
  "trial_days",
  "trial_starts_at",
  "trial_ends_at",
  "display_start_at",
  "display_end_at",
  "is_active",
  "is_free",
  "is_recommended",
  "sort_order",
];

async function logPackageChange(pkg: PackageRow, action: string, previous: PackageRow | null) {
  const changes: Record<string, { from: string | null; to: string | null }> = {};
  const str = (v: unknown) => (v == null ? null : String(v));
  for (const key of AUDITED_FIELDS) {
    const before = previous ? previous[key] : null;
    if (!previous || before !== pkg[key]) changes[key] = { from: str(before), to: str(pkg[key]) };
  }
  const { data: auth } = await supabase.auth.getUser();
  await supabase.from("package_audit_log").insert({
    package_id: pkg.id,
    package_slug: pkg.slug,
    admin_user_id: auth.user?.id ?? null,
    admin_email: auth.user?.email ?? null,
    action,
    changes,
  });
}

export async function fetchPackageAuditLog(limit = 25) {
  const { data, error } = await supabase
    .from("package_audit_log")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(limit);
  if (error) throw error;
  return data ?? [];
}

// ---- display helpers -----------------------------------------------------

export const FREE_LABEL = tx("Free", "مجاني");
export const UNLIMITED_LABEL = tx("Unlimited", "غير محدود");
export const CONTACT_LABEL = tx("Contact Us", "تواصل معنا");

export function pick(lang: Lang, en: string | null, ar: string | null): string {
  return (lang === "ar" ? ar || en : en || ar) ?? "";
}

/** Promotional price is used only while the promotion window is open. */
export function effectivePrice(p: PackageRow, now = Date.now()): number {
  if (p.promo_price == null) return Number(p.price);
  const startsOk = !p.promo_starts_at || Date.parse(p.promo_starts_at) <= now;
  const endsOk = !p.promo_ends_at || Date.parse(p.promo_ends_at) >= now;
  return startsOk && endsOk ? Number(p.promo_price) : Number(p.price);
}

export function trialActive(p: PackageRow, now = Date.now()): boolean {
  if (!p.trial_enabled || p.trial_days <= 0) return false;
  if (p.trial_starts_at && Date.parse(p.trial_starts_at) > now) return false;
  if (p.trial_ends_at && Date.parse(p.trial_ends_at) < now) return false;
  return true;
}

export function trialLabel(p: PackageRow, lang: Lang): string | null {
  if (!trialActive(p)) return null;
  const months = Math.round(p.trial_days / 30);
  if (months >= 1)
    return lang === "ar"
      ? `مجانية لمدة ${months} أشهر`
      : `Free for ${months} month${months > 1 ? "s" : ""}`;
  return lang === "ar" ? `مجانية لمدة ${p.trial_days} يوم` : `Free for ${p.trial_days} days`;
}

export function durationLabel(p: PackageRow, lang: Lang): string {
  const custom = pick(lang, p.duration_label_en, p.duration_label_ar);
  if (custom) return custom;
  if (!p.duration_months) return lang === "ar" ? "مخصصة" : "Custom";
  return lang === "ar" ? `${p.duration_months} أشهر` : `${p.duration_months} months`;
}

export function priceLabel(p: PackageRow, lang: Lang): string {
  if (p.contact_instead_of_price || !p.show_price)
    return lang === "ar" ? "تواصل معنا" : "Contact Us";
  const amount = effectivePrice(p);
  if (p.is_free || amount <= 0) return lang === "ar" ? "مجاني" : "Free";
  return `${amount.toLocaleString(lang === "ar" ? "ar-SA" : "en-US")} ${p.currency}`;
}

export function featureValueLabel(f: PackageFeatureRow, lang: Lang): string {
  switch (f.value_type as FeatureValueType) {
    case "boolean":
      return f.value_bool ? (lang === "ar" ? "نعم" : "Yes") : lang === "ar" ? "لا" : "—";
    case "number":
      return f.value_number == null ? "—" : Number(f.value_number).toLocaleString();
    case "unlimited":
      return lang === "ar" ? "غير محدود" : "Unlimited";
    default:
      return pick(lang, f.value_text_en, f.value_text_ar) || "—";
  }
}

/** Union of feature keys across packages, ordered — powers the comparison table. */
export function comparisonRows(pkgs: PackageWithFeatures[], lang: Lang) {
  const rows = new Map<string, { key: string; label: string; order: number }>();
  for (const p of pkgs) {
    for (const f of p.features) {
      if (!f.enabled) continue;
      if (!rows.has(f.feature_key))
        rows.set(f.feature_key, {
          key: f.feature_key,
          label: pick(lang, f.label_en, f.label_ar),
          order: f.sort_order,
        });
    }
  }
  return [...rows.values()].sort((a, b) => a.order - b.order || a.label.localeCompare(b.label));
}
