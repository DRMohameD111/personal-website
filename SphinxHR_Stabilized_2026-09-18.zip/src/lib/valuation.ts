// ---------------------------------------------------------------------------
// Job status + automatic Job Valuation.
// Single source of truth: reuses the existing job_postings status/date fields,
// the existing job_applications records (applicant count) and the existing
// company profile (portal valuation, company type, branches).
// ---------------------------------------------------------------------------
import { tx } from "@/i18n";
import type { BiLabel } from "@/lib/sectors";
import { supabase } from "@/integrations/supabase/client";
import type { Job } from "@/lib/jobs";

// ---- Job state (derived from the existing status + dates) ------------------

export type JobState = "draft" | "active" | "closing_soon" | "closed" | "archived" | "paused";

export const JOB_STATE_LABELS: Record<JobState, BiLabel> = {
  draft: tx("Draft", "مسودة"),
  active: tx("Active", "متاحة"),
  closing_soon: tx("Closing Soon", "قرب انتهاء التقديم"),
  closed: tx("Closed", "مغلقة"),
  archived: tx("Archived", "مؤرشفة"),
  paused: tx("Paused", "متوقفة مؤقتاً"),
};

export const jobStateLabel = (s: JobState): BiLabel => JOB_STATE_LABELS[s];

export const JOB_STATE_TONE: Record<JobState, string> = {
  draft: "bg-muted text-muted-foreground border-border",
  active: "bg-emerald-500/15 text-emerald-700 border-emerald-500/30",
  closing_soon: "bg-primary/15 text-gold-dark border-primary/40",
  closed: "bg-muted text-muted-foreground border-border",
  archived: "bg-muted text-muted-foreground border-border",
  paused: "bg-amber-500/15 text-amber-700 border-amber-500/30",
};

export const DAY_MS = 86_400_000;
export const CLOSING_SOON_DAYS = 7;

/** Closing date = publication date + 1 calendar month (never derived from updates). */
export function closingDate(publishedAt: string | null | undefined): string | null {
  if (!publishedAt) return null;
  const d = new Date(publishedAt);
  if (Number.isNaN(d.getTime())) return null;
  const c = new Date(d);
  c.setMonth(c.getMonth() + 1);
  return c.toISOString();
}

export function daysRemaining(
  closesAt: string | null | undefined,
  now = Date.now(),
): number | null {
  if (!closesAt) return null;
  const diff = Date.parse(closesAt) - now;
  if (Number.isNaN(diff)) return null;
  return Math.max(0, Math.ceil(diff / DAY_MS));
}

/**
 * Derives the displayed status from the stored status + publication/closing
 * dates. "Closing Soon" is a derived view of an active job (no duplicate field).
 */
export function deriveJobState(
  input: { status?: string | null; publishedAt?: string | null; closesAt?: string | null },
  now = Date.now(),
): JobState {
  const status = (input.status ?? "published").toLowerCase();
  if (status === "archived") return "archived";
  if (status === "closed" || status === "expired") return "closed";
  if (status === "draft" || status === "pending_approval" || status === "rejected") return "draft";
  if (status === "paused") return "paused";
  const closes = input.closesAt ?? closingDate(input.publishedAt);
  if (!input.publishedAt) return "draft";
  if (closes && Date.parse(closes) <= now) return "closed";
  const left = daysRemaining(closes, now);
  if (left !== null && left <= CLOSING_SOON_DAYS) return "closing_soon";
  return "active";
}

/** Jobs that still accept applications. */
export const acceptsApplications = (state: JobState) =>
  state === "active" || state === "closing_soon";

/** Statuses a job seeker may normally see in search results. */
export const isPubliclyListed = (state: JobState) => acceptsApplications(state);

// ---- Company evaluation ---------------------------------------------------

export const PORTAL_VALUATION_LABELS: Record<number, BiLabel> = {
  1: tx("Basic", "ضعيف"),
  2: tx("Below Average", "مقبول"),
  3: tx("Good", "جيد"),
  4: tx("Very Good", "جيد جداً"),
  5: tx("Excellent", "ممتاز"),
};

export const COMPANY_TYPES: { value: 1 | 2 | 3; factor: number; label: BiLabel }[] = [
  {
    value: 1,
    factor: 1,
    label: tx("Sole Establishment or Partnership", "مؤسسة فردية أو شركة أشخاص / شراكة"),
  },
  { value: 2, factor: 2, label: tx("Limited Partnership", "شركة توصية بسيطة") },
  { value: 3, factor: 3, label: tx("Joint Stock Company", "شركة مساهمة") },
];

export const companyTypeFactor = (type: number | null | undefined) =>
  COMPANY_TYPES.find((c) => c.value === type)?.factor ?? 1;

export const companyTypeLabel = (type: number | null | undefined): BiLabel =>
  COMPANY_TYPES.find((c) => c.value === type)?.label ?? COMPANY_TYPES[0]!.label;

/** Maps the existing client legal structure onto the company type scale. */
export const LEGAL_STRUCTURE_TO_COMPANY_TYPE: Record<string, 1 | 2 | 3> = {
  sole_proprietorship: 1,
  general_partnership: 1,
  limited_partnership: 2,
  joint_stock: 3,
};

/** Normalised branch bands — a huge branch count cannot distort the valuation. */
export function branchFactor(branches: number | null | undefined): number {
  const n = Math.max(0, Math.floor(branches ?? 1));
  if (n <= 1) return 1.0;
  if (n <= 3) return 1.2;
  if (n <= 6) return 1.5;
  if (n <= 10) return 1.8;
  return 2.0;
}

const MAX_RAW = 5 * 2.0 * 3; // portal 5 × branch 2.0 × type 3

export type CompanyInputs = {
  portalValuation?: number | null;
  companyType?: number | null;
  branchesCount?: number | null;
};

export function companyRawScore(c: CompanyInputs): number {
  const portal = Math.min(5, Math.max(1, c.portalValuation ?? 3));
  return portal * branchFactor(c.branchesCount) * companyTypeFactor(c.companyType);
}

/** Company Score, normalised to 0–100. */
export function companyScore(c: CompanyInputs): number {
  return clamp((companyRawScore(c) / MAX_RAW) * 100);
}

const clamp = (n: number, min = 0, max = 100) => Math.min(max, Math.max(min, n));

// ---- Salary evaluation ----------------------------------------------------

export type SalaryRange = { min: number | null; max: number | null; midpoint: number | null };

/** Parses the existing salary text (e.g. "SAR 18,000 – 24,000"). */
export function parseSalary(text: string | null | undefined): SalaryRange {
  if (!text) return { min: null, max: null, midpoint: null };
  const nums = (text.match(/[\d][\d,،.\s]*/g) ?? [])
    .map((s) => Number(s.replace(/[^\d]/g, "")))
    .filter((n) => Number.isFinite(n) && n > 0);
  if (nums.length === 0) return { min: null, max: null, midpoint: null };
  const min = Math.min(...nums);
  const max = Math.max(...nums);
  return { min, max, midpoint: (min + max) / 2 };
}

export type SalaryBenchmark = {
  id: string;
  job_category: string;
  sector: string | null;
  career_level: string | null;
  country: string | null;
  currency: string;
  benchmark_amount: number;
  salary_period: string;
};

const norm = (v: string | null | undefined) => (v ?? "").trim().toLowerCase();

/** Most specific benchmark for this job title / sector / level / location. */
export function findBenchmark(
  benchmarks: SalaryBenchmark[],
  job: { profession: BiLabel; sector: string; level: BiLabel; country: BiLabel },
): SalaryBenchmark | null {
  let best: SalaryBenchmark | null = null;
  let bestScore = -1;
  for (const b of benchmarks) {
    const cat = norm(b.job_category);
    const matchesCat =
      cat === norm(job.profession.en) ||
      cat === norm(job.profession.ar) ||
      cat === norm(job.sector);
    if (!matchesCat) continue;
    let score = 1;
    if (b.sector) {
      if (norm(b.sector) !== norm(job.sector)) continue;
      score += 1;
    }
    if (b.career_level) {
      if (
        norm(b.career_level) !== norm(job.level.en) &&
        norm(b.career_level) !== norm(job.level.ar)
      )
        continue;
      score += 1;
    }
    if (b.country) {
      if (norm(b.country) !== norm(job.country.en) && norm(b.country) !== norm(job.country.ar))
        continue;
      score += 1;
    }
    if (score > bestScore) {
      best = b;
      bestScore = score;
    }
  }
  return best;
}

/** Salary Score bands (percentage of the benchmark). */
export function salaryScore(midpoint: number | null, benchmark: number | null): number {
  if (!midpoint || !benchmark) return 60; // neutral when no data is available
  const ratio = midpoint / benchmark;
  if (ratio >= 1.1) return 100;
  if (ratio >= 1.0) return 90;
  if (ratio >= 0.9) return 75;
  if (ratio >= 0.8) return 60;
  return 40;
}

// ---- Configuration + final valuation -------------------------------------

export type ValuationConfig = {
  salary_weight: number;
  company_weight: number;
  excellent_threshold: number;
  very_good_threshold: number;
  show_applicant_count_public: boolean;
  show_portal_valuation_public: boolean;
  default_benchmark_amount: number;
};

export const DEFAULT_VALUATION_CONFIG: ValuationConfig = {
  salary_weight: 0.6,
  company_weight: 0.4,
  excellent_threshold: 85,
  very_good_threshold: 70,
  show_applicant_count_public: false,
  show_portal_valuation_public: false,
  default_benchmark_amount: 12000,
};

export type Grade = "excellent" | "very_good" | "good";

export const GRADE_LABELS: Record<Grade, BiLabel> = {
  excellent: tx("Excellent", "ممتاز"),
  very_good: tx("Very Good", "جيد جداً"),
  good: tx("Good", "جيد"),
};

export const gradeLabel = (g: Grade): BiLabel => GRADE_LABELS[g];

export function gradeFor(score: number, config: ValuationConfig = DEFAULT_VALUATION_CONFIG): Grade {
  if (score >= config.excellent_threshold) return "excellent";
  if (score >= config.very_good_threshold) return "very_good";
  return "good";
}

export type JobValuation = {
  salaryScore: number;
  companyScore: number;
  finalScore: number;
  grade: Grade;
  benchmark: number | null;
  salary: SalaryRange;
};

/** Automatic valuation — companies can never choose it themselves. */
export function valuateJob(
  job: { profession: BiLabel; sector: string; level: BiLabel; country: BiLabel; salary: BiLabel },
  company: CompanyInputs,
  benchmarks: SalaryBenchmark[] = [],
  config: ValuationConfig = DEFAULT_VALUATION_CONFIG,
): JobValuation {
  const salary = parseSalary(job.salary.en || job.salary.ar);
  const bm = findBenchmark(benchmarks, job);
  const benchmark = bm?.benchmark_amount ?? config.default_benchmark_amount ?? null;
  const sScore = salaryScore(salary.midpoint, benchmark);
  const cScore = companyScore(company);
  const finalScore = clamp(sScore * config.salary_weight + cScore * config.company_weight);
  return {
    salaryScore: sScore,
    companyScore: cScore,
    finalScore,
    grade: gradeFor(finalScore, config),
    benchmark,
    salary,
  };
}

export const JOB_VALUATION_TITLE = tx("Job Valuation", "تقييم الوظيفة");
export const JOB_VALUATION_EXPLANATION = tx(
  "The Job Valuation is calculated automatically based on salary competitiveness, company evaluation, company size, and company type.",
  "يتم احتساب تقييم الوظيفة تلقائياً بناءً على مستوى الراتب وتقييم الشركة وحجمها ونوعها.",
);
export const PUBLICATION_DATE = tx("Publication Date", "تاريخ النشر");
export const JOB_CLOSING_DATE = tx("Job Closing Date", "تاريخ إغلاق الوظيفة");
export const APPLICANTS_LABEL = tx("Applicants", "عدد المتقدمين");
export const DAYS_REMAINING = tx("Days Remaining", "الأيام المتبقية");

// ---- Direct Vacancy Ad labels (single source, reused on card + details) ----
export const AD_DATE = tx("Ad Date", "تاريخ الإعلان");
export const TIME_REMAINING = tx("Time Remaining", "الفترة المتبقية");
export const OPPORTUNITY_RATING = tx("Opportunity Rating", "تقييم الفرصة");
export const VIEWS_LABEL = tx("Views", "عدد المشاهدات");
export const ADVERTISER_LABEL = tx("Advertiser", "المعلن");
export const DIRECT_AD_LABEL = tx("Direct Vacancy Ad", "إعلان مباشر عن وظيفة");
export const TRUSTED_AD_LABEL = tx("Trusted Ad", "موثوق للإعلان");
export const SEND_NOW_CTA = tx("Send Now to the Company", "ارسل فوراً إلى المعلن");
export const COPY_EMAIL_CTA = tx("Copy Email", "نسخ البريد الإلكتروني");
export const DIRECT_AD_CONTACT_HINT = tx(
  "Upload your CV from your device and contact the advertiser directly by email.",
  "ارفع سيرتك الذاتية من جهازك ثم تواصل مباشرة مع المعلن عبر البريد الإلكتروني.",
);
/** Shown to guests only — registration stays optional for Direct Ads. */
export const DIRECT_AD_REGISTER_HINT = tx(
  "If you are not registered, you can easily create an account.",
  "إذا لم تكن مسجلاً، يمكنك إنشاء حساب بسهولة.",
);
export const AD_EXPIRED = tx("Ad expired", "انتهت مدة الإعلان");

/** Human "time remaining" text from the closing date. */
export function timeRemainingLabel(
  closesAt: string | null | undefined,
  now = Date.now(),
): BiLabel | null {
  const days = daysRemaining(closesAt, now);
  if (days === null) return null;
  if (days <= 0) return AD_EXPIRED;
  if (days === 1) return tx("1 day", "يوم واحد");
  return tx(`${days} days`, `${days} يوم`);
}

// ---- Data access (public, RLS-safe) --------------------------------------

export type JobMetaRow = {
  job_posting_id: string;
  applicant_count: number;
  portal_valuation: number | null;
  company_type: number | null;
  branches_count: number | null;
  published_at: string | null;
  closes_at: string | null;
  status: string;
  views: number | null;
  is_direct_ad: boolean | null;
};

/** Real applicant counts + company evaluation inputs for every job posting. */
export async function fetchJobMeta(): Promise<Record<string, JobMetaRow>> {
  const { data, error } = await supabase.rpc("job_listing_meta");
  if (error || !data) return {};
  const map: Record<string, JobMetaRow> = {};
  for (const row of data as JobMetaRow[]) map[row.job_posting_id] = row;
  return map;
}

/** Counts one view — called only when the Job Details page is actually opened. */
export async function recordJobView(jobPostingId: string): Promise<void> {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  await (supabase.rpc as any)("increment_job_views", { _job_posting_id: jobPostingId });
}

export async function fetchValuationConfig(): Promise<ValuationConfig> {
  const { data } = await supabase
    .from("valuation_config")
    .select(
      "salary_weight, company_weight, excellent_threshold, very_good_threshold, show_applicant_count_public, show_portal_valuation_public, default_benchmark_amount",
    )
    .maybeSingle();
  if (!data) return DEFAULT_VALUATION_CONFIG;
  return {
    salary_weight: Number(data.salary_weight),
    company_weight: Number(data.company_weight),
    excellent_threshold: Number(data.excellent_threshold),
    very_good_threshold: Number(data.very_good_threshold),
    show_applicant_count_public: !!data.show_applicant_count_public,
    show_portal_valuation_public: !!data.show_portal_valuation_public,
    default_benchmark_amount: Number(data.default_benchmark_amount),
  };
}

export async function fetchSalaryBenchmarks(): Promise<SalaryBenchmark[]> {
  const { data } = await supabase
    .from("salary_benchmarks")
    .select(
      "id, job_category, sector, career_level, country, currency, benchmark_amount, salary_period",
    );
  return (data ?? []).map((b) => ({ ...b, benchmark_amount: Number(b.benchmark_amount) }));
}

// ---- Combined insight used by every jobs surface -------------------------

export type JobInsight = {
  state: JobState;
  publishedAt: string | null;
  closesAt: string | null;
  daysRemaining: number | null;
  applicantCount: number | null;
  valuation: JobValuation;
  canApply: boolean;
  /** Direct Vacancy Ad — styled and labelled differently on the job card. */
  directAd: boolean;
  views: number | null;
  timeRemaining: BiLabel | null;
};

export function buildInsight(
  job: Job,
  meta: JobMetaRow | undefined,
  benchmarks: SalaryBenchmark[],
  config: ValuationConfig,
  now = Date.now(),
): JobInsight {
  const publishedAt = meta?.published_at ?? job.addedAt ?? null;
  const closesAt = meta?.closes_at ?? job.deadline ?? closingDate(publishedAt);
  const state = deriveJobState(
    {
      status: meta?.status ?? (job.source === "posting" ? "published" : "published"),
      publishedAt,
      closesAt,
    },
    now,
  );
  const valuation = valuateJob(
    job,
    {
      portalValuation: meta?.portal_valuation ?? 3,
      companyType: meta?.company_type ?? 1,
      branchesCount: meta?.branches_count ?? 1,
    },
    benchmarks,
    config,
  );
  return {
    state,
    publishedAt,
    closesAt,
    daysRemaining: daysRemaining(closesAt, now),
    applicantCount: meta ? meta.applicant_count : null,
    valuation,
    canApply: acceptsApplications(state),
    directAd: meta?.is_direct_ad === true || job.directAd === true,
    views: meta?.views ?? job.views ?? null,
    timeRemaining: timeRemainingLabel(closesAt, now),
  };
}

// ---- Admin writes (RLS: admin role only) ---------------------------------

export const VALUATION_LIMITS = {
  thresholdMin: 0,
  thresholdMax: 100,
  benchmarkMin: 0,
} as const;

export type ValuationConfigInput = Pick<
  ValuationConfig,
  | "salary_weight"
  | "company_weight"
  | "excellent_threshold"
  | "very_good_threshold"
  | "default_benchmark_amount"
  | "show_applicant_count_public"
  | "show_portal_valuation_public"
>;

/** Validation shared by the admin form and the save call. */
export function validateValuationConfig(c: ValuationConfigInput): BiLabel | null {
  const sum = Number(c.salary_weight) + Number(c.company_weight);
  if (Math.abs(sum - 1) > 0.001)
    return tx(
      "Salary weight and company weight must add up to 100%.",
      "يجب أن يكون مجموع وزن الراتب ووزن الشركة 100%.",
    );
  if (c.excellent_threshold <= c.very_good_threshold)
    return tx(
      "The Excellent threshold must be higher than the Very Good threshold.",
      "يجب أن يكون حد «ممتاز» أعلى من حد «جيد جداً».",
    );
  if (c.very_good_threshold < 0 || c.excellent_threshold > 100)
    return tx("Thresholds must be between 0 and 100.", "يجب أن تكون الحدود بين 0 و 100.");
  if (!(c.default_benchmark_amount > 0))
    return tx(
      "The default salary benchmark must be greater than zero.",
      "يجب أن يكون متوسط الراتب المرجعي أكبر من صفر.",
    );
  return null;
}

/** Persists the singleton valuation configuration (admins only, enforced by RLS). */
export async function saveValuationConfig(c: ValuationConfigInput): Promise<void> {
  const { error } = await supabase
    .from("valuation_config")
    .update({
      salary_weight: c.salary_weight,
      company_weight: c.company_weight,
      excellent_threshold: c.excellent_threshold,
      very_good_threshold: c.very_good_threshold,
      default_benchmark_amount: c.default_benchmark_amount,
      show_applicant_count_public: c.show_applicant_count_public,
      show_portal_valuation_public: c.show_portal_valuation_public,
    })
    .eq("id", true);
  if (error) throw error;
}

export type SalaryBenchmarkInput = Omit<SalaryBenchmark, "id"> & { id?: string };

export async function saveSalaryBenchmark(b: SalaryBenchmarkInput): Promise<void> {
  const row = {
    job_category: b.job_category.trim(),
    sector: b.sector?.trim() || null,
    career_level: b.career_level?.trim() || null,
    country: b.country?.trim() || null,
    currency: b.currency || "SAR",
    benchmark_amount: b.benchmark_amount,
    salary_period: b.salary_period || "monthly",
  };
  const { error } = b.id
    ? await supabase.from("salary_benchmarks").update(row).eq("id", b.id)
    : await supabase.from("salary_benchmarks").insert(row);
  if (error) throw error;
}

export async function deleteSalaryBenchmark(id: string): Promise<void> {
  const { error } = await supabase.from("salary_benchmarks").delete().eq("id", id);
  if (error) throw error;
}
