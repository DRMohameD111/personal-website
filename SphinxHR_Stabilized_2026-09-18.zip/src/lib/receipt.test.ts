import { describe, expect, it } from "vitest";
import { paymentState, receiptNumber, receiptEmailHtml, type PackageReceipt } from "./receipt";

const base: PackageReceipt = {
  subscriptionId: "11111111-2222-3333-4444-555555555555",
  receiptNumber: "RCPT-P-ACME-0126-0007",
  packageCode: "P-ACME-0126-0007",
  companyName: "Acme",
  companyCode: "ACM",
  contactName: null,
  email: "a@b.com",
  nameEn: "Professional",
  nameAr: "المتقدمة",
  status: "active",
  changeType: "upgrade",
  isTrial: false,
  durationMonths: 12,
  currency: "SAR",
  listPrice: 1000,
  discount: 100,
  creditApplied: 50,
  amountDue: 850,
  amountPaid: 850,
  outstanding: 0,
  paymentState: "paid",
  paymentReference: "PAY-1",
  paymentDate: "2026-01-05T00:00:00Z",
  startedAt: "2026-01-05T00:00:00Z",
  expiresAt: "2027-01-05T00:00:00Z",
  remainingDays: 300,
  features: [],
  generatedAt: "2026-01-06T00:00:00Z",
};

describe("receipt numbering", () => {
  it("is stable and derived from the immutable package code", () => {
    expect(receiptNumber("P-ACM-0126-0007", base.subscriptionId)).toBe("RCPT-P-ACM-0126-0007");
    expect(receiptNumber("P-ACM-0126-0007", base.subscriptionId)).toBe(
      receiptNumber("P-ACM-0126-0007", base.subscriptionId),
    );
  });

  it("falls back to the subscription id when no package code exists", () => {
    expect(receiptNumber(null, base.subscriptionId)).toBe("RCPT-111111112222");
  });
});

describe("payment state", () => {
  it("classifies verified payment amounts", () => {
    expect(paymentState(0, 0)).toBe("free");
    expect(paymentState(850, 850)).toBe("paid");
    expect(paymentState(850, 900)).toBe("paid");
    expect(paymentState(850, 100)).toBe("partial");
    expect(paymentState(850, 0)).toBe("awaiting_payment");
  });
});

describe("email card", () => {
  it("renders verified figures and escapes untrusted text", () => {
    const html = receiptEmailHtml(
      { ...base, companyName: "<script>x</script>" },
      "en",
      "https://x/receipt/1",
    );
    expect(html).toContain("RCPT-P-ACME-0126-0007");
    expect(html).toContain("P-ACME-0126-0007");
    expect(html).not.toContain("<script>");
    expect(html).toContain("https://x/receipt/1");
  });

  it("renders the Arabic card in RTL", () => {
    expect(receiptEmailHtml(base, "ar")).toContain('dir="rtl"');
  });
});
