import { tx } from "@/i18n";

/**
 * Admin permission vocabulary. Shared by the server checks and the control
 * panel UI so there is a single source of truth for modules and actions.
 */
export const ADMIN_MODULES = [
  "companies",
  "job_seekers",
  "jobs",
  "applications",
  "packages",
  "payments",
  "direct_ads",
  "cvs",
  "reports",
] as const;

export const ADMIN_ACTIONS = ["view", "edit", "verify", "print", "export", "approve"] as const;

export type AdminModule = (typeof ADMIN_MODULES)[number];
export type AdminAction = (typeof ADMIN_ACTIONS)[number];

export const MODULE_LABELS: Record<AdminModule, ReturnType<typeof tx>> = {
  companies: tx("Companies", "الشركات"),
  job_seekers: tx("Job Seekers", "الباحثون عن عمل"),
  jobs: tx("Jobs", "الوظائف"),
  applications: tx("Applications", "الطلبات"),
  packages: tx("Packages", "الباقات"),
  payments: tx("Payments", "المدفوعات"),
  direct_ads: tx("Direct Ads", "الإعلانات المباشرة"),
  cvs: tx("CVs", "السير الذاتية"),
  reports: tx("Reports", "التقارير"),
};

export const ACTION_LABELS: Record<AdminAction, ReturnType<typeof tx>> = {
  view: tx("View", "عرض"),
  edit: tx("Edit", "تعديل"),
  verify: tx("Verify", "توثيق"),
  print: tx("Print", "طباعة"),
  export: tx("Export", "تصدير"),
  approve: tx("Approve", "اعتماد"),
};

export const permKey = (module: AdminModule, action: AdminAction) => `${module}:${action}`;

export function canDo(
  access: { isMain: boolean; permissions: string[] } | undefined | null,
  module: AdminModule,
  action: AdminAction,
): boolean {
  if (!access) return false;
  return access.isMain || access.permissions.includes(permKey(module, action));
}

/** Client-side CSV export used by the Print / Export actions. */
export function toCsv(rows: Record<string, unknown>[]): string {
  if (rows.length === 0) return "";
  const headers = Object.keys(rows[0]!);
  const cell = (v: unknown) => `"${String(v ?? "").replace(/"/g, '""')}"`;
  return [headers.join(","), ...rows.map((r) => headers.map((h) => cell(r[h])).join(","))].join(
    "\n",
  );
}
