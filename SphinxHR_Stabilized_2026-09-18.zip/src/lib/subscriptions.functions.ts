// ---------------------------------------------------------------------------
// Company package management — server side is the ONLY source of truth.
// The browser may send a package id and an idempotency key; every commercial
// value (price, discount, credit, dates, change type, status, package code,
// serial) is derived on the server from the database.
// ---------------------------------------------------------------------------
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { Json } from "@/integrations/supabase/types";
import {
  classifyChange,
  quoteChange,
  remainingDays,
  type ChangeRequestRow,
  type ChangeType,
  type PackageRow,
  type Quote,
  type SubscriptionPolicy,
  type SubscriptionRow,
} from "./subscriptions";
import {
  paymentState,
  receiptEmailHtml,
  receiptNumber,
  type PackageReceipt,
  type ReceiptFeature,
} from "./receipt";

const OPEN_STATUSES = ["pending", "awaiting_payment", "scheduled"] as const;

export type CurrentPackage = {
  companyCode: string | null;
  policy: SubscriptionPolicy;
  subscription:
    | (Pick<
        SubscriptionRow,
        | "id"
        | "package_id"
        | "package_code"
        | "status"
        | "started_at"
        | "expires_at"
        | "price_paid"
        | "amount_due"
        | "outstanding_amount"
        | "credit_applied"
        | "discount"
        | "currency"
        | "is_trial"
        | "change_type"
      > & { nameEn: string; nameAr: string; remainingDays: number | null })
    | null;
  pendingChange:
    | (Pick<
        ChangeRequestRow,
        | "id"
        | "status"
        | "change_type"
        | "new_package_id"
        | "effective_date"
        | "amount_due"
        | "amount_paid"
        | "credit_applied"
        | "currency"
        | "requested_at"
      > & { nameEn: string; nameAr: string })
    | null;
};

/** Companies only: a job seeker has no package surface. */
async function requireCompany(
  supabase: {
    from: (t: string) => {
      select: (c: string) => {
        eq: (k: string, v: string) => { maybeSingle: () => Promise<{ data: unknown }> };
      };
    };
  },
  userId: string,
): Promise<{
  account_type: string;
  company_code: string | null;
  company_name: string | null;
  email: string | null;
}> {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const { data } = await (supabase as any)
    .from("profiles")
    .select("account_type, company_code, company_name, email")
    .eq("id", userId)
    .maybeSingle();
  if (!data || data.account_type !== "company") throw new Error("Forbidden");
  return data;
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function loadPolicy(client: any): Promise<SubscriptionPolicy> {
  const { data, error } = await client
    .from("subscription_policy")
    .select("*")
    .eq("id", true)
    .maybeSingle();
  if (error || !data) throw new Error("Subscription policy unavailable");
  return data as SubscriptionPolicy;
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function loadCurrent(client: any, userId: string): Promise<SubscriptionRow | null> {
  const { data } = await client
    .from("subscriptions")
    .select("*")
    .eq("user_id", userId)
    .eq("status", "active")
    .maybeSingle();
  return (data as SubscriptionRow) ?? null;
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function loadOpenRequest(client: any, userId: string): Promise<ChangeRequestRow | null> {
  const { data } = await client
    .from("package_change_requests")
    .select("*")
    .eq("user_id", userId)
    .in("status", [...OPEN_STATUSES])
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  return (data as ChangeRequestRow) ?? null;
}

const snapName = (row: SubscriptionRow | ChangeRequestRow, key: "name_en" | "name_ar") => {
  const snap = (("package_snapshot" in row ? row.package_snapshot : null) ?? {}) as Record<
    string,
    unknown
  >;
  return typeof snap[key] === "string" ? (snap[key] as string) : "";
};

/** Verified "Current Package" data for the company dashboard. */
export const getMyPackage = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<CurrentPackage> => {
    const { supabase, userId } = context;
    const profile = await requireCompany(supabase as never, userId);
    const policy = await loadPolicy(supabase);
    const current = await loadCurrent(supabase, userId);
    const open = await loadOpenRequest(supabase, userId);

    // Package names for the pending request come from the visible package rows.
    let pendingNames = { nameEn: "", nameAr: "" };
    if (open) {
      const { data: pkg } = await supabase
        .from("packages")
        .select("name_en, name_ar")
        .eq("id", open.new_package_id)
        .maybeSingle();
      pendingNames = { nameEn: pkg?.name_en ?? "", nameAr: pkg?.name_ar ?? "" };
    }

    return {
      companyCode: profile.company_code,
      policy,
      subscription: current
        ? {
            id: current.id,
            package_id: current.package_id,
            package_code: current.package_code,
            status: current.status,
            started_at: current.started_at,
            expires_at: current.expires_at,
            price_paid: current.price_paid,
            amount_due: current.amount_due,
            outstanding_amount: current.outstanding_amount,
            credit_applied: current.credit_applied,
            discount: current.discount,
            currency: current.currency,
            is_trial: current.is_trial,
            change_type: current.change_type,
            nameEn: snapName(current, "name_en"),
            nameAr: snapName(current, "name_ar"),
            remainingDays: remainingDays(current.expires_at),
          }
        : null,
      pendingChange: open
        ? {
            id: open.id,
            status: open.status,
            change_type: open.change_type,
            new_package_id: open.new_package_id,
            effective_date: open.effective_date,
            amount_due: open.amount_due,
            amount_paid: open.amount_paid,
            credit_applied: open.credit_applied,
            currency: open.currency,
            requested_at: open.requested_at,
            ...pendingNames,
          }
        : null,
    };
  });

// ---------------------------------------------------------------------------
// Quote (informational only — writes nothing)
// ---------------------------------------------------------------------------

export type ChangePreview = {
  quote: Quote | null;
  error: "same_package" | "package_unavailable" | "pending_change_exists" | null;
  newPackage: {
    nameEn: string;
    nameAr: string;
    durationMonths: number | null;
    rank: number;
  } | null;
  currentPackage: {
    nameEn: string;
    nameAr: string;
    durationMonths: number | null;
    rank: number;
  } | null;
};

async function resolveChange(
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  supabase: any,
  userId: string,
  packageId: string,
): Promise<
  | { error: NonNullable<ChangePreview["error"]> }
  | {
      error: null;
      quote: Quote;
      pkg: PackageRow;
      current: SubscriptionRow | null;
      currentPkg: PackageRow | null;
      policy: SubscriptionPolicy;
      changeType: ChangeType;
    }
> {
  const policy = await loadPolicy(supabase);

  // Read through the user's client: RLS already hides inactive / out-of-window
  // packages, so an inactive package can never be selected.
  const { data: pkg } = await supabase
    .from("packages")
    .select("*")
    .eq("id", packageId)
    .maybeSingle();
  if (!pkg) return { error: "package_unavailable" };

  const current = await loadCurrent(supabase, userId);
  let currentPkg: PackageRow | null = null;
  if (current?.package_id) {
    // The current package may have been deactivated later; read its rank with a
    // read-only privileged lookup so ranking never depends on visible names.
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data } = await supabaseAdmin
      .from("packages")
      .select("*")
      .eq("id", current.package_id)
      .maybeSingle();
    currentPkg = (data as PackageRow) ?? null;
  }

  const cls = classifyChange(
    currentPkg?.rank ?? null,
    (pkg as PackageRow).rank,
    policy.allow_same_package_renewal,
  );
  if ("error" in cls) return { error: cls.error };

  const quote = quoteChange({ pkg: pkg as PackageRow, current, policy, changeType: cls.type });
  return {
    error: null,
    quote,
    pkg: pkg as PackageRow,
    current,
    currentPkg,
    policy,
    changeType: cls.type,
  };
}

export const previewPackageChange = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ packageId: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }): Promise<ChangePreview> => {
    const { supabase, userId } = context;
    await requireCompany(supabase as never, userId);

    const open = await loadOpenRequest(supabase, userId);
    if (open)
      return {
        quote: null,
        error: "pending_change_exists",
        newPackage: null,
        currentPackage: null,
      };

    const res = await resolveChange(supabase, userId, data.packageId);
    if (res.error) return { quote: null, error: res.error, newPackage: null, currentPackage: null };

    const shape = (p: PackageRow | null) =>
      p
        ? { nameEn: p.name_en, nameAr: p.name_ar, durationMonths: p.duration_months, rank: p.rank }
        : null;
    return {
      quote: res.quote,
      error: null,
      newPackage: shape(res.pkg),
      currentPackage: shape(res.currentPkg),
    };
  });

// ---------------------------------------------------------------------------
// Request a change (upgrade / downgrade / renewal)
// ---------------------------------------------------------------------------

export type ChangeResult = {
  ok: boolean;
  error:
    | "same_package"
    | "package_unavailable"
    | "pending_change_exists"
    | "activation_failed"
    | null;
  requestId: string | null;
  status: string | null;
  requiresPayment: boolean;
  scheduled: boolean;
  effectiveDate: string | null;
  packageCode: string | null;
  amountDue: number;
  currency: string;
};

export const requestPackageChange = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        packageId: z.string().uuid(),
        // Idempotency key: a repeat submit with the same key never creates a
        // second request (unique index in the database).
        idempotencyKey: z.string().uuid(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }): Promise<ChangeResult> => {
    const { supabase, userId } = context;
    const profile = await requireCompany(supabase as never, userId);

    const fail = (error: NonNullable<ChangeResult["error"]>): ChangeResult => ({
      ok: false,
      error,
      requestId: null,
      status: null,
      requiresPayment: false,
      scheduled: false,
      effectiveDate: null,
      packageCode: null,
      amountDue: 0,
      currency: "SAR",
    });

    // Only one unresolved change per company.
    const open = await loadOpenRequest(supabase, userId);
    if (open) return fail("pending_change_exists");

    const res = await resolveChange(supabase, userId, data.packageId);
    if (res.error) return fail(res.error);
    const { quote, pkg, current, policy, changeType } = res;

    const insertStatus =
      quote.requiresPayment || policy.require_admin_approval ? "awaiting_payment" : "pending";

    // Inserted through the user's own client: RLS forbids foreign user_id,
    // pre-set payments, and pre-set activation fields.
    const { data: inserted, error } = await supabase
      .from("package_change_requests")
      .insert({
        user_id: userId,
        requested_by: userId,
        old_package_id: current?.package_id ?? null,
        old_subscription_id: current?.id ?? null,
        new_package_id: pkg.id,
        change_type: changeType,
        status: insertStatus,
        effective_date: quote.effectiveDate,
        currency: quote.currency,
        amount_before_credit: quote.amountBeforeCredit,
        discount: quote.discount,
        credit_applied: quote.creditApplied,
        amount_due: quote.amountDue,
        idempotency_key: data.idempotencyKey,
        policy_snapshot: policy as unknown as Json,
        package_snapshot: {
          package_id: pkg.id,
          slug: pkg.slug,
          name_en: pkg.name_en,
          name_ar: pkg.name_ar,
          price: pkg.price,
          currency: pkg.currency,
          duration_months: pkg.duration_months,
          rank: pkg.rank,
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
      } as any)
      .select("*")
      .maybeSingle();

    if (error || !inserted) {
      // Unique violation = a concurrent/duplicate submit; surface the existing one.
      const existing = await loadOpenRequest(supabase, userId);
      if (existing) return fail("pending_change_exists");
      throw new Error(error?.message ?? "Could not create the package change request");
    }
    const request = inserted as ChangeRequestRow;

    // Nothing to pay and no admin approval needed → activate atomically now.
    if (!quote.requiresPayment && !policy.require_admin_approval) {
      const activated = await activateRequest(request.id, null, 0, userId);
      if (!activated.ok) return { ...fail("activation_failed"), requestId: request.id };
      return {
        ok: true,
        error: null,
        requestId: request.id,
        status: activated.status,
        requiresPayment: false,
        scheduled: activated.status === "scheduled",
        effectiveDate: quote.effectiveDate,
        packageCode: activated.packageCode,
        amountDue: 0,
        currency: quote.currency,
      };
    }

    await notify(userId, "package_change_requested", {
      request_id: request.id,
      package_en: pkg.name_en,
      package_ar: pkg.name_ar,
      amount_due: quote.amountDue,
      currency: quote.currency,
      company_email: profile.email,
    });

    return {
      ok: true,
      error: null,
      requestId: request.id,
      status: insertStatus,
      requiresPayment: quote.requiresPayment,
      scheduled: false,
      effectiveDate: quote.effectiveDate,
      packageCode: null,
      amountDue: quote.amountDue,
      currency: quote.currency,
    };
  });

/**
 * Atomic activation via the database routine (transaction-safe, idempotent,
 * concurrency-safe serial + immutable package code). Never called with values
 * that originate from the browser.
 */
async function activateRequest(
  requestId: string,
  paymentReference: string | null,
  amountPaid: number,
  actor: string | null,
): Promise<{ ok: boolean; status: string; packageCode: string | null; reason?: string }> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const { data, error } = await (supabaseAdmin as any).rpc("activate_package_change", {
    _request_id: requestId,
    _payment_reference: paymentReference,
    _amount_paid: amountPaid,
    _actor: actor,
  });
  if (error || !data)
    return {
      ok: false,
      status: "failed",
      packageCode: null,
      // A null result means the routine recorded a verified payment mismatch.
      reason: error?.message ?? "amount_mismatch",
    };

  const { data: sub } = await supabaseAdmin
    .from("subscriptions")
    .select("*")
    .eq("id", data as string)
    .maybeSingle();

  if (sub) {
    const snap = (sub.package_snapshot ?? {}) as Record<string, unknown>;
    const amountDue = Number(sub.amount_due ?? 0);
    const amountPaid = Number(sub.price_paid ?? 0);
    // Confirmation card payload: verified figures only, ready for e-mail
    // delivery as soon as an outbound mail domain is configured.
    const card: PackageReceipt = {
      subscriptionId: sub.id,
      receiptNumber: receiptNumber(sub.package_code, sub.id),
      packageCode: sub.package_code,
      companyName: null,
      companyCode: null,
      contactName: null,
      email: null,
      nameEn: typeof snap["name_en"] === "string" ? (snap["name_en"] as string) : "—",
      nameAr: typeof snap["name_ar"] === "string" ? (snap["name_ar"] as string) : "—",
      status: sub.status,
      changeType: sub.change_type,
      isTrial: sub.is_trial,
      durationMonths:
        typeof snap["duration_months"] === "number" ? (snap["duration_months"] as number) : null,
      currency: sub.currency,
      listPrice: typeof snap["price"] === "number" ? (snap["price"] as number) : amountDue,
      discount: Number(sub.discount ?? 0),
      creditApplied: Number(sub.credit_applied ?? 0),
      amountDue,
      amountPaid,
      outstanding: Number(sub.outstanding_amount ?? 0),
      paymentState: paymentState(amountDue, amountPaid),
      paymentReference: sub.payment_reference,
      paymentDate: sub.activated_at,
      startedAt: sub.started_at,
      expiresAt: sub.expires_at,
      remainingDays: remainingDays(sub.expires_at),
      features: [],
      generatedAt: new Date().toISOString(),
    };
    const link = `${process.env["PUBLIC_SITE_URL"] ?? "https://sphinxhr.com"}/receipt/${sub.id}`;
    await notify(
      sub.user_id,
      sub.status === "scheduled" ? "package_change_scheduled" : "package_change_activated",
      {
        subscription_id: data,
        receipt_number: card.receiptNumber,
        package_code: sub.package_code,
        package_en: card.nameEn,
        package_ar: card.nameAr,
        amount_due: amountDue,
        amount_paid: amountPaid,
        outstanding_amount: sub.outstanding_amount,
        currency: sub.currency,
        payment_reference: sub.payment_reference,
        payment_status: card.paymentState,
        started_at: sub.started_at,
        expires_at: sub.expires_at,
        status: sub.status,
        receipt_url: link,
        email_html_en: receiptEmailHtml(card, "en", link),
        email_html_ar: receiptEmailHtml(card, "ar", link),
      },
    );
  }

  return { ok: true, status: sub?.status ?? "active", packageCode: sub?.package_code ?? null };
}

/**
 * Confirmation notice built exclusively from verified database values.
 * Delivery failure is recorded but never rolls back a valid activation.
 */
async function notify(userId: string, type: string, payload: Record<string, unknown>) {
  try {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin
      .from("app_notifications")
      .insert({ user_id: userId, type, payload: payload as unknown as Json });
  } catch (e) {
    console.error("[subscriptions] notification delivery failed", type, e);
  }
}

// ---------------------------------------------------------------------------
// Cancel an unresolved request (company, own request only)
// ---------------------------------------------------------------------------

export const cancelPackageChange = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ requestId: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }): Promise<{ ok: boolean }> => {
    const { supabase, userId } = context;
    await requireCompany(supabase as never, userId);

    // Ownership is verified server-side against the session, not the payload.
    const { data: req } = await supabase
      .from("package_change_requests")
      .select("id, user_id, status")
      .eq("id", data.requestId)
      .maybeSingle();
    if (!req || req.user_id !== userId) throw new Error("Forbidden");
    if (!(OPEN_STATUSES as readonly string[]).includes(req.status))
      throw new Error("Request is not cancellable");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("package_change_requests")
      .update({ status: "cancelled", cancelled_at: new Date().toISOString() })
      .eq("id", req.id)
      .eq("user_id", userId);
    if (error) throw new Error(error.message);

    await supabaseAdmin.from("package_audit_log").insert({
      action: "package_change_cancelled",
      admin_user_id: userId,
      changes: { request_id: req.id, by: "company" },
    });
    return { ok: true };
  });

// ---------------------------------------------------------------------------
// Package history (read-only for companies)
// ---------------------------------------------------------------------------

export type HistoryRow = {
  id: string;
  packageCode: string | null;
  nameEn: string;
  nameAr: string;
  amount: number;
  amountPaid: number;
  outstanding: number;
  currency: string;
  startedAt: string;
  expiresAt: string | null;
  status: string;
  changeType: string | null;
  requestedAt: string | null;
  effectiveDate: string | null;
};

export const listMyPackageHistory = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<HistoryRow[]> => {
    const { supabase, userId } = context;
    await requireCompany(supabase as never, userId);

    const { data: subs, error } = await supabase
      .from("subscriptions")
      .select("*")
      .eq("user_id", userId)
      .order("started_at", { ascending: false });
    if (error) throw new Error(error.message);

    const { data: reqs } = await supabase
      .from("package_change_requests")
      .select("id, activated_subscription_id, requested_at, effective_date")
      .eq("user_id", userId);
    const byId = new Map((reqs ?? []).map((r) => [r.activated_subscription_id, r]));

    return (subs ?? []).map((s) => {
      const snap = (s.package_snapshot ?? {}) as Record<string, unknown>;
      const req = byId.get(s.id);
      return {
        id: s.id,
        packageCode: s.package_code,
        nameEn: typeof snap["name_en"] === "string" ? (snap["name_en"] as string) : "—",
        nameAr: typeof snap["name_ar"] === "string" ? (snap["name_ar"] as string) : "—",
        amount: Number(s.amount_due ?? 0),
        amountPaid: Number(s.price_paid ?? 0),
        outstanding: Number(s.outstanding_amount ?? 0),
        currency: s.currency,
        startedAt: s.started_at,
        expiresAt: s.expires_at,
        status: s.status,
        changeType: s.change_type,
        requestedAt: req?.requested_at ?? null,
        effectiveDate: req?.effective_date ?? null,
      };
    });
  });

// ---------------------------------------------------------------------------
// Admin: verified payment confirmation, override, policy configuration
// ---------------------------------------------------------------------------

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function requireAdmin(supabase: any, userId: string) {
  const { data, error } = await supabase.rpc("has_role", { _user_id: userId, _role: "admin" });
  if (error || data !== true) throw new Error("Forbidden");
}

/**
 * Records a payment that has been verified against the payment provider and
 * activates the subscription atomically. The amount is validated inside the
 * database routine against the backend-calculated amount due.
 */
export const confirmPackagePayment = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        requestId: z.string().uuid(),
        paymentReference: z.string().trim().min(3).max(120),
        amountPaid: z.number().nonnegative(),
        reason: z.string().trim().min(3).max(400),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await requireAdmin(supabase, userId);

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.from("package_audit_log").insert({
      action: "payment_confirmed",
      admin_user_id: userId,
      changes: {
        request_id: data.requestId,
        payment_reference: data.paymentReference,
        amount_paid: data.amountPaid,
        reason: data.reason,
      },
    });

    const res = await activateRequest(
      data.requestId,
      data.paymentReference,
      data.amountPaid,
      userId,
    );
    if (!res.ok) {
      await supabaseAdmin.from("package_audit_log").insert({
        action: "activation_failed",
        admin_user_id: userId,
        changes: { request_id: data.requestId, reason: res.reason ?? null },
      });
      return { ok: false, status: null, packageCode: null };
    }
    return { ok: true, status: res.status, packageCode: res.packageCode };
  });

export const getSubscriptionPolicy = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<SubscriptionPolicy> => loadPolicy(context.supabase));

export const updateSubscriptionPolicy = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        upgrade_timing: z.enum(["immediate", "after_payment"]),
        downgrade_timing: z.enum(["end_of_term", "immediate"]),
        prorate_credit: z.boolean(),
        require_admin_approval: z.boolean(),
        allow_same_package_renewal: z.boolean(),
        tax_percent: z.number().min(0).max(100),
      })
      .parse(input),
  )
  .handler(async ({ data, context }): Promise<{ ok: true }> => {
    const { supabase, userId } = context;
    await requireAdmin(supabase, userId);
    const before = await loadPolicy(supabase);

    const { error } = await supabase.from("subscription_policy").update(data).eq("id", true);
    if (error) throw new Error(error.message);

    await supabase.from("package_audit_log").insert({
      action: "subscription_policy_updated",
      admin_user_id: userId,
      changes: { from: before, to: data } as unknown as Json,
    });
    return { ok: true };
  });

/** Admin: stable package rank + code prefix (never derived from display names). */
export const updatePackageRanking = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        packageId: z.string().uuid(),
        rank: z.number().int().min(0).max(999),
        codePrefix: z
          .string()
          .trim()
          .regex(/^[A-Za-z]{1,4}$/)
          .transform((v) => v.toUpperCase()),
        reason: z.string().trim().max(400).optional().default(""),
      })
      .parse(input),
  )
  .handler(async ({ data, context }): Promise<{ ok: true }> => {
    const { supabase, userId } = context;
    await requireAdmin(supabase, userId);

    const { data: before } = await supabase
      .from("packages")
      .select("slug, rank, code_prefix")
      .eq("id", data.packageId)
      .maybeSingle();

    const { error } = await supabase
      .from("packages")
      .update({ rank: data.rank, code_prefix: data.codePrefix })
      .eq("id", data.packageId);
    if (error) throw new Error(error.message);

    await supabase.from("package_audit_log").insert({
      package_id: data.packageId,
      package_slug: before?.slug ?? null,
      action: "package_ranking_updated",
      admin_user_id: userId,
      changes: {
        rank: { from: before?.rank ?? null, to: data.rank },
        code_prefix: { from: before?.code_prefix ?? null, to: data.codePrefix },
        reason: data.reason,
      },
    });
    return { ok: true };
  });

/** Admin: unresolved requests awaiting verified payment / approval. */
export const listOpenChangeRequests = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    await requireAdmin(supabase, userId);
    const { data, error } = await supabase
      .from("package_change_requests")
      .select("*")
      .in("status", [...OPEN_STATUSES])
      .order("requested_at", { ascending: false })
      .limit(100);
    if (error) throw new Error(error.message);
    return (data ?? []) as ChangeRequestRow[];
  });

// ---------------------------------------------------------------------------
// Package Confirmation Card / printable receipt (company: own rows only)
// The card is rendered from stored, verified values — the browser sends only
// the subscription id and never any amount, date, code or payment reference.
// ---------------------------------------------------------------------------

export const getPackageReceipt = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ subscriptionId: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }): Promise<PackageReceipt> => {
    const { supabase, userId } = context;
    const profile = await requireCompany(supabase as never, userId);

    const { data: sub, error } = await supabase
      .from("subscriptions")
      .select("*")
      .eq("id", data.subscriptionId)
      .eq("user_id", userId)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!sub) throw new Error("Forbidden");

    const snap = (sub.package_snapshot ?? {}) as Record<string, unknown>;
    const str = (k: string) => (typeof snap[k] === "string" ? (snap[k] as string) : null);
    const num = (k: string) => (typeof snap[k] === "number" ? (snap[k] as number) : null);

    const rawFeatures = Array.isArray(snap["features"])
      ? (snap["features"] as Record<string, unknown>[])
      : [];
    const features: ReceiptFeature[] = rawFeatures.map((f) => {
      const type = typeof f["value_type"] === "string" ? (f["value_type"] as string) : "boolean";
      const valueEn =
        type === "unlimited"
          ? "Unlimited"
          : type === "number"
            ? String(f["value_number"] ?? "—")
            : type === "text"
              ? String(f["value_text_en"] ?? "—")
              : f["value_bool"] === false
                ? "No"
                : "Yes";
      const valueAr =
        type === "unlimited"
          ? "غير محدود"
          : type === "number"
            ? String(f["value_number"] ?? "—")
            : type === "text"
              ? String(f["value_text_ar"] ?? f["value_text_en"] ?? "—")
              : f["value_bool"] === false
                ? "لا"
                : "نعم";
      return {
        labelEn: typeof f["label_en"] === "string" ? (f["label_en"] as string) : "—",
        labelAr: typeof f["label_ar"] === "string" ? (f["label_ar"] as string) : "—",
        valueEn,
        valueAr,
      };
    });

    const amountDue = Number(sub.amount_due ?? 0);
    const amountPaid = Number(sub.price_paid ?? 0);

    return {
      subscriptionId: sub.id,
      receiptNumber: receiptNumber(sub.package_code, sub.id),
      packageCode: sub.package_code,
      companyName: profile.company_name,
      companyCode: profile.company_code,
      contactName: null,
      email: profile.email,
      nameEn: str("name_en") ?? "—",
      nameAr: str("name_ar") ?? "—",
      status: sub.status,
      changeType: sub.change_type,
      isTrial: sub.is_trial,
      durationMonths: num("duration_months"),
      currency: sub.currency,
      listPrice: Number(num("price") ?? amountDue),
      discount: Number(sub.discount ?? 0),
      creditApplied: Number(sub.credit_applied ?? 0),
      amountDue,
      amountPaid,
      outstanding: Number(sub.outstanding_amount ?? 0),
      paymentState: paymentState(amountDue, amountPaid),
      paymentReference: sub.payment_reference,
      paymentDate: sub.activated_at,
      startedAt: sub.started_at,
      expiresAt: sub.expires_at,
      remainingDays: remainingDays(sub.expires_at),
      features,
      generatedAt: new Date().toISOString(),
    };
  });
