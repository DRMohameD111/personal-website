import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

/**
 * Only accounts with account_type = 'company' may manage job postings.
 * The identity always comes from the verified session, never from request input.
 */
export async function assertCompanyAccount(
  supabase: SupabaseClient<Database>,
  userId: string,
): Promise<void> {
  const { data, error } = await supabase
    .from("profiles")
    .select("account_type")
    .eq("id", userId)
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (data?.account_type !== "company") {
    throw new Error("This action is available to company accounts only.");
  }
}
