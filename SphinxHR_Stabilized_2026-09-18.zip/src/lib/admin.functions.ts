import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { ADMIN_ACTIONS, ADMIN_MODULES, type AdminAction, type AdminModule } from "./admin-access";

/**
 * Admin roles, sub-admin management and authorised data access.
 * Reuses the existing `user_roles` / `has_role` auth system and the existing
 * `profiles` table. Permission storage: `admin_accounts`, `admin_permissions`.
 * Every important change is written to `admin_audit_log`.
 *
 * Every check runs on the server against the verified session — the frontend
 * never decides who may read or write.
 */

const moduleSchema = z.enum(ADMIN_MODULES);
const actionSchema = z.enum(ADMIN_ACTIONS);

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type Sb = any;

async function assertPermission(
  supabase: Sb,
  userId: string,
  module: AdminModule,
  action: AdminAction,
) {
  const { data, error } = await supabase.rpc("admin_can", {
    _user_id: userId,
    _module: module,
    _action: action,
  });
  if (error) throw new Error(error.message);
  if (data !== true) throw new Error("Forbidden");
}

async function assertMainAdmin(supabase: Sb, userId: string) {
  const { data, error } = await supabase.rpc("is_main_admin", { _user_id: userId });
  if (error) throw new Error(error.message);
  if (data !== true) throw new Error("Only the main administrator may perform this action.");
}

async function audit(
  admin: Sb,
  actorId: string,
  actorEmail: string | null,
  action: string,
  targetType: string,
  targetId: string | null,
  changes: Record<string, unknown>,
) {
  await admin.from("admin_audit_log").insert({
    actor_id: actorId,
    actor_email: actorEmail,
    action,
    target_type: targetType,
    target_id: targetId,
    changes,
  });
}

// ---------------------------------------------------------------------------
// Who am I?
// ---------------------------------------------------------------------------

export type AdminAccess = {
  isAdmin: boolean;
  isMain: boolean;
  isDisabled: boolean;
  permissions: string[];
};

export const getMyAdminAccess = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<AdminAccess> => {
    const { supabase, userId } = context;
    const { data: isAdmin } = await supabase.rpc("has_role", { _user_id: userId, _role: "admin" });
    if (isAdmin !== true)
      return { isAdmin: false, isMain: false, isDisabled: false, permissions: [] };

    const { data: account } = await supabase
      .from("admin_accounts")
      .select("is_main, is_disabled")
      .eq("user_id", userId)
      .maybeSingle();
    const { data: perms } = await supabase
      .from("admin_permissions")
      .select("module, action")
      .eq("user_id", userId);

    return {
      isAdmin: true,
      isMain: !!account?.is_main && !account?.is_disabled,
      isDisabled: !!account?.is_disabled,
      permissions: (perms ?? []).map(
        (p: { module: string; action: string }) => `${p.module}:${p.action}`,
      ),
    };
  });

// ---------------------------------------------------------------------------
// Main admin — sub-admin accounts
// ---------------------------------------------------------------------------

export type AdminRow = {
  userId: string;
  email: string | null;
  displayName: string | null;
  isMain: boolean;
  isDisabled: boolean;
  createdAt: string;
  permissions: string[];
};

export const listAdmins = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<AdminRow[]> => {
    await assertMainAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: accounts, error } = await supabaseAdmin
      .from("admin_accounts")
      .select("user_id, is_main, is_disabled, display_name, created_at")
      .order("created_at", { ascending: true });
    if (error) throw new Error(error.message);

    const { data: perms } = await supabaseAdmin
      .from("admin_permissions")
      .select("user_id, module, action");

    const rows: AdminRow[] = [];
    for (const a of accounts ?? []) {
      const { data: u } = await supabaseAdmin.auth.admin.getUserById(a.user_id);
      rows.push({
        userId: a.user_id,
        email: u?.user?.email ?? null,
        displayName: a.display_name,
        isMain: a.is_main,
        isDisabled: a.is_disabled,
        createdAt: a.created_at,
        permissions: (perms ?? [])
          .filter((p) => p.user_id === a.user_id)
          .map((p) => `${p.module}:${p.action}`),
      });
    }
    return rows;
  });

const permListSchema = z
  .array(z.object({ module: moduleSchema, action: actionSchema }))
  .max(ADMIN_MODULES.length * ADMIN_ACTIONS.length)
  .default([]);

export const createSubAdmin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        email: z.string().trim().email().max(200),
        password: z.string().min(8).max(200),
        displayName: z.string().trim().max(200).optional(),
        permissions: permListSchema,
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId, claims } = context;
    await assertMainAdmin(supabase, userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const created = await supabaseAdmin.auth.admin.createUser({
      email: data.email,
      password: data.password,
      email_confirm: true,
      user_metadata: { account_type: "job_seeker", full_name: data.displayName ?? data.email },
    });
    if (created.error || !created.data.user) {
      throw new Error(created.error?.message ?? "Could not create the sub-admin account.");
    }
    const newId = created.data.user.id;

    await supabaseAdmin.from("user_roles").insert({ user_id: newId, role: "admin" });
    await supabaseAdmin.from("admin_accounts").insert({
      user_id: newId,
      is_main: false,
      display_name: data.displayName ?? null,
      created_by: userId,
    });
    if (data.permissions.length > 0) {
      await supabaseAdmin.from("admin_permissions").insert(
        data.permissions.map((p) => ({
          user_id: newId,
          module: p.module,
          action: p.action,
          granted_by: userId,
        })),
      );
    }

    await audit(
      supabaseAdmin,
      userId,
      claims?.email ?? null,
      "sub_admin_created",
      "admin_account",
      newId,
      {
        email: data.email,
        permissions: data.permissions,
      },
    );

    return { userId: newId };
  });

export const setSubAdminPermissions = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ userId: z.string().uuid(), permissions: permListSchema }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId, claims } = context;
    await assertMainAdmin(supabase, userId);
    // A sub-admin can never widen their own authority, and the main admin's own
    // authority is not stored as permission rows.
    if (data.userId === userId) throw new Error("You cannot change your own permissions.");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: target } = await supabaseAdmin
      .from("admin_accounts")
      .select("is_main")
      .eq("user_id", data.userId)
      .maybeSingle();
    if (!target) throw new Error("Administrator not found.");
    if (target.is_main) throw new Error("Main administrators always hold every permission.");

    await supabaseAdmin.from("admin_permissions").delete().eq("user_id", data.userId);
    if (data.permissions.length > 0) {
      await supabaseAdmin.from("admin_permissions").insert(
        data.permissions.map((p) => ({
          user_id: data.userId,
          module: p.module,
          action: p.action,
          granted_by: userId,
        })),
      );
    }

    await audit(
      supabaseAdmin,
      userId,
      claims?.email ?? null,
      "sub_admin_permissions_updated",
      "admin_account",
      data.userId,
      { permissions: data.permissions },
    );
    return { ok: true };
  });

export const setSubAdminDisabled = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ userId: z.string().uuid(), disabled: z.boolean() }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId, claims } = context;
    await assertMainAdmin(supabase, userId);
    if (data.userId === userId) throw new Error("You cannot disable your own account.");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: target } = await supabaseAdmin
      .from("admin_accounts")
      .select("is_main")
      .eq("user_id", data.userId)
      .maybeSingle();
    if (!target) throw new Error("Administrator not found.");
    if (target.is_main) throw new Error("A main administrator cannot be disabled.");

    const { error } = await supabaseAdmin
      .from("admin_accounts")
      .update({ is_disabled: data.disabled })
      .eq("user_id", data.userId);
    if (error) throw new Error(error.message);

    await audit(
      supabaseAdmin,
      userId,
      claims?.email ?? null,
      data.disabled ? "sub_admin_disabled" : "sub_admin_enabled",
      "admin_account",
      data.userId,
      {},
    );
    return { ok: true };
  });

export const resetSubAdminPassword = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ userId: z.string().uuid(), password: z.string().min(8).max(200) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId, claims } = context;
    await assertMainAdmin(supabase, userId);
    if (data.userId === userId) {
      throw new Error("Change your own password from the admin credentials card.");
    }
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.auth.admin.updateUserById(data.userId, {
      password: data.password,
    });
    if (error) throw new Error(error.message);

    await audit(
      supabaseAdmin,
      userId,
      claims?.email ?? null,
      "sub_admin_password_reset",
      "admin_account",
      data.userId,
      {},
    );
    return { ok: true };
  });

// ---------------------------------------------------------------------------
// Activity log
// ---------------------------------------------------------------------------

export type AuditRow = {
  id: string;
  actorEmail: string | null;
  action: string;
  targetType: string | null;
  targetId: string | null;
  changes: string;
  createdAt: string;
};

export const listAdminActivity = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<AuditRow[]> => {
    await assertMainAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin
      .from("admin_audit_log")
      .select("id, actor_email, action, target_type, target_id, changes, created_at")
      .order("created_at", { ascending: false })
      .limit(100);
    if (error) throw new Error(error.message);
    return (data ?? []).map((r) => ({
      id: r.id,
      actorEmail: r.actor_email,
      action: r.action,
      targetType: r.target_type,
      targetId: r.target_id,
      changes: JSON.stringify(r.changes ?? {}),
      createdAt: r.created_at,
    }));
  });

// ---------------------------------------------------------------------------
// Authorised data access — companies & job seekers (existing `profiles` table)
// ---------------------------------------------------------------------------

const PROFILE_COLUMNS =
  "id, account_type, full_name, company_name, email, phone, country, nationality, profession, sector, education, languages, cv_url, cv_uploaded_at, company_code, branches_count, branches_verified, candidate_source, created_at";

export type AdminProfile = {
  id: string;
  account_type: string;
  full_name: string | null;
  company_name: string | null;
  email: string | null;
  phone: string | null;
  country: string | null;
  nationality: string | null;
  profession: string | null;
  sector: string | null;
  education: string | null;
  languages: string | null;
  cv_url: string | null;
  cv_uploaded_at: string | null;
  company_code: string | null;
  branches_count: number | null;
  branches_verified: boolean | null;
  candidate_source: string | null;
  created_at: string;
};

const searchSchema = z.object({
  kind: z.enum(["company", "job_seeker"]),
  query: z.string().trim().max(200).default(""),
});

export const searchProfiles = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => searchSchema.parse(input))
  .handler(async ({ data, context }): Promise<AdminProfile[]> => {
    const module: AdminModule = data.kind === "company" ? "companies" : "job_seekers";
    await assertPermission(context.supabase, context.userId, module, "view");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    let q = supabaseAdmin
      .from("profiles")
      .select(PROFILE_COLUMNS)
      .eq("account_type", data.kind === "company" ? "company" : "job_seeker")
      .order("created_at", { ascending: false })
      .limit(200);

    const term = data.query.replace(/[%,]/g, " ").trim();
    if (term) {
      q = q.or(
        [
          `full_name.ilike.%${term}%`,
          `company_name.ilike.%${term}%`,
          `email.ilike.%${term}%`,
          `phone.ilike.%${term}%`,
          `profession.ilike.%${term}%`,
          `country.ilike.%${term}%`,
        ].join(","),
      );
    }
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    return (rows ?? []) as unknown as AdminProfile[];
  });

const EDITABLE_COMPANY = [
  "company_name",
  "email",
  "phone",
  "country",
  "sector",
  "branches_count",
] as const;
const EDITABLE_SEEKER = [
  "full_name",
  "email",
  "phone",
  "country",
  "nationality",
  "profession",
  "sector",
  "education",
  "languages",
] as const;

export const updateProfileFields = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        userId: z.string().uuid(),
        kind: z.enum(["company", "job_seeker"]),
        fields: z.record(z.string(), z.union([z.string(), z.number(), z.null()])),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId, claims } = context;
    const module: AdminModule = data.kind === "company" ? "companies" : "job_seekers";
    await assertPermission(supabase, userId, module, "edit");

    const allowed: readonly string[] = data.kind === "company" ? EDITABLE_COMPANY : EDITABLE_SEEKER;
    const patch: Record<string, string | number | null> = {};
    for (const [k, v] of Object.entries(data.fields)) {
      if (allowed.includes(k))
        patch[k] = typeof v === "string" ? v.trim().slice(0, 400) || null : v;
    }
    if (Object.keys(patch).length === 0) throw new Error("Nothing to update.");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: before } = await supabaseAdmin
      .from("profiles")
      .select(PROFILE_COLUMNS)
      .eq("id", data.userId)
      .maybeSingle();
    if (!before) throw new Error("Profile not found.");

    const { error } = await supabaseAdmin
      .from("profiles")
      .update(patch as never)
      .eq("id", data.userId);
    if (error) throw new Error(error.message);

    await audit(
      supabaseAdmin,
      userId,
      claims?.email ?? null,
      "profile_updated",
      "profile",
      data.userId,
      {
        kind: data.kind,
        patch,
      },
    );
    return { ok: true };
  });

/**
 * Verification. Companies reuse the existing `branches_verified` flag; job
 * seekers reuse the existing `candidate_source` field ("verified"). No new
 * columns are introduced.
 */
export const verifyProfile = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        userId: z.string().uuid(),
        kind: z.enum(["company", "job_seeker"]),
        verified: z.boolean(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId, claims } = context;
    const module: AdminModule = data.kind === "company" ? "companies" : "job_seekers";
    await assertPermission(supabase, userId, module, "verify");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const patch =
      data.kind === "company"
        ? { branches_verified: data.verified }
        : { candidate_source: data.verified ? "verified" : "registered" };
    const { error } = await supabaseAdmin
      .from("profiles")
      .update(patch as never)
      .eq("id", data.userId);
    if (error) throw new Error(error.message);

    await audit(
      supabaseAdmin,
      userId,
      claims?.email ?? null,
      "profile_verified",
      "profile",
      data.userId,
      {
        kind: data.kind,
        verified: data.verified,
      },
    );
    return { ok: true };
  });

/** Signed download link for a candidate CV, gated by the CVs permission. */
export const getCvLink = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ userId: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }): Promise<{ url: string; fileName: string }> => {
    const { supabase, userId, claims } = context;
    await assertPermission(supabase, userId, "cvs", "view");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: profile } = await supabaseAdmin
      .from("profiles")
      .select("cv_url")
      .eq("id", data.userId)
      .maybeSingle();
    if (!profile?.cv_url) throw new Error("This candidate has no CV on file.");

    const path = profile.cv_url as string;
    const fileName = path.substring(path.lastIndexOf("/") + 1);
    const { isInlineViewable } = await import("@/lib/open-file");
    const signed = await supabaseAdmin.storage
      .from("cvs")
      .createSignedUrl(path, 300, isInlineViewable(fileName) ? undefined : { download: fileName });
    if (signed.error || !signed.data)
      throw new Error(signed.error?.message ?? "Could not open the CV.");

    await audit(
      supabaseAdmin,
      userId,
      claims?.email ?? null,
      "cv_viewed",
      "profile",
      data.userId,
      {},
    );
    return { url: signed.data.signedUrl, fileName };
  });

/** Server-side gate for the Print / Export report actions. */
export const authorizeReport = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ mode: z.enum(["print", "export"]), scope: z.string().trim().max(120) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId, claims } = context;
    await assertPermission(supabase, userId, "reports", data.mode);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await audit(
      supabaseAdmin,
      userId,
      claims?.email ?? null,
      `report_${data.mode}`,
      "report",
      null,
      {
        scope: data.scope,
      },
    );
    return { ok: true };
  });

// ---------------------------------------------------------------------------
// Job applications review (reuses the existing `job_applications` table and
// its `application_status` enum — no new tables or statuses).
// ---------------------------------------------------------------------------

export type AdminApplication = {
  id: string;
  status: string;
  created_at: string;
  candidate_id: string;
  employer_id: string | null;
  candidate_name: string | null;
  candidate_email: string | null;
  company_name: string | null;
  job_title: string | null;
  cv_url: string | null;
};

export const listApplications = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ query: z.string().trim().max(200).default("") }).parse(input),
  )
  .handler(async ({ data, context }): Promise<AdminApplication[]> => {
    await assertPermission(context.supabase, context.userId, "applications", "view");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: rows, error } = await supabaseAdmin
      .from("job_applications")
      .select(
        "id, status, created_at, candidate_id, employer_id, cv_url, job_snapshot, candidate_snapshot",
      )
      .order("created_at", { ascending: false })
      .limit(300);
    if (error) throw new Error(error.message);

    const term = data.query.toLowerCase();
    const list = (rows ?? []).map((r) => {
      const job = (r.job_snapshot ?? {}) as Record<string, unknown>;
      const cand = (r.candidate_snapshot ?? {}) as Record<string, unknown>;
      const str = (v: unknown) => (typeof v === "string" && v.trim() ? v : null);
      return {
        id: r.id as string,
        status: r.status as string,
        created_at: r.created_at as string,
        candidate_id: r.candidate_id as string,
        employer_id: (r.employer_id as string | null) ?? null,
        candidate_name: str(cand["full_name"]) ?? str(cand["name"]),
        candidate_email: str(cand["email"]),
        company_name: str(job["company_name"]) ?? str(job["company"]),
        job_title: str(job["title_en"]) ?? str(job["title_ar"]) ?? str(job["title"]),
        cv_url: (r.cv_url as string | null) ?? null,
      };
    });
    if (!term) return list;
    return list.filter((a) =>
      [a.candidate_name, a.candidate_email, a.company_name, a.job_title, a.status]
        .filter(Boolean)
        .some((v) => String(v).toLowerCase().includes(term)),
    );
  });

/** Approve (shortlist) or reject an application on behalf of the platform. */
export const reviewApplication = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        applicationId: z.string().uuid(),
        decision: z.enum(["approve", "reject"]),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId, claims } = context;
    await assertPermission(supabase, userId, "applications", "approve");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: existing, error: readError } = await supabaseAdmin
      .from("job_applications")
      .select("id, status, status_history")
      .eq("id", data.applicationId)
      .maybeSingle();
    if (readError) throw new Error(readError.message);
    if (!existing) throw new Error("Application not found.");

    const status = data.decision === "approve" ? "shortlisted" : "rejected";
    const history = Array.isArray(existing.status_history) ? existing.status_history : [];
    const { error } = await supabaseAdmin
      .from("job_applications")
      .update({
        status,
        status_history: [...history, { status, at: new Date().toISOString(), by: "admin" }],
      } as never)
      .eq("id", data.applicationId);
    if (error) throw new Error(error.message);

    await audit(
      supabaseAdmin,
      userId,
      claims?.email ?? null,
      "application_reviewed",
      "job_application",
      data.applicationId,
      { decision: data.decision, status },
    );
    return { ok: true, status };
  });
