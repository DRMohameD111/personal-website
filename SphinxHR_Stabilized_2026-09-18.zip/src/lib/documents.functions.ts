import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/**
 * Optional supporting documents for the existing job-seeker profile
 * (`candidate_documents` + the existing private `cvs` storage bucket).
 * The CV itself stays on `profiles.cv_url` — no duplicate CV storage.
 */

export const DOC_TYPES = [
  "education",
  "experience",
  "professional",
  "training",
  "license",
  "recommendation",
  "portfolio",
  "other",
] as const;

export type DocType = (typeof DOC_TYPES)[number];

export type CandidateDocument = {
  id: string;
  docType: DocType;
  title: string | null;
  fileName: string | null;
  sizeBytes: number | null;
  createdAt: string;
};

const row = (d: {
  id: string;
  doc_type: string;
  title: string | null;
  file_name: string | null;
  size_bytes: number | null;
  created_at: string;
}): CandidateDocument => ({
  id: d.id,
  docType: (DOC_TYPES as readonly string[]).includes(d.doc_type)
    ? (d.doc_type as DocType)
    : "other",
  title: d.title,
  fileName: d.file_name,
  sizeBytes: d.size_bytes,
  createdAt: d.created_at,
});

export const listMyDocuments = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<CandidateDocument[]> => {
    const { supabase, userId } = context;
    const { data, error } = await supabase
      .from("candidate_documents")
      .select("id, doc_type, title, file_name, size_bytes, created_at")
      .eq("user_id", userId)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return (data ?? []).map(row);
  });

const saveSchema = z.object({
  id: z.string().uuid().optional(),
  docType: z.enum(DOC_TYPES).default("other"),
  title: z.string().trim().max(200).optional(),
  storagePath: z.string().trim().min(1).max(800).optional(),
  fileName: z.string().trim().max(300).optional(),
  sizeBytes: z
    .number()
    .int()
    .min(0)
    .max(20 * 1024 * 1024)
    .optional(),
});

/** Create a new document row, or update an existing one (same record). */
export const saveMyDocument = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => saveSchema.parse(input))
  .handler(async ({ data, context }): Promise<CandidateDocument> => {
    const { supabase, userId } = context;

    if (data.id) {
      const patch: Record<string, unknown> = {
        doc_type: data.docType,
        title: data.title ?? null,
      };
      if (data.storagePath) {
        patch.storage_path = data.storagePath;
        patch.file_name = data.fileName ?? null;
        patch.size_bytes = data.sizeBytes ?? null;
      }
      const { data: updated, error } = await supabase
        .from("candidate_documents")
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        .update(patch as any)
        .eq("id", data.id)
        .eq("user_id", userId)
        .select("id, doc_type, title, file_name, size_bytes, created_at")
        .single();
      if (error) throw new Error(error.message);
      return row(updated);
    }

    if (!data.storagePath) throw new Error("Missing file");
    const { data: inserted, error } = await supabase
      .from("candidate_documents")
      .insert({
        user_id: userId,
        doc_type: data.docType,
        title: data.title ?? null,
        storage_path: data.storagePath,
        file_name: data.fileName ?? null,
        size_bytes: data.sizeBytes ?? null,
      })
      .select("id, doc_type, title, file_name, size_bytes, created_at")
      .single();
    if (error) throw new Error(error.message);
    return row(inserted);
  });

export const deleteMyDocument = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: doc } = await supabase
      .from("candidate_documents")
      .select("storage_path")
      .eq("id", data.id)
      .eq("user_id", userId)
      .maybeSingle();
    const { error } = await supabase
      .from("candidate_documents")
      .delete()
      .eq("id", data.id)
      .eq("user_id", userId);
    if (error) throw new Error(error.message);
    if (doc?.storage_path) {
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
      await supabaseAdmin.storage.from("cvs").remove([doc.storage_path as string]);
    }
    return { ok: true };
  });

/** Short-lived link to a document, for its owner or the employer of a job it applied to. */
export const getDocumentUrl = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }): Promise<{ url: string; fileName: string }> => {
    const { supabase } = context;
    // RLS already restricts visibility to the owner and applied-to employers.
    const { data: doc, error } = await supabase
      .from("candidate_documents")
      .select("storage_path, file_name")
      .eq("id", data.id)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!doc?.storage_path) throw new Error("Document not available");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const path = doc.storage_path as string;
    const fileName = (doc.file_name as string | null) || path.substring(path.lastIndexOf("/") + 1);
    const { isInlineViewable } = await import("@/lib/open-file");
    const { data: signed, error: sErr } = await supabaseAdmin.storage
      .from("cvs")
      .createSignedUrl(path, 300, isInlineViewable(fileName) ? undefined : { download: fileName });
    if (sErr || !signed) throw new Error(sErr?.message ?? "Could not create link");
    return { url: signed.signedUrl, fileName };
  });

/** Documents of a candidate who applied to one of the caller's own vacancies. */
export const listApplicantDocuments = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ applicationId: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }): Promise<CandidateDocument[]> => {
    const { supabase, userId } = context;
    const { data: app, error } = await supabase
      .from("job_applications")
      .select("candidate_id, employer_id")
      .eq("id", data.applicationId)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!app || app.employer_id !== userId) throw new Error("Forbidden");
    const { data: docs, error: dErr } = await supabase
      .from("candidate_documents")
      .select("id, doc_type, title, file_name, size_bytes, created_at")
      .eq("user_id", app.candidate_id)
      .order("created_at", { ascending: false });
    if (dErr) throw new Error(dErr.message);
    return (docs ?? []).map(row);
  });
