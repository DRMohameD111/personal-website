import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Search,
  MapPin,
  Briefcase,
  Banknote,
  ArrowRight,
  Filter,
  X,
  Sparkles,
  FileDown,
  FileSpreadsheet,
  Building2,
  Clock,
  CalendarPlus,
  GraduationCap,
  CheckCircle2,
  Share2,
  Loader2,
  Mail,
  Send,
  Upload,
  Copy,
  BadgeCheck,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { useI18n, tx } from "@/i18n";
import { SECTORS, getSector, type BiLabel } from "@/lib/sectors";
import { supabase } from "@/integrations/supabase/client";
import {
  applyToJob,
  getProfileReadiness,
  updateCandidateProfile,
  type ProfileReadiness,
} from "@/lib/applications.functions";
import { useAppliedJobs } from "@/lib/use-applied-jobs";
import { JobCard } from "@/components/JobCard";
import { MultiSelectFilter, FilterChip, type MultiOption } from "@/components/MultiSelectFilter";
import { JobValuationBadge } from "@/components/JobValuationBadge";
import { useJobInsights } from "@/lib/use-job-insights";
import {
  ADVERTISER_LABEL,
  AD_DATE,
  APPLICANTS_LABEL,
  COPY_EMAIL_CTA,
  DAYS_REMAINING,
  DIRECT_AD_CONTACT_HINT,
  DIRECT_AD_REGISTER_HINT,
  DIRECT_AD_LABEL,
  JOB_CLOSING_DATE,
  JOB_STATE_TONE,
  JOB_VALUATION_TITLE,
  PUBLICATION_DATE,
  SEND_NOW_CTA,
  TIME_REMAINING,
  TRUSTED_AD_LABEL,
  VIEWS_LABEL,
  jobStateLabel,
  recordJobView,
  type JobInsight,
} from "@/lib/valuation";
import {
  JOBS,
  COUNTRY,
  CITY,
  LEVEL,
  EMPLOYMENT_TYPES,
  bi,
  skillLabel,
  fetchPublishedJobs,
  compareAddedAt,
  formatJobDate,
  jobCode,
  JOB_ADDED_DATE,
  type Job,
  type SortDir,
} from "@/lib/jobs";

type JobsSearch = {
  sector?: string;
  skills?: string;
  /** Deep-link to a single vacancy (used when returning from profile completion). */
  job?: string;
};

export const Route = createFileRoute("/jobs")({
  validateSearch: (search: Record<string, unknown>): JobsSearch => ({
    sector: typeof search.sector === "string" ? search.sector : undefined,
    skills: typeof search.skills === "string" ? search.skills : undefined,
    job: typeof search.job === "string" ? search.job : undefined,
  }),

  head: () => ({
    meta: [
      { title: "Jobs — SPHINX Workforce" },
      {
        name: "description",
        content:
          "Browse open roles across Saudi Arabia, the GCC and Egypt — engineers, technicians, skilled labour, hospitality and corporate positions.",
      },
      { property: "og:title", content: "Open Jobs — SPHINX Workforce" },
      {
        property: "og:description",
        content: "Curated opportunities across KSA, the GCC and Egypt.",
      },
    ],
  }),
  component: JobsPage,
});

// Build bilingual narrative sections for a job using its existing attributes.
function jobNarrative(j: Job) {
  const summary: BiLabel = {
    en: `We are hiring a ${j.level.en} ${j.title.en} to join our ${j.profession.en} team in ${j.city.en}, ${j.country.en}. This ${j.type.en.toLowerCase()} role offers competitive compensation in the range of ${j.salary.en} and the opportunity to work on impactful projects across the region.`,
    ar: `نبحث عن ${j.title.ar} (${j.level.ar}) للانضمام إلى فريق ${j.profession.ar} في ${j.city.ar}، ${j.country.ar}. وظيفة ${j.type.ar} براتب تنافسي ضمن نطاق ${j.salary.ar}، مع فرصة المساهمة في مشاريع مؤثرة على مستوى المنطقة.`,
  };

  const responsibilities: BiLabel[] = [
    {
      en: `Lead day-to-day ${j.profession.en.toLowerCase()} activities and deliver work to agreed quality, cost and timeline.`,
      ar: `قيادة الأنشطة اليومية لـ${j.profession.ar} وتسليم الأعمال وفق معايير الجودة والتكلفة والجدول الزمني.`,
    },
    {
      en: `Collaborate with cross-functional teams, vendors and client stakeholders to meet project objectives.`,
      ar: `التنسيق مع الفرق متعددة التخصصات والموردين وأصحاب المصلحة لتحقيق أهداف المشروع.`,
    },
    {
      en: `Apply industry best practices and ensure full compliance with HSE, regulatory and company standards.`,
      ar: `تطبيق أفضل الممارسات في المجال والالتزام التام بمعايير السلامة والاشتراطات النظامية وسياسات الشركة.`,
    },
    {
      en: `Prepare reports, dashboards and updates for line management and continuously improve processes.`,
      ar: `إعداد التقارير ولوحات المتابعة والتحديثات للإدارة، والعمل على التحسين المستمر للعمليات.`,
    },
  ];

  const requirements: BiLabel[] = [
    {
      en: `Relevant degree or recognized certification in ${j.profession.en}.`,
      ar: `شهادة جامعية أو اعتماد معترف به في تخصص ${j.profession.ar}.`,
    },
    {
      en: `Proven ${j.level.en.toLowerCase()}-level experience in a similar ${j.profession.en.toLowerCase()} role, ideally in the GCC or Egypt.`,
      ar: `خبرة عملية بمستوى ${j.level.ar} في دور مشابه ضمن ${j.profession.ar}، ويفضل في دول الخليج أو مصر.`,
    },
    {
      en: `Strong working knowledge of: ${j.skills.join(", ")}.`,
      ar: `إلمام عملي قوي بـ: ${j.skills.map((s) => skillLabel(s).ar).join("، ")}.`,
    },
    {
      en: `Excellent communication skills in English; Arabic is a strong plus.`,
      ar: `مهارات تواصل ممتازة باللغة الإنجليزية، وإجادة العربية ميزة إضافية.`,
    },
    {
      en: `Valid right to work in ${j.country.en} (or willingness to relocate).`,
      ar: `حق العمل في ${j.country.ar} أو الاستعداد للانتقال.`,
    },
  ];

  const benefits: BiLabel[] = [
    { en: `Competitive salary: ${j.salary.en}`, ar: `راتب تنافسي: ${j.salary.ar}` },
    { en: `Medical insurance for employee and dependents`, ar: `تأمين طبي للموظف وأفراد الأسرة` },
    {
      en: `Annual leave, end-of-service benefits and air tickets per local law`,
      ar: `إجازة سنوية ومكافأة نهاية الخدمة وتذاكر سفر وفق الأنظمة المحلية`,
    },
    {
      en: `Career development through SPHINX learning programs`,
      ar: `تطوير مهني عبر برامج التدريب والتأهيل في سفنكس`,
    },
  ];

  return { summary, responsibilities, requirements, benefits };
}

function JobsPage() {
  const { t, lang } = useI18n();
  const navigate = useNavigate({ from: "/jobs" });
  const { sector: sectorParam, skills: skillsParam, job: jobParam } = Route.useSearch();
  const selectedSkills = useMemo(
    () => (skillsParam ? skillsParam.split(",").filter(Boolean) : []),
    [skillsParam],
  );
  /** Sector supports multiple values (comma list) — single values stay compatible. */
  const sectors = useMemo(
    () => (sectorParam ? sectorParam.split(",").filter(Boolean) : []),
    [sectorParam],
  );
  const sectorMeta = getSector(sectors.length === 1 ? sectors[0] : undefined);

  const applied = useAppliedJobs();
  const [q, setQ] = useState("");
  // Categorical filters are multi-select (OR inside a group, AND across groups).
  const [country, setCountry] = useState<string[]>([]);
  const [city, setCity] = useState<string[]>([]);
  const [level, setLevel] = useState<string[]>([]);
  const [type, setType] = useState<string[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(jobParam ?? null);
  const [sortDir, setSortDir] = useState<SortDir>("newest");

  // Returning from profile completion / sign-in re-opens the same vacancy.
  useEffect(() => {
    if (jobParam) setSelectedId(jobParam);
  }, [jobParam]);

  // A view is counted only when the Job Details panel is actually opened.
  const counted = useRef(new Set<string>());
  useEffect(() => {
    if (!selectedId || counted.current.has(selectedId)) return;
    counted.current.add(selectedId);
    void recordJobView(selectedId);
  }, [selectedId]);

  // Every job published by a company account is loaded automatically here —
  // no manual step, no separate listing model.
  const { data: publishedJobs = [] } = useQuery({
    queryKey: ["published-jobs"],
    queryFn: fetchPublishedJobs,
    staleTime: 30_000,
    refetchOnMount: "always",
  });

  const allJobs = useMemo<Job[]>(() => {
    const seen = new Set<string>();
    return [...publishedJobs, ...JOBS].filter((j) => {
      const key = `${j.id}`.toLowerCase();
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }, [publishedJobs]);

  // Applicant count, status and automatic Job Valuation (shared hook).
  const { insights, config } = useJobInsights(allJobs);

  // Filter options use English keys; we display labels via the dicts.
  const opts = useMemo(() => {
    const uniq = (k: "country" | "city" | "level" | "type") =>
      Array.from(new Set(allJobs.map((j) => j[k].en).filter(Boolean))).sort();
    return {
      country: uniq("country"),
      city: uniq("city"),
      level: uniq("level"),
      type: uniq("type"),
    };
  }, [allJobs]);

  const filtered = useMemo(() => {
    const ql = q.trim().toLowerCase();
    const skillSet = new Set(selectedSkills.map((s: string) => s.toLowerCase()));
    // Empty group = no constraint; otherwise OR inside the group.
    const inGroup = (selected: string[], value: string) =>
      selected.length === 0 || selected.includes(value);
    const scored = allJobs
      .map((j) => {
        if (!inGroup(country, j.country.en)) return null;
        if (!inGroup(city, j.city.en)) return null;
        if (!inGroup(level, j.level.en)) return null;
        if (!inGroup(type, j.type.en)) return null;
        if (ql) {
          // Search across both languages
          const hay = [
            j.title.en,
            j.title.ar,
            j.city.en,
            j.city.ar,
            j.country.en,
            j.country.ar,
            j.profession.en,
            j.profession.ar,
          ]
            .join(" ")
            .toLowerCase();
          if (!hay.includes(ql)) return null;
        }
        if (!inGroup(sectors, j.sector)) return null;
        const matchedSkills = j.skills.filter((s) => skillSet.has(s.toLowerCase()));
        if (skillSet.size > 0 && matchedSkills.length === 0) return null;
        return { job: j, matchedSkills };
      })
      .filter(Boolean) as { job: Job; matchedSkills: string[] }[];
    // Skill matches first, then Job Added Date (newest / oldest), then title.
    scored.sort(
      (a, b) =>
        b.matchedSkills.length - a.matchedSkills.length ||
        compareAddedAt(a.job, b.job, sortDir) ||
        a.job.title[lang].localeCompare(b.job.title[lang]),
    );
    return scored;
  }, [allJobs, q, country, city, level, type, sectors, selectedSkills, lang, sortDir]);

  const setSectors = (next: string[]) =>
    navigate({
      search: (prev: JobsSearch) => ({ ...prev, sector: next.length ? next.join(",") : undefined }),
    });

  const removeSkill = (skill: string) => {
    const next = selectedSkills.filter((s: string) => s !== skill);
    navigate({
      search: (prev: JobsSearch) => ({ ...prev, skills: next.length ? next.join(",") : undefined }),
    });
  };

  const clearMatch = () => navigate({ search: () => ({}) as JobsSearch });

  /** Multi-select groups, declared once and reused for controls and chips. */
  const groups = [
    {
      key: "sector",
      label: tx("Sector", "القطاع"),
      values: sectors,
      set: setSectors,
      options: SECTORS.map((s) => ({ value: s.id, label: s.label })),
    },
    {
      key: "country",
      label: tx("Country", "الدولة"),
      values: country,
      set: setCountry,
      options: opts.country.map((o) => ({ value: o, label: bi(COUNTRY, o) })),
    },
    {
      key: "city",
      label: tx("City", "المدينة"),
      values: city,
      set: setCity,
      options: opts.city.map((o) => ({ value: o, label: bi(CITY, o) })),
    },
    {
      key: "level",
      label: tx("Experience", "الخبرة"),
      values: level,
      set: setLevel,
      options: opts.level.map((o) => ({ value: o, label: bi(LEVEL, o) })),
    },
    {
      key: "type",
      label: tx("Employment Type", "نوع التوظيف"),
      values: type,
      set: setType,
      options: EMPLOYMENT_TYPES.map((o) => ({ value: o.label.en, label: o.label })),
    },
  ] satisfies {
    key: string;
    label: BiLabel;
    values: string[];
    set: (next: string[]) => void;
    options: MultiOption[];
  }[];

  const activeCount =
    groups.reduce((n, g) => n + g.values.length, 0) + selectedSkills.length + (q.trim() ? 1 : 0);

  const clearAll = () => {
    setQ("");
    setCountry([]);
    setCity([]);
    setLevel([]);
    setType([]);
    setSortDir("newest");
    clearMatch();
  };

  const exportRows = useMemo(
    () =>
      filtered.map(({ job: j }) => ({
        code: jobCode(j),
        title: t(j.title),
        country: t(j.country),
        city: t(j.city),
        profession: t(j.profession),
        level: t(j.level),
        type: t(j.type),
        salary: t(j.salary),
        addedAt: formatJobDate(j.addedAt, lang),
        skills: j.skills.map((s) => t(skillLabel(s))).join(" | "),
      })),
    [filtered, t, lang],
  );

  const headers = {
    code: t(tx("Job Code", "كود الوظيفة")),
    title: t(tx("Title", "المسمى")),
    country: t(tx("Country", "الدولة")),
    city: t(tx("City", "المدينة")),
    profession: t(tx("Profession", "المهنة")),
    level: t(tx("Experience", "الخبرة")),
    type: t(tx("Type", "النوع")),
    salary: t(tx("Salary", "الراتب")),
    addedAt: t(JOB_ADDED_DATE),
    skills: t(tx("Skills", "المهارات")),
  };

  const exportCSV = () => {
    const cols = [
      "code",
      "title",
      "country",
      "city",
      "profession",
      "level",
      "type",
      "salary",
      "addedAt",
      "skills",
    ] as const;
    const esc = (v: string) => `"${v.replace(/"/g, '""')}"`;
    const lines = [
      cols.map((c) => esc(headers[c])).join(","),
      ...exportRows.map((r) => cols.map((c) => esc(r[c])).join(",")),
    ];
    // UTF-8 BOM so Excel renders Arabic correctly
    const blob = new Blob(["\uFEFF" + lines.join("\r\n")], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `sphinx-jobs-${lang}-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportPDF = () => {
    const dir = lang === "ar" ? "rtl" : "ltr";
    const title = t(tx("Open Roles — SPHINX Workforce", "الوظائف المتاحة — سفنكس"));
    const cols = [
      "code",
      "title",
      "country",
      "city",
      "profession",
      "level",
      "type",
      "salary",
      "addedAt",
      "skills",
    ] as const;
    const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    const html = `<!doctype html><html lang="${lang}" dir="${dir}"><head><meta charset="utf-8"><title>${esc(title)}</title>
<style>
  body{font-family:${lang === "ar" ? '"Segoe UI","Tahoma","Arial",sans-serif' : '"Helvetica","Arial",sans-serif'};color:#111;padding:24px;}
  h1{font-size:20px;margin:0 0 4px;}
  .meta{font-size:12px;color:#666;margin-bottom:16px;}
  table{width:100%;border-collapse:collapse;font-size:11px;}
  th,td{border:1px solid #ddd;padding:6px 8px;text-align:${lang === "ar" ? "right" : "left"};vertical-align:top;}
  th{background:#c9a14a;color:#fff;}
  tr:nth-child(even) td{background:#fafafa;}
  @media print{@page{size:A4 landscape;margin:12mm;}}
</style></head><body>
<h1>${esc(title)}</h1>
<div class="meta">${esc(new Date().toLocaleDateString(lang === "ar" ? "ar-EG" : "en-US"))} · ${exportRows.length} ${esc(t(tx("roles", "وظيفة")))}</div>
<table><thead><tr>${cols.map((c) => `<th>${esc(headers[c])}</th>`).join("")}</tr></thead>
<tbody>${exportRows
      .map((r) => `<tr>${cols.map((c) => `<td>${esc(r[c])}</td>`).join("")}</tr>`)
      .join("")}</tbody></table>
<script>window.addEventListener('load',()=>{setTimeout(()=>{window.print();},250);});</script>
</body></html>`;
    const w = window.open("", "_blank");
    if (!w) return;
    w.document.open();
    w.document.write(html);
    w.document.close();
  };

  return (
    <main className="min-h-screen">
      <section className="relative pt-32 pb-12 md:pt-44 md:pb-16">
        <div className="absolute inset-0 bg-gradient-hero opacity-90" />
        <div className="relative mx-auto max-w-5xl px-4 text-center sm:px-6 lg:px-8">
          <span className="text-xs font-semibold uppercase tracking-[0.25em] text-gold-dark">
            {t(tx("Open Roles", "وظائف متاحة"))}
          </span>
          <h1 className="mt-3 font-display text-4xl font-bold text-foreground md:text-6xl">
            {t(tx("Find Your Next Role", "ابحث عن وظيفتك القادمة"))}
          </h1>
          <div className="gold-divider mx-auto mt-6 w-24" />
          <p className="mx-auto mt-5 max-w-2xl text-base text-muted-foreground md:text-lg">
            {t(
              tx(
                "Curated opportunities across Saudi Arabia, the GCC and Egypt.",
                "فرص منتقاة في السعودية ودول الخليج ومصر.",
              ),
            )}
          </p>
        </div>
      </section>

      <section className="pb-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          {(sectorMeta || selectedSkills.length > 0) && (
            <div className="mb-6 rounded-2xl border border-primary/40 bg-primary/5 p-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-gold-dark">
                    <Sparkles className="h-3.5 w-3.5" />
                    {t(tx("Matched to your profile", "وظائف مطابقة لملفك"))}
                  </div>
                  {sectorMeta && (
                    <div className="mt-2 text-sm text-foreground">
                      {t(tx("Sector", "القطاع"))}:{" "}
                      <span className="font-semibold text-gold-dark">{t(sectorMeta.label)}</span>
                    </div>
                  )}
                  {selectedSkills.length > 0 && (
                    <div className="mt-3 flex flex-wrap gap-1.5">
                      {selectedSkills.map((s: string) => (
                        <button
                          key={s}
                          type="button"
                          onClick={() => removeSkill(s)}
                          className="inline-flex items-center gap-1 rounded-full bg-gradient-gold text-primary-foreground px-2.5 py-1 text-[11px] font-semibold"
                          title={t(tx("Remove skill", "إزالة المهارة"))}
                        >
                          {t(skillLabel(s))}
                          <X className="h-3 w-3" />
                        </button>
                      ))}
                    </div>
                  )}
                </div>
                <button
                  type="button"
                  onClick={clearMatch}
                  className="text-xs font-semibold text-muted-foreground hover:text-gold-dark"
                >
                  {t(tx("Clear match", "إلغاء المطابقة"))}
                </button>
              </div>
            </div>
          )}

          <div className="rounded-2xl bg-gradient-card ring-inset-gold p-5 md:p-7">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder={t(
                  tx("Search by title, city, or profession…", "ابحث بالمسمى أو المدينة أو المهنة…"),
                )}
                className="pl-9 h-12 bg-background"
              />
            </div>

            <div className="mt-4 flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-gold-dark">
                <Filter className="h-3.5 w-3.5" />
                {t(tx("Filters", "تصفية"))}
                {activeCount > 0 && <span className="normal-case">({activeCount})</span>}
              </div>
              {activeCount > 0 && (
                <button
                  type="button"
                  onClick={clearAll}
                  className="text-xs font-semibold text-muted-foreground hover:text-gold-dark"
                >
                  {t(tx("Clear all", "مسح الكل"))}
                </button>
              )}
            </div>

            <div className="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
              {groups.map((g) => (
                <MultiSelectFilter
                  key={g.key}
                  label={g.label}
                  options={g.options}
                  values={g.values}
                  onChange={g.set}
                />
              ))}
            </div>

            {activeCount > 0 && (
              <div className="mt-4 flex flex-wrap gap-1.5 border-t border-border/60 pt-4">
                {groups.flatMap((g) =>
                  g.values.map((v) => {
                    const label = g.options.find((o) => o.value === v)?.label;
                    return (
                      <FilterChip
                        key={`${g.key}:${v}`}
                        text={label ? t(label) : v}
                        onRemove={() => g.set(g.values.filter((x) => x !== v))}
                      />
                    );
                  }),
                )}
                {q.trim() && (
                  <FilterChip
                    text={`${t(tx("Search", "بحث"))}: ${q.trim()}`}
                    onRemove={() => setQ("")}
                  />
                )}
              </div>
            )}
          </div>

          <div className="mt-6 mb-4 flex flex-wrap items-center justify-between gap-3">
            <div className="text-sm text-muted-foreground">
              {filtered.length} {t(tx(filtered.length === 1 ? "role" : "roles", "وظيفة"))}
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <label className="inline-flex items-center gap-2 text-xs text-muted-foreground">
                <CalendarPlus className="h-3.5 w-3.5 text-gold-dark" />
                {t(tx("Sort by date", "الترتيب حسب التاريخ"))}
                <select
                  value={sortDir}
                  onChange={(e) => setSortDir(e.target.value as SortDir)}
                  className="rounded-md border border-input bg-background px-2 py-1.5 text-xs text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                >
                  <option value="newest">{t(tx("Newest first", "الأحدث أولاً"))}</option>
                  <option value="oldest">{t(tx("Oldest first", "الأقدم أولاً"))}</option>
                </select>
              </label>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={exportCSV}
                disabled={exportRows.length === 0}
              >
                <FileSpreadsheet className="h-4 w-4" />
                {t(tx("Export Excel", "تصدير Excel"))}
              </Button>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={exportPDF}
                disabled={exportRows.length === 0}
              >
                <FileDown className="h-4 w-4" />
                {t(tx("Export PDF", "تصدير PDF"))}
              </Button>
            </div>
          </div>

          {(() => {
            const selectedJob = selectedId
              ? filtered.find((r) => r.job.id === selectedId)?.job
              : null;
            const listColsClass = selectedJob
              ? "grid gap-4 grid-cols-1"
              : "grid gap-4 md:grid-cols-2";

            return (
              <div
                className={
                  selectedJob ? "grid gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.4fr)]" : ""
                }
              >
                {/* Detail panel — rendered FIRST in DOM:
                    LTR (en) → appears on the LEFT
                    RTL (ar) → appears on the RIGHT */}
                {selectedJob && (
                  <aside className="order-1 lg:sticky lg:top-24 lg:self-start">
                    <JobDetailPanel
                      job={selectedJob}
                      insight={insights[selectedJob.id]}
                      showApplicantCount={config.show_applicant_count_public}
                      onClose={() => setSelectedId(null)}
                    />
                  </aside>
                )}

                <div className={selectedJob ? "order-2 min-w-0" : "min-w-0"}>
                  <div className={listColsClass}>
                    {filtered.map(({ job: j, matchedSkills }) => (
                      <JobCard
                        key={j.id}
                        job={j}
                        matchedSkills={matchedSkills}
                        applied={applied[j.id]}
                        active={j.id === selectedId}
                        insight={insights[j.id]}
                        showApplicantCount={config.show_applicant_count_public}
                        onSelect={setSelectedId}
                      />
                    ))}
                  </div>

                  {filtered.length === 0 && (
                    <div className="mt-10 rounded-2xl bg-gradient-card ring-inset-gold p-10 text-center">
                      <p className="text-sm text-muted-foreground">
                        {t(
                          tx(
                            "No roles match your filters. Try broadening your search.",
                            "لا توجد وظائف مطابقة. حاول توسيع البحث.",
                          ),
                        )}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            );
          })()}
        </div>
      </section>
    </main>
  );
}

function JobDetailPanel({
  job,
  onClose,
  insight,
  showApplicantCount = false,
}: {
  job: Job;
  onClose: () => void;
  insight?: JobInsight;
  showApplicantCount?: boolean;
}) {
  const { t, lang } = useI18n();
  const n = useMemo(() => jobNarrative(job), [job]);
  const isDirect = insight?.directAd ?? job.directAd ?? false;

  const Section = ({
    icon: Icon,
    title,
    children,
  }: {
    icon: typeof CheckCircle2;
    title: BiLabel;
    children: ReactNode;
  }) => (
    <div className="mt-6">
      <h3 className="flex items-center gap-2 font-display text-base font-semibold text-foreground">
        <Icon className="h-4 w-4 text-gold-dark" />
        {t(title)}
      </h3>
      <div className="mt-3 text-sm leading-relaxed text-muted-foreground">{children}</div>
    </div>
  );

  const Bullets = ({ items }: { items: BiLabel[] }) => (
    <ul className="space-y-2">
      {items.map((it, i) => (
        <li key={i} className="flex items-start gap-2">
          <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-gold-dark" />
          <span>{t(it)}</span>
        </li>
      ))}
    </ul>
  );

  const share = async () => {
    const url = typeof window !== "undefined" ? window.location.href : "";
    const title = `${t(job.title)} — SPHINX Workforce`;
    if (typeof navigator !== "undefined" && navigator.share) {
      try {
        await navigator.share({ title, url });
        return;
      } catch {
        /* user cancelled */
      }
    }
    try {
      await navigator.clipboard?.writeText(url);
    } catch {
      /* ignore */
    }
  };

  return (
    <div className="rounded-2xl bg-gradient-card ring-inset-gold p-6 md:p-8 max-h-[calc(100vh-7rem)] overflow-y-auto">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <div className="inline-flex items-center gap-1 rounded-full border border-primary/40 bg-primary/10 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wider text-gold-dark">
              {t(job.type)}
            </div>
            {isDirect && (
              <span className="inline-flex items-center gap-1 rounded-full bg-gradient-gold px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-primary-foreground">
                <BadgeCheck className="h-3 w-3" />
                {t(TRUSTED_AD_LABEL)}
              </span>
            )}
          </div>
          <h2 className="mt-3 font-display text-2xl font-bold text-foreground md:text-3xl">
            {t(job.title)}
          </h2>
          <div className="mt-2 text-xs font-mono text-muted-foreground">
            {t(tx("Job ID", "رقم الوظيفة"))}: {jobCode(job)}
          </div>
          <div className="mt-2 flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
            <span className="inline-flex items-center gap-1.5">
              <CalendarPlus className="h-3.5 w-3.5 text-gold-dark" />
              {t(JOB_ADDED_DATE)}: {formatJobDate(job.addedAt, lang)}
            </span>
            {insight?.publishedAt && (
              <span className="inline-flex items-center gap-1.5">
                <CalendarPlus className="h-3.5 w-3.5 text-gold-dark" />
                {t(PUBLICATION_DATE)}: {formatJobDate(insight.publishedAt, lang)}
              </span>
            )}
            {insight?.closesAt && (
              <span className="inline-flex items-center gap-1.5">
                <Clock className="h-3.5 w-3.5 text-gold-dark" />
                {t(JOB_CLOSING_DATE)}: {formatJobDate(insight.closesAt, lang)}
              </span>
            )}
            {!insight?.closesAt && job.deadline && (
              <span className="inline-flex items-center gap-1.5">
                <Clock className="h-3.5 w-3.5 text-gold-dark" />
                {t(tx("Application Deadline", "آخر موعد للتقديم"))}:{" "}
                {formatJobDate(job.deadline, lang)}
              </span>
            )}
            {showApplicantCount && insight?.applicantCount != null && (
              <span className="inline-flex items-center gap-1.5">
                {t(APPLICANTS_LABEL)}: {insight.applicantCount}
              </span>
            )}
            {insight?.daysRemaining != null && insight.canApply && (
              <span className="inline-flex items-center gap-1.5">
                {t(DAYS_REMAINING)}: {insight.daysRemaining}
              </span>
            )}
            {isDirect && (
              <>
                {job.company && (
                  <span className="inline-flex items-center gap-1.5">
                    <Building2 className="h-3.5 w-3.5 text-gold-dark" />
                    {t(ADVERTISER_LABEL)}: {job.company}
                  </span>
                )}
                <span className="inline-flex items-center gap-1.5">
                  <CalendarPlus className="h-3.5 w-3.5 text-gold-dark" />
                  {t(AD_DATE)}: {formatJobDate(insight?.publishedAt ?? job.addedAt, lang)}
                </span>
                {insight?.timeRemaining && (
                  <span className="inline-flex items-center gap-1.5">
                    <Clock className="h-3.5 w-3.5 text-gold-dark" />
                    {t(TIME_REMAINING)}: {t(insight.timeRemaining)}
                  </span>
                )}
                {insight?.views != null && (
                  <span className="inline-flex items-center gap-1.5">
                    {t(VIEWS_LABEL)}: {insight.views}
                  </span>
                )}
              </>
            )}
          </div>
          {insight && (
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <span
                className={`inline-flex items-center rounded-full border px-2.5 py-1 text-[11px] font-semibold ${JOB_STATE_TONE[insight.state]}`}
              >
                {t(jobStateLabel(insight.state))}
              </span>
              <span className="text-[11px] text-muted-foreground">{t(JOB_VALUATION_TITLE)}:</span>
              <JobValuationBadge grade={insight.valuation.grade} size="md" withInfo />
            </div>
          )}
        </div>

        <button
          type="button"
          onClick={onClose}
          aria-label={t(tx("Close", "إغلاق"))}
          className="shrink-0 rounded-full border border-input p-2 text-muted-foreground hover:bg-accent hover:text-foreground"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      {/* Meta grid */}
      <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[
          {
            icon: MapPin,
            label: tx("Location", "الموقع"),
            value: `${t(job.city)}، ${t(job.country)}`,
          },
          { icon: Building2, label: tx("Profession", "المهنة"), value: t(job.profession) },
          { icon: GraduationCap, label: tx("Experience", "الخبرة"), value: t(job.level) },
          { icon: Clock, label: tx("Type", "النوع"), value: t(job.type) },
        ].map((m, i) => (
          <div key={i} className="rounded-xl border border-border bg-background/40 p-3">
            <div className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wider text-gold-dark">
              <m.icon className="h-3.5 w-3.5" />
              {t(m.label)}
            </div>
            <div className="mt-1 truncate text-sm font-semibold text-foreground" title={m.value}>
              {m.value}
            </div>
          </div>
        ))}
      </div>

      {/* Salary banner */}
      <div className="mt-5 flex items-center justify-between rounded-xl bg-gradient-gold/15 border border-primary/30 p-4">
        <div className="inline-flex items-center gap-2 text-sm font-semibold text-foreground">
          <Banknote className="h-5 w-5 text-gold-dark" />
          {t(tx("Salary range", "نطاق الراتب"))}
        </div>
        <div className="font-display text-lg font-bold text-gold-dark">{t(job.salary)}</div>
      </div>

      <Section icon={Briefcase} title={tx("Job summary", "ملخص الوظيفة")}>
        <p>{t(n.summary)}</p>
      </Section>

      <Section icon={CheckCircle2} title={tx("Key responsibilities", "المهام الرئيسية")}>
        <Bullets items={n.responsibilities} />
      </Section>

      <Section icon={GraduationCap} title={tx("Requirements", "المتطلبات")}>
        <Bullets items={n.requirements} />
      </Section>

      <Section icon={Sparkles} title={tx("Required skills", "المهارات المطلوبة")}>
        <div className="flex flex-wrap gap-1.5">
          {job.skills.map((s) => (
            <span
              key={s}
              className="inline-flex items-center gap-1 rounded-full bg-gradient-gold text-primary-foreground px-2.5 py-1 text-[11px] font-semibold"
            >
              <Sparkles className="h-2.5 w-2.5" />
              {t(skillLabel(s))}
            </span>
          ))}
        </div>
      </Section>

      <Section icon={CheckCircle2} title={tx("What we offer", "ما نقدمه")}>
        <Bullets items={n.benefits} />
      </Section>

      {job.directAd ? (
        <DirectAdContact job={job} />
      ) : (
        <ApplyForJob job={job} canApply={insight ? insight.canApply : true} />
      )}

      <div className="mt-3 flex items-center gap-3">
        <Button type="button" variant="outline" onClick={share}>
          <Share2 className="h-4 w-4" />
          {t(tx("Share", "مشاركة"))}
        </Button>
      </div>

      <p className="mt-4 text-[11px] text-muted-foreground">
        {lang === "ar"
          ? "هذه الوظيفة منشورة عبر سفنكس للقوى العاملة. التقديم يخضع لسياسات التوظيف المحلية."
          : "This role is listed by SPHINX Workforce. Applications are subject to local employment regulations."}
      </p>
    </div>
  );
}

// ---------------------------------------------------------------
// Apply-for-job flow (inline, inside the existing detail panel)
// ---------------------------------------------------------------

const FIELD_LABELS: Record<string, BiLabel> = {
  full_name: tx("Full name", "الاسم الكامل"),
  phone: tx("Phone number", "رقم الجوال"),
  country: tx("Country of residence", "بلد الإقامة"),
  nationality: tx("Nationality", "الجنسية"),
  profession: tx("Profession", "المهنة"),
  education: tx("Education", "المؤهل الدراسي"),
  languages: tx("Languages", "اللغات"),
};

type Step = "submitted" | "cv_sent" | "employer_notified";

/**
 * Direct Ads are guest advertiser listings: copy the email and send the CV
 * directly. No profile completion is required, so this stays a separate
 * component (keeps ApplyForJob's hook order unconditional).
 */
function DirectAdContact({ job }: { job: Job }) {
  const { t, lang } = useI18n();
  const [signedIn, setSignedIn] = useState(false);
  const isAr = lang === "ar";

  useEffect(() => {
    let mounted = true;
    supabase.auth.getUser().then(({ data }) => {
      if (mounted) setSignedIn(!!data.user);
    });
    const sub = supabase.auth.onAuthStateChange((_e, session) => {
      if (mounted) setSignedIn(!!session?.user);
    });
    return () => {
      mounted = false;
      sub.data.subscription.unsubscribe();
    };
  }, []);

  const copyEmail = async () => {
    const email = job.advertiserEmail;
    if (!email) {
      toast.error(isAr ? "بريد المعلن غير متوفر." : "Advertiser email is not available.");
      return;
    }
    try {
      await navigator.clipboard.writeText(email);
      toast.success(isAr ? "تم نسخ البريد الإلكتروني." : "Email copied to clipboard.");
    } catch {
      toast.error(
        isAr ? "تعذر النسخ. يرجى المحاولة مرة أخرى." : "Could not copy. Please try again.",
      );
    }
  };

  return (
    <div className="mt-8 rounded-2xl border border-primary/30 bg-background p-5">
      <div className="flex flex-wrap items-center gap-2">
        <span className="inline-flex items-center gap-1 rounded-full bg-gradient-gold px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-primary-foreground">
          <BadgeCheck className="h-3 w-3" />
          {t(TRUSTED_AD_LABEL)}
        </span>
        <span className="text-xs font-semibold text-gold-dark">{t(DIRECT_AD_LABEL)}</span>
      </div>
      <p className="mt-3 text-sm leading-relaxed text-foreground">{t(DIRECT_AD_CONTACT_HINT)}</p>
      {/* Registration stays optional: only guests see the sign-up hint/CTA. */}
      {!signedIn && (
        <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
          {t(DIRECT_AD_REGISTER_HINT)}
        </p>
      )}
      <div className="mt-4 flex flex-col gap-3 sm:flex-row">
        <Button
          onClick={copyEmail}
          className="w-full bg-gradient-gold text-primary-foreground font-semibold sm:w-auto"
        >
          <Copy className="h-4 w-4" />
          {t(COPY_EMAIL_CTA)}
        </Button>
        {!signedIn && (
          <Link to="/job-seekers">
            <Button variant="outline" className="w-full border-primary/60 text-gold-dark sm:w-auto">
              {t(tx("Create Account", "إنشاء حساب"))}
            </Button>
          </Link>
        )}
      </div>
      {job.advertiserEmail && (
        <p className="mt-3 text-xs font-mono text-muted-foreground break-all">
          {job.advertiserEmail}
        </p>
      )}
    </div>
  );
}

function ApplyForJob({ job, canApply = true }: { job: Job; canApply?: boolean }) {
  const { t, lang } = useI18n();
  const navigate = useNavigate();
  const applied = useAppliedJobs();
  const [authChecked, setAuthChecked] = useState(false);
  const [signedIn, setSignedIn] = useState(false);
  const [readiness, setReadiness] = useState<ProfileReadiness | null>(null);
  const [checking, setChecking] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState<{ applicationId: string; appliedAt: string } | null>(null);
  const [failure, setFailure] = useState<string | null>(null);
  const [step, setStep] = useState<Step>("submitted");
  const errorRef = useRef<HTMLDivElement | null>(null);
  const missingRef = useRef<HTMLDivElement | null>(null);

  const isAr = lang === "ar";
  const fmtDate = (iso: string) =>
    new Date(iso).toLocaleDateString(isAr ? "ar-EG" : "en-GB", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  const jobTitle = t(job.title);

  // Check auth state once
  useEffect(() => {
    let mounted = true;
    supabase.auth.getUser().then(({ data }) => {
      if (!mounted) return;
      setSignedIn(!!data.user);
      setAuthChecked(true);
    });
    const sub = supabase.auth.onAuthStateChange((_e, session) => {
      if (!mounted) return;
      setSignedIn(!!session?.user);
    });
    return () => {
      mounted = false;
      sub.data.subscription.unsubscribe();
    };
  }, []);

  // Server-truth "already applied" state (keeps the original application date).
  const alreadyApplied = applied[job.id] ?? null;

  // Load readiness when signed in
  useEffect(() => {
    if (!signedIn) {
      setReadiness(null);
      return;
    }
    setChecking(true);
    getProfileReadiness()
      .then((r) => setReadiness(r))
      .catch(() => setReadiness(null))
      .finally(() => setChecking(false));
  }, [signedIn, job.id]);

  // Reset transient submission state on job change (profile data is never reset)
  useEffect(() => {
    setDone(null);
    setFailure(null);
    setStep("submitted");
  }, [job.id]);

  const goToAuth = () => {
    toast.info(
      t(tx("Please sign in to apply for this role.", "يرجى تسجيل الدخول للتقديم على هذه الوظيفة.")),
    );
    // Preserve the selected job so the user returns to it after signing in.
    navigate({ to: "/auth", search: { next: `/jobs?job=${job.id}` } });
  };

  const goToProfileCompletion = () => {
    toast.info(
      t(
        tx(
          "Complete your candidate profile and upload your CV to apply.",
          "يرجى استكمال ملفك الشخصي ورفع السيرة الذاتية للتقديم.",
        ),
      ),
    );
    navigate({ to: "/job-seekers", search: { returnJob: job.id } });
  };

  const handleApply = async () => {
    if (!authChecked || submitting) return;
    if (!signedIn) return goToAuth();
    if (!readiness) return;
    if (!readiness.ready) {
      // Front-end guard: surface exactly what is missing and focus it.
      missingRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
      missingRef.current?.focus();
      return;
    }
    setSubmitting(true);
    setFailure(null);
    setStep("submitted");
    try {
      const result = await applyToJob({
        data: {
          // Published company jobs link to the posting row; showcase roles
          // keep using the external id.
          ...(job.source === "posting" ? { jobPostingId: job.id } : { externalJobId: job.id }),
          jobSnapshot: {
            title: job.title.en,
            title_ar: job.title.ar,
            country: job.country.en,
            city: job.city.en,
            profession: job.profession.en,
            level: job.level.en,
            type: job.type.en,
            salary: job.salary.en,
            sector: job.sector,
          },
        },
      });
      if (!result.ok && result.reason === "already_applied") {
        toast.info(
          isAr
            ? `سبق لك التقدم إلى وظيفة "${jobTitle}" بتاريخ ${fmtDate(result.appliedAt)}.`
            : `You already applied for "${jobTitle}" on ${fmtDate(result.appliedAt)}.`,
        );
        setDone({ applicationId: result.applicationId, appliedAt: result.appliedAt });
        setStep("employer_notified");
        return;
      }
      if (!result.ok) {
        // Backend re-validation failed: refresh readiness, keep all user data.
        const fresh = await getProfileReadiness();
        setReadiness(fresh);
        const names = fresh.missingFields.map((f) => t(FIELD_LABELS[f] ?? { en: f, ar: f }));
        if (!fresh.hasCv) names.push(t(tx("CV – Required", "السيرة الذاتية – إلزامية")));
        setFailure(
          (isAr
            ? "يرجى استكمال البيانات التالية قبل إرسال الطلب: "
            : "Please complete the following information before submitting your application: ") +
            names.join(isAr ? "، " : ", "),
        );
        return;
      }
      // Animate progress: submitted → cv_sent → employer_notified
      setStep("submitted");
      setTimeout(() => setStep("cv_sent"), 500);
      setTimeout(() => setStep("employer_notified"), 1100);
      setDone({ applicationId: result.applicationId, appliedAt: result.appliedAt });
      toast.success(
        isAr
          ? `تم التقدم بنجاح إلى وظيفة "${jobTitle}".`
          : `Your application for "${jobTitle}" has been submitted successfully.`,
      );
    } catch {
      // Never expose technical database errors; nothing entered is lost.
      setFailure(
        isAr
          ? "تعذر إرسال الطلب حاليًا. تم الاحتفاظ ببياناتك، يرجى المحاولة مرة أخرى."
          : "We couldn't submit your application at this time. Your information has been preserved. Please try again.",
      );
    } finally {
      setSubmitting(false);
    }
  };

  // Move focus to the error region so screen readers announce it.
  useEffect(() => {
    if (failure) errorRef.current?.focus();
  }, [failure]);

  // --- Rendering ---
  const confirmation =
    done ?? (alreadyApplied ? { applicationId: "", appliedAt: alreadyApplied.appliedAt } : null);

  if (confirmation) {
    const isNew = !!done && !alreadyApplied;
    return (
      <div className="mt-8 rounded-2xl border border-primary/30 bg-primary/5 p-5">
        <div className="flex items-center gap-2 text-gold-dark">
          <CheckCircle2 className="h-5 w-5" />
          <span className="font-semibold">
            {isNew
              ? isAr
                ? `تم التقدم بنجاح إلى وظيفة "${jobTitle}".`
                : `Your application for "${jobTitle}" has been submitted successfully.`
              : isAr
                ? `سبق لك التقدم إلى وظيفة "${jobTitle}" بتاريخ ${fmtDate(confirmation.appliedAt)}.`
                : `You already applied for "${jobTitle}" on ${fmtDate(confirmation.appliedAt)}.`}
          </span>
        </div>
        <ApplyProgress step={step} />
        <p className="mt-3 text-xs text-muted-foreground">
          {t(tx("Application Date", "تاريخ التقديم"))}: {fmtDate(confirmation.appliedAt)}
        </p>
        {confirmation.applicationId && (
          <p className="mt-1 text-[11px] font-mono text-muted-foreground">
            {t(tx("Application Reference", "رقم الطلب"))}:{" "}
            {confirmation.applicationId.slice(0, 8).toUpperCase()}
          </p>
        )}
        <div className="mt-4 flex flex-wrap gap-3">
          <Link to="/account" hash="applications">
            <Button variant="outline" className="border-primary/60 text-gold-dark">
              {t(tx("View Application", "عرض الطلب"))}
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  // Closed / expired / paused vacancies no longer accept applications.
  if (!canApply) {
    return (
      <div className="mt-8 rounded-2xl border border-border bg-muted/40 p-5">
        <p className="text-sm font-semibold text-foreground">
          {t(tx("Applications are closed for this vacancy.", "التقديم على هذه الوظيفة مغلق."))}
        </p>
        <p className="mt-1 text-xs text-muted-foreground">
          {t(
            tx(
              "Browse the latest published vacancies instead.",
              "يمكنك استعراض أحدث الوظائف المنشورة.",
            ),
          )}
        </p>
      </div>
    );
  }

  // Auth check loading

  if (!authChecked) {
    return (
      <div className="mt-8 flex items-center gap-2 border-t border-border pt-5 text-sm text-muted-foreground">
        <Loader2 className="h-4 w-4 animate-spin" />
        {t(tx("Loading…", "جارٍ التحميل…"))}
      </div>
    );
  }

  if (!signedIn) {
    return (
      <div className="mt-8 border-t border-border pt-5">
        <Button
          onClick={goToAuth}
          className="w-full bg-gradient-gold text-primary-foreground font-semibold"
        >
          {t(tx("Sign in to apply", "سجّل الدخول للتقديم"))}
          <ArrowRight className="h-4 w-4" />
        </Button>
        <p className="mt-2 text-xs text-muted-foreground">
          {t(
            tx(
              "New here? You'll be guided to complete your candidate profile and upload your CV.",
              "جديد هنا؟ سنقوم بإرشادك لاستكمال ملفك الشخصي ورفع سيرتك الذاتية.",
            ),
          )}
        </p>
      </div>
    );
  }

  if (checking || !readiness) {
    return (
      <div className="mt-8 flex items-center gap-2 border-t border-border pt-5 text-sm text-muted-foreground">
        <Loader2 className="h-4 w-4 animate-spin" />
        {t(tx("Checking your profile…", "جارٍ التحقق من ملفك الشخصي…"))}
      </div>
    );
  }

  if (!readiness.ready) {
    const missingLabels = readiness.missingFields.map((f) => FIELD_LABELS[f] ?? { en: f, ar: f });
    return (
      <div className="mt-8 border-t border-border pt-5">
        <div
          ref={missingRef}
          tabIndex={-1}
          role="alert"
          className="rounded-xl border border-amber-500/40 bg-amber-500/5 p-4 outline-none"
        >
          <div className="flex items-center justify-between gap-3">
            <span className="text-sm font-semibold text-foreground">
              {t(tx("Profile completion", "اكتمال الملف"))}: {readiness.completion}%
            </span>
            <span className="text-[11px] font-semibold uppercase tracking-wider text-amber-600 dark:text-amber-400">
              {t(tx("Action required", "إجراء مطلوب"))}
            </span>
          </div>
          <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-muted">
            <div
              className="h-full bg-gradient-gold transition-all"
              style={{ width: `${readiness.completion}%` }}
            />
          </div>
          {missingLabels.length > 0 && (
            <div className="mt-3">
              <p className="text-xs font-semibold text-foreground">
                {t(
                  tx(
                    "Please complete the following information before submitting your application:",
                    "يرجى استكمال البيانات التالية قبل إرسال الطلب:",
                  ),
                )}
              </p>
              <ul className="mt-1.5 grid grid-cols-1 gap-1 sm:grid-cols-2">
                {missingLabels.map((m, i) => (
                  <li key={i} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <X className="h-3 w-3 text-destructive" />
                    {t(m)}
                  </li>
                ))}
              </ul>
            </div>
          )}
          {!readiness.hasCv && (
            <p className="mt-3 flex items-center gap-1.5 text-xs font-semibold text-destructive">
              <Upload className="h-3 w-3" />
              {t(
                tx(
                  "Please upload your CV before applying for this job. (CV – Required)",
                  "يرجى رفع السيرة الذاتية قبل التقدم إلى هذه الوظيفة. (السيرة الذاتية – إلزامية)",
                ),
              )}
            </p>
          )}
          <p className="mt-3 text-xs text-muted-foreground">
            {t(
              tx(
                "Additional Attachments – Optional and can be added later",
                "المرفقات الإضافية – اختيارية ويمكن إضافتها لاحقًا",
              ),
            )}
          </p>
        </div>
        <Button
          onClick={goToProfileCompletion}
          className="mt-4 w-full bg-gradient-gold text-primary-foreground font-semibold"
        >
          {t(tx("Complete profile & upload CV", "استكمال الملف ورفع السيرة"))}
          <ArrowRight className="h-4 w-4" />
        </Button>
      </div>
    );
  }

  // Ready to apply
  return (
    <div className="mt-8 border-t border-border pt-5">
      {failure && (
        <div
          ref={errorRef}
          tabIndex={-1}
          role="alert"
          className="mb-4 rounded-xl border border-destructive/40 bg-destructive/5 p-4 text-sm text-destructive outline-none"
        >
          {failure}
        </div>
      )}
      <Button
        onClick={handleApply}
        disabled={submitting}
        aria-busy={submitting}
        aria-disabled={submitting}
        className="w-full bg-gradient-gold text-primary-foreground font-semibold"
      >
        {submitting ? (
          <>
            <Loader2 className="h-4 w-4 animate-spin" />
            {t(tx("Submitting Application…", "جاري إرسال الطلب..."))}
          </>
        ) : (
          <>
            {job.directAd ? <Send className="h-4 w-4" /> : null}
            {t(job.directAd ? SEND_NOW_CTA : tx("Send Application", "إرسال الطلب"))}
            {!job.directAd && <ArrowRight className="h-4 w-4" />}
          </>
        )}
      </Button>
      <p aria-live="polite" className="sr-only">
        {submitting ? t(tx("Submitting Application…", "جاري إرسال الطلب...")) : ""}
      </p>
      <p className="mt-2 text-xs text-muted-foreground">
        {isAr
          ? "سيتم إرسال بيانات ملفك الشخصي وسيرتك الذاتية المحفوظة مباشرة إلى صاحب العمل. المرفقات الإضافية اختيارية ويمكن إضافتها لاحقًا."
          : "Your saved profile information and CV will be sent directly to the employer. Additional attachments are optional and can be added later."}
      </p>
    </div>
  );
}

function ApplyProgress({ step }: { step: Step }) {
  const { t } = useI18n();
  const steps: { id: Step; label: BiLabel; icon: typeof Send }[] = [
    { id: "submitted", label: tx("Application Submitted", "تم إرسال الطلب"), icon: Send },
    { id: "cv_sent", label: tx("CV Sent", "تم إرسال السيرة"), icon: Upload },
    { id: "employer_notified", label: tx("Employer Notified", "تم إشعار صاحب العمل"), icon: Mail },
  ];
  const activeIdx = steps.findIndex((s) => s.id === step);
  return (
    <ol className="mt-4 grid grid-cols-3 gap-2">
      {steps.map((s, i) => {
        const active = i <= activeIdx;
        return (
          <li
            key={s.id}
            className={`flex flex-col items-center gap-1.5 rounded-xl border p-3 text-center transition-all ${
              active
                ? "border-primary/50 bg-primary/10 text-foreground"
                : "border-border bg-background/40 text-muted-foreground"
            }`}
          >
            <div
              className={`flex h-8 w-8 items-center justify-center rounded-full ${
                active ? "bg-gradient-gold text-primary-foreground" : "bg-muted"
              }`}
            >
              {active ? <CheckCircle2 className="h-4 w-4" /> : <s.icon className="h-4 w-4" />}
            </div>
            <span className="text-[11px] font-semibold leading-tight">{t(s.label)}</span>
          </li>
        );
      })}
    </ol>
  );
}
