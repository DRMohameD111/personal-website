import { createFileRoute } from "@tanstack/react-router";
import { ServicesSection } from "@/components/ServicesSection";
import { useI18n, tx } from "@/i18n";
import { imagery, ornaments } from "@/brand";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Services — SPHINX Workforce" },
      {
        name: "description",
        content:
          "Explore SPHINX Workforce services: outsourcing, manpower supply, blue collar recruitment, technical staffing, employee leasing, temporary staffing, facility management, and industrial workforce solutions.",
      },
      { property: "og:title", content: "Services — SPHINX Workforce" },
      {
        property: "og:description",
        content: "Comprehensive workforce solutions for Saudi Arabia, the GCC, and Egypt.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ServicesPage,
});

function ServicesPage() {
  const { t } = useI18n();

  return (
    <main className="relative isolate min-h-screen bg-background">
      {/* Light ivory ground with a very faint hieroglyphic branding layer */}
      <div aria-hidden className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-b from-background via-surface-soft to-background" />
        <div
          className="ornament-faint absolute inset-0 bg-repeat"
          style={{ backgroundImage: `url(${ornaments.pattern})`, backgroundSize: "380px" }}
        />
      </div>

      {/* Page hero — reuses the approved Pharaonic LABOR FORCE artwork, veiled for readability */}
      <section className="relative isolate overflow-hidden pt-28 pb-16 md:pt-36 md:pb-20">
        <div aria-hidden className="absolute inset-0 -z-10">
          <div
            className="absolute inset-0 bg-cover bg-[position:72%_center] bg-no-repeat md:bg-center"
            style={{ backgroundImage: `url(${imagery.laborForce})` }}
          />
          <div className="hero-veil absolute inset-0" />
          <div className="absolute inset-x-0 bottom-0 h-20 bg-gradient-to-b from-transparent to-background" />
        </div>

        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="max-w-xl">
            <div className="flex items-center gap-4">
              <div className="h-px w-12 bg-primary" />
              <span className="text-[10px] font-bold uppercase tracking-[0.4em] text-gold-dark md:text-xs">
                {t(tx("What We Deliver", "ما نقدمه"))}
              </span>
            </div>
            <h1 className="mt-5 font-display text-4xl font-medium leading-tight text-heading md:text-6xl">
              {t(tx("Workforce Services", "خدمات القوى العاملة"))}
            </h1>
            <div className="gold-divider mt-6 w-24" />
            <p className="mt-6 text-lg leading-relaxed text-foreground">
              {t(
                tx(
                  "Outsourcing, manpower supply and technical staffing across Saudi Arabia, the GCC and Egypt — delivered with compliance and speed.",
                  "التعهيد وإمداد العمالة والتوظيف التقني في السعودية والخليج ومصر — بالتزام كامل وسرعة في التنفيذ.",
                ),
              )}
            </p>
          </div>
        </div>
      </section>

      {/* Existing shared services grid — reused, heading hidden (page already has an H1) */}
      <ServicesSection showHeading={false} className="pt-4" />

      <div
        aria-hidden
        className="mx-auto h-10 max-w-5xl bg-contain bg-center bg-no-repeat opacity-30"
        style={{ backgroundImage: `url(${ornaments.divider})` }}
      />
    </main>
  );
}
