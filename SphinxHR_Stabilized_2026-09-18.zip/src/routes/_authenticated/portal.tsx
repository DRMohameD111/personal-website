// ---------------------------------------------------------------------------
// Company Portal / بوابة الشركة — subscription management surface for company
// accounts. It reuses the existing verified package panel (current package,
// details & payments, change flow, history and printable receipts); no
// commercial value is computed in the browser.
// ---------------------------------------------------------------------------
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, LayoutGrid, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useI18n, tx } from "@/i18n";
import { requireCompanyAccount } from "@/lib/account-type";
import { CompanyPackagePanel } from "@/components/CompanyPackagePanel";

export const Route = createFileRoute("/_authenticated/portal")({
  beforeLoad: async () => {
    await requireCompanyAccount();
  },
  head: () => ({
    meta: [
      { title: "Company Portal — SPHINX Workforce" },
      {
        name: "description",
        content:
          "Manage your subscription: current package, benefits and limits, payments, receipts and package changes.",
      },
      { property: "og:title", content: "Company Portal — SPHINX Workforce" },
      {
        property: "og:description",
        content: "Subscription management: package details, payments, receipts and upgrades.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: CompanyPortalPage,
});

function CompanyPortalPage() {
  const { t, lang } = useI18n();
  const isAr = lang === "ar";

  return (
    <main className="min-h-screen bg-background pt-28 pb-20" dir={isAr ? "rtl" : "ltr"}>
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="flex items-center gap-2 font-display text-3xl font-semibold text-heading sm:text-4xl">
              <LayoutGrid className="h-7 w-7 text-gold-dark" />
              {t(tx("Company Portal", "بوابة الشركة"))}
            </h1>
            <p className="mt-2 text-sm text-muted-foreground">
              {t(
                tx(
                  "Your subscription, benefits, payments and receipts — all verified from your account records.",
                  "اشتراكك ومزاياك ومدفوعاتك وإيصالاتك — جميعها موثقة من سجلات حسابك.",
                ),
              )}
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Link to="/pricing">
              <Button variant="outline" className="border-primary/60 text-gold-dark">
                <Sparkles className="h-4 w-4" />
                {t(tx("Browse Packages", "استعراض الباقات"))}
              </Button>
            </Link>
            <Link to="/company">
              <Button variant="ghost">
                <ArrowLeft className={isAr ? "h-4 w-4 rotate-180" : "h-4 w-4"} />
                {t(tx("Back to Company Account", "العودة إلى حساب الشركة"))}
              </Button>
            </Link>
          </div>
        </div>

        <CompanyPackagePanel />
      </div>
    </main>
  );
}
