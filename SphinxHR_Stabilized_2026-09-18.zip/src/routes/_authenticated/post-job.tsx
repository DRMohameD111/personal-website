import { createFileRoute, useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQueryClient } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
import { useStateDraft } from "@/lib/form-draft";
import { Upload, Plus, Loader2, Download, CheckCircle2, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useI18n, tx } from "@/i18n";
import { toast } from "sonner";
import {
  listProfessions,
  listExperienceLevels,
  createJobPosting,
  bulkCreateJobPostings,
} from "@/lib/postings.functions";
import { requireCompanyAccount } from "@/lib/account-type";
import { BilingualField } from "@/components/BilingualField";
import { EmploymentTypeSelect } from "@/components/EmploymentTypeSelect";
import {
  EMPLOYMENT_TYPE_LABEL,
  normalizeEmploymentType,
  type EmploymentTypeValue,
} from "@/lib/jobs";

export const Route = createFileRoute("/_authenticated/post-job")({
  beforeLoad: async () => {
    await requireCompanyAccount();
  },
  head: () => ({
    meta: [{ title: "Post a Job — SPHINX Workforce" }],
  }),
  component: PostJobPage,
});

type Profession = Awaited<ReturnType<typeof listProfessions>>[number];
type Level = Awaited<ReturnType<typeof listExperienceLevels>>[number];

const CSV_HEADERS = [
  "profession_slug",
  "title_en",
  "title_ar",
  "country_en",
  "country_ar",
  "city_en",
  "city_ar",
  "level_slug",
  "type_en",
  "type_ar",
  "salary_en",
  "salary_ar",
  "summary_en",
  "summary_ar",
  "skills",
] as const;

function PostJobPage() {
  const { t, lang } = useI18n();
  const router = useRouter();
  const loadProfs = useServerFn(listProfessions);
  const loadLevels = useServerFn(listExperienceLevels);
  const queryClient = useQueryClient();
  const createOne = useServerFn(createJobPosting);
  const createMany = useServerFn(bulkCreateJobPostings);

  const [profs, setProfs] = useState<Profession[]>([]);
  const [levels, setLevels] = useState<Level[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([loadProfs(), loadLevels()])
      .then(([p, l]) => {
        setProfs(p);
        setLevels(l);
      })
      .catch((e) => toast.error(String(e?.message || e)))
      .finally(() => setLoading(false));
  }, [loadProfs, loadLevels]);

  return (
    <main className="min-h-screen pt-28 pb-16">
      <section className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="font-display text-3xl font-bold text-foreground md:text-4xl">
            {t(tx("Post a Job", "نشر وظيفة"))}
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            {t(
              tx(
                "Publish openings bilingually. Use the form for a single role or upload a CSV to add many at once.",
                "انشر الوظائف بلغتين. استخدم النموذج لوظيفة واحدة أو ارفع ملف CSV لإضافة عدة وظائف دفعة واحدة.",
              ),
            )}
          </p>
        </div>

        {loading ? (
          <div className="flex items-center gap-2 text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" />
            {t(tx("Loading…", "جاري التحميل…"))}
          </div>
        ) : (
          <Tabs defaultValue="manual">
            <TabsList>
              <TabsTrigger value="manual">
                <Plus className="h-4 w-4" /> {t(tx("Single posting", "وظيفة واحدة"))}
              </TabsTrigger>
              <TabsTrigger value="import">
                <Upload className="h-4 w-4" /> {t(tx("Import CSV / Excel", "استيراد CSV / Excel"))}
              </TabsTrigger>
            </TabsList>

            <TabsContent value="manual" className="mt-6">
              <ManualForm
                profs={profs}
                levels={levels}
                onSubmit={async (payload) => {
                  await createOne({ data: payload });
                  // Published jobs appear immediately in every listing.
                  await queryClient.invalidateQueries({ queryKey: ["published-jobs"] });
                  toast.success(t(tx("Posting published", "تم نشر الوظيفة")));
                  router.navigate({ to: "/jobs" });
                }}
              />
            </TabsContent>

            <TabsContent value="import" className="mt-6">
              <ImportTab
                profs={profs}
                levels={levels}
                onImport={async (rows) => {
                  const res = await createMany({ data: { postings: rows } });
                  await queryClient.invalidateQueries({ queryKey: ["published-jobs"] });
                  toast.success(
                    t(tx(`Imported ${res.count} postings`, `تم استيراد ${res.count} وظيفة`)),
                  );
                }}
              />
            </TabsContent>
          </Tabs>
        )}
      </section>
    </main>
  );
}

// ---------------- Manual form ----------------

type ManualPayload = {
  profession_id: string;
  title_en: string;
  title_ar: string;
  country_en: string;
  country_ar: string;
  city_en: string;
  city_ar: string;
  level_id?: string;
  level_en?: string;
  level_ar?: string;
  employment_type?: EmploymentTypeValue;
  type_en: string;
  type_ar: string;
  salary_en?: string;
  salary_ar?: string;
  summary_en?: string;
  summary_ar?: string;
  skills: string[];
};

function ManualForm({
  profs,
  levels,
  onSubmit,
}: {
  profs: Profession[];
  levels: Level[];
  onSubmit: (p: ManualPayload) => Promise<void>;
}) {
  const { t, lang } = useI18n();
  const [form, setForm] = useState({
    profession_id: profs[0]?.id ?? "",
    title_en: "",
    title_ar: "",
    country_en: "Saudi Arabia",
    country_ar: "المملكة العربية السعودية",
    city_en: "Riyadh",
    city_ar: "الرياض",
    level_id: levels[0]?.id ?? "",
    employment_type: "full_time" as EmploymentTypeValue,
    type_en: "Full Time",
    type_ar: "دوام كامل",
    salary_en: "",
    salary_ar: "",
    summary_en: "",
    summary_ar: "",
    skills: "",
  });
  const [busy, setBusy] = useState(false);
  const { clearDraft } = useStateDraft(
    "post-job-manual",
    form,
    (d) => setForm((f) => ({ ...f, ...d })),
    lang,
  );

  const set = <K extends keyof typeof form>(k: K, v: (typeof form)[K]) =>
    setForm((f) => ({ ...f, [k]: v }));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      const level = levels.find((l) => l.id === form.level_id);
      await onSubmit({
        profession_id: form.profession_id,
        title_en: form.title_en.trim(),
        title_ar: form.title_ar.trim(),
        country_en: form.country_en.trim(),
        country_ar: form.country_ar.trim(),
        city_en: form.city_en.trim(),
        city_ar: form.city_ar.trim(),
        level_id: level?.id,
        level_en: level?.name_en,
        level_ar: level?.name_ar,
        employment_type: form.employment_type,
        type_en: form.type_en.trim(),
        type_ar: form.type_ar.trim(),
        salary_en: form.salary_en.trim() || undefined,
        salary_ar: form.salary_ar.trim() || undefined,
        summary_en: form.summary_en.trim() || undefined,
        summary_ar: form.summary_ar.trim() || undefined,
        skills: form.skills
          .split(",")
          .map((s) => s.trim())
          .filter(Boolean),
      });
      clearDraft();
    } catch (err) {
      toast.error(String((err as Error).message || err));
    } finally {
      setBusy(false);
    }
  };

  const selectClass =
    "w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring";

  return (
    <form
      onSubmit={submit}
      className="rounded-2xl bg-gradient-card ring-inset-gold p-6 md:p-8 space-y-5"
    >
      <div className="grid gap-4 md:grid-cols-2">
        <Field label={t(tx("Profession", "المهنة"))}>
          <select
            className={selectClass}
            value={form.profession_id}
            onChange={(e) => set("profession_id", e.target.value)}
            required
          >
            {profs.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name_en} — {p.name_ar}
              </option>
            ))}
          </select>
        </Field>

        <Field label={t(tx("Experience level", "مستوى الخبرة"))}>
          <select
            className={selectClass}
            value={form.level_id}
            onChange={(e) => set("level_id", e.target.value)}
          >
            {levels.map((l) => (
              <option key={l.id} value={l.id}>
                {l.name_en} — {l.name_ar}
              </option>
            ))}
          </select>
        </Field>
      </div>

      <BilingualField
        labelEn={t(tx("Title (English)", "المسمى (إنجليزي)"))}
        labelAr={t(tx("Title (Arabic)", "المسمى (عربي)"))}
        valueEn={form.title_en}
        valueAr={form.title_ar}
        required
        onChange={(p) =>
          setForm((f) => ({
            ...f,
            ...(p.en !== undefined ? { title_en: p.en } : {}),
            ...(p.ar !== undefined ? { title_ar: p.ar } : {}),
          }))
        }
      />

      <div className="grid gap-4 md:grid-cols-2">
        <Field label={t(tx("Country (English)", "الدولة (إنجليزي)"))}>
          <Input value={form.country_en} onChange={(e) => set("country_en", e.target.value)} />
        </Field>
        <Field label={t(tx("Country (Arabic)", "الدولة (عربي)"))}>
          <Input
            value={form.country_ar}
            onChange={(e) => set("country_ar", e.target.value)}
            dir="rtl"
          />
        </Field>

        <Field label={t(tx("City (English)", "المدينة (إنجليزي)"))}>
          <Input value={form.city_en} onChange={(e) => set("city_en", e.target.value)} />
        </Field>
        <Field label={t(tx("City (Arabic)", "المدينة (عربي)"))}>
          <Input value={form.city_ar} onChange={(e) => set("city_ar", e.target.value)} dir="rtl" />
        </Field>

        <Field label={t(tx("Employment Type", "نوع التوظيف"))}>
          <EmploymentTypeSelect
            value={form.employment_type}
            typeEn={form.type_en}
            typeAr={form.type_ar}
            onChange={(p) => setForm((f) => ({ ...f, ...p }))}
          />
        </Field>

        <Field label={t(tx("Salary (English)", "الراتب (إنجليزي)"))}>
          <Input
            placeholder="SAR 10,000 – 14,000"
            value={form.salary_en}
            onChange={(e) => set("salary_en", e.target.value)}
          />
        </Field>
        <Field label={t(tx("Salary (Arabic)", "الراتب (عربي)"))}>
          <Input
            placeholder="ر.س 10,000 – 14,000"
            value={form.salary_ar}
            onChange={(e) => set("salary_ar", e.target.value)}
            dir="rtl"
          />
        </Field>
      </div>

      <BilingualField
        labelEn={t(tx("Summary (English)", "الملخص (إنجليزي)"))}
        labelAr={t(tx("Summary (Arabic)", "الملخص (عربي)"))}
        valueEn={form.summary_en}
        valueAr={form.summary_ar}
        multiline
        rows={3}
        onChange={(p) =>
          setForm((f) => ({
            ...f,
            ...(p.en !== undefined ? { summary_en: p.en } : {}),
            ...(p.ar !== undefined ? { summary_ar: p.ar } : {}),
          }))
        }
      />

      <Field label={t(tx("Skills (comma-separated)", "المهارات (مفصولة بفواصل)"))}>
        <Input
          placeholder="React, TypeScript, Tailwind"
          value={form.skills}
          onChange={(e) => set("skills", e.target.value)}
        />
      </Field>

      <div className="pt-2">
        <Button
          type="submit"
          disabled={busy}
          className="bg-gradient-gold text-primary-foreground font-semibold"
        >
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
          {t(tx("Publish posting", "نشر الوظيفة"))}
        </Button>
      </div>
    </form>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block space-y-1.5">
      <span className="text-xs font-semibold uppercase tracking-wider text-gold-dark">{label}</span>
      {children}
    </label>
  );
}

// ---------------- CSV / Excel import ----------------

type ParsedRow = {
  ok: boolean;
  error?: string;
  payload?: ManualPayload;
  raw: Record<string, string>;
};

function ImportTab({
  profs,
  levels,
  onImport,
}: {
  profs: Profession[];
  levels: Level[];
  onImport: (rows: ManualPayload[]) => Promise<void>;
}) {
  const { t } = useI18n();
  const [rows, setRows] = useState<ParsedRow[]>([]);
  const [busy, setBusy] = useState(false);

  const profBySlug = useMemo(() => new Map(profs.map((p) => [p.slug, p])), [profs]);
  const lvlBySlug = useMemo(() => new Map(levels.map((l) => [l.slug, l])), [levels]);

  const validRows = rows.filter((r) => r.ok && r.payload).map((r) => r.payload!);

  const handleFile = async (file: File) => {
    const text = await file.text();
    const parsed = parseCSV(text);
    if (parsed.length === 0) {
      toast.error(t(tx("Empty or unreadable file", "ملف فارغ أو غير قابل للقراءة")));
      return;
    }
    const validated: ParsedRow[] = parsed.map((raw) => {
      const profSlug = (raw.profession_slug || "").trim();
      const prof = profBySlug.get(profSlug);
      if (!prof) {
        return { ok: false, raw, error: `Unknown profession_slug "${profSlug}"` };
      }
      const lvlSlug = (raw.level_slug || "").trim();
      const lvl = lvlSlug ? lvlBySlug.get(lvlSlug) : undefined;
      if (lvlSlug && !lvl) {
        return { ok: false, raw, error: `Unknown level_slug "${lvlSlug}"` };
      }
      const required = [
        "title_en",
        "title_ar",
        "country_en",
        "country_ar",
        "city_en",
        "city_ar",
        "type_en",
        "type_ar",
      ];
      for (const k of required) {
        if (!(raw[k] || "").trim()) return { ok: false, raw, error: `Missing ${k}` };
      }
      const payload: ManualPayload = {
        profession_id: prof.id,
        title_en: raw.title_en,
        title_ar: raw.title_ar,
        country_en: raw.country_en,
        country_ar: raw.country_ar,
        city_en: raw.city_en,
        city_ar: raw.city_ar,
        level_id: lvl?.id,
        level_en: lvl?.name_en,
        level_ar: lvl?.name_ar,
        employment_type: normalizeEmploymentType(raw.employment_type, raw.type_en, raw.type_ar),
        type_en:
          EMPLOYMENT_TYPE_LABEL[
            normalizeEmploymentType(raw.employment_type, raw.type_en, raw.type_ar)
          ].en,
        type_ar:
          EMPLOYMENT_TYPE_LABEL[
            normalizeEmploymentType(raw.employment_type, raw.type_en, raw.type_ar)
          ].ar,
        salary_en: raw.salary_en || undefined,
        salary_ar: raw.salary_ar || undefined,
        summary_en: raw.summary_en || undefined,
        summary_ar: raw.summary_ar || undefined,
        skills: (raw.skills || "")
          .split(/[|;]/)
          .map((s) => s.trim())
          .filter(Boolean),
      };
      return { ok: true, raw, payload };
    });
    setRows(validated);
  };

  const downloadTemplate = () => {
    const sample = [
      CSV_HEADERS.join(","),
      [
        "site-engineer",
        "Site Engineer",
        "مهندس موقع",
        "Saudi Arabia",
        "المملكة العربية السعودية",
        "Riyadh",
        "الرياض",
        "mid",
        "Full-time",
        "دوام كامل",
        "SAR 12000 - 16000",
        "ر.س 12000 - 16000",
        "Manage day-to-day site execution.",
        "إدارة تنفيذ الموقع اليومي.",
        "AutoCAD|HSE|Supervision",
      ]
        .map((v) => `"${v.replace(/"/g, '""')}"`)
        .join(","),
    ].join("\r\n");
    const blob = new Blob(["\uFEFF" + sample], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "sphinx-jobs-template.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  const submit = async () => {
    if (validRows.length === 0) return;
    setBusy(true);
    try {
      await onImport(validRows);
      setRows([]);
    } catch (err) {
      toast.error(String((err as Error).message || err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="rounded-2xl bg-gradient-card ring-inset-gold p-6 md:p-8 space-y-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="font-display text-lg font-semibold text-foreground">
            {t(tx("Bulk import", "استيراد دفعة واحدة"))}
          </h2>
          <p className="mt-1 text-sm text-muted-foreground">
            {t(
              tx(
                "Upload a CSV file (UTF-8). For Excel, save your sheet as CSV first.",
                "ارفع ملف CSV بترميز UTF-8. للملفات Excel، احفظ الورقة كـ CSV أولاً.",
              ),
            )}
          </p>
        </div>
        <Button type="button" variant="outline" onClick={downloadTemplate}>
          <Download className="h-4 w-4" />
          {t(tx("Download template", "تحميل قالب"))}
        </Button>
      </div>

      <div>
        <input
          type="file"
          accept=".csv,text/csv"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) handleFile(f);
          }}
          className="block w-full text-sm text-foreground file:mr-3 file:rounded-md file:border-0 file:bg-gradient-gold file:px-4 file:py-2 file:text-sm file:font-semibold file:text-primary-foreground"
        />
      </div>

      {rows.length > 0 && (
        <>
          <div className="flex flex-wrap items-center gap-4 text-sm">
            <span className="inline-flex items-center gap-1.5 text-green-600">
              <CheckCircle2 className="h-4 w-4" /> {validRows.length} {t(tx("valid", "صالح"))}
            </span>
            {rows.length - validRows.length > 0 && (
              <span className="inline-flex items-center gap-1.5 text-destructive">
                <AlertTriangle className="h-4 w-4" /> {rows.length - validRows.length}{" "}
                {t(tx("with errors", "بأخطاء"))}
              </span>
            )}
          </div>

          <div className="max-h-80 overflow-y-auto rounded-md border border-border">
            <table className="w-full text-xs">
              <thead className="bg-muted/50 text-left">
                <tr>
                  <th className="px-3 py-2">#</th>
                  <th className="px-3 py-2">{t(tx("Title", "المسمى"))}</th>
                  <th className="px-3 py-2">{t(tx("Profession", "المهنة"))}</th>
                  <th className="px-3 py-2">{t(tx("Status", "الحالة"))}</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r, i) => (
                  <tr key={i} className="border-t border-border">
                    <td className="px-3 py-2 text-muted-foreground">{i + 1}</td>
                    <td className="px-3 py-2">{r.raw.title_en || r.raw.title_ar || "—"}</td>
                    <td className="px-3 py-2">{r.raw.profession_slug || "—"}</td>
                    <td className="px-3 py-2">
                      {r.ok ? (
                        <span className="text-green-600">OK</span>
                      ) : (
                        <span className="text-destructive">{r.error}</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <Button
            type="button"
            onClick={submit}
            disabled={busy || validRows.length === 0}
            className="bg-gradient-gold text-primary-foreground font-semibold"
          >
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
            {t(tx(`Import ${validRows.length} postings`, `استيراد ${validRows.length} وظيفة`))}
          </Button>
        </>
      )}
    </div>
  );
}

// ---------- Minimal RFC-4180 CSV parser ----------
function parseCSV(text: string): Record<string, string>[] {
  // Strip UTF-8 BOM
  const src = text.replace(/^\uFEFF/, "");
  const rows: string[][] = [];
  let i = 0;
  let cur = "";
  let row: string[] = [];
  let inQuotes = false;
  while (i < src.length) {
    const ch = src[i];
    if (inQuotes) {
      if (ch === '"') {
        if (src[i + 1] === '"') {
          cur += '"';
          i += 2;
          continue;
        }
        inQuotes = false;
        i++;
        continue;
      }
      cur += ch;
      i++;
      continue;
    }
    if (ch === '"') {
      inQuotes = true;
      i++;
      continue;
    }
    if (ch === ",") {
      row.push(cur);
      cur = "";
      i++;
      continue;
    }
    if (ch === "\r") {
      i++;
      continue;
    }
    if (ch === "\n") {
      row.push(cur);
      rows.push(row);
      row = [];
      cur = "";
      i++;
      continue;
    }
    cur += ch;
    i++;
  }
  if (cur.length > 0 || row.length > 0) {
    row.push(cur);
    rows.push(row);
  }
  if (rows.length < 2) return [];
  const headers = rows[0].map((h) => h.trim());
  return rows
    .slice(1)
    .filter((r) => r.some((c) => c.trim() !== ""))
    .map((r) => {
      const obj: Record<string, string> = {};
      headers.forEach((h, idx) => {
        obj[h] = (r[idx] ?? "").trim();
      });
      return obj;
    });
}
