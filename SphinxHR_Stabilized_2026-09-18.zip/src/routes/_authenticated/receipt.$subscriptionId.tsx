// ---------------------------------------------------------------------------
// Printable Package Confirmation / Receipt page.
// Data comes from the verified `getPackageReceipt` server function; the page
// only renders and prints it. Print → "Save as PDF" produces the ticket PDF.
// ---------------------------------------------------------------------------
import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { useEffect } from "react";
import { ArrowLeft, Loader2, Printer } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useI18n, tx } from "@/i18n";
import { requireCompanyAccount } from "@/lib/account-type";
import { getPackageReceipt } from "@/lib/subscriptions.functions";
import { receiptFileName } from "@/lib/receipt";
import { PackageReceiptTicket } from "@/components/PackageReceiptTicket";

export const Route = createFileRoute("/_authenticated/receipt/$subscriptionId")({
  beforeLoad: async () => {
    await requireCompanyAccount();
  },
  head: () => ({
    meta: [
      { title: "Package Receipt — SPHINX Workforce" },
      {
        name: "description",
        content:
          "Printable package confirmation card and payment receipt with verified subscription and payment details.",
      },
      { property: "og:title", content: "Package Receipt — SPHINX Workforce" },
      {
        property: "og:description",
        content: "Verified package confirmation card and payment receipt.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ReceiptPage,
});

function ReceiptPage() {
  const { subscriptionId } = Route.useParams();
  const { t, lang } = useI18n();
  const fetchReceipt = useServerFn(getPackageReceipt);

  const receipt = useQuery({
    queryKey: ["package-receipt", subscriptionId],
    queryFn: () => fetchReceipt({ data: { subscriptionId } }),
  });

  // The browser uses the document title as the default PDF file name.
  useEffect(() => {
    if (!receipt.data) return;
    const previous = document.title;
    document.title = receiptFileName(receipt.data, lang);
    return () => {
      document.title = previous;
    };
  }, [receipt.data, lang]);

  return (
    <main
      className="min-h-screen bg-background pt-28 pb-20 print:pt-0 print:pb-0"
      dir={lang === "ar" ? "rtl" : "ltr"}
    >
      <div className="mx-auto max-w-3xl px-4 sm:px-6">
        <div className="no-print mb-6 flex flex-wrap items-center justify-between gap-3">
          <Link to="/company">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="h-4 w-4" />
              {t(tx("Back to my account", "العودة إلى حسابي"))}
            </Button>
          </Link>
          <Button
            className="bg-gradient-gold font-semibold text-primary-foreground hover:shadow-gold"
            disabled={!receipt.data}
            onClick={() => window.print()}
          >
            <Printer className="h-4 w-4" />
            {t(tx("Print / Save as PDF", "طباعة / حفظ PDF"))}
          </Button>
        </div>

        {receipt.isLoading ? (
          <Loader2 className="mx-auto h-6 w-6 animate-spin text-gold-dark" />
        ) : receipt.isError || !receipt.data ? (
          <p className="text-center text-sm text-destructive">
            {t(
              tx(
                "This receipt could not be loaded. It may not belong to your account.",
                "تعذر تحميل هذا الإيصال. قد لا يكون مرتبطاً بحسابك.",
              ),
            )}
          </p>
        ) : (
          <PackageReceiptTicket receipt={receipt.data} />
        )}
      </div>
    </main>
  );
}
