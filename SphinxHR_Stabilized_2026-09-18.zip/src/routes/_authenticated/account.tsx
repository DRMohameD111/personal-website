import { createFileRoute, Link, redirect, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import {
  Loader2,
  Pencil,
  FileText,
  Mail,
  Phone,
  Globe2,
  GraduationCap,
  Languages,
  BriefcaseBusiness,
  Eye,
  ExternalLink,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useI18n, tx } from "@/i18n";
import { getMyAccount, listMyApplications, type MyApplication } from "@/lib/account.functions";
import { getMyAccountType } from "@/lib/account-type";
import { applicationStatusLabel } from "@/lib/status-labels";
import { ProfileDocuments } from "@/components/ProfileDocuments";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { JobCard } from "@/components/JobCard";
import { useAppliedJobs } from "@/lib/use-applied-jobs";
import { useJobInsights } from "@/lib/use-job-insights";
import { JOBS, fetchPublishedJobs, compareAddedAt, relevanceScore, type Job } from "@/lib/jobs";
import { openSignedFile } from "@/lib/open-file";

export const Route = createFileRoute("/_authenticated/account")({
  beforeLoad: async () => {
    // Companies have their own dashboard; keep one source of truth per audience.
    if ((await getMyAccountType()) === "company") throw redirect({ to: "/company" });
  },
  head: () => ({
    meta: [
      { title: "My Account — SPHINX Workforce" },
      {
        name: "description",
        content:
          "View your SPHINX Workforce profile summary, CV status and all the jobs you applied for.",
      },
      { property: "og:title", content: "My Account — SPHINX Workforce" },
      {
        property: "og:description",
        content: "Your profile summary and application history on SPHINX Workforce.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AccountPage,
});

function AccountPage() {
  const { t, lang } = useI18n();
  const fetchAccount = useServerFn(getMyAccount);
  const fetchApplications = useServerFn(listMyApplications);

  const account = useQuery({ queryKey: ["my-account"], queryFn: () => fetchAccount({}) });
  const apps = useQuery({ queryKey: ["my-applications"], queryFn: () => fetchApplications({}) });

  const isAr = lang === "ar";
  const p = account.data?.profile;
  const fmt = (d: string | null | undefined) =>
    d
      ? new Date(d).toLocaleDateString(isAr ? "ar-EG" : "en-GB", {
          year: "numeric",
          month: "short",
          day: "numeric",
        })
      : "—";

  const [detailApp, setDetailApp] = useState<MyApplication | null>(null);

  /** Opens the CV that was sent with the application (stored on the profile). */
  const openMyCv = async (_applicationId: string) => {
    const path = p?.cv_url;
    if (!path) {
      toast.error(t(tx("No CV found on your profile.", "لا توجد سيرة ذاتية في ملفك.")));
      return;
    }
    const { data, error } = await supabase.storage.from("cvs").createSignedUrl(path, 300);
    if (error || !data?.signedUrl) {
      toast.error(
        t(
          tx("Could not open the CV. Please try again.", "تعذر فتح السيرة الذاتية. حاول مرة أخرى."),
        ),
      );
      return;
    }
    openSignedFile(data.signedUrl, path.substring(path.lastIndexOf("/") + 1));
  };

  const rows: Array<{
    icon: typeof Mail;
    label: ReturnType<typeof tx>;
    value: string | null | undefined;
  }> = [
    { icon: Mail, label: tx("Email", "البريد الإلكتروني"), value: p?.email ?? account.data?.email },
    { icon: Phone, label: tx("Mobile", "الجوال"), value: p?.phone },
    { icon: Globe2, label: tx("Country", "الدولة"), value: p?.country },
    { icon: Globe2, label: tx("Nationality", "الجنسية"), value: p?.nationality },
    { icon: BriefcaseBusiness, label: tx("Profession", "المهنة"), value: p?.profession },
    { icon: GraduationCap, label: tx("Education", "المؤهل"), value: p?.education },
    { icon: Languages, label: tx("Languages", "اللغات"), value: p?.languages },
  ];

  return (
    <main className="min-h-screen bg-background pt-28 pb-20" dir={isAr ? "rtl" : "ltr"}>
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="font-display text-3xl font-semibold text-heading sm:text-4xl">
              {t(tx("My Account", "حسابي"))}
            </h1>
            <p className="mt-2 text-sm text-muted-foreground">
              {t(tx("Individual – Job Seeker", "فرد – طالب وظيفة"))}
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {account.data?.userId && (
              <Link to="/candidate/$id" params={{ id: account.data.userId }}>
                <Button variant="outline" className="border-primary/60 text-gold-dark">
                  {t(tx("My Professional Profile", "ملفي الاحترافي"))}
                </Button>
              </Link>
            )}
            <Link to="/job-seekers">
              <Button className="bg-gradient-gold font-semibold text-primary-foreground hover:shadow-gold">
                <Pencil className="h-4 w-4" />
                {t(tx("Edit Profile", "تعديل الملف الشخصي"))}
              </Button>
            </Link>
          </div>
        </div>

        {/* Profile summary */}
        <Card className="mt-8 border-border/60 shadow-elegant">
          <CardHeader>
            <CardTitle className="font-display text-xl">
              {p?.full_name || t(tx("Profile Summary", "ملخص الملف الشخصي"))}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {account.isLoading ? (
              <Loader2 className="h-5 w-5 animate-spin text-gold-dark" />
            ) : (
              <>
                <dl className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  {rows.map((r) => (
                    <div key={r.label.en} className="flex items-start gap-3">
                      <r.icon className="mt-0.5 h-4 w-4 shrink-0 text-gold-dark" />
                      <div>
                        <dt className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                          {t(r.label)}
                        </dt>
                        <dd className="text-sm text-foreground break-words">{r.value || "—"}</dd>
                      </div>
                    </div>
                  ))}
                </dl>
                <div className="mt-6 flex items-center gap-3 border-t border-border/60 pt-4">
                  <FileText className="h-4 w-4 text-gold-dark" />
                  <span className="text-sm text-foreground">{t(tx("CV", "السيرة الذاتية"))}</span>
                  {p?.cv_url ? (
                    <Badge className="bg-primary/15 text-gold-dark">
                      {t(tx("Uploaded", "تم الرفع"))} · {fmt(p.cv_uploaded_at)}
                    </Badge>
                  ) : (
                    <Badge variant="outline">{t(tx("Not uploaded yet", "لم يتم الرفع بعد"))}</Badge>
                  )}
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {/* My applications */}
        <section id="applications" className="mt-10 scroll-mt-28">
          <h2 className="font-display text-2xl font-semibold text-heading">
            {t(tx("My Applications", "طلباتي"))}
          </h2>
          <Card className="mt-4 border-border/60 shadow-elegant">
            <CardContent className="p-0">
              {apps.isLoading ? (
                <div className="p-6">
                  <Loader2 className="h-5 w-5 animate-spin text-gold-dark" />
                </div>
              ) : (apps.data?.length ?? 0) === 0 ? (
                <div className="p-8 text-center text-sm text-muted-foreground">
                  {t(tx("You have not applied to any job yet.", "لم تتقدم لأي وظيفة حتى الآن."))}
                  <div className="mt-4">
                    <Link to="/jobs">
                      <Button variant="outline" className="border-primary/60 text-gold-dark">
                        {t(tx("Explore Jobs", "استعراض الوظائف"))}
                      </Button>
                    </Link>
                  </div>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-surface-soft text-xs uppercase tracking-wider text-muted-foreground">
                      <tr>
                        <th className="px-4 py-3 text-start">
                          {t(tx("Job Title", "المسمى الوظيفي"))}
                        </th>
                        <th className="px-4 py-3 text-start">{t(tx("Job Code", "كود الوظيفة"))}</th>
                        <th className="px-4 py-3 text-start">{t(tx("Company", "الشركة"))}</th>
                        <th className="px-4 py-3 text-start">
                          {t(tx("Application Date", "تاريخ التقديم"))}
                        </th>
                        <th className="px-4 py-3 text-start">{t(tx("Status", "الحالة"))}</th>
                        <th className="px-4 py-3 text-end">{t(tx("Actions", "إجراءات"))}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {apps.data!.map((a) => (
                        <tr key={a.id} className="border-t border-border/60">
                          <td className="px-4 py-3 font-medium text-foreground">
                            {isAr ? a.jobTitleAr : a.jobTitleEn}
                          </td>
                          <td className="px-4 py-3 text-muted-foreground">{a.jobCode}</td>
                          <td className="px-4 py-3 text-muted-foreground">
                            {a.company || t(tx("SPHINX Workforce", "سفنكس للقوى العاملة"))}
                          </td>
                          <td className="px-4 py-3 text-muted-foreground">{fmt(a.appliedAt)}</td>
                          <td className="px-4 py-3">
                            <Badge variant="outline" className="border-primary/50 text-gold-dark">
                              {t(applicationStatusLabel(a.status))}
                            </Badge>
                          </td>
                          <td className="px-4 py-3">
                            <div className="flex justify-end gap-2">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => setDetailApp(a)}
                                className="border-primary/60 text-gold-dark"
                              >
                                <Eye className="h-4 w-4" />
                                {t(tx("Details", "التفاصيل"))}
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => void openMyCv(a.id)}
                              >
                                {t(tx("View Application", "عرض الطلب"))}
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>

          <Dialog open={detailApp !== null} onOpenChange={(open) => !open && setDetailApp(null)}>
            {detailApp && (
              <DialogContent className="sm:max-w-md" dir={isAr ? "rtl" : "ltr"}>
                <DialogHeader>
                  <DialogTitle className="font-display text-xl">
                    {isAr ? detailApp.jobTitleAr : detailApp.jobTitleEn}
                  </DialogTitle>
                  <DialogDescription>
                    {t(tx("Application details", "تفاصيل الطلب"))}
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">
                      {t(tx("Job Code", "كود الوظيفة"))}
                    </span>
                    <span className="font-medium">{detailApp.jobCode}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">{t(tx("Company", "الشركة"))}</span>
                    <span className="font-medium">
                      {detailApp.company || t(tx("SPHINX Workforce", "سفنكس للقوى العاملة"))}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">
                      {t(tx("Application Date", "تاريخ التقديم"))}
                    </span>
                    <span className="font-medium">{fmt(detailApp.appliedAt)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">{t(tx("Status", "الحالة"))}</span>
                    <Badge variant="outline" className="border-primary/50 text-gold-dark">
                      {t(applicationStatusLabel(detailApp.status))}
                    </Badge>
                  </div>
                </div>
                <div className="mt-6 flex flex-wrap gap-3">
                  {detailApp.externalJobId ? (
                    <Link to="/jobs" search={{ job: detailApp.externalJobId }} className="flex-1">
                      <Button className="w-full bg-gradient-gold font-semibold text-primary-foreground hover:shadow-gold">
                        <ExternalLink className="h-4 w-4" />
                        {t(tx("View Job", "عرض الوظيفة"))}
                      </Button>
                    </Link>
                  ) : detailApp.jobPostingId ? (
                    <Button disabled className="flex-1">
                      <ExternalLink className="h-4 w-4" />
                      {t(tx("View Job", "عرض الوظيفة"))}
                    </Button>
                  ) : (
                    <Button disabled className="flex-1">
                      <ExternalLink className="h-4 w-4" />
                      {t(tx("View Job", "عرض الوظيفة"))}
                    </Button>
                  )}
                  <Button
                    variant="outline"
                    className="flex-1 border-primary/60 text-gold-dark"
                    onClick={() => {
                      void openMyCv(detailApp.id);
                    }}
                  >
                    <FileText className="h-4 w-4" />
                    {t(tx("View Application", "عرض الطلب"))}
                  </Button>
                </div>
                {!detailApp.externalJobId && detailApp.jobPostingId && (
                  <p className="text-xs text-muted-foreground">
                    {t(
                      tx(
                        "This vacancy was posted directly by the employer and is not listed on the public jobs page.",
                        "هذه الوظيفة منشورة مباشرة من صاحب العمل وغير معروضة في صفحة الوظائف العامة.",
                      ),
                    )}
                  </p>
                )}
              </DialogContent>
            )}
          </Dialog>
        </section>

        {/* Available / recommended vacancies — same data + card as Explore Jobs */}
        <AvailableJobs
          profile={{
            sector: p?.sector ?? null,
            profession: p?.profession ?? null,
            country: p?.country ?? null,
          }}
        />

        {/* Optional supporting documents (CV stays mandatory and separate) */}
        <ProfileDocuments />
      </div>
    </main>
  );
}

/**
 * Job Seeker dashboard listing. Reuses the shared job data + JobCard so a
 * vacancy published by a company shows up here automatically, newest first.
 */
function AvailableJobs({
  profile,
}: {
  profile: { sector: string | null; profession: string | null; country: string | null };
}) {
  const { t } = useI18n();
  const navigate = useNavigate();
  const applied = useAppliedJobs();

  const { data: published = [], isLoading } = useQuery({
    queryKey: ["published-jobs"],
    queryFn: fetchPublishedJobs,
    staleTime: 30_000,
    refetchOnMount: "always",
  });

  const all: Job[] = [...published, ...JOBS];
  const recommended = [...all]
    .map((j) => ({ j, score: relevanceScore(j, profile) }))
    .sort((a, b) => b.score - a.score || compareAddedAt(a.j, b.j, "newest"))
    .filter((x) => x.score > 0)
    .slice(0, 4)
    .map((x) => x.j);
  const latest = [...all].sort((a, b) => compareAddedAt(a, b, "newest")).slice(0, 6);
  const { insights, config } = useJobInsights(all);

  const open = (id: string) => navigate({ to: "/jobs", search: { job: id } });

  const Grid = ({ jobs }: { jobs: Job[] }) => (
    <div className="mt-4 grid gap-4 md:grid-cols-2">
      {jobs.map((j) => (
        <JobCard
          key={j.id}
          job={j}
          applied={applied[j.id]}
          insight={insights[j.id]}
          showApplicantCount={config.show_applicant_count_public}
          onSelect={open}
        />
      ))}
    </div>
  );

  return (
    <section id="available-jobs" className="mt-10 scroll-mt-28">
      {recommended.length > 0 && (
        <>
          <h2 className="font-display text-2xl font-semibold text-heading">
            {t(tx("Recommended For You", "وظائف مقترحة لك"))}
          </h2>
          <Grid jobs={recommended} />
        </>
      )}

      <div className="mt-10 flex flex-wrap items-center justify-between gap-3">
        <h2 className="font-display text-2xl font-semibold text-heading">
          {t(tx("Latest Jobs", "أحدث الوظائف"))}
        </h2>
        <Link to="/jobs">
          <Button variant="outline" size="sm" className="border-primary/60 text-gold-dark">
            {t(tx("Explore all jobs", "استعراض كل الوظائف"))}
          </Button>
        </Link>
      </div>
      {isLoading ? (
        <div className="mt-4">
          <Loader2 className="h-5 w-5 animate-spin text-gold-dark" />
        </div>
      ) : latest.length === 0 ? (
        <p className="mt-4 text-sm text-muted-foreground">
          {t(tx("No published jobs available right now.", "لا توجد وظائف منشورة حالياً."))}
        </p>
      ) : (
        <Grid jobs={latest} />
      )}
    </section>
  );
}
