import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState, type FormEvent } from "react";
import { useStateDraft } from "@/lib/form-draft";
import { Loader2, Users, Plus, ArrowRight, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { SearchableSelect } from "@/components/SearchableSelect";
import { ClientForm } from "@/components/ClientForm";
import { useI18n, tx } from "@/i18n";
import { imagery, ornaments } from "@/brand";
import { NATURE_OF_BUSINESS, type ClientRecord } from "@/lib/clients";
import { NATIONALITIES } from "@/lib/countries";
import { createManpowerRequest, listClients, listManpowerRequests } from "@/lib/clients.functions";

export const Route = createFileRoute("/_authenticated/manpower")({
  head: () => ({
    meta: [
      { title: "Manpower Requests — SPHINX Workforce" },
      {
        name: "description",
        content:
          "Select or create a client, then define the manpower requirement: job category, required quantity, nationality, salary, location, duration and experience.",
      },
      { property: "og:title", content: "Manpower Requests — SPHINX Workforce" },
      {
        property: "og:description",
        content: "Client selection and workforce requirement definition in one flow.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ManpowerPage,
});

const NATIONALITY_OPTIONS = NATIONALITIES.map((n) => ({ value: n.en, label: n }));

function ManpowerPage() {
  const { t, lang } = useI18n();
  const queryClient = useQueryClient();
  const fetchClients = useServerFn(listClients);
  const fetchRequests = useServerFn(listManpowerRequests);
  const submitRequest = useServerFn(createManpowerRequest);

  const clients = useQuery({ queryKey: ["clients"], queryFn: () => fetchClients({}) });
  const requests = useQuery({ queryKey: ["manpower-requests"], queryFn: () => fetchRequests({}) });

  const [creatingClient, setCreatingClient] = useState(false);
  const [clientId, setClientId] = useState("");
  const [saving, setSaving] = useState(false);
  const [req, setReq] = useState({
    job_category: "",
    required_quantity: "1",
    nationality_required: "",
    salary_range: "",
    work_location: "",
    contract_duration: "",
    required_experience: "",
    notes: "",
  });
  const { clearDraft } = useStateDraft(
    "manpower-request",
    req,
    (d) => setReq((r) => ({ ...r, ...d })),
    lang,
  );

  const clientOptions = (clients.data ?? []).map((c) => ({
    value: c.id,
    label: { en: c.name, ar: c.name },
  }));
  const selected = (clients.data ?? []).find((c) => c.id === clientId) ?? null;

  /** After saving from Manpower, return to the flow with the new client selected. */
  async function onClientSaved(client: ClientRecord) {
    await queryClient.invalidateQueries({ queryKey: ["clients"] });
    setClientId(client.id);
    setCreatingClient(false);
  }

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!clientId) {
      toast.error(
        t(tx("Please select or create a client first.", "يرجى اختيار أو إنشاء عميل أولاً.")),
      );
      return;
    }
    if (!req.job_category) {
      toast.error(t(tx("Please select the job category.", "يرجى اختيار الفئة الوظيفية.")));
      return;
    }
    if (!req.required_quantity || Number(req.required_quantity) < 1) {
      toast.error(t(tx("Please enter the required quantity.", "يرجى إدخال العدد المطلوب.")));
      return;
    }
    setSaving(true);
    try {
      await submitRequest({ data: { ...req, client_id: clientId } });
      await queryClient.invalidateQueries({ queryKey: ["manpower-requests"] });
      clearDraft();
      setReq({
        job_category: "",
        required_quantity: "1",
        nationality_required: "",
        salary_range: "",
        work_location: "",
        contract_duration: "",
        required_experience: "",
        notes: "",
      });
      toast.success(
        t(tx("Manpower request saved successfully.", "تم حفظ طلب القوى العاملة بنجاح.")),
      );
    } catch {
      toast.error(
        t(
          tx(
            "Saving failed. Your entries were kept — please try again.",
            "فشل الحفظ. تم الاحتفاظ بالبيانات — يرجى إعادة المحاولة.",
          ),
        ),
      );
    } finally {
      setSaving(false);
    }
  }

  const inputClass = "h-11 bg-background";
  const selectClass =
    "h-11 w-full rounded-md border border-input bg-background px-3 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring";

  return (
    <main className="relative isolate min-h-screen bg-background pb-24 pt-28 md:pt-36">
      {/* Light ivory ground with a faint hieroglyphic branding layer (shared with Services/Home) */}
      <div aria-hidden className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-b from-background via-surface-soft to-background" />
        <div
          className="ornament-faint absolute inset-0 bg-repeat"
          style={{ backgroundImage: `url(${ornaments.pattern})`, backgroundSize: "380px" }}
        />
      </div>

      {/* Soft Pharaonic header band — veiled artwork keeps titles fully readable */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-[420px] overflow-hidden"
      >
        <div
          className="absolute inset-0 bg-cover bg-[position:72%_center] bg-no-repeat md:bg-center"
          style={{ backgroundImage: `url(${imagery.laborForce})` }}
        />
        <div className="hero-veil absolute inset-0" />
        <div className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-b from-transparent to-background" />
      </div>

      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
        <span className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.25em] text-gold-dark">
          <Users className="h-3.5 w-3.5" /> {t(tx("Manpower", "القوى العاملة"))}
        </span>
        <h1 className="mt-2 font-display text-3xl font-medium text-heading md:text-4xl">
          {t(tx("Manpower Requests", "طلبات القوى العاملة"))}
        </h1>
        <div className="gold-divider mt-6 w-24" />

        {/* Step 1 — select or create client */}
        <Card className="mt-8 border-border/80 bg-card/95 shadow-elegant ring-inset-gold backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="font-display text-xl">
              {t(tx("1. Select or Create Client", "١. اختيار أو إنشاء عميل"))}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {creatingClient ? (
              <ClientForm
                onSaved={(c) => void onClientSaved(c)}
                onCancel={() => setCreatingClient(false)}
                onSelectExisting={(c) => void onClientSaved(c)}
              />
            ) : (
              <div className="space-y-4">
                <div className="grid gap-4 md:grid-cols-[1fr_auto] md:items-end">
                  <div>
                    <Label className="text-xs font-semibold uppercase tracking-wider text-gold-dark">
                      {t(tx("Existing Client", "عميل حالي"))}
                    </Label>
                    <div className="mt-2">
                      {clients.isLoading ? (
                        <Loader2 className="h-5 w-5 animate-spin text-gold-dark" />
                      ) : (
                        <SearchableSelect
                          options={clientOptions}
                          value={clientId}
                          onChange={setClientId}
                          placeholder={t(tx("Search clients…", "ابحث عن العملاء…"))}
                        />
                      )}
                    </div>
                  </div>
                  <Button
                    type="button"
                    variant="outline"
                    className="border-primary/60 text-gold-dark"
                    onClick={() => setCreatingClient(true)}
                  >
                    <Plus className="h-4 w-4" />
                    {t(tx("Create New Client", "تعريف عميل جديد"))}
                  </Button>
                </div>
                {selected && (
                  <p className="flex items-center gap-2 text-sm text-foreground">
                    <CheckCircle2 className="h-4 w-4 text-gold-dark" />
                    {t(tx("Selected client:", "العميل المختار:"))} <strong>{selected.name}</strong>
                    <Link to="/clients" className="text-xs text-gold-dark underline">
                      {t(tx("Manage clients", "إدارة العملاء"))}
                    </Link>
                  </p>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Step 2 — manpower requirement (job category + quantity live here) */}
        <Card className="mt-6 border-border/80 bg-card/95 shadow-elegant ring-inset-gold backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="font-display text-xl">
              {t(tx("2. Manpower Requirement", "٢. متطلبات القوى العاملة"))}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={onSubmit} className="space-y-5">
              <div className="grid gap-5 md:grid-cols-2">
                <div>
                  <Label className="text-xs font-semibold uppercase tracking-wider text-gold-dark">
                    {t(tx("Job Category", "الفئة الوظيفية"))}{" "}
                    <span className="text-destructive">*</span>
                  </Label>
                  <div className="mt-2">
                    <SearchableSelect
                      options={NATURE_OF_BUSINESS}
                      value={req.job_category}
                      onChange={(v) => setReq((r) => ({ ...r, job_category: v }))}
                      placeholder={t(tx("Select a category…", "اختر الفئة…"))}
                    />
                  </div>
                </div>
                <div>
                  <Label className="text-xs font-semibold uppercase tracking-wider text-gold-dark">
                    {t(tx("Required Quantity", "العدد المطلوب"))}{" "}
                    <span className="text-destructive">*</span>
                  </Label>
                  <Input
                    type="number"
                    min={1}
                    className={`mt-2 ${inputClass}`}
                    value={req.required_quantity}
                    onChange={(e) => setReq((r) => ({ ...r, required_quantity: e.target.value }))}
                  />
                </div>
                <div>
                  <Label className="text-xs font-semibold uppercase tracking-wider text-gold-dark">
                    {t(tx("Nationality Required", "الجنسية المطلوبة"))}
                  </Label>
                  <div className="mt-2">
                    <SearchableSelect
                      options={NATIONALITY_OPTIONS}
                      value={req.nationality_required}
                      onChange={(v) => setReq((r) => ({ ...r, nationality_required: v }))}
                      placeholder={t(tx("Search nationality…", "ابحث عن الجنسية…"))}
                    />
                  </div>
                </div>
                <div>
                  <Label className="text-xs font-semibold uppercase tracking-wider text-gold-dark">
                    {t(tx("Salary Range", "نطاق الراتب"))}
                  </Label>
                  <Input
                    className={`mt-2 ${inputClass}`}
                    value={req.salary_range}
                    onChange={(e) => setReq((r) => ({ ...r, salary_range: e.target.value }))}
                    placeholder="SAR 5,000 – 8,000"
                  />
                </div>
                <div>
                  <Label className="text-xs font-semibold uppercase tracking-wider text-gold-dark">
                    {t(tx("Work Location", "موقع العمل"))}
                  </Label>
                  <Input
                    className={`mt-2 ${inputClass}`}
                    value={req.work_location}
                    onChange={(e) => setReq((r) => ({ ...r, work_location: e.target.value }))}
                  />
                </div>
                <div>
                  <Label className="text-xs font-semibold uppercase tracking-wider text-gold-dark">
                    {t(tx("Contract Duration", "مدة العقد"))}
                  </Label>
                  <select
                    className={`mt-2 ${selectClass}`}
                    value={req.contract_duration}
                    onChange={(e) => setReq((r) => ({ ...r, contract_duration: e.target.value }))}
                  >
                    <option value="">{t(tx("Select duration…", "اختر المدة…"))}</option>
                    <option value="lt3m">{t(tx("Less than 3 months", "أقل من 3 أشهر"))}</option>
                    <option value="3to6m">{t(tx("3 – 6 months", "3 – 6 أشهر"))}</option>
                    <option value="6to12m">{t(tx("6 – 12 months", "6 – 12 شهر"))}</option>
                    <option value="1to2y">{t(tx("1 – 2 years", "1 – 2 سنة"))}</option>
                    <option value="gt2y">{t(tx("2+ years", "أكثر من سنتين"))}</option>
                  </select>
                </div>
                <div>
                  <Label className="text-xs font-semibold uppercase tracking-wider text-gold-dark">
                    {t(tx("Required Experience", "الخبرة المطلوبة"))}
                  </Label>
                  <select
                    className={`mt-2 ${selectClass}`}
                    value={req.required_experience}
                    onChange={(e) => setReq((r) => ({ ...r, required_experience: e.target.value }))}
                  >
                    <option value="">{t(tx("Select…", "اختر…"))}</option>
                    <option value="lt2">{t(tx("Less than 2 years", "أقل من سنتين"))}</option>
                    <option value="3to7">{t(tx("3 – 7 years", "من 3 إلى 7 سنوات"))}</option>
                    <option value="gt7">{t(tx("7+ years", "أكثر من 7 سنوات"))}</option>
                  </select>
                </div>
              </div>

              <div>
                <Label className="text-xs font-semibold uppercase tracking-wider text-gold-dark">
                  {t(tx("Additional Notes", "ملاحظات إضافية"))}
                </Label>
                <Textarea
                  rows={4}
                  className="mt-2 bg-background"
                  value={req.notes}
                  onChange={(e) => setReq((r) => ({ ...r, notes: e.target.value }))}
                />
              </div>

              <Button
                type="submit"
                disabled={saving}
                aria-busy={saving}
                className="bg-gradient-gold font-semibold text-primary-foreground hover:shadow-gold"
              >
                {saving ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <ArrowRight className="h-4 w-4" />
                )}
                {t(tx("Submit Manpower Request", "إرسال طلب القوى العاملة"))}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Existing requests */}
        <Card className="mt-6 border-border/80 bg-card/95 shadow-elegant ring-inset-gold backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="font-display text-xl">
              {t(tx("My Manpower Requests", "طلبات القوى العاملة"))}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {requests.isLoading ? (
              <Loader2 className="h-5 w-5 animate-spin text-gold-dark" />
            ) : (requests.data ?? []).length === 0 ? (
              <p className="text-sm text-muted-foreground">
                {t(tx("No manpower requests yet.", "لا توجد طلبات بعد."))}
              </p>
            ) : (
              <ul className="divide-y divide-border">
                {(requests.data ?? []).map((r) => (
                  <li
                    key={r.id}
                    className="flex flex-wrap items-center justify-between gap-3 py-3 text-sm"
                  >
                    <span className="font-medium">{r.client_name}</span>
                    <span className="text-muted-foreground">
                      {NATURE_OF_BUSINESS.find((n) => n.value === r.job_category)?.label[lang] ??
                        r.job_category}
                    </span>
                    <Badge variant="outline" className="border-primary/50 text-gold-dark">
                      {r.required_quantity}
                    </Badge>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      </div>
    </main>
  );
}
