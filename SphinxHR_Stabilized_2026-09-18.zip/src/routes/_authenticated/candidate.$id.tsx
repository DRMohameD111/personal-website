import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import {
  BadgeCheck,
  FileText,
  GraduationCap,
  Languages,
  Loader2,
  Lock,
  Mail,
  Phone,
  PlayCircle,
  Star,
} from "lucide-react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useI18n, tx } from "@/i18n";
import { CandidateAvatar } from "@/components/CandidateAvatar";
import { PACKAGE_REQUIRED, type CandidateFeature } from "@/lib/entitlements";
import { getCandidateMediaUrl, getCandidateProfile } from "@/lib/candidate-profile.functions";
import { openSignedFile } from "@/lib/open-file";
import { LockedFeature } from "@/components/LockedFeature";

export const Route = createFileRoute("/_authenticated/candidate/$id")({
  head: () => ({
    meta: [
      { title: "Professional Candidate Profile — SPHINX Workforce" },
      {
        name: "description",
        content:
          "Verified candidate profile with experience, skills, certificates, CV and interview video, opened according to your active package.",
      },
      { property: "og:title", content: "Professional Candidate Profile — SPHINX Workforce" },
      {
        property: "og:description",
        content: "Verified candidate experience, skills, certificates and interview video.",
      },
      { property: "og:type", content: "profile" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: CandidateProfilePage,
});

function CandidateProfilePage() {
  const { t, lang } = useI18n();
  const isAr = lang === "ar";
  const { id } = Route.useParams();
  const fetchProfile = useServerFn(getCandidateProfile);
  const fetchMedia = useServerFn(getCandidateMediaUrl);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  const q = useQuery({
    queryKey: ["candidate-profile", id],
    queryFn: () => fetchProfile({ data: { candidateId: id } }),
    retry: false,
  });

  const locked = q.isError && String((q.error as Error).message) === PACKAGE_REQUIRED;

  const open = async (kind: "cv" | "video" | "certificate", documentId?: string) => {
    setBusy(documentId ?? kind);
    try {
      const { url, fileName } = await fetchMedia({ data: { candidateId: id, kind, documentId } });
      if (kind === "video") setVideoUrl(url);
      else openSignedFile(url, fileName);
    } catch (err) {
      const msg = String((err as Error).message);
      toast.error(
        msg === PACKAGE_REQUIRED
          ? t(
              tx(
                "Your current package does not include this.",
                "باقتك الحالية لا تتضمن هذه الميزة.",
              ),
            )
          : t(tx("Could not open the file.", "تعذر فتح الملف.")),
      );
    } finally {
      setBusy(null);
    }
  };

  const p = q.data;
  const allows = (f: CandidateFeature) => !p || p.viewerRole !== "company" || p.access[f];

  return (
    <main className="min-h-screen bg-background pt-28 pb-20" dir={isAr ? "rtl" : "ltr"}>
      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
        {q.isLoading ? (
          <Loader2 className="h-6 w-6 animate-spin text-gold-dark" />
        ) : locked ? (
          <Card className="border-primary/50 shadow-elegant">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 font-display text-xl">
                <Lock className="h-5 w-5 text-gold-dark" />
                {t(
                  tx(
                    "Professional profile is not in your package",
                    "الملف الاحترافي غير متضمن في باقتك",
                  ),
                )}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-sm text-muted-foreground">
              {t(
                tx(
                  "Upgrade your package to open professional candidate profiles, certificates, interview videos and contact details.",
                  "قم بترقية باقتك لعرض الملفات الاحترافية للمرشحين والشهادات وفيديو المقابلة وبيانات التواصل.",
                ),
              )}
              <div>
                <Link to="/portal">
                  <Button className="bg-gradient-gold font-semibold text-primary-foreground hover:shadow-gold">
                    {t(tx("Change or upgrade package", "تغيير أو ترقية الباقة"))}
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        ) : q.isError || !p ? (
          <p className="text-sm text-destructive">
            {t(tx("This profile is not available.", "هذا الملف غير متاح."))}
          </p>
        ) : (
          <>
            <Card className="sphinx-card border-primary/40 shadow-elegant">
              <CardContent className="p-6">
                <div className="flex flex-wrap items-start gap-5">
                  <CandidateAvatar photoUrl={p.photoUrl} gender={p.gender} name={p.name} />
                  <div className="min-w-0 flex-1">
                    <h1 className="font-display text-2xl font-semibold text-heading sm:text-3xl">
                      {p.name || t(tx("Candidate", "مرشح"))}
                    </h1>
                    <p className="mt-1 text-sm text-muted-foreground">{p.jobTitle || "—"}</p>
                    <div className="mt-3 flex flex-wrap items-center gap-2">
                      {p.verified && (
                        <Badge variant="outline" className="border-emerald-500/60 text-emerald-700">
                          <BadgeCheck className="h-3.5 w-3.5" />
                          {t(tx("Verified", "موثّق"))}
                        </Badge>
                      )}
                      {p.featured && (
                        <Badge variant="outline" className="border-primary/60 text-gold-dark">
                          <Star className="h-3.5 w-3.5" />
                          {t(tx("Featured", "مميز"))}
                        </Badge>
                      )}
                      {p.availability && (
                        <Badge variant="outline" className="border-primary/50 text-gold-dark">
                          {p.availability}
                        </Badge>
                      )}
                      {[p.country, p.nationality].filter(Boolean).length > 0 && (
                        <span className="text-xs text-muted-foreground">
                          {[p.country, p.nationality].filter(Boolean).join(" · ")}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
                <div className="pharaonic-strip mt-6" />
              </CardContent>
            </Card>

            <div className="mt-6 grid gap-6 md:grid-cols-2">
              <Card className="border-border/60">
                <CardHeader>
                  <CardTitle className="font-display text-lg">
                    {t(tx("Experience & Skills", "الخبرة والمهارات"))}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4 text-sm">
                  <p className="text-foreground">{p.experience || "—"}</p>
                  <div className="flex flex-wrap gap-2">
                    {p.skills.length === 0 ? (
                      <span className="text-muted-foreground">
                        {t(tx("No skills listed.", "لا توجد مهارات مدرجة."))}
                      </span>
                    ) : (
                      p.skills.map((s) => (
                        <span
                          key={s}
                          className="rounded-full border border-primary/40 bg-primary/5 px-3 py-1 text-xs font-medium text-gold-dark"
                        >
                          {s}
                        </span>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border/60">
                <CardHeader>
                  <CardTitle className="font-display text-lg">
                    {t(tx("Education & Languages", "المؤهل واللغات"))}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 text-sm">
                  <p className="flex items-start gap-2">
                    <GraduationCap className="mt-0.5 h-4 w-4 text-gold-dark" />
                    {p.education || "—"}
                  </p>
                  <p className="flex items-start gap-2">
                    <Languages className="mt-0.5 h-4 w-4 text-gold-dark" />
                    {p.languages || "—"}
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Contact */}
            <Card className="mt-6 border-border/60">
              <CardHeader>
                <CardTitle className="font-display text-lg">
                  {t(tx("Contact", "التواصل"))}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                {p.contact ? (
                  <>
                    <p className="flex items-center gap-2">
                      <Mail className="h-4 w-4 text-gold-dark" />
                      {p.contact.email || "—"}
                    </p>
                    <p className="flex items-center gap-2">
                      <Phone className="h-4 w-4 text-gold-dark" />
                      {p.contact.phone || "—"}
                    </p>
                  </>
                ) : (
                  <LockedFeature label={t(tx("Contact candidate", "التواصل مع المرشح"))} />
                )}
              </CardContent>
            </Card>

            {/* CV, certificates, interview video */}
            <Card className="mt-6 border-border/60">
              <CardHeader>
                <CardTitle className="font-display text-lg">
                  {t(
                    tx(
                      "CV, Certificates & Interview Video",
                      "السيرة الذاتية والشهادات وفيديو المقابلة",
                    ),
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4 text-sm">
                <div className="flex flex-wrap items-center gap-2">
                  {!allows("cv_download") ? (
                    <LockedFeature label={t(tx("Download CV", "تنزيل السيرة الذاتية"))} />
                  ) : (
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-primary/60 text-gold-dark"
                      disabled={!p.hasCv || busy === "cv"}
                      onClick={() => void open("cv")}
                    >
                      {busy === "cv" ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <FileText className="h-4 w-4" />
                      )}
                      {t(tx("Download CV", "تنزيل السيرة الذاتية"))}
                    </Button>
                  )}

                  {!allows("interview_video") ? (
                    <LockedFeature label={t(tx("Interview video", "فيديو المقابلة"))} />
                  ) : (
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-primary/60 text-gold-dark"
                      disabled={!p.hasVideo || busy === "video"}
                      onClick={() => void open("video")}
                    >
                      {busy === "video" ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <PlayCircle className="h-4 w-4" />
                      )}
                      {t(tx("Interview video", "فيديو المقابلة"))}
                    </Button>
                  )}
                </div>

                {videoUrl && (
                  <video
                    src={videoUrl}
                    controls
                    className="w-full rounded-xl border border-primary/40"
                  />
                )}

                <div className="border-t border-border/60 pt-4">
                  <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    {t(tx("Certificates", "الشهادات"))}
                  </p>
                  {!allows("certificates") ? (
                    <div className="mt-2">
                      <LockedFeature label={t(tx("Certificates", "الشهادات"))} />
                    </div>
                  ) : p.certificates.length === 0 ? (
                    <p className="mt-2 text-muted-foreground">
                      {t(tx("No certificates uploaded.", "لا توجد شهادات مرفوعة."))}
                    </p>
                  ) : (
                    <ul className="mt-2 space-y-2">
                      {p.certificates.map((c) => (
                        <li
                          key={c.id}
                          className="flex flex-wrap items-center justify-between gap-2"
                        >
                          <span className="text-foreground">{c.title}</span>
                          <Button
                            size="sm"
                            variant="outline"
                            className="border-primary/60 text-gold-dark"
                            disabled={busy === c.id}
                            onClick={() => void open("certificate", c.id)}
                          >
                            {busy === c.id ? (
                              <Loader2 className="h-4 w-4 animate-spin" />
                            ) : (
                              <FileText className="h-4 w-4" />
                            )}
                            {t(tx("View", "عرض"))}
                          </Button>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </main>
  );
}
