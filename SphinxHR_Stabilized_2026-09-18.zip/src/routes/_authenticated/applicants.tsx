import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Loader2, Users, FileText, ChevronDown, ChevronUp, UserSquare2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { useI18n, tx } from "@/i18n";
import {
  listMyJobsWithApplicants,
  listApplicantsForJob,
  getApplicantCvUrl,
} from "@/lib/account.functions";
import { requireCompanyAccount } from "@/lib/account-type";
import { AddReceivedCv } from "@/components/AddReceivedCv";
import { CandidateRecommendations } from "@/components/CandidateRecommendations";

import { applicationStatusLabel, jobStatusLabel } from "@/lib/status-labels";
import { openSignedFile } from "@/lib/open-file";
import { useCandidateAccess } from "@/lib/use-candidate-access";
import { LockedFeature } from "@/components/LockedFeature";

export const Route = createFileRoute("/_authenticated/applicants")({
  validateSearch: (s: Record<string, unknown>): { job?: string } =>
    typeof s.job === "string" && s.job ? { job: s.job } : {},
  beforeLoad: async () => {
    await requireCompanyAccount();
  },
  head: () => ({
    meta: [
      { title: "Applicants — SPHINX Workforce" },
      {
        name: "description",
        content:
          "Review candidates who applied to each of your vacancies and open their CVs securely.",
      },
      { property: "og:title", content: "Applicants — SPHINX Workforce" },
      { property: "og:description", content: "Candidates grouped by your posted vacancies." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ApplicantsPage,
});

function ApplicantsPage() {
  const { t, lang } = useI18n();
  const isAr = lang === "ar";
  const { job: initialJob } = Route.useSearch();
  const fetchJobs = useServerFn(listMyJobsWithApplicants);
  const jobs = useQuery({ queryKey: ["company-jobs"], queryFn: () => fetchJobs({}) });
  const [openJob, setOpenJob] = useState<string | null>(initialJob ?? null);

  return (
    <main className="min-h-screen bg-background pt-28 pb-20" dir={isAr ? "rtl" : "ltr"}>
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="font-display text-3xl font-semibold text-heading sm:text-4xl">
              {t(tx("Applicants", "المتقدمون"))}
            </h1>
            <p className="mt-2 text-sm text-muted-foreground">
              {t(
                tx(
                  "Candidates are grouped under the vacancy they applied to.",
                  "يتم تجميع المرشحين حسب الوظيفة التي تقدموا إليها.",
                ),
              )}
            </p>
          </div>
          <Link to="/company" className="text-sm font-medium text-gold-dark hover:underline">
            {t(tx("Company Account", "حساب الشركة"))}
          </Link>
        </div>

        {jobs.isLoading ? (
          <div className="mt-10">
            <Loader2 className="h-5 w-5 animate-spin text-gold-dark" />
          </div>
        ) : (jobs.data?.length ?? 0) === 0 ? (
          <Card className="mt-8 border-border/60">
            <CardContent className="p-8 text-center text-sm text-muted-foreground">
              {t(tx("You have not posted any job yet.", "لم تنشر أي وظيفة حتى الآن."))}
            </CardContent>
          </Card>
        ) : (
          <div className="mt-8 space-y-4">
            {jobs.data!.map((j) => {
              const open = openJob === j.id;
              return (
                <Card key={j.id} className="border-border/60 shadow-elegant">
                  <CardContent className="p-5">
                    <div className="flex flex-wrap items-center justify-between gap-4">
                      <div>
                        <h2 className="font-display text-xl md:text-2xl font-semibold text-heading">
                          {isAr ? j.titleAr : j.titleEn}{" "}
                          <span className="text-muted-foreground">– {j.jobCode}</span>
                        </h2>
                        <div className="mt-1 flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
                          <Badge variant="outline" className="border-primary/50 text-gold-dark">
                            {t(jobStatusLabel(j.status))}
                          </Badge>
                          <span>
                            {j.applicants} {t(tx("Applicants", "متقدم"))}
                          </span>
                          <span>·</span>
                          <span>
                            {j.cvs} {t(tx("CVs", "سيرة ذاتية"))}
                          </span>
                        </div>
                      </div>
                      <div className="flex flex-wrap items-center gap-2">
                        <AddReceivedCv jobPostingId={j.id} />
                        <Button
                          variant="outline"
                          className="border-primary/60 text-gold-dark"
                          onClick={() => setOpenJob(open ? null : j.id)}
                        >
                          <Users className="h-4 w-4" />
                          {t(tx("View Applicants", "عرض المتقدمين"))}
                          {open ? (
                            <ChevronUp className="h-4 w-4" />
                          ) : (
                            <ChevronDown className="h-4 w-4" />
                          )}
                        </Button>
                      </div>
                    </div>

                    <CandidateRecommendations jobPostingId={j.id} />

                    {open && <ApplicantTable jobPostingId={j.id} />}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </main>
  );
}

function ApplicantTable({ jobPostingId }: { jobPostingId: string }) {
  const { t, lang } = useI18n();
  const isAr = lang === "ar";
  const fetchApplicants = useServerFn(listApplicantsForJob);
  const fetchCv = useServerFn(getApplicantCvUrl);
  const [cvLoading, setCvLoading] = useState<string | null>(null);
  const access = useCandidateAccess();

  const q = useQuery({
    queryKey: ["job-applicants", jobPostingId],
    queryFn: () => fetchApplicants({ data: { jobPostingId } }),
  });

  const fmt = (d: string) =>
    new Date(d).toLocaleDateString(isAr ? "ar-EG" : "en-GB", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });

  async function openCv(applicationId: string) {
    setCvLoading(applicationId);
    try {
      const { url, fileName } = await fetchCv({ data: { applicationId } });
      openSignedFile(url, fileName);
    } catch {
      toast.error(
        t(
          tx(
            "The operation could not be completed. Please review your information and try again.",
            "تعذر إتمام العملية. يرجى مراجعة البيانات والمحاولة مرة أخرى.",
          ),
        ),
      );
    } finally {
      setCvLoading(null);
    }
  }

  if (q.isLoading)
    return (
      <div className="mt-5 border-t border-border/60 pt-5">
        <Loader2 className="h-5 w-5 animate-spin text-gold-dark" />
      </div>
    );

  if ((q.data?.length ?? 0) === 0)
    return (
      <div className="mt-5 border-t border-border/60 pt-5 text-sm text-muted-foreground">
        {t(tx("No applicants for this job yet.", "لا يوجد متقدمون لهذه الوظيفة حتى الآن."))}
      </div>
    );

  return (
    <div className="mt-5 overflow-x-auto border-t border-border/60 pt-5">
      <table className="w-full text-sm">
        <thead className="text-xs uppercase tracking-wider text-muted-foreground">
          <tr>
            <th className="px-3 py-2 text-start">{t(tx("Candidate", "المرشح"))}</th>
            <th className="px-3 py-2 text-start">{t(tx("Application Date", "تاريخ التقديم"))}</th>
            <th className="px-3 py-2 text-start">{t(tx("Status", "الحالة"))}</th>
            <th className="px-3 py-2 text-start">{t(tx("Profession", "المهنة"))}</th>
            <th className="px-3 py-2 text-start">
              {t(tx("Experience / Level", "الخبرة / المستوى"))}
            </th>
            <th className="px-3 py-2" />
          </tr>
        </thead>
        <tbody>
          {q.data!.map((a) => (
            <tr key={a.id} className="border-t border-border/60">
              <td className="px-3 py-3 font-medium text-foreground">{a.name || "—"}</td>
              <td className="px-3 py-3 text-muted-foreground">{fmt(a.appliedAt)}</td>
              <td className="px-3 py-3">
                <Badge variant="outline" className="border-primary/50 text-gold-dark">
                  {t(applicationStatusLabel(a.status))}
                </Badge>
              </td>
              <td className="px-3 py-3 text-muted-foreground">{a.profession || "—"}</td>
              <td className="px-3 py-3 text-muted-foreground">{a.level || "—"}</td>
              <td className="px-3 py-3">
                <div className="flex flex-wrap items-center gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    disabled={!a.hasCv || cvLoading === a.id}
                    onClick={() => void openCv(a.id)}
                    className="border-primary/60 text-gold-dark"
                  >
                    {cvLoading === a.id ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <FileText className="h-4 w-4" />
                    )}
                    {t(tx("View CV", "عرض السيرة الذاتية"))}
                  </Button>
                  {a.candidateId &&
                    (access.professional_profile ? (
                      <Link to="/candidate/$id" params={{ id: a.candidateId }}>
                        <Button
                          size="sm"
                          variant="outline"
                          className="border-primary/60 text-gold-dark"
                        >
                          <UserSquare2 className="h-4 w-4" />
                          {t(tx("Professional Profile", "الملف الاحترافي"))}
                        </Button>
                      </Link>
                    ) : (
                      <LockedFeature label={t(tx("Professional Profile", "الملف الاحترافي"))} />
                    ))}
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
