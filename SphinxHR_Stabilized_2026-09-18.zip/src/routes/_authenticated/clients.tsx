import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Loader2, Plus, Pencil, Building2, Globe2, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useI18n, tx } from "@/i18n";
import { ClientForm } from "@/components/ClientForm";
import { listClients } from "@/lib/clients.functions";
import {
  branchesLabel,
  countryLabel,
  legalStructureLabel,
  natureOfBusinessLabel,
  type ClientRecord,
} from "@/lib/clients";

export const Route = createFileRoute("/_authenticated/clients")({
  head: () => ({
    meta: [
      { title: "Clients — SPHINX Workforce" },
      {
        name: "description",
        content:
          "Create and manage client master data: nature of business, company nationality, legal structure, headquarters, branches, official email and website.",
      },
      { property: "og:title", content: "Clients — SPHINX Workforce" },
      {
        property: "og:description",
        content: "Client master data management for SPHINX Workforce.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ClientsPage,
});

function ClientsPage() {
  const { t, lang } = useI18n();
  const queryClient = useQueryClient();
  const fetchClients = useServerFn(listClients);
  const clients = useQuery({ queryKey: ["clients"], queryFn: () => fetchClients({}) });

  const [mode, setMode] = useState<
    { kind: "list" } | { kind: "form"; client: ClientRecord | null }
  >({
    kind: "list",
  });

  const done = async () => {
    await queryClient.invalidateQueries({ queryKey: ["clients"] });
    setMode({ kind: "list" });
  };

  return (
    <main className="min-h-screen pb-24 pt-28 md:pt-36">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <span className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.25em] text-gold-dark">
              <Building2 className="h-3.5 w-3.5" /> {t(tx("Client Master Data", "بيانات العملاء"))}
            </span>
            <h1 className="mt-2 font-display text-3xl font-bold text-foreground md:text-4xl">
              {t(tx("Clients", "العملاء"))}
            </h1>
          </div>
          {mode.kind === "list" && (
            <Button
              onClick={() => setMode({ kind: "form", client: null })}
              className="bg-gradient-gold font-semibold text-primary-foreground hover:shadow-gold"
            >
              <Plus className="h-4 w-4" />
              {t(tx("Create New Client", "تعريف عميل جديد"))}
            </Button>
          )}
        </div>
        <div className="gold-divider mt-6 w-24" />

        {mode.kind === "form" ? (
          <Card className="mt-8 bg-gradient-card ring-inset-gold">
            <CardHeader>
              <CardTitle className="font-display text-xl">
                {mode.client
                  ? t(tx("Edit Client", "تعديل العميل"))
                  : t(tx("Create New Client", "تعريف عميل جديد"))}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ClientForm
                initial={mode.client}
                onSaved={() => void done()}
                onCancel={() => setMode({ kind: "list" })}
                onSelectExisting={(c) => setMode({ kind: "form", client: c })}
              />
            </CardContent>
          </Card>
        ) : clients.isLoading ? (
          <div className="mt-10 flex justify-center">
            <Loader2 className="h-6 w-6 animate-spin text-gold-dark" />
          </div>
        ) : (clients.data ?? []).length === 0 ? (
          <p className="mt-10 text-muted-foreground">
            {t(
              tx("No clients yet. Create your first client.", "لا يوجد عملاء بعد. أنشئ أول عميل."),
            )}
          </p>
        ) : (
          <div className="mt-8 grid gap-4 md:grid-cols-2">
            {(clients.data ?? []).map((c) => (
              <Card key={c.id} className="bg-gradient-card ring-inset-gold">
                <CardHeader className="flex flex-row items-start justify-between gap-3">
                  <div>
                    <CardTitle className="font-display text-lg">{c.name}</CardTitle>
                    <p className="mt-1 text-xs text-muted-foreground">
                      {c.client_code || t(tx("No client code", "بدون كود"))}
                    </p>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    className="border-primary/60 text-gold-dark"
                    onClick={() => setMode({ kind: "form", client: c })}
                  >
                    <Pencil className="h-4 w-4" />
                    {t(tx("Edit", "تعديل"))}
                  </Button>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                  <Row label={t(tx("Nature of Business", "طبيعة النشاط"))}>
                    {c.nature_of_business === "other"
                      ? c.nature_of_business_other || "—"
                      : natureOfBusinessLabel(c.nature_of_business)[lang]}
                  </Row>
                  <Row label={t(tx("Company Nationality", "جنسية الشركة"))}>
                    {countryLabel(c.nationality_code)[lang]}
                  </Row>
                  <Row label={t(tx("Legal / Investment Structure", "نوع الاستثمار"))}>
                    {legalStructureLabel(c.legal_structure)[lang]}
                  </Row>
                  <Row label={t(tx("Headquarters Location", "موقع المقر الرئيسي"))}>
                    {[c.hq_city, countryLabel(c.hq_country_code)[lang]].filter(Boolean).join(", ")}
                  </Row>
                  <Row label={t(tx("Number of Branches", "عدد الفروع"))}>
                    <Badge variant="outline" className="border-primary/50 text-gold-dark">
                      {branchesLabel(c.branches_count)[lang]}
                    </Badge>
                  </Row>
                  <Row label={t(tx("Official Email", "البريد الإلكتروني الرسمي"))}>
                    <span className="inline-flex items-center gap-1">
                      <Mail className="h-3.5 w-3.5 text-gold-dark" />
                      {c.official_email}
                    </span>
                  </Row>
                  {c.website && (
                    <Row label={t(tx("Website", "الموقع الإلكتروني"))}>
                      <a
                        href={c.website}
                        target="_blank"
                        rel="noreferrer noopener"
                        className="inline-flex items-center gap-1 text-gold-dark underline"
                      >
                        <Globe2 className="h-3.5 w-3.5" />
                        {c.website}
                      </a>
                    </Row>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </main>
  );
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className="text-muted-foreground">{label}</span>
      <span className="truncate font-medium">{children}</span>
    </div>
  );
}
