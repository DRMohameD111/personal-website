import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useCallback, useEffect, useMemo, useState } from "react";
import {
  Loader2,
  Pencil,
  Pause,
  Play,
  Trash2,
  Plus,
  MapPin,
  Briefcase,
  CalendarPlus,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import { useI18n, tx } from "@/i18n";
import {
  listMyPostings,
  updateJobPosting,
  setJobPostingStatus,
  deleteJobPosting,
} from "@/lib/postings.functions";
import { requireCompanyAccount } from "@/lib/account-type";
import {
  formatJobDate,
  JOB_ADDED_DATE,
  postingToJob,
  employmentTypeLabel,
  type EmploymentTypeValue,
} from "@/lib/jobs";
import { EmploymentTypeSelect } from "@/components/EmploymentTypeSelect";
import { useJobInsights } from "@/lib/use-job-insights";
import { JobValuationBadge } from "@/components/JobValuationBadge";
import { BilingualField } from "@/components/BilingualField";
import {
  APPLICANTS_LABEL,
  DAYS_REMAINING,
  JOB_CLOSING_DATE,
  JOB_STATE_TONE,
  jobStateLabel,
} from "@/lib/valuation";

export const Route = createFileRoute("/_authenticated/my-jobs")({
  beforeLoad: async () => {
    await requireCompanyAccount();
  },
  head: () => ({ meta: [{ title: "My Jobs — SPHINX Workforce" }] }),
  component: MyJobsPage,
});

type Posting = Awaited<ReturnType<typeof listMyPostings>>[number];
type PostingData = {
  title_en?: string;
  title_ar?: string;
  country_en?: string;
  country_ar?: string;
  city_en?: string;
  city_ar?: string;
  employment_type?: EmploymentTypeValue;
  type_en?: string;
  type_ar?: string;
  salary_en?: string;
  salary_ar?: string;
  summary_en?: string;
  summary_ar?: string;
  skills?: string[];
  posted_at?: string;
};

function MyJobsPage() {
  const { t, lang } = useI18n();
  const isAr = lang === "ar";
  const loadFn = useServerFn(listMyPostings);
  const updateFn = useServerFn(updateJobPosting);
  const statusFn = useServerFn(setJobPostingStatus);
  const deleteFn = useServerFn(deleteJobPosting);

  const [items, setItems] = useState<Posting[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<Posting | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<Posting | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  // Applicant counts, live status and the automatic Job Valuation (shared).
  const jobs = useMemo(() => items.map((p) => postingToJob(p)), [items]);
  const { insights } = useJobInsights(jobs);

  const refresh = useCallback(() => {
    setLoading(true);
    loadFn()
      .then((d) => setItems(d))
      .catch((e) => toast.error(String(e?.message || e)))
      .finally(() => setLoading(false));
  }, [loadFn]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const onToggle = async (p: Posting) => {
    const next = p.status === "published" ? "paused" : "published";
    setBusy(p.id);
    try {
      await statusFn({ data: { id: p.id, status: next } });
      toast.success(t(tx("Status updated", "تم تحديث الحالة")));
      refresh();
    } catch (e) {
      toast.error(String((e as Error)?.message || e));
    } finally {
      setBusy(null);
    }
  };

  const onDelete = async () => {
    if (!confirmDelete) return;
    setBusy(confirmDelete.id);
    try {
      await deleteFn({ data: { id: confirmDelete.id } });
      toast.success(t(tx("Job deleted", "تم حذف الوظيفة")));
      setConfirmDelete(null);
      refresh();
    } catch (e) {
      toast.error(String((e as Error)?.message || e));
    } finally {
      setBusy(null);
    }
  };

  return (
    <main className="min-h-screen pt-28 pb-16" dir={isAr ? "rtl" : "ltr"}>
      <section className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="font-display text-3xl font-bold text-foreground md:text-4xl">
              {t(tx("My Jobs", "وظائفي"))}
            </h1>
            <p className="mt-2 text-sm text-muted-foreground">
              {t(
                tx(
                  "Manage the jobs you posted: edit details, pause or delete listings.",
                  "أدر الوظائف التي نشرتها: تعديل التفاصيل، إيقاف مؤقت أو حذف الإعلانات.",
                ),
              )}
            </p>
          </div>
          <Link to="/post-job">
            <Button className="bg-gradient-gold text-primary-foreground font-semibold">
              <Plus className="h-4 w-4" />
              {t(tx("Post a Job", "نشر وظيفة"))}
            </Button>
          </Link>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-24 text-muted-foreground">
            <Loader2 className="h-5 w-5 animate-spin" />
          </div>
        ) : items.length === 0 ? (
          <div className="rounded-lg border border-dashed border-border bg-card/30 p-12 text-center">
            <Briefcase className="mx-auto h-10 w-10 text-muted-foreground" />
            <p className="mt-4 text-foreground font-medium">
              {t(tx("You haven't posted any jobs yet.", "لم تنشر أي وظائف بعد."))}
            </p>
            <Link to="/post-job" className="mt-4 inline-block">
              <Button variant="outline">{t(tx("Post your first job", "انشر أول وظيفة"))}</Button>
            </Link>
          </div>
        ) : (
          <div className="grid gap-4">
            {items.map((p) => {
              const d = (p.data ?? {}) as PostingData;
              const title = isAr ? d.title_ar || d.title_en : d.title_en || d.title_ar;
              const city = isAr ? d.city_ar || d.city_en : d.city_en || d.city_ar;
              const country = isAr ? d.country_ar || d.country_en : d.country_en || d.country_ar;
              const type = t(employmentTypeLabel(d.employment_type, d.type_en, d.type_ar));
              const salary = isAr ? d.salary_ar || d.salary_en : d.salary_en || d.salary_ar;
              return (
                <article
                  key={p.id}
                  className="rounded-xl border border-border bg-card p-5 shadow-sm transition hover:shadow-elegant"
                >
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <h2 className="font-display text-lg font-semibold text-foreground">
                          {title || t(tx("Untitled", "بدون عنوان"))}
                        </h2>
                        {insights[p.id] && (
                          <>
                            <Badge
                              variant="outline"
                              className={JOB_STATE_TONE[insights[p.id]!.state]}
                            >
                              {t(jobStateLabel(insights[p.id]!.state))}
                            </Badge>
                            <JobValuationBadge grade={insights[p.id]!.valuation.grade} withInfo />
                          </>
                        )}
                      </div>
                      <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-muted-foreground">
                        {(city || country) && (
                          <span className="inline-flex items-center gap-1">
                            <MapPin className="h-3.5 w-3.5" />
                            {[city, country].filter(Boolean).join(isAr ? "، " : ", ")}
                          </span>
                        )}
                        {type && <span>{type}</span>}
                        {salary && <span className="text-gold-dark">{salary}</span>}
                        <span className="inline-flex items-center gap-1">
                          <CalendarPlus className="h-3.5 w-3.5" />
                          {t(JOB_ADDED_DATE)}: {formatJobDate(d.posted_at || p.created_at, lang)}
                        </span>
                        {insights[p.id]?.closesAt && (
                          <span>
                            {t(JOB_CLOSING_DATE)}: {formatJobDate(insights[p.id]!.closesAt!, lang)}
                          </span>
                        )}
                        {insights[p.id]?.daysRemaining != null && insights[p.id]!.canApply && (
                          <span>
                            {t(DAYS_REMAINING)}: {insights[p.id]!.daysRemaining}
                          </span>
                        )}
                        <span className="font-semibold text-foreground">
                          {t(APPLICANTS_LABEL)}: {insights[p.id]?.applicantCount ?? 0}
                        </span>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setEditing(p)}
                        disabled={busy === p.id}
                      >
                        <Pencil className="h-3.5 w-3.5" />
                        {t(tx("Edit", "تعديل"))}
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => onToggle(p)}
                        disabled={busy === p.id || p.status === "closed"}
                      >
                        {p.status === "published" ? (
                          <>
                            <Pause className="h-3.5 w-3.5" />
                            {t(tx("Pause", "إيقاف"))}
                          </>
                        ) : (
                          <>
                            <Play className="h-3.5 w-3.5" />
                            {t(tx("Resume", "استئناف"))}
                          </>
                        )}
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="text-destructive hover:text-destructive"
                        onClick={() => setConfirmDelete(p)}
                        disabled={busy === p.id}
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                        {t(tx("Delete", "حذف"))}
                      </Button>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </section>

      <EditDialog
        posting={editing}
        onClose={() => setEditing(null)}
        onSave={async (id, patch) => {
          try {
            await updateFn({ data: { id, patch } });
            toast.success(t(tx("Job updated", "تم تحديث الوظيفة")));
            setEditing(null);
            refresh();
          } catch (e) {
            toast.error(String((e as Error)?.message || e));
          }
        }}
      />

      <AlertDialog open={!!confirmDelete} onOpenChange={(o) => !o && setConfirmDelete(null)}>
        <AlertDialogContent dir={isAr ? "rtl" : "ltr"}>
          <AlertDialogHeader>
            <AlertDialogTitle>{t(tx("Delete this job?", "حذف هذه الوظيفة؟"))}</AlertDialogTitle>
            <AlertDialogDescription>
              {t(
                tx(
                  "This will permanently remove the listing. This action cannot be undone.",
                  "سيتم حذف الإعلان نهائياً. لا يمكن التراجع عن هذا الإجراء.",
                ),
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t(tx("Cancel", "إلغاء"))}</AlertDialogCancel>
            <AlertDialogAction
              onClick={onDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {t(tx("Delete", "حذف"))}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </main>
  );
}

function EditDialog({
  posting,
  onClose,
  onSave,
}: {
  posting: Posting | null;
  onClose: () => void;
  onSave: (id: string, patch: PostingData) => Promise<void>;
}) {
  const { t, lang } = useI18n();
  const isAr = lang === "ar";
  const [form, setForm] = useState<PostingData>({});
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (posting) setForm({ ...(posting.data as PostingData) });
  }, [posting]);

  const set = <K extends keyof PostingData>(k: K, v: PostingData[K]) =>
    setForm((f) => ({ ...f, [k]: v }));

  if (!posting) return null;

  return (
    <Dialog open={!!posting} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto" dir={isAr ? "rtl" : "ltr"}>
        <DialogHeader>
          <DialogTitle>{t(tx("Edit Job", "تعديل الوظيفة"))}</DialogTitle>
          <DialogDescription>
            {t(tx("Update the bilingual job details.", "حدّث تفاصيل الوظيفة بلغتيها."))}
          </DialogDescription>
        </DialogHeader>

        <BilingualField
          labelEn={t(tx("Title (English)", "العنوان (إنجليزي)"))}
          labelAr={t(tx("Title (Arabic)", "العنوان (عربي)"))}
          valueEn={form.title_en || ""}
          valueAr={form.title_ar || ""}
          onChange={(p) =>
            setForm((f) => ({
              ...f,
              ...(p.en !== undefined ? { title_en: p.en } : {}),
              ...(p.ar !== undefined ? { title_ar: p.ar } : {}),
            }))
          }
        />

        <BilingualField
          labelEn={t(tx("Summary (English)", "الملخص (إنجليزي)"))}
          labelAr={t(tx("Summary (Arabic)", "الملخص (عربي)"))}
          valueEn={form.summary_en || ""}
          valueAr={form.summary_ar || ""}
          multiline
          rows={3}
          onChange={(p) =>
            setForm((f) => ({
              ...f,
              ...(p.en !== undefined ? { summary_en: p.en } : {}),
              ...(p.ar !== undefined ? { summary_ar: p.ar } : {}),
            }))
          }
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Field label={t(tx("Country (English)", "الدولة (إنجليزي)"))}>
            <Input
              value={form.country_en || ""}
              onChange={(e) => set("country_en", e.target.value)}
            />
          </Field>
          <Field label={t(tx("Country (Arabic)", "الدولة (عربي)"))}>
            <Input
              value={form.country_ar || ""}
              onChange={(e) => set("country_ar", e.target.value)}
              dir="rtl"
            />
          </Field>

          <Field label={t(tx("City (English)", "المدينة (إنجليزي)"))}>
            <Input value={form.city_en || ""} onChange={(e) => set("city_en", e.target.value)} />
          </Field>
          <Field label={t(tx("City (Arabic)", "المدينة (عربي)"))}>
            <Input
              value={form.city_ar || ""}
              onChange={(e) => set("city_ar", e.target.value)}
              dir="rtl"
            />
          </Field>

          <Field label={t(tx("Employment Type", "نوع التوظيف"))}>
            <EmploymentTypeSelect
              value={form.employment_type}
              typeEn={form.type_en}
              typeAr={form.type_ar}
              onChange={(p) => setForm((f) => ({ ...f, ...p }))}
            />
          </Field>

          <Field label={t(tx("Salary (English)", "الراتب (إنجليزي)"))}>
            <Input
              value={form.salary_en || ""}
              onChange={(e) => set("salary_en", e.target.value)}
            />
          </Field>
          <Field label={t(tx("Salary (Arabic)", "الراتب (عربي)"))}>
            <Input
              value={form.salary_ar || ""}
              onChange={(e) => set("salary_ar", e.target.value)}
              dir="rtl"
            />
          </Field>

          <Field
            label={t(tx("Skills (comma separated)", "المهارات (مفصولة بفواصل)"))}
            className="md:col-span-2"
          >
            <Input
              value={(form.skills || []).join(", ")}
              onChange={(e) =>
                set(
                  "skills",
                  e.target.value
                    .split(",")
                    .map((s) => s.trim())
                    .filter(Boolean),
                )
              }
            />
          </Field>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={saving}>
            {t(tx("Cancel", "إلغاء"))}
          </Button>
          <Button
            onClick={async () => {
              setSaving(true);
              try {
                await onSave(posting.id, form);
              } finally {
                setSaving(false);
              }
            }}
            disabled={saving}
            className="bg-gradient-gold text-primary-foreground font-semibold"
          >
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
            {t(tx("Save changes", "حفظ التغييرات"))}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function Field({
  label,
  children,
  className,
}: {
  label: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={className}>
      <label className="mb-1.5 block text-xs font-medium text-foreground/80">{label}</label>
      {children}
    </div>
  );
}
