import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState, type FormEvent } from "react";
import {
  Loader2,
  Building2,
  Pencil,
  Users,
  Plus,
  Briefcase,
  LayoutGrid,
  BadgeCheck,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useI18n, tx } from "@/i18n";
import { getMyAccount, listMyJobsWithApplicants } from "@/lib/account.functions";
import { updateCandidateProfile } from "@/lib/applications.functions";
import { requireCompanyAccount } from "@/lib/account-type";
import { jobStatusLabel } from "@/lib/status-labels";
import { COUNTRIES } from "@/lib/countries";
import { useStateDraft } from "@/lib/form-draft";

export const Route = createFileRoute("/_authenticated/company")({
  beforeLoad: async () => {
    await requireCompanyAccount();
  },
  head: () => ({
    meta: [
      { title: "Company Account — SPHINX Workforce" },
      {
        name: "description",
        content:
          "Manage your company profile, review your posted vacancies and see how many candidates applied to each job.",
      },
      { property: "og:title", content: "Company Account — SPHINX Workforce" },
      { property: "og:description", content: "Company profile, posted jobs and applicant counts." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: CompanyAccountPage,
});

function CompanyAccountPage() {
  const { t, lang } = useI18n();
  const isAr = lang === "ar";
  const queryClient = useQueryClient();
  const fetchAccount = useServerFn(getMyAccount);
  const fetchJobs = useServerFn(listMyJobsWithApplicants);
  const saveProfile = useServerFn(updateCandidateProfile);

  const account = useQuery({ queryKey: ["my-account"], queryFn: () => fetchAccount({}) });
  const jobs = useQuery({ queryKey: ["company-jobs"], queryFn: () => fetchJobs({}) });

  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const p = account.data?.profile;

  const [form, setForm] = useState({ company_name: "", full_name: "", phone: "", country: "" });
  const [dirty, setDirty] = useState(false);
  useEffect(() => {
    // Pre-fill from the saved record, but never overwrite unsaved edits.
    if (p && !dirty)
      setForm({
        company_name: p.company_name ?? "",
        full_name: p.full_name ?? "",
        phone: p.phone ?? "",
        country: p.country ?? "",
      });
  }, [p, dirty]);

  // Reuse the shared draft autosave: unsaved edits survive errors, refresh and return.
  const { clearDraft } = useStateDraft(
    "company-profile",
    form,
    (d) => {
      setForm((f) => ({ ...f, ...d }));
      setDirty(true);
      setEditing(true);
    },
    lang,
    { dirty },
  );

  const update = (patch: Partial<typeof form>) => {
    setDirty(true);
    setForm((f) => ({ ...f, ...patch }));
  };

  const fmt = (d: string | null | undefined) =>
    d
      ? new Date(d).toLocaleDateString(isAr ? "ar-EG" : "en-GB", {
          year: "numeric",
          month: "short",
          day: "numeric",
        })
      : "—";

  async function onSave(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setSaving(true);
    try {
      await saveProfile({ data: form });
      clearDraft();
      setDirty(false);
      await queryClient.invalidateQueries({ queryKey: ["my-account"] });
      setEditing(false);
      toast.success(
        t(tx("Your profile has been updated successfully.", "تم تحديث الملف الشخصي بنجاح.")),
      );
    } catch {
      toast.error(
        t(
          tx(
            "The operation could not be completed. Please review your information and try again.",
            "تعذر إتمام العملية. يرجى مراجعة البيانات والمحاولة مرة أخرى.",
          ),
        ),
      );
    } finally {
      setSaving(false);
    }
  }

  return (
    <main className="min-h-screen bg-background pt-28 pb-20" dir={isAr ? "rtl" : "ltr"}>
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="font-display text-3xl font-semibold text-heading sm:text-4xl">
              {t(tx("Company Account", "حساب الشركة"))}
            </h1>
            <p className="mt-2 text-sm text-muted-foreground">
              {t(tx("Company – Job Poster", "شركة – عارض وظائف"))}
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Link to="/post-job">
              <Button className="bg-gradient-gold font-semibold text-primary-foreground hover:shadow-gold">
                <Plus className="h-4 w-4" />
                {t(tx("Post a Job", "إضافة وظيفة"))}
              </Button>
            </Link>
            <Link to="/applicants">
              <Button variant="outline" className="border-primary/60 text-gold-dark">
                <Users className="h-4 w-4" />
                {t(tx("Applicants", "المتقدمون"))}
              </Button>
            </Link>
          </div>
        </div>

        {/* Dashboard overview — active jobs, applications, verified candidates (reuses company-jobs data) */}
        <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-3">
          {[
            {
              label: tx("Active Job Posts", "الوظائف النشطة"),
              icon: Briefcase,
              value: (jobs.data ?? []).filter((j) => j.status === "published").length,
              to: "/my-jobs" as const,
            },
            {
              label: tx("Applications", "الطلبات"),
              icon: Users,
              value: (jobs.data ?? []).reduce((s, j) => s + j.applicants, 0),
              to: "/applicants" as const,
            },
            {
              label: tx("Verified Candidates", "مرشحون معتمدون"),
              icon: BadgeCheck,
              value: (jobs.data ?? []).reduce((s, j) => s + j.verified, 0),
              to: "/applicants" as const,
            },
          ].map((s) => (
            <Link key={s.label.en} to={s.to}>
              <Card className="h-full border-primary/30 bg-surface-soft shadow-elegant transition hover:shadow-gold">
                <CardContent className="flex items-center gap-4 p-5">
                  <span className="flex h-11 w-11 items-center justify-center rounded-full bg-gradient-gold text-primary-foreground">
                    <s.icon className="h-5 w-5" />
                  </span>
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                      {t(s.label)}
                    </p>
                    <p className="font-display text-2xl font-semibold text-heading">
                      {jobs.isLoading ? "—" : s.value}
                    </p>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>

        {/* Company profile */}
        <Card className="mt-6 border-border/60 shadow-elegant">
          <CardHeader className="flex flex-row items-center justify-between gap-4">
            <CardTitle className="flex items-center gap-2 font-display text-xl">
              <Building2 className="h-5 w-5 text-gold-dark" />
              {t(tx("Company Profile", "ملف الشركة"))}
            </CardTitle>
            {!editing && (
              <Button
                variant="outline"
                size="sm"
                className="border-primary/60 text-gold-dark"
                onClick={() => setEditing(true)}
              >
                <Pencil className="h-4 w-4" />
                {t(tx("Edit Profile", "تعديل الملف"))}
              </Button>
            )}
          </CardHeader>
          <CardContent>
            {account.isLoading ? (
              <Loader2 className="h-5 w-5 animate-spin text-gold-dark" />
            ) : editing ? (
              <form onSubmit={onSave} className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="company_name">{t(tx("Company name", "اسم الشركة"))}</Label>
                  <Input
                    id="company_name"
                    value={form.company_name}
                    onChange={(e) => update({ company_name: e.target.value })}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="full_name">{t(tx("Contact person", "الشخص المسؤول"))}</Label>
                  <Input
                    id="full_name"
                    value={form.full_name}
                    onChange={(e) => update({ full_name: e.target.value })}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="phone">{t(tx("Mobile", "الجوال"))}</Label>
                  <Input
                    id="phone"
                    value={form.phone}
                    onChange={(e) => update({ phone: e.target.value })}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="country">{t(tx("Country", "الدولة"))}</Label>
                  <select
                    id="country"
                    value={form.country}
                    onChange={(e) => update({ country: e.target.value })}
                    className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm"
                  >
                    <option value="">{t(tx("Select country…", "اختر الدولة…"))}</option>
                    {COUNTRIES.map((c) => (
                      <option key={c.en} value={c.en}>
                        {t(c)}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="sm:col-span-2 flex gap-2">
                  <Button
                    type="submit"
                    disabled={saving}
                    className="bg-gradient-gold font-semibold text-primary-foreground"
                  >
                    {saving && <Loader2 className="h-4 w-4 animate-spin" />}
                    {t(tx("Save changes", "حفظ التغييرات"))}
                  </Button>
                  <Button type="button" variant="ghost" onClick={() => setEditing(false)}>
                    {t(tx("Cancel", "إلغاء"))}
                  </Button>
                </div>
              </form>
            ) : (
              <dl className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                {[
                  { label: tx("Company name", "اسم الشركة"), value: p?.company_name },
                  { label: tx("Contact person", "الشخص المسؤول"), value: p?.full_name },
                  {
                    label: tx("Email", "البريد الإلكتروني"),
                    value: p?.email ?? account.data?.email,
                  },
                  { label: tx("Mobile", "الجوال"), value: p?.phone },
                  { label: tx("Country", "الدولة"), value: p?.country },
                ].map((r) => (
                  <div key={r.label.en}>
                    <dt className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                      {t(r.label)}
                    </dt>
                    <dd className="text-sm text-foreground break-words">{r.value || "—"}</dd>
                  </div>
                ))}
              </dl>
            )}
          </CardContent>
        </Card>

        {/* Subscription management lives in the Company Portal (single source) */}
        <Card className="mt-6 border-primary/40 bg-surface-soft shadow-elegant">
          <CardContent className="flex flex-wrap items-center justify-between gap-4 p-6">
            <div>
              <h2 className="font-display text-xl font-semibold text-heading">
                {t(tx("Company Portal", "بوابة الشركة"))}
              </h2>
              <p className="mt-1 text-sm text-muted-foreground">
                {t(
                  tx(
                    "Manage your package, benefits and limits, payments, receipts and upgrades.",
                    "إدارة باقتك ومزاياك وحدودها والمدفوعات والإيصالات والترقيات.",
                  ),
                )}
              </p>
            </div>
            <Link to="/portal">
              <Button className="bg-gradient-gold font-semibold text-primary-foreground hover:shadow-gold">
                <LayoutGrid className="h-4 w-4" />
                {t(tx("Open Company Portal", "فتح بوابة الشركة"))}
              </Button>
            </Link>
          </CardContent>
        </Card>

        {/* Posted jobs */}
        <section className="mt-10">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h2 className="flex items-center gap-2 font-display text-2xl font-semibold text-heading">
              <Briefcase className="h-5 w-5 text-gold-dark" />
              {t(tx("My Posted Jobs", "الوظائف التي تم نشرها"))}
            </h2>
            <Link to="/my-jobs" className="text-sm font-medium text-gold-dark hover:underline">
              {t(tx("Manage jobs", "إدارة الوظائف"))}
            </Link>
          </div>

          <Card className="mt-4 border-border/60 shadow-elegant">
            <CardContent className="p-0">
              {jobs.isLoading ? (
                <div className="p-6">
                  <Loader2 className="h-5 w-5 animate-spin text-gold-dark" />
                </div>
              ) : (jobs.data?.length ?? 0) === 0 ? (
                <div className="p-8 text-center text-sm text-muted-foreground">
                  {t(tx("You have not posted any job yet.", "لم تنشر أي وظيفة حتى الآن."))}
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-surface-soft text-xs uppercase tracking-wider text-muted-foreground">
                      <tr>
                        <th className="px-4 py-3 text-start">
                          {t(tx("Job Title", "المسمى الوظيفي"))}
                        </th>
                        <th className="px-4 py-3 text-start">{t(tx("Job Code", "كود الوظيفة"))}</th>
                        <th className="px-4 py-3 text-start">
                          {t(tx("Publication Date", "تاريخ النشر"))}
                        </th>
                        <th className="px-4 py-3 text-start">{t(tx("Status", "الحالة"))}</th>
                        <th className="px-4 py-3 text-start">{t(tx("Deadline", "آخر موعد"))}</th>
                        <th className="px-4 py-3 text-start">{t(tx("Applicants", "المتقدمون"))}</th>
                        <th className="px-4 py-3 text-start">{t(tx("CVs", "السير الذاتية"))}</th>
                        <th className="px-4 py-3" />
                      </tr>
                    </thead>
                    <tbody>
                      {jobs.data!.map((j) => (
                        <tr key={j.id} className="border-t border-border/60">
                          <td className="px-4 py-3 font-medium text-foreground">
                            {isAr ? j.titleAr : j.titleEn}
                          </td>
                          <td className="px-4 py-3 text-muted-foreground">{j.jobCode}</td>
                          <td className="px-4 py-3 text-muted-foreground">{fmt(j.postedAt)}</td>
                          <td className="px-4 py-3">
                            <Badge variant="outline" className="border-primary/50 text-gold-dark">
                              {t(jobStatusLabel(j.status))}
                            </Badge>
                          </td>
                          <td className="px-4 py-3 text-muted-foreground">
                            {j.deadline ? fmt(j.deadline) : "—"}
                          </td>
                          <td className="px-4 py-3 font-semibold text-foreground">
                            {j.applicants}
                          </td>
                          <td className="px-4 py-3 text-muted-foreground">{j.cvs}</td>
                          <td className="px-4 py-3">
                            <Link to="/applicants" search={{ job: j.id }}>
                              <Button
                                size="sm"
                                variant="outline"
                                className="border-primary/60 text-gold-dark"
                              >
                                <Users className="h-4 w-4" />
                                {t(tx("View Applicants", "عرض المتقدمين"))}
                              </Button>
                            </Link>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </section>
      </div>
    </main>
  );
}
