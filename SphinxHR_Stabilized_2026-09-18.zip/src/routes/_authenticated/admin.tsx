import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Loader2, Plus, Save, ShieldCheck, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { AdminPasswordCard } from "@/components/AdminPasswordCard";
import { AdminDataAccess } from "@/components/AdminDataAccess";
import { AdminApplicationsQueue } from "@/components/AdminApplicationsQueue";
import { AdminTeamCard } from "@/components/AdminTeamCard";
import { DirectAdsQueue } from "@/components/DirectAdsQueue";
import { ExternalCvImport } from "@/components/ExternalCvImport";

import { PackageManager } from "@/components/PackageManager";
import { SubscriptionPolicyCard } from "@/components/SubscriptionPolicyCard";
import { useI18n, tx } from "@/i18n";

import { requireAdminAccount } from "@/lib/account-type";
import {
  DEFAULT_VALUATION_CONFIG,
  JOB_VALUATION_TITLE,
  deleteSalaryBenchmark,
  fetchSalaryBenchmarks,
  fetchValuationConfig,
  saveSalaryBenchmark,
  saveValuationConfig,
  validateValuationConfig,
  type SalaryBenchmark,
  type ValuationConfigInput,
} from "@/lib/valuation";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    meta: [
      { title: "Control Panel — SPHINX Workforce" },
      {
        name: "description",
        content:
          "Administrator control panel to configure salary benchmarks, salary and company weights, and the Excellent / Very Good / Good valuation thresholds.",
      },
      { property: "og:title", content: "Control Panel — SPHINX Workforce" },
      {
        property: "og:description",
        content: "Configure the automatic job valuation: benchmarks, weights and grade thresholds.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  beforeLoad: async () => {
    await requireAdminAccount();
  },
  component: AdminPanel,
});

const EMPTY_BENCHMARK: SalaryBenchmark = {
  id: "",
  job_category: "",
  sector: null,
  career_level: null,
  country: null,
  currency: "SAR",
  benchmark_amount: 0,
  salary_period: "monthly",
};

function AdminPanel() {
  const { t } = useI18n();
  const queryClient = useQueryClient();

  const configQuery = useQuery({ queryKey: ["valuation-config"], queryFn: fetchValuationConfig });
  const benchmarksQuery = useQuery({
    queryKey: ["salary-benchmarks"],
    queryFn: fetchSalaryBenchmarks,
  });

  const [form, setForm] = useState<ValuationConfigInput>(DEFAULT_VALUATION_CONFIG);
  useEffect(() => {
    if (configQuery.data) setForm(configQuery.data);
  }, [configQuery.data]);

  const [draft, setDraft] = useState<SalaryBenchmark | null>(null);

  const invalidate = async () => {
    await queryClient.invalidateQueries({ queryKey: ["valuation-config"] });
    await queryClient.invalidateQueries({ queryKey: ["salary-benchmarks"] });
  };

  const saveConfig = useMutation({
    mutationFn: async () => {
      const problem = validateValuationConfig(form);
      if (problem) throw new Error(t(problem));
      await saveValuationConfig(form);
    },
    onSuccess: async () => {
      await invalidate();
      toast.success(t(tx("Valuation settings saved.", "تم حفظ إعدادات التقييم.")));
    },
    onError: (e: Error) =>
      toast.error(e.message || t(tx("Could not save the settings.", "تعذر حفظ الإعدادات."))),
  });

  const saveBenchmark = useMutation({
    mutationFn: async (b: SalaryBenchmark) => {
      if (!b.job_category.trim())
        throw new Error(t(tx("Job category is required.", "التصنيف الوظيفي مطلوب.")));
      if (!(b.benchmark_amount > 0))
        throw new Error(
          t(
            tx(
              "Benchmark amount must be greater than zero.",
              "يجب أن يكون الراتب المرجعي أكبر من صفر.",
            ),
          ),
        );
      await saveSalaryBenchmark({ ...b, id: b.id || undefined });
    },
    onSuccess: async () => {
      await invalidate();
      setDraft(null);
      toast.success(t(tx("Salary benchmark saved.", "تم حفظ الراتب المرجعي.")));
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const removeBenchmark = useMutation({
    mutationFn: deleteSalaryBenchmark,
    onSuccess: async () => {
      await invalidate();
      toast.success(t(tx("Salary benchmark removed.", "تم حذف الراتب المرجعي.")));
    },
    onError: () =>
      toast.error(t(tx("Could not remove the benchmark.", "تعذر حذف الراتب المرجعي."))),
  });

  const num = (v: string) => (v === "" ? 0 : Number(v));

  return (
    <main className="min-h-screen pb-24 pt-28 md:pt-36">
      <div className="mx-auto max-w-5xl space-y-8 px-4 sm:px-6 lg:px-8">
        <header>
          <span className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.25em] text-gold-dark">
            <ShieldCheck className="h-3.5 w-3.5" /> {t(tx("Control Panel", "لوحة التحكم"))}
          </span>
          <h1 className="mt-2 font-display text-3xl text-heading md:text-4xl">
            {t(JOB_VALUATION_TITLE)} — {t(tx("Settings", "الإعدادات"))}
          </h1>
          <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
            {t(
              tx(
                "Configure the default salary benchmark, the salary and company weights, and the thresholds for Excellent, Very Good and Good. Changes apply to every job listing immediately.",
                "اضبط متوسط الراتب المرجعي الافتراضي، ووزن الراتب ووزن الشركة، وحدود «ممتاز» و«جيد جداً» و«جيد». تنطبق التغييرات على جميع الوظائف فوراً.",
              ),
            )}
          </p>
        </header>

        {/* Weights + thresholds ------------------------------------------ */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">
              {t(tx("Weights & Thresholds", "الأوزان والحدود"))}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {configQuery.isLoading ? (
              <Loader2 className="h-5 w-5 animate-spin text-gold-dark" />
            ) : (
              <>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="salary-weight">
                      {t(tx("Salary weight (%)", "وزن الراتب (%)"))}
                    </Label>
                    <Input
                      id="salary-weight"
                      type="number"
                      min={0}
                      max={100}
                      value={Math.round(form.salary_weight * 100)}
                      onChange={(e) => {
                        const pct = Math.min(100, Math.max(0, num(e.target.value)));
                        setForm((f) => ({
                          ...f,
                          salary_weight: pct / 100,
                          company_weight: (100 - pct) / 100,
                        }));
                      }}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="company-weight">
                      {t(tx("Company weight (%)", "وزن الشركة (%)"))}
                    </Label>
                    <Input
                      id="company-weight"
                      type="number"
                      min={0}
                      max={100}
                      value={Math.round(form.company_weight * 100)}
                      onChange={(e) => {
                        const pct = Math.min(100, Math.max(0, num(e.target.value)));
                        setForm((f) => ({
                          ...f,
                          company_weight: pct / 100,
                          salary_weight: (100 - pct) / 100,
                        }));
                      }}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="excellent">{t(tx("Excellent threshold", "حد «ممتاز»"))}</Label>
                    <Input
                      id="excellent"
                      type="number"
                      min={0}
                      max={100}
                      value={form.excellent_threshold}
                      onChange={(e) =>
                        setForm((f) => ({ ...f, excellent_threshold: num(e.target.value) }))
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="very-good">
                      {t(tx("Very Good threshold", "حد «جيد جداً»"))}
                    </Label>
                    <Input
                      id="very-good"
                      type="number"
                      min={0}
                      max={100}
                      value={form.very_good_threshold}
                      onChange={(e) =>
                        setForm((f) => ({ ...f, very_good_threshold: num(e.target.value) }))
                      }
                    />
                  </div>
                  <div className="space-y-2 sm:col-span-2">
                    <Label htmlFor="default-benchmark">
                      {t(tx("Default salary benchmark", "متوسط الراتب المرجعي الافتراضي"))}
                    </Label>
                    <Input
                      id="default-benchmark"
                      type="number"
                      min={0}
                      value={form.default_benchmark_amount}
                      onChange={(e) =>
                        setForm((f) => ({ ...f, default_benchmark_amount: num(e.target.value) }))
                      }
                    />
                    <p className="text-xs text-muted-foreground">
                      {t(
                        tx(
                          "Used when no specific benchmark matches the job.",
                          "يُستخدم عند عدم وجود راتب مرجعي مطابق للوظيفة.",
                        ),
                      )}
                    </p>
                  </div>
                </div>

                <div className="space-y-3 rounded-lg border border-border/70 p-4">
                  <div className="flex items-center justify-between gap-4">
                    <Label htmlFor="show-applicants" className="font-normal">
                      {t(tx("Show applicant count publicly", "إظهار عدد المتقدمين للعامة"))}
                    </Label>
                    <Switch
                      id="show-applicants"
                      checked={form.show_applicant_count_public}
                      onCheckedChange={(v) =>
                        setForm((f) => ({ ...f, show_applicant_count_public: v }))
                      }
                    />
                  </div>
                  <div className="flex items-center justify-between gap-4">
                    <Label htmlFor="show-portal" className="font-normal">
                      {t(tx("Show company evaluation publicly", "إظهار تقييم الشركة للعامة"))}
                    </Label>
                    <Switch
                      id="show-portal"
                      checked={form.show_portal_valuation_public}
                      onCheckedChange={(v) =>
                        setForm((f) => ({ ...f, show_portal_valuation_public: v }))
                      }
                    />
                  </div>
                </div>

                <Button
                  onClick={() => saveConfig.mutate()}
                  disabled={saveConfig.isPending}
                  aria-busy={saveConfig.isPending}
                >
                  {saveConfig.isPending ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Save className="h-4 w-4" />
                  )}
                  {t(tx("Save settings", "حفظ الإعدادات"))}
                </Button>
              </>
            )}
          </CardContent>
        </Card>

        {/* Salary benchmarks --------------------------------------------- */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-4">
            <CardTitle className="text-lg">
              {t(tx("Salary Benchmarks", "الرواتب المرجعية"))}
            </CardTitle>
            <Button variant="outline" size="sm" onClick={() => setDraft({ ...EMPTY_BENCHMARK })}>
              <Plus className="h-4 w-4" /> {t(tx("Add benchmark", "إضافة راتب مرجعي"))}
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            {draft && (
              <div className="grid gap-3 rounded-lg border border-primary/40 bg-primary/5 p-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="bm-category">{t(tx("Job category", "التصنيف الوظيفي"))}</Label>
                  <Input
                    id="bm-category"
                    value={draft.job_category}
                    onChange={(e) => setDraft({ ...draft, job_category: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="bm-sector">
                    {t(tx("Sector (optional)", "القطاع (اختياري)"))}
                  </Label>
                  <Input
                    id="bm-sector"
                    value={draft.sector ?? ""}
                    onChange={(e) => setDraft({ ...draft, sector: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="bm-level">
                    {t(tx("Career level (optional)", "المستوى الوظيفي (اختياري)"))}
                  </Label>
                  <Input
                    id="bm-level"
                    value={draft.career_level ?? ""}
                    onChange={(e) => setDraft({ ...draft, career_level: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="bm-country">
                    {t(tx("Country (optional)", "الدولة (اختياري)"))}
                  </Label>
                  <Input
                    id="bm-country"
                    value={draft.country ?? ""}
                    onChange={(e) => setDraft({ ...draft, country: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="bm-amount">{t(tx("Benchmark amount", "الراتب المرجعي"))}</Label>
                  <Input
                    id="bm-amount"
                    type="number"
                    min={0}
                    value={draft.benchmark_amount}
                    onChange={(e) => setDraft({ ...draft, benchmark_amount: num(e.target.value) })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="bm-currency">{t(tx("Currency", "العملة"))}</Label>
                  <Input
                    id="bm-currency"
                    value={draft.currency}
                    onChange={(e) => setDraft({ ...draft, currency: e.target.value })}
                  />
                </div>
                <div className="flex gap-2 sm:col-span-2">
                  <Button
                    onClick={() => saveBenchmark.mutate(draft)}
                    disabled={saveBenchmark.isPending}
                    aria-busy={saveBenchmark.isPending}
                  >
                    {saveBenchmark.isPending ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Save className="h-4 w-4" />
                    )}
                    {t(tx("Save benchmark", "حفظ الراتب المرجعي"))}
                  </Button>
                  <Button variant="ghost" onClick={() => setDraft(null)}>
                    {t(tx("Cancel", "إلغاء"))}
                  </Button>
                </div>
              </div>
            )}

            {benchmarksQuery.isLoading ? (
              <Loader2 className="h-5 w-5 animate-spin text-gold-dark" />
            ) : (benchmarksQuery.data ?? []).length === 0 ? (
              <p className="text-sm text-muted-foreground">
                {t(
                  tx(
                    "No benchmarks yet — the default amount above is used for every job.",
                    "لا توجد رواتب مرجعية بعد — يتم استخدام المتوسط الافتراضي أعلاه لجميع الوظائف.",
                  ),
                )}
              </p>
            ) : (
              <ul className="divide-y divide-border/70">
                {(benchmarksQuery.data ?? []).map((b) => (
                  <li key={b.id} className="flex flex-wrap items-center justify-between gap-3 py-3">
                    <div>
                      <p className="font-medium text-heading">{b.job_category}</p>
                      <p className="text-xs text-muted-foreground">
                        {[b.sector, b.career_level, b.country].filter(Boolean).join(" · ") || "—"}
                      </p>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-sm font-semibold text-gold-dark">
                        {b.currency} {b.benchmark_amount.toLocaleString()}
                      </span>
                      <Button variant="ghost" size="sm" onClick={() => setDraft(b)}>
                        {t(tx("Edit", "تعديل"))}
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        aria-label={t(tx("Remove", "حذف"))}
                        onClick={() => removeBenchmark.mutate(b.id)}
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>

        {/* Administrators, permissions and activity log (main admin only) */}
        <AdminTeamCard />

        {/* Authorised company / job seeker data access */}
        <AdminDataAccess kind="company" />
        <AdminDataAccess kind="job_seeker" />

        {/* Platform-wide job application review */}
        <AdminApplicationsQueue />

        {/* External CV import */}
        <ExternalCvImport />

        {/* Direct Vacancy Ads approval queue */}
        <DirectAdsQueue />

        {/* Package management */}
        <PackageManager />

        {/* Subscription policy, package ranking and verified payment activation */}
        <SubscriptionPolicyCard />

        {/* Admin credentials */}
        <AdminPasswordCard />
      </div>
    </main>
  );
}
