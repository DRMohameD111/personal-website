import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Loader2, Link2, FileText } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useI18n, tx } from "@/i18n";
import {
  listMyJobsWithApplicants,
  listEmployerApplications,
  linkApplicationToJob,
  getApplicantCvUrl,
} from "@/lib/account.functions";
import { requireCompanyAccount } from "@/lib/account-type";
import { APPLICATION_STATUS_LABELS, applicationStatusLabel } from "@/lib/status-labels";
import { openSignedFile } from "@/lib/open-file";

const STATUSES = Object.keys(APPLICATION_STATUS_LABELS);

export const Route = createFileRoute("/_authenticated/match")({
  beforeLoad: async () => {
    await requireCompanyAccount();
  },
  head: () => ({
    meta: [
      { title: "Link Job to Application — SPHINX Workforce" },
      {
        name: "description",
        content:
          "Match a vacancy from your job list with a received application and set the application status in one place.",
      },
      { property: "og:title", content: "Link Job to Application — SPHINX Workforce" },
      {
        property: "og:description",
        content: "Connect your vacancies with incoming applications and update their status.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: MatchPage,
});

function MatchPage() {
  const { t, lang } = useI18n();
  const isAr = lang === "ar";
  const qc = useQueryClient();

  const fetchJobs = useServerFn(listMyJobsWithApplicants);
  const fetchApps = useServerFn(listEmployerApplications);
  const fetchCv = useServerFn(getApplicantCvUrl);
  const linkFn = useServerFn(linkApplicationToJob);

  const jobs = useQuery({ queryKey: ["company-jobs"], queryFn: () => fetchJobs({}) });
  const apps = useQuery({ queryKey: ["employer-applications"], queryFn: () => fetchApps({}) });

  const [jobId, setJobId] = useState("");
  const [appId, setAppId] = useState("");
  const [status, setStatus] = useState("employer_reviewed");
  const [saving, setSaving] = useState(false);
  const [cvLoading, setCvLoading] = useState<string | null>(null);

  const fmt = (d: string) =>
    new Date(d).toLocaleDateString(isAr ? "ar-EG" : "en-GB", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });

  async function openCv(applicationId: string) {
    setCvLoading(applicationId);
    try {
      const { url, fileName } = await fetchCv({ data: { applicationId } });
      openSignedFile(url, fileName);
    } catch {
      toast.error(
        t(
          tx("Could not open the CV. Please try again.", "تعذر فتح السيرة الذاتية. حاول مرة أخرى."),
        ),
      );
    } finally {
      setCvLoading(null);
    }
  }

  async function submit() {
    if (!jobId || !appId) {
      toast.error(t(tx("Select a job and an application first.", "اختر وظيفة وطلبًا أولًا.")));
      return;
    }
    setSaving(true);
    try {
      await linkFn({
        data: { applicationId: appId, jobPostingId: jobId, status: status as never },
      });
      toast.success(t(tx("Application linked to the job.", "تم ربط الطلب بالوظيفة.")));
      setAppId("");
      await Promise.all([
        qc.invalidateQueries({ queryKey: ["employer-applications"] }),
        qc.invalidateQueries({ queryKey: ["company-jobs"] }),
        qc.invalidateQueries({ queryKey: ["job-applicants"] }),
      ]);
    } catch {
      toast.error(
        t(
          tx(
            "The operation could not be completed. Please review your selection and try again.",
            "تعذر إتمام العملية. يرجى مراجعة الاختيار والمحاولة مرة أخرى.",
          ),
        ),
      );
    } finally {
      setSaving(false);
    }
  }

  const selectCls =
    "w-full rounded-md border border-border/60 bg-background px-3 py-2 text-sm text-foreground focus:border-primary focus:outline-none";

  return (
    <main className="min-h-screen bg-background pt-28 pb-20" dir={isAr ? "rtl" : "ltr"}>
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="font-display text-3xl font-semibold text-heading sm:text-4xl">
              {t(tx("Link Job to Application", "ربط الوظيفة بالطلب"))}
            </h1>
            <p className="mt-2 text-sm text-muted-foreground">
              {t(
                tx(
                  "Pick one of your vacancies, pick a received application, then set its status.",
                  "اختر إحدى وظائفك، ثم اختر طلبًا مستلمًا، وحدد حالته.",
                ),
              )}
            </p>
          </div>
          <Link to="/applicants" className="text-sm font-medium text-gold-dark hover:underline">
            {t(tx("Applicants", "المتقدمون"))}
          </Link>
        </div>

        <Card className="mt-8 border-border/60 shadow-elegant">
          <CardHeader>
            <CardTitle className="font-display text-xl">{t(tx("New Link", "ربط جديد"))}</CardTitle>
          </CardHeader>
          <CardContent>
            {jobs.isLoading || apps.isLoading ? (
              <Loader2 className="h-5 w-5 animate-spin text-gold-dark" />
            ) : (
              <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
                <label className="block">
                  <span className="mb-1 block text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    {t(tx("Job", "الوظيفة"))}
                  </span>
                  <select
                    className={selectCls}
                    value={jobId}
                    onChange={(e) => setJobId(e.target.value)}
                  >
                    <option value="">{t(tx("Select a job", "اختر وظيفة"))}</option>
                    {(jobs.data ?? []).map((j) => (
                      <option key={j.id} value={j.id}>
                        {(isAr ? j.titleAr : j.titleEn) + " – " + j.jobCode}
                      </option>
                    ))}
                  </select>
                </label>

                <label className="block">
                  <span className="mb-1 block text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    {t(tx("Application", "الطلب"))}
                  </span>
                  <select
                    className={selectCls}
                    value={appId}
                    onChange={(e) => setAppId(e.target.value)}
                  >
                    <option value="">{t(tx("Select an application", "اختر طلبًا"))}</option>
                    {(apps.data ?? []).map((a) => (
                      <option key={a.id} value={a.id}>
                        {(a.candidateName || t(tx("Candidate", "مرشح"))) +
                          " – " +
                          (isAr ? a.jobTitleAr : a.jobTitleEn) +
                          " – " +
                          fmt(a.appliedAt)}
                      </option>
                    ))}
                  </select>
                </label>

                <label className="block">
                  <span className="mb-1 block text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    {t(tx("Status", "الحالة"))}
                  </span>
                  <select
                    className={selectCls}
                    value={status}
                    onChange={(e) => setStatus(e.target.value)}
                  >
                    {STATUSES.map((s) => (
                      <option key={s} value={s}>
                        {t(applicationStatusLabel(s))}
                      </option>
                    ))}
                  </select>
                </label>
              </div>
            )}

            <div className="mt-5">
              <Button
                onClick={() => void submit()}
                disabled={saving || !jobId || !appId}
                aria-busy={saving}
                className="bg-gradient-gold font-semibold text-primary-foreground hover:shadow-gold"
              >
                {saving ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Link2 className="h-4 w-4" />
                )}
                {t(tx("Link & Save Status", "ربط وحفظ الحالة"))}
              </Button>
            </div>
          </CardContent>
        </Card>

        <section className="mt-10">
          <h2 className="font-display text-2xl font-semibold text-heading">
            {t(tx("Received Applications", "الطلبات المستلمة"))}
          </h2>
          <Card className="mt-4 border-border/60 shadow-elegant">
            <CardContent className="p-0">
              {apps.isLoading ? (
                <div className="p-6">
                  <Loader2 className="h-5 w-5 animate-spin text-gold-dark" />
                </div>
              ) : (apps.data?.length ?? 0) === 0 ? (
                <div className="p-8 text-center text-sm text-muted-foreground">
                  {t(tx("No applications received yet.", "لا توجد طلبات مستلمة حتى الآن."))}
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="text-xs uppercase tracking-wider text-muted-foreground">
                      <tr>
                        <th className="px-4 py-3 text-start">{t(tx("Candidate", "المرشح"))}</th>
                        <th className="px-4 py-3 text-start">{t(tx("Job", "الوظيفة"))}</th>
                        <th className="px-4 py-3 text-start">
                          {t(tx("Application Date", "تاريخ التقديم"))}
                        </th>
                        <th className="px-4 py-3 text-start">{t(tx("Status", "الحالة"))}</th>
                        <th className="px-4 py-3 text-start">{t(tx("Linked", "مرتبط"))}</th>
                        <th className="px-4 py-3" />
                      </tr>
                    </thead>
                    <tbody>
                      {apps.data!.map((a) => (
                        <tr key={a.id} className="border-t border-border/60">
                          <td className="px-4 py-3 font-medium text-foreground">
                            {a.candidateName || "—"}
                          </td>
                          <td className="px-4 py-3 text-muted-foreground">
                            {isAr ? a.jobTitleAr : a.jobTitleEn}
                          </td>
                          <td className="px-4 py-3 text-muted-foreground">{fmt(a.appliedAt)}</td>
                          <td className="px-4 py-3">
                            <Badge variant="outline" className="border-primary/50 text-gold-dark">
                              {t(applicationStatusLabel(a.status))}
                            </Badge>
                          </td>
                          <td className="px-4 py-3 text-muted-foreground">
                            {a.jobPostingId
                              ? t(tx("Linked to a vacancy", "مرتبط بوظيفة"))
                              : a.externalJobId
                                ? a.externalJobId.toUpperCase()
                                : t(tx("Not linked", "غير مرتبط"))}
                          </td>
                          <td className="px-4 py-3">
                            <div className="flex flex-wrap gap-2">
                              <Button
                                size="sm"
                                variant="outline"
                                className="border-primary/60 text-gold-dark"
                                onClick={() => setAppId(a.id)}
                              >
                                <Link2 className="h-4 w-4" />
                                {t(tx("Select", "اختيار"))}
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                disabled={!a.hasCv || cvLoading === a.id}
                                onClick={() => void openCv(a.id)}
                                className="border-primary/60 text-gold-dark"
                              >
                                {cvLoading === a.id ? (
                                  <Loader2 className="h-4 w-4 animate-spin" />
                                ) : (
                                  <FileText className="h-4 w-4" />
                                )}
                                {t(tx("View CV", "عرض السيرة"))}
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </section>
      </div>
    </main>
  );
}
