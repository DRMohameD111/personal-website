import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useState, type FormEvent } from "react";
import {
  GraduationCap,
  BadgeCheck,
  Award,
  Crown,
  Sparkles,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  Upload,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { useI18n, tx } from "@/i18n";
import { cn } from "@/lib/utils";
import { COUNTRIES, NATIONALITIES } from "@/lib/countries";
import { SECTORS } from "@/lib/sectors";
import { supabase } from "@/integrations/supabase/client";
import { useFormDraft } from "@/lib/form-draft";
import { updateCandidateProfile } from "@/lib/applications.functions";
import { getMyAccount } from "@/lib/account.functions";

export const Route = createFileRoute("/job-seekers")({
  validateSearch: (s: Record<string, unknown>): { returnJob?: string } => ({
    returnJob: typeof s.returnJob === "string" ? s.returnJob : undefined,
  }),

  head: () => ({
    meta: [
      { title: "Job Seekers — SPHINX Workforce" },
      {
        name: "description",
        content:
          "Apply to join the SPHINX Workforce talent network. Roles for fresh graduates through C-level partners across KSA, the GCC and Egypt.",
      },
      { property: "og:title", content: "Job Seekers — SPHINX Workforce" },
      {
        property: "og:description",
        content: "Join the talent network powering Saudi Arabia, the GCC and Egypt.",
      },
    ],
  }),
  component: JobSeekersPage,
});

type Profile = "fresh" | "expert" | "professional" | "partner" | "overqualified";

function JobSeekersPage() {
  const { t } = useI18n();
  const [profile, setProfile] = useState<Profile | null>(null);

  const profiles: {
    id: Profile;
    icon: typeof Award;
    title: ReturnType<typeof tx>;
    desc: ReturnType<typeof tx>;
  }[] = [
    {
      id: "fresh",
      icon: GraduationCap,
      title: tx("Fresh Graduate", "خريج جديد"),
      desc: tx("Less than 2 years of experience", "أقل من سنتين خبرة"),
    },
    {
      id: "expert",
      icon: BadgeCheck,
      title: tx("Expert", "خبير"),
      desc: tx("3 – 7 years of experience", "خبرة من 3 إلى 7 سنوات"),
    },
    {
      id: "professional",
      icon: Award,
      title: tx("Professional", "محترف"),
      desc: tx("7+ years of experience", "خبرة أكثر من 7 سنوات"),
    },
    {
      id: "partner",
      icon: Crown,
      title: tx("Partner / C-Level", "شريك / تنفيذي"),
      desc: tx("Executive leadership", "قيادة تنفيذية"),
    },
    {
      id: "overqualified",
      icon: Sparkles,
      title: tx("Overqualified Candidate", "مرشح بمؤهلات استثنائية"),
      desc: tx("Specialised or executive expertise", "خبرة متخصصة أو تنفيذية"),
    },
  ];

  return (
    <main className="min-h-screen">
      <section className="relative pt-32 pb-12 md:pt-44 md:pb-16">
        <div className="absolute inset-0 bg-gradient-hero opacity-90" />
        <div className="relative mx-auto max-w-5xl px-4 text-center sm:px-6 lg:px-8">
          <span className="text-xs font-semibold uppercase tracking-[0.25em] text-gold-dark">
            {t(tx("Talent Network", "شبكة المواهب"))}
          </span>
          <h1 className="mt-3 font-display text-4xl font-bold text-foreground md:text-6xl">
            {t(tx("Who Are You?", "من أنت؟"))}
          </h1>
          <div className="gold-divider mx-auto mt-6 w-24" />
          <p className="mx-auto mt-5 max-w-2xl text-base text-muted-foreground md:text-lg">
            {t(
              tx(
                "Select your profile to begin your application.",
                "اختر مسارك للبدء بطلب التوظيف.",
              ),
            )}
          </p>
        </div>
      </section>

      {!profile && (
        <section className="pb-24">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
              {profiles.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => setProfile(p.id)}
                  className={cn(
                    "group text-start rounded-2xl bg-gradient-card ring-inset-gold p-7 hover-lift",
                    "transition-all duration-300 hover:ring-2 hover:ring-primary/60",
                  )}
                >
                  <div className="inline-flex h-14 w-14 items-center justify-center rounded-xl bg-primary/15 ring-1 ring-primary/30 group-hover:bg-gradient-gold group-hover:ring-0 transition-all">
                    <p.icon className="h-7 w-7 text-gold-dark group-hover:text-primary-foreground transition-colors" />
                  </div>
                  <h3 className="mt-5 font-display text-lg font-semibold text-foreground">
                    {t(p.title)}
                  </h3>
                  <p className="mt-2 text-sm text-muted-foreground">{t(p.desc)}</p>
                  <div className="mt-5 inline-flex items-center gap-1.5 text-xs font-semibold text-gold-dark">
                    {t(tx("Continue", "متابعة"))} <ArrowRight className="h-3.5 w-3.5" />
                  </div>
                </button>
              ))}
            </div>
          </div>
        </section>
      )}

      {profile && (
        <ApplicationForm
          profile={profile}
          profileLabel={t(profiles.find((p) => p.id === profile)!.title)}
          onBack={() => setProfile(null)}
        />
      )}
    </main>
  );
}

function ApplicationForm({
  profile,
  profileLabel,
  onBack,
}: {
  profile: Profile;
  profileLabel: string;
  onBack: () => void;
}) {
  const { t, lang } = useI18n();
  const navigate = useNavigate();
  const [formMounted, setFormMounted] = useState(false);
  const [sectorId, setSectorId] = useState<string>(profile === "partner" ? "executive" : "hr");
  const [skills, setSkills] = useState<string[]>([]);
  const [submitted, setSubmitted] = useState(false);

  // Edit mode: load the values already saved on this person's profile so the
  // same form opens pre-filled. Unsaved drafts are restored on top by
  // useFormDraft, so in-progress edits always win over stored values.
  const fetchAccount = useServerFn(getMyAccount);
  const account = useQuery({
    queryKey: ["my-account"],
    queryFn: () => fetchAccount({}),
    retry: false,
    staleTime: 30_000,
  });
  const saved = account.data?.profile;
  const ready = !account.isLoading;
  // The form is mounted only once the saved values are known, so it is never
  // remounted underneath the person while they are typing.
  const { formRef, clearDraft } = useFormDraft("job-seeker-profile", lang, formMounted);

  useEffect(() => {
    if (ready) setFormMounted(true);
  }, [ready]);

  useEffect(() => {
    if (saved?.sector && SECTORS.some((s) => s.id === saved.sector)) setSectorId(saved.sector);
  }, [saved?.sector]);

  // Saved skills open pre-selected so nothing has to be re-entered.
  useEffect(() => {
    if (saved?.skills?.length) setSkills(saved.skills);
  }, [saved?.skills]);

  const activeSector = SECTORS.find((s) => s.id === sectorId) ?? SECTORS[0];

  const includeAchievements =
    profile === "expert" ||
    profile === "professional" ||
    profile === "partner" ||
    profile === "overqualified";

  const toggleSkill = (s: string) =>
    setSkills((curr) => (curr.includes(s) ? curr.filter((x) => x !== s) : [...curr, s]));

  const { returnJob } = Route.useSearch();

  const goToMatchingJobs = () => {
    // Returning to the vacancy the user came from takes priority over matching.
    if (returnJob) {
      navigate({ to: "/jobs", search: { job: returnJob } });
      return;
    }
    navigate({
      to: "/jobs",
      search: {
        sector: sectorId,
        skills: skills.length ? skills.join(",") : undefined,
      },
    });
  };

  const onSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    // React nulls out currentTarget after the first await, so read the form now.
    const formEl = e.currentTarget;
    const fd = new FormData(formEl);
    setSubmitted(true);
    try {
      // 1) Ensure signed in — required to persist profile + upload CV
      const { data: userData } = await supabase.auth.getUser();
      const user = userData?.user;
      if (!user) {
        toast.info(t(tx("Please sign in to save your profile.", "يرجى تسجيل الدخول لحفظ ملفك.")));
        navigate({ to: "/auth" });
        return;
      }
      const getStr = (k: string) => (fd.get(k) ?? "").toString().trim();

      // 2) Upload CV (resume) to private cvs bucket if provided
      let cvUrl: string | undefined;
      const resume = fd.get("resume") as File | null;
      if (resume && resume.size > 0) {
        const ext = resume.name.split(".").pop()?.toLowerCase() || "pdf";
        const path = `${user.id}/cv-${Date.now()}.${ext}`;
        const { error: upErr } = await supabase.storage
          .from("cvs")
          .upload(path, resume, { upsert: true, contentType: resume.type || undefined });
        if (upErr) {
          // Mandatory attachment: never continue silently when the CV fails.
          setSubmitted(false);
          toast.error(
            t(
              tx(
                "The CV could not be uploaded. Please upload it again before submitting your application.",
                "تعذر رفع السيرة الذاتية. يرجى إعادة رفع الملف ثم المحاولة مرة أخرى.",
              ),
            ),
          );
          return;
        }

        cvUrl = path;
        toast.success(
          t(tx("Your CV has been uploaded successfully.", "تم رفع سيرتك الذاتية بنجاح.")),
        );
      }

      // 2b) Optional profile photo (private candidate media bucket)
      let photoPath: string | undefined;
      const photo = fd.get("photo") as File | null;
      if (photo && photo.size > 0) {
        const pext = photo.name.split(".").pop()?.toLowerCase() || "jpg";
        const ppath = `${user.id}/photo-${Date.now()}.${pext}`;
        const { error: pErr } = await supabase.storage
          .from("candidate-media")
          .upload(ppath, photo, { upsert: true, contentType: photo.type || undefined });
        if (pErr) {
          toast.error(t(tx("The photo could not be uploaded.", "تعذر رفع الصورة الشخصية.")));
        } else {
          photoPath = ppath;
        }
      }

      // 3) Persist profile fields
      await updateCandidateProfile({
        data: {
          full_name: getStr("name") || undefined,
          phone: getStr("mobile") || undefined,
          country: getStr("residence") || undefined,
          nationality: getStr("nationality") || undefined,
          profession: getStr("profession") || undefined,
          sector: getStr("sector") || undefined,
          education: getStr("education") || undefined,
          languages: getStr("languages") || undefined,
          cv_url: cvUrl,
          gender: (getStr("gender") === "male" || getStr("gender") === "female"
            ? getStr("gender")
            : undefined) as "male" | "female" | undefined,
          photo_url: photoPath,
          availability: getStr("availability") || undefined,
          job_title: getStr("job_title") || undefined,
          experience: getStr("achievements") || undefined,
          skills: skills.length ? skills : undefined,
        },
      });

      clearDraft();
      toast.success(
        t(tx("Your profile has been completed successfully.", "تم إكمال ملفك الشخصي بنجاح.")),
      );
      setTimeout(() => {
        setSubmitted(false);
        goToMatchingJobs();
      }, 600);
    } catch (err) {
      setSubmitted(false);
      toast.error(
        t(
          tx(
            `Could not save your profile. ${(err as Error).message ?? ""}`.trim(),
            `تعذّر حفظ ملفك الشخصي. ${(err as Error).message ?? ""}`.trim(),
          ),
        ),
      );
    }
  };

  const inputClass = "h-11 bg-background";
  const selectClass =
    "h-11 w-full rounded-md border border-input bg-background px-3 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring";

  return (
    <section className="pb-24">
      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
        <button
          type="button"
          onClick={onBack}
          className="mb-6 inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground hover:text-gold-dark transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          {t(tx("Choose a different profile", "اختر مساراً آخر"))}
        </button>

        <div className="mb-7 rounded-xl border border-primary/30 bg-primary/5 px-5 py-4 text-sm">
          <span className="text-muted-foreground">{t(tx("Applying as", "تتقدم بصفتك"))}: </span>
          <span className="font-semibold text-gold-dark">{profileLabel}</span>
        </div>

        {!ready ? (
          <div className="rounded-3xl bg-gradient-card ring-inset-gold p-7 md:p-10 text-sm text-muted-foreground">
            {t(tx("Loading your details…", "جارٍ تحميل بياناتك…"))}
          </div>
        ) : (
          <form
            ref={formRef}
            onSubmit={onSubmit}
            className="rounded-3xl bg-gradient-card ring-inset-gold p-7 md:p-10"
          >
            <div className="grid gap-5 md:grid-cols-2">
              <Field label={t(tx("Full Name", "الاسم الكامل"))} required>
                <Input
                  className={inputClass}
                  name="name"
                  required
                  defaultValue={saved?.full_name ?? ""}
                />
              </Field>
              <Field label={t(tx("Nationality", "الجنسية"))} required>
                <select
                  className={selectClass}
                  name="nationality"
                  required
                  defaultValue={saved?.nationality ?? ""}
                >
                  <option value="" disabled>
                    {t(tx("Select nationality…", "اختر الجنسية…"))}
                  </option>
                  {NATIONALITIES.map((n) => (
                    <option key={n.en} value={n.en}>
                      {t(n)}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label={t(tx("Country of Residence", "بلد الإقامة"))} required>
                <select
                  className={selectClass}
                  name="residence"
                  required
                  defaultValue={saved?.country ?? ""}
                >
                  <option value="" disabled>
                    {t(tx("Select country…", "اختر الدولة…"))}
                  </option>
                  {COUNTRIES.map((c) => (
                    <option key={c.en} value={c.en}>
                      {t(c)}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label={t(tx("Mobile Number", "رقم الجوال"))} required>
                <Input
                  className={inputClass}
                  name="mobile"
                  type="tel"
                  required
                  defaultValue={saved?.phone ?? ""}
                />
              </Field>
              <Field label={t(tx("Email", "البريد الإلكتروني"))} required>
                <Input
                  className={inputClass}
                  name="email"
                  type="email"
                  required
                  defaultValue={saved?.email ?? account.data?.email ?? ""}
                  readOnly={!!(saved?.email ?? account.data?.email)}
                />
              </Field>
              <Field label={t(tx("Profession", "المهنة"))} required>
                <Input
                  className={inputClass}
                  name="profession"
                  required
                  defaultValue={saved?.profession ?? ""}
                />
              </Field>
              <Field label={t(tx("Job Title", "المسمى الوظيفي"))}>
                <Input
                  className={inputClass}
                  name="job_title"
                  defaultValue={saved?.job_title ?? ""}
                />
              </Field>
              <Field label={t(tx("Gender", "الجنس"))}>
                <select className={selectClass} name="gender" defaultValue={saved?.gender ?? ""}>
                  <option value="">{t(tx("Prefer not to say", "أفضل عدم الإفصاح"))}</option>
                  <option value="male">{t(tx("Male", "ذكر"))}</option>
                  <option value="female">{t(tx("Female", "أنثى"))}</option>
                </select>
              </Field>
              <Field label={t(tx("Availability", "الجاهزية للعمل"))}>
                <Input
                  className={inputClass}
                  name="availability"
                  defaultValue={saved?.availability ?? ""}
                  placeholder={t(tx("Immediately / 1 month", "فوراً / بعد شهر"))}
                />
              </Field>
              <Field label={t(tx("Profile Photo", "الصورة الشخصية"))}>
                <Input className={inputClass} name="photo" type="file" accept="image/*" />
                {saved?.photo_url && (
                  <span className="mt-1 block text-xs text-muted-foreground">
                    {t(
                      tx(
                        "A photo is already saved. Upload a new one to replace it.",
                        "توجد صورة محفوظة. ارفع صورة جديدة لاستبدالها.",
                      ),
                    )}
                  </span>
                )}
              </Field>

              <Field label={t(tx("Sector / Field", "القطاع / المجال"))} required>
                <select
                  className={selectClass}
                  name="sector"
                  required
                  value={sectorId}
                  onChange={(e) => {
                    setSectorId(e.target.value);
                    setSkills([]);
                  }}
                >
                  {SECTORS.map((s) => (
                    <option key={s.id} value={s.id}>
                      {t(s.label)}
                    </option>
                  ))}
                </select>
              </Field>
            </div>

            {/* Skills */}
            <div className="mt-6">
              <Label className="text-xs font-semibold uppercase tracking-wider text-gold-dark">
                {t(
                  tx(
                    `Top Skills — ${activeSector.label.en}`,
                    `المهارات الأكثر طلباً — ${activeSector.label.ar}`,
                  ),
                )}
              </Label>
              <div className="mt-3 flex flex-wrap gap-2">
                {activeSector.skills.map((s) => {
                  const active = skills.includes(s.en);
                  return (
                    <button
                      key={s.en}
                      type="button"
                      onClick={() => toggleSkill(s.en)}
                      className={cn(
                        "rounded-full border px-3 py-1.5 text-xs font-medium transition-all",
                        active
                          ? "bg-gradient-gold text-primary-foreground border-transparent shadow-gold"
                          : "border-border text-foreground/80 hover:border-primary hover:text-gold-dark",
                      )}
                    >
                      {t(s)}
                    </button>
                  );
                })}
              </div>
              <div className="mt-4 flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={goToMatchingJobs}
                  className="inline-flex items-center gap-1.5 rounded-full border border-primary/40 bg-primary/10 px-4 py-1.5 text-xs font-semibold text-gold-dark hover:bg-primary hover:text-primary-foreground transition-colors"
                >
                  {t(tx("View matching jobs", "عرض الوظائف المطابقة"))}
                  <ArrowRight className="h-3.5 w-3.5" />
                </button>
                {skills.length > 0 && (
                  <span className="text-xs text-muted-foreground">
                    {t(
                      tx(
                        `Matching on ${skills.length} skill${skills.length === 1 ? "" : "s"} in ${activeSector.label.en}`,
                        `سيتم المطابقة على ${skills.length} مهارة في ${activeSector.label.ar}`,
                      ),
                    )}
                  </span>
                )}
              </div>
            </div>

            {includeAchievements && (
              <div className="mt-6">
                <Label className="text-xs font-semibold uppercase tracking-wider text-gold-dark">
                  {t(tx("Key Achievements", "أبرز الإنجازات"))}
                </Label>
                <Textarea
                  name="achievements"
                  rows={5}
                  defaultValue={saved?.experience ?? ""}
                  className="mt-2 bg-background"
                  placeholder={t(
                    tx(
                      "Tell us about quantifiable wins, leadership moments, and signature projects…",
                      "اذكر إنجازاتك القابلة للقياس ومواقف قيادتك ومشاريعك المميزة…",
                    ),
                  )}
                />
              </div>
            )}

            <div className="mt-6 grid gap-5 md:grid-cols-2">
              <Field label={t(tx("Education", "المؤهل الدراسي"))} required>
                <Input
                  className={inputClass}
                  name="education"
                  required
                  defaultValue={saved?.education ?? ""}
                  placeholder={t(tx("Degree, institution, year", "الشهادة، المؤسسة، السنة"))}
                />
              </Field>
              <Field label={t(tx("Languages", "اللغات"))} required>
                <Input
                  className={inputClass}
                  name="languages"
                  required
                  defaultValue={saved?.languages ?? ""}
                  placeholder={t(
                    tx(
                      "e.g. Arabic (native), English (fluent)",
                      "مثال: العربية (لغة أم)، الإنجليزية (طلاقة)",
                    ),
                  )}
                />
              </Field>
            </div>

            {/* Uploads */}
            <div className="mt-7 grid gap-4 md:grid-cols-3">
              <FileField
                name="resume"
                label={t(tx("Resume", "السيرة الذاتية"))}
                required={!saved?.cv_url}
              />
              <FileField name="certificates" label={t(tx("Certificates", "الشهادات"))} multiple />
              <FileField
                name="id"
                label={t(tx("ID Document", "الهوية"))}
                required={!saved?.cv_url}
              />
            </div>

            <Button
              type="submit"
              size="lg"
              disabled={submitted}
              className="mt-9 w-full bg-gradient-gold text-primary-foreground font-semibold text-base py-6 hover:shadow-gold"
            >
              {submitted ? (
                <>
                  <CheckCircle2 className="h-4 w-4" />{" "}
                  {t(tx("Application Submitted", "تم إرسال الطلب"))}
                </>
              ) : (
                <>
                  {t(tx("Submit Application", "إرسال الطلب"))} <ArrowRight className="h-4 w-4" />
                </>
              )}
            </Button>
          </form>
        )}
      </div>
    </section>
  );
}

function Field({
  label,
  required,
  children,
}: {
  label: string;
  required?: boolean;
  children: React.ReactNode;
}) {
  return (
    <div>
      <Label className="text-xs font-semibold uppercase tracking-wider text-gold-dark">
        {label} {required && <span className="text-destructive">*</span>}
      </Label>
      <div className="mt-2">{children}</div>
    </div>
  );
}

function FileField({
  name,
  label,
  required,
  multiple,
}: {
  name: string;
  label: string;
  required?: boolean;
  multiple?: boolean;
}) {
  const [fileName, setFileName] = useState<string>("");
  return (
    <div>
      <Label className="text-xs font-semibold uppercase tracking-wider text-gold-dark">
        {label} {required && <span className="text-destructive">*</span>}
      </Label>
      <label className="mt-2 flex h-24 cursor-pointer flex-col items-center justify-center gap-1.5 rounded-md border border-dashed border-primary/40 bg-background/60 px-3 text-center text-xs text-muted-foreground hover:border-primary hover:bg-primary/5 transition-colors">
        <Upload className="h-4 w-4 text-gold-dark" />
        <span className="font-medium text-foreground truncate max-w-full">
          {fileName || "Click to upload"}
        </span>
        <span className="text-[10px]">PDF, JPG or PNG · up to 10MB</span>
        <input
          type="file"
          name={name}
          required={required}
          multiple={multiple}
          accept=".pdf,.jpg,.jpeg,.png"
          className="hidden"
          onChange={(e) => {
            const files = e.target.files;
            if (!files || files.length === 0) return setFileName("");
            setFileName(files.length > 1 ? `${files.length} files selected` : files[0].name);
          }}
        />
      </label>
    </div>
  );
}
