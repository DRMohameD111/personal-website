import { createFileRoute, Link } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { Building2, ArrowRight, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { useI18n, tx } from "@/i18n";

export const Route = createFileRoute("/employers")({
  head: () => ({
    meta: [
      { title: "For Employers — SPHINX Workforce" },
      {
        name: "description",
        content:
          "Request workforce from SPHINX. Submit your manpower requirements for KSA, the GCC and Egypt — engineers, technicians, skilled labour, hospitality and more.",
      },
      { property: "og:title", content: "For Employers — SPHINX Workforce" },
      {
        property: "og:description",
        content: "Submit your workforce request. Response within one business hour.",
      },
    ],
  }),
  component: EmployersPage,
});

function EmployersPage() {
  const { t } = useI18n();
  const [submitted, setSubmitted] = useState(false);

  const onSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setSubmitted(true);
    toast.success(
      t(
        tx(
          "Request received. Our team will respond within one business hour.",
          "تم استلام طلبك. سيتواصل فريقنا خلال ساعة عمل واحدة.",
        ),
      ),
    );
    (e.target as HTMLFormElement).reset();
    setTimeout(() => setSubmitted(false), 4000);
  };

  const inputClass = "h-11 bg-background";
  const selectClass =
    "h-11 w-full rounded-md border border-input bg-background px-3 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring";

  return (
    <main className="min-h-screen">
      <section className="relative pt-32 pb-12 md:pt-44 md:pb-16">
        <div className="absolute inset-0 bg-gradient-hero opacity-90" />
        <div className="relative mx-auto max-w-5xl px-4 text-center sm:px-6 lg:px-8">
          <span className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.25em] text-gold-dark">
            <Building2 className="h-3.5 w-3.5" /> {t(tx("For Employers", "لأصحاب العمل"))}
          </span>
          <h1 className="mt-3 font-display text-4xl font-bold text-foreground md:text-6xl">
            {t(tx("Request Workforce", "اطلب قوى عاملة"))}
          </h1>
          <div className="gold-divider mx-auto mt-6 w-24" />
          <p className="mx-auto mt-5 max-w-2xl text-base text-muted-foreground md:text-lg">
            {t(
              tx(
                "Tell us what you need. We mobilise vetted talent within 48 hours.",
                "أخبرنا باحتياجك. ننشر مواهب مؤهلة خلال 48 ساعة.",
              ),
            )}
          </p>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
            <Link to="/post-job">
              <Button className="bg-gradient-gold text-primary-foreground font-semibold">
                {t(tx("Post a job", "نشر وظيفة"))}
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
            <Link to="/manpower">
              <Button
                variant="outline"
                className="border-primary/60 text-gold-dark hover:bg-primary/10"
              >
                {t(tx("Manpower Requests", "طلبات القوى العاملة"))}
              </Button>
            </Link>
            <Link to="/my-jobs">
              <Button
                variant="outline"
                className="border-primary/60 text-gold-dark hover:bg-primary/10"
              >
                {t(tx("My Jobs", "وظائفي"))}
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <section className="pb-24">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <form
            onSubmit={onSubmit}
            className="rounded-3xl bg-gradient-card ring-inset-gold p-7 md:p-10"
          >
            <div className="grid gap-5 md:grid-cols-2">
              <Field label={t(tx("Company Name", "اسم الشركة"))} required>
                <Input className={inputClass} name="company" required />
              </Field>
              <Field label={t(tx("Contact Person", "الشخص المسؤول"))} required>
                <Input className={inputClass} name="contact" required />
              </Field>
              <Field label={t(tx("Mobile Number", "رقم الجوال"))} required>
                <Input className={inputClass} name="mobile" type="tel" required />
              </Field>
              <Field label={t(tx("Email", "البريد الإلكتروني"))} required>
                <Input className={inputClass} name="email" type="email" required />
              </Field>
              <Field label={t(tx("City", "المدينة"))} required>
                <Input className={inputClass} name="city" required />
              </Field>
              <Field label={t(tx("Commercial Registration No.", "رقم السجل التجاري"))}>
                <Input className={inputClass} name="cr" />
              </Field>
              {/* Job Category / الفئة الوظيفية and Required Quantity / العدد المطلوب
                  belong to the Manpower Requirement (/manpower), not to client master data. */}
              <Field label={t(tx("Contract Duration", "مدة العقد"))}>
                <select className={selectClass} name="duration" defaultValue="">
                  <option value="" disabled>
                    {t(tx("Select duration…", "اختر المدة…"))}
                  </option>
                  <option>{t(tx("Less than 3 months", "أقل من 3 أشهر"))}</option>
                  <option>{t(tx("3 – 6 months", "3 – 6 أشهر"))}</option>
                  <option>{t(tx("6 – 12 months", "6 – 12 شهر"))}</option>
                  <option>{t(tx("1 – 2 years", "1 – 2 سنة"))}</option>
                  <option>{t(tx("2+ years", "أكثر من سنتين"))}</option>
                </select>
              </Field>
              <Field label={t(tx("Project Location", "موقع المشروع"))}>
                <Input className={inputClass} name="location" />
              </Field>
              <Field label={t(tx("Salary Range", "نطاق الراتب"))}>
                <Input className={inputClass} name="salary" placeholder="e.g. SAR 5,000 – 8,000" />
              </Field>
            </div>

            <div className="mt-5">
              <Label className="text-xs font-semibold uppercase tracking-wider text-gold-dark">
                {t(tx("Additional Notes", "ملاحظات إضافية"))}
              </Label>
              <Textarea
                name="notes"
                rows={5}
                className="mt-2 bg-background"
                placeholder={t(
                  tx(
                    "Tell us about the project scope, mobilisation timeline, certifications required…",
                    "أخبرنا عن نطاق المشروع وموعد التعبئة والشهادات المطلوبة…",
                  ),
                )}
              />
            </div>

            <Button
              type="submit"
              size="lg"
              disabled={submitted}
              className="mt-8 w-full bg-gradient-gold text-primary-foreground font-semibold text-base py-6 hover:shadow-gold"
            >
              {submitted ? (
                <>
                  <CheckCircle2 className="h-4 w-4" /> {t(tx("Request Submitted", "تم الإرسال"))}
                </>
              ) : (
                <>
                  {t(tx("Submit Workforce Request", "إرسال طلب القوى العاملة"))}{" "}
                  <ArrowRight className="h-4 w-4" />
                </>
              )}
            </Button>
          </form>
        </div>
      </section>
    </main>
  );
}

function Field({
  label,
  required,
  children,
}: {
  label: string;
  required?: boolean;
  children: React.ReactNode;
}) {
  return (
    <div>
      <Label className="text-xs font-semibold uppercase tracking-wider text-gold-dark">
        {label} {required && <span className="text-destructive">*</span>}
      </Label>
      <div className="mt-2">{children}</div>
    </div>
  );
}
