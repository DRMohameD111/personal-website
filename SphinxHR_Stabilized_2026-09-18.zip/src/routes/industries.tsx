import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/industries")({
  head: () => ({
    meta: [
      { title: "Industries — SPHINX Workforce" },
      {
        name: "description",
        content:
          "SPHINX Workforce serves construction, oil & gas, manufacturing, hospitality, healthcare, logistics, facility management and technology across Saudi Arabia, the GCC and Egypt.",
      },
      { property: "og:title", content: "Industries — SPHINX Workforce" },
      {
        property: "og:description",
        content:
          "Workforce solutions tailored to every sector — built for Saudi Arabia and the GCC.",
      },
    ],
  }),
  component: IndustriesPage,
});

function IndustriesPage() {
  return null;
}
