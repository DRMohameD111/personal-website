import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ArrowRight,
  FileText,
  Building2,
  Globe2,
  Zap,
  CheckCircle2,
  ShieldCheck,
  Sparkles,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { ServicesSection } from "@/components/ServicesSection";
import { HomeServiceCards } from "@/components/HomeServiceCards";
import { useI18n, tx } from "@/i18n";
import { imagery, ornaments, brand } from "@/brand";
import { cn } from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";
import { getPlatformStats } from "@/lib/account.functions";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "SPHINX Workforce — Premium Manpower & Workforce Outsourcing" },
      {
        name: "description",
        content:
          "SPHINX Workforce delivers workforce outsourcing, manpower supply, and technical staffing across Saudi Arabia, the GCC and Egypt. Skilled candidates deployed in 48 hours.",
      },
      {
        property: "og:title",
        content: "SPHINX Workforce — Premium Manpower & Workforce Outsourcing",
      },
      {
        property: "og:description",
        content: "Workforce outsourcing and manpower supply for Saudi Arabia, the GCC and Egypt.",
      },
      { property: "og:image", content: imagery.heroWorkforce },
    ],
    links: [{ rel: "preload", as: "image", href: imagery.laborForce }],
  }),
  component: Home,
});

function Home() {
  const { t, lang } = useI18n();
  const stats = useQuery({ queryKey: ["platform-stats"], queryFn: () => getPlatformStats() });

  const n = (v: number | undefined) =>
    typeof v === "number" ? v.toLocaleString(lang === "ar" ? "ar-EG" : "en-US") : "—";

  const trustStats = [
    {
      icon: FileText,
      value: n(stats.data?.cvs),
      label: tx("Trusted & Updated CVs", "سيرة ذاتية معتمدة ومحدثة"),
    },
    {
      icon: Building2,
      value: n(stats.data?.companies),
      label: tx("Registered Companies", "شركة مسجلة"),
    },
    { icon: Globe2, value: n(stats.data?.jobs), label: tx("Published Jobs", "وظيفة منشورة") },
    { icon: Zap, value: n(stats.data?.hires), label: tx("Successful Placements", "تعيين ناجح") },
  ];

  const pillars = [
    {
      icon: ShieldCheck,
      title: tx("Compliance First", "الالتزام أولاً"),
      desc: tx(
        "Full Saudization, GCC labour law and visa compliance across every placement.",
        "التزام كامل بالسعودة وأنظمة العمل الخليجية ومتطلبات التأشيرات في كل تعيين.",
      ),
    },
    {
      icon: Zap,
      title: tx("48-Hour Mobilisation", "تعبئة خلال 48 ساعة"),
      desc: tx(
        "Pre-vetted talent pools ready to deploy on site in two business days.",
        "قواعد مواهب جاهزة للنشر في الموقع خلال يومي عمل فقط.",
      ),
    },
    {
      icon: Sparkles,
      title: tx("Enterprise-Grade Service", "خدمة بمستوى المؤسسات"),
      desc: tx(
        "Dedicated account leadership, performance reporting, and on-site supervision.",
        "إدارة حسابات مخصصة وتقارير أداء وإشراف ميداني مستمر.",
      ),
    },
  ];

  return (
    <main className="relative isolate min-h-screen overflow-hidden">
      {/* ============ PAGE GROUND — ivory with faint hieroglyph branding ============ */}
      <div aria-hidden className="pointer-events-none fixed inset-0 -z-10 bg-background">
        <div className="absolute inset-0 bg-gradient-to-b from-background via-surface-soft to-background" />
        <div
          className="ornament-faint absolute inset-0 bg-repeat"
          style={{ backgroundImage: `url(${ornaments.pattern})`, backgroundSize: "420px" }}
        />
      </div>

      {/* ============ HERO — Pharaonic LABOR FORCE artwork ============ */}
      <section className="relative isolate overflow-hidden pt-32 pb-20 md:pt-40 md:pb-28">
        {/* Approved Pharaonic workforce artwork as a true background layer */}
        <div aria-hidden className="absolute inset-0 -z-10">
          <div
            className="absolute inset-0 bg-cover bg-[position:72%_center] bg-no-repeat md:bg-center"
            style={{ backgroundImage: `url(${imagery.laborForce})` }}
          />
          {/* Directional ivory veil — flips automatically for RTL */}
          <div className="hero-veil absolute inset-0" />
          <div className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-b from-transparent to-background" />
        </div>
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col items-center gap-12 lg:flex-row lg:gap-24">
            {/* Message column */}
            <div className="w-full space-y-8 lg:w-1/2">
              <div className="space-y-5 text-center lg:text-start">
                <span className="inline-block rounded-full border border-primary/30 px-3 py-1 text-[10px] font-semibold uppercase tracking-[0.25em] text-gold-dark">
                  {t(tx("Manpower Solutions", "حلول القوى العاملة"))}
                </span>
                <h1
                  className={cn(
                    "font-display text-3xl font-medium leading-[1.1] tracking-tight text-heading md:text-5xl",
                  )}
                >
                  {t(brand.tagline)}
                </h1>
              </div>

              <p
                className={cn(
                  "mx-auto max-w-md text-base leading-relaxed text-foreground/80 lg:mx-0 md:text-lg",
                  lang === "ar" && "font-arabic leading-loose",
                )}
              >
                {lang === "ar"
                  ? "حلول متكاملة للتشغيل والتعهيد وإدارة القوى العاملة للشركات والمشروعات في السعودية والخليج ومصر."
                  : "End-to-end workforce solutions for operations, outsourcing, and labour management across Saudi Arabia, the GCC and Egypt."}
              </p>
            </div>

            {/*
             * Visual column intentionally left open on desktop so the hieroglyphic
             * LABOR FORCE band, workers, Sphinx and pyramids stay visible.
             */}
            <div aria-hidden className="relative hidden w-full lg:block lg:w-1/2">
              <div className="min-h-[26rem]" />
              <div className="pointer-events-none absolute inset-y-6 inset-x-10 border border-primary/25" />
            </div>
          </div>

          {/* Stats strip — light panel over the artwork, hairline gold dividers */}
          <div className="mt-14 rounded-[2rem] border border-primary/20 bg-background/90 px-4 py-7 shadow-elegant backdrop-blur-sm md:px-8">
            <div className="grid grid-cols-2 gap-y-6 md:grid-cols-4 md:divide-x md:divide-primary/20 rtl:md:divide-x-reverse">
              {trustStats.map((s) => (
                <div key={s.label.en} className="px-4 text-center">
                  <div className="font-display text-2xl font-medium text-heading md:text-3xl">
                    {typeof s.value === "string" ? s.value : t(s.value)}
                  </div>
                  <div className="mt-1 text-[9px] font-semibold uppercase tracking-[0.2em] text-gold-dark">
                    {t(s.label)}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ============ PLATFORM SERVICE CARDS ============ */}
      <HomeServiceCards />

      {/* ============ PILLARS ============ */}
      <section className="relative py-24 md:py-32">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <span className="text-xs font-semibold uppercase tracking-[0.25em] text-gold-dark">
              {t(tx("Why SPHINX", "لماذا سفنكس"))}
            </span>
            <h2 className="mt-3 font-display text-3xl font-bold text-foreground md:text-4xl">
              {t(
                tx(
                  "Built for enterprise workforce excellence",
                  "نحسن التوفيق بين ذوي المهارات و أصحاب الاعمال ",
                ),
              )}
            </h2>
            <div className="gold-divider mx-auto mt-5 w-24" />
          </div>

          <div className="mt-14 grid gap-6 md:grid-cols-3">
            {pillars.map((p) => (
              <div
                key={p.title.en}
                className="rounded-2xl bg-gradient-card ring-inset-gold p-8 hover-lift"
              >
                <div className="inline-flex h-12 w-12 items-center justify-center rounded-xl bg-primary/15 ring-1 ring-primary/30">
                  <p.icon className="h-6 w-6 text-gold-dark" />
                </div>
                <h3 className="mt-5 font-display text-xl font-semibold text-foreground">
                  {t(p.title)}
                </h3>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{t(p.desc)}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ============ SERVICES (disabled temporarily) ============ */}
      {/* <ServicesSection /> */}

      {/* ============ ABOUT TEASER ============ */}
      <section className="relative py-24 md:py-32 border-t border-border/40">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid items-center gap-12 lg:grid-cols-2">
            <div className="relative">
              <div className="relative overflow-hidden rounded-2xl ring-inset-gold">
                <img
                  src={imagery.aboutLeadership}
                  alt={t(tx("SPHINX leadership", "قيادة سفنكس"))}
                  className="h-[420px] w-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-tr from-background/80 via-background/20 to-transparent" />
              </div>
              <div className="absolute -bottom-6 -right-6 hidden md:flex h-32 w-32 items-center justify-center rounded-2xl bg-gradient-gold shadow-gold">
                <span className="font-display text-3xl font-bold text-primary-foreground">12+</span>
              </div>
            </div>

            <div>
              <span className="text-xs font-semibold uppercase tracking-[0.25em] text-gold-dark">
                {t(tx("About SPHINX", "عن سفنكس"))}
              </span>
              <h2 className="mt-3 font-display text-3xl font-bold text-foreground md:text-4xl">
                {t(tx("A strong  Strategic workforce partner .", "شريك استراتيجي قوي ."))}
              </h2>
              <div className="gold-divider mt-5 w-20" />
              <p className="mt-6 text-base leading-relaxed text-muted-foreground">
                {t(
                  tx(
                    "We combine civilized discipline with the power of knowledge and wisdom in performance.",
                    "نمزج بين الانضباط الحضاري و قوة المعرفة و الحكمة في الاداء  .",
                  ),
                )}
              </p>

              <ul className="mt-7 space-y-3">
                {[
                  tx(
                    "Carefully selected CVs that meet the job requirements",
                    "سير ذاتية مختارة بعناية و متوافقة مع متطلبات الوظيفة",
                  ),
                  tx("Fully updated cv's ", "سير ذاتية محدثة بالكامل"),
                  tx(
                    "The first platform for highly experienced professionals ",
                    "اول منصة لاصحاب الخبرات الفائقة ",
                  ),
                  tx(
                    "Diverse technical expertise ranging from recent graduates to business partners",
                    "خبرات فنية متنوعة من حديثي التخرج الي شركاء الاعمال ",
                  ),
                ].map((line) => (
                  <li key={line.en} className="flex items-start gap-3 text-sm text-foreground/85">
                    <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-gold-dark" />
                    <span>{t(line)}</span>
                  </li>
                ))}
              </ul>

              <div className="mt-8">
                <Link to="/about">
                  <Button
                    variant="outline"
                    className="border-primary/60 text-gold-dark hover:bg-primary/10"
                  >
                    {t(tx("Discover Our Story", "اكتشف قصتنا"))}
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ============ CTA BAND ============ */}
      <section className="surface-dark relative isolate py-24 md:py-32">
        <div className="absolute inset-0 -z-10">
          <img
            src={imagery.ctaBand}
            alt=""
            loading="lazy"
            className="h-full w-full object-cover brightness-125 saturate-125"
          />
          <div className="absolute inset-0 photo-overlay-warm" />
        </div>

        <div className="mx-auto max-w-4xl px-4 text-center sm:px-6 lg:px-8">
          <h2 className="font-display text-3xl font-bold tracking-tight text-foreground md:text-5xl">
            {t(tx("Ready to scale your workforce?", "هل أنت جاهز لتوسيع قواك العاملة؟"))}
          </h2>
          <p className="mx-auto mt-5 max-w-2xl text-base text-muted-foreground md:text-lg">
            {t(
              tx(
                "Speak with a workforce strategist today. We respond within one business hour.",
                "تحدث مع مختص في إدارة القوى العاملة الآن. نرد خلال ساعة عمل واحدة.",
              ),
            )}
          </p>
          <div className="mt-9 flex flex-wrap justify-center gap-3">
            <Link to="/employers">
              <Button
                size="lg"
                className="bg-gradient-gold text-primary-foreground font-semibold px-7 py-6"
              >
                {t(tx("Request Workforce", "اطلب عمالة"))}
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
            <Link to="/contact">
              <Button
                size="lg"
                variant="outline"
                className="border-primary/60 text-gold-dark hover:bg-primary/10 px-7 py-6"
              >
                {t(tx("Talk to Sales", "تواصل مع المبيعات"))}
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </main>
  );
}
