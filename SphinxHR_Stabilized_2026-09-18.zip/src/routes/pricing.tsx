import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Check, Loader2, Minus, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useI18n, tx } from "@/i18n";
import {
  comparisonRows,
  durationLabel,
  featureValueLabel,
  fetchPublicPackages,
  pick,
  priceLabel,
  trialLabel,
  type PackageWithFeatures,
} from "@/lib/packages";

export const Route = createFileRoute("/pricing")({
  head: () => ({
    meta: [
      { title: "Packages & Pricing — SPHINX Workforce" },
      {
        name: "description",
        content:
          "Compare SPHINX Workforce recruitment packages: job postings, CV access, candidate contacts and support. Main Package free for 3 months for new companies.",
      },
      { property: "og:title", content: "Packages & Pricing — SPHINX Workforce" },
      {
        property: "og:description",
        content:
          "Recruitment packages for companies — job posts, CV access, candidate contacts and priority support.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: PricingPage,
});

function PriceBlock({ p }: { p: PackageWithFeatures }) {
  const { lang, t } = useI18n();
  const trial = trialLabel(p, lang);
  return (
    <div className="space-y-1">
      <p className="font-display text-3xl text-heading">{priceLabel(p, lang)}</p>
      {trial && <p className="text-sm font-semibold text-gold-dark">{trial}</p>}
      {trial && p.price_after_trial != null && (
        <p className="text-xs text-muted-foreground">
          {t(tx("Then", "بعد ذلك"))} {Number(p.price_after_trial).toLocaleString()} {p.currency}
        </p>
      )}
      <p className="text-xs text-muted-foreground">
        {t(tx("Duration", "المدة"))}: {durationLabel(p, lang)}
      </p>
    </div>
  );
}

function PricingPage() {
  const { t, lang } = useI18n();
  const { data, isLoading } = useQuery({
    queryKey: ["public-packages"],
    queryFn: fetchPublicPackages,
  });
  const packages = data ?? [];
  const rows = comparisonRows(packages, lang);

  return (
    <main className="min-h-screen pb-24 pt-28 md:pt-36">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <header className="mx-auto max-w-3xl text-center">
          <span className="text-xs font-semibold uppercase tracking-[0.25em] text-gold-dark">
            {t(tx("Packages & Pricing", "الباقات والأسعار"))}
          </span>
          <h1 className="mt-2 font-display text-3xl text-heading md:text-4xl">
            {t(
              tx(
                "Choose the package that fits your hiring",
                "اختر الباقة المناسبة لاحتياجك من التوظيف",
              ),
            )}
          </h1>
          <p className="mt-3 text-sm text-muted-foreground">
            {t(
              tx(
                "Every package is managed by the SPHINX team — prices, limits and offers shown here are always up to date.",
                "تُدار جميع الباقات من فريق سفنكس — الأسعار والحدود والعروض المعروضة هنا محدثة دائماً.",
              ),
            )}
          </p>
        </header>

        {isLoading ? (
          <div className="mt-16 flex justify-center">
            <Loader2 className="h-6 w-6 animate-spin text-gold-dark" />
          </div>
        ) : packages.length === 0 ? (
          <p className="mt-16 text-center text-sm text-muted-foreground">
            {t(tx("No packages are available right now.", "لا توجد باقات متاحة حالياً."))}
          </p>
        ) : (
          <>
            {/* Cards */}
            <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {packages.map((p) => (
                <article
                  key={p.id}
                  className={`relative flex flex-col rounded-xl border bg-card/95 p-6 shadow-elegant ${
                    p.is_recommended ? "border-primary ring-inset-gold" : "border-border/70"
                  }`}
                >
                  {p.is_recommended && (
                    <span className="absolute -top-3 start-6 inline-flex items-center gap-1 rounded-full bg-gradient-gold px-3 py-1 text-[11px] font-bold text-primary-foreground">
                      <Sparkles className="h-3 w-3" />
                      {pick(lang, p.badge_text_en, p.badge_text_ar) ||
                        t(tx("Most Popular", "الأكثر شيوعاً"))}
                    </span>
                  )}
                  <h2 className="font-display text-xl text-heading">
                    {pick(lang, p.name_en, p.name_ar)}
                  </h2>
                  <p className="mt-1 text-sm text-muted-foreground">
                    {pick(lang, p.short_desc_en, p.short_desc_ar)}
                  </p>
                  <div className="mt-4">
                    <PriceBlock p={p} />
                  </div>
                  {pick(lang, p.full_desc_en, p.full_desc_ar) && (
                    <p className="mt-4 text-sm text-foreground/80">
                      {pick(lang, p.full_desc_en, p.full_desc_ar)}
                    </p>
                  )}
                  <ul className="mt-5 flex-1 space-y-2.5">
                    {p.features
                      .filter((f) => f.enabled)
                      .map((f) => (
                        <li key={f.id} className="flex items-start gap-2 text-sm">
                          <Check className="mt-0.5 h-4 w-4 shrink-0 text-gold-dark" />
                          <span className="text-foreground/90">
                            {pick(lang, f.label_en, f.label_ar)}
                            {f.value_type !== "boolean" && (
                              <span className="font-semibold text-heading">
                                {" "}
                                — {featureValueLabel(f, lang)}
                              </span>
                            )}
                          </span>
                        </li>
                      ))}
                  </ul>
                  {pick(lang, p.vat_note_en, p.vat_note_ar) && (
                    <p className="mt-4 text-xs text-muted-foreground">
                      {pick(lang, p.vat_note_en, p.vat_note_ar)}
                    </p>
                  )}
                  <Link to={p.cta_url || "/get-started"} className="mt-6">
                    <Button
                      className={
                        p.is_recommended
                          ? "w-full bg-gradient-gold font-semibold text-primary-foreground hover:shadow-gold"
                          : "w-full"
                      }
                      variant={p.is_recommended ? "default" : "outline"}
                    >
                      {pick(lang, p.cta_text_en, p.cta_text_ar) ||
                        t(tx("Get started", "ابدأ الآن"))}
                    </Button>
                  </Link>
                </article>
              ))}
            </div>

            {/* Comparison table (generated from the same package data) */}
            {rows.length > 0 && (
              <section className="mt-20">
                <h2 className="font-display text-2xl text-heading">
                  {t(tx("Package comparison", "مقارنة الباقات"))}
                </h2>
                <div className="mt-5 overflow-x-auto rounded-xl border border-border/70 bg-card/95 shadow-elegant">
                  <table className="w-full min-w-[640px] text-sm">
                    <thead>
                      <tr className="border-b border-border/70 bg-primary/5">
                        <th className="p-4 text-start font-semibold text-heading">
                          {t(tx("Feature", "الميزة"))}
                        </th>
                        {packages.map((p) => (
                          <th key={p.id} className="p-4 text-start font-semibold text-heading">
                            {pick(lang, p.name_en, p.name_ar)}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border-b border-border/60">
                        <td className="p-4 font-medium text-foreground/90">
                          {t(tx("Price", "السعر"))}
                        </td>
                        {packages.map((p) => (
                          <td key={p.id} className="p-4 font-semibold text-gold-dark">
                            {priceLabel(p, lang)}
                          </td>
                        ))}
                      </tr>
                      <tr className="border-b border-border/60">
                        <td className="p-4 font-medium text-foreground/90">
                          {t(tx("Free trial", "الفترة المجانية"))}
                        </td>
                        {packages.map((p) => (
                          <td key={p.id} className="p-4">
                            {trialLabel(p, lang) ?? "—"}
                          </td>
                        ))}
                      </tr>
                      <tr className="border-b border-border/60">
                        <td className="p-4 font-medium text-foreground/90">
                          {t(tx("Duration", "المدة"))}
                        </td>
                        {packages.map((p) => (
                          <td key={p.id} className="p-4">
                            {durationLabel(p, lang)}
                          </td>
                        ))}
                      </tr>
                      {rows.map((r) => (
                        <tr key={r.key} className="border-b border-border/60 last:border-0">
                          <td className="p-4 font-medium text-foreground/90">{r.label}</td>
                          {packages.map((p) => {
                            const f = p.features.find((x) => x.feature_key === r.key && x.enabled);
                            return (
                              <td key={p.id} className="p-4">
                                {!f ? (
                                  <Minus className="h-4 w-4 text-muted-foreground" aria-label="—" />
                                ) : f.value_type === "boolean" && f.value_bool ? (
                                  <Check className="h-4 w-4 text-gold-dark" />
                                ) : (
                                  featureValueLabel(f, lang)
                                )}
                              </td>
                            );
                          })}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </section>
            )}
          </>
        )}
      </div>
    </main>
  );
}
