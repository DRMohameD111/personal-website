import { createFileRoute, Link, useNavigate, useRouter } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { Building2, User, Loader2, Mail, Lock } from "lucide-react";
import { toast } from "sonner";
import { z } from "zod";

import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useI18n, tx } from "@/i18n";
import { cn } from "@/lib/utils";
import { PasswordStrength, checkPassword } from "@/components/PasswordStrength";
import { COUNTRIES } from "@/lib/countries";
import { ACCOUNT_TYPE_LABELS, type AccountType } from "@/lib/account-type";

function safeNext(value: unknown): string {
  if (typeof value !== "string" || !value.startsWith("/") || value.startsWith("//")) return "";
  return value;
}

export const Route = createFileRoute("/auth")({
  validateSearch: (s: Record<string, unknown>): { next?: string } => {
    const next = safeNext(s.next);
    return next ? { next } : {};
  },
  head: () => ({
    meta: [
      { title: "Sign In or Register — SPHINX Workforce" },
      {
        name: "description",
        content:
          "Sign in or create an account on SPHINX Workforce — for individuals seeking jobs and companies hiring workforce across the GCC.",
      },
      { property: "og:title", content: "Sign In or Register — SPHINX Workforce" },
      {
        property: "og:description",
        content: "Access your SPHINX Workforce account — individuals and companies.",
      },
    ],
  }),
  component: AuthPage,
});

type Mode = "signin" | "signup";

const passwordComplexity = z
  .string()
  .min(8, "Password must be at least 8 characters")
  .max(72, "Password must be at most 72 characters")
  .regex(/[A-Z]/, "Password must contain at least one uppercase letter")
  .regex(/[a-z]/, "Password must contain at least one lowercase letter")
  .regex(/[0-9]/, "Password must contain at least one number")
  .regex(/[^A-Za-z0-9]/, "Password must contain at least one special character");

const jobSeekerSignUpSchema = z.object({
  full_name: z.string().trim().min(2, "Full name is required").max(120),
  email: z.string().trim().email("Invalid email").max(255),
  phone: z.string().trim().max(40).optional().or(z.literal("")),
  country: z.string().trim().max(80).optional().or(z.literal("")),
  password: passwordComplexity,
});

const companySignUpSchema = z.object({
  company_name: z.string().trim().min(2, "Company name is required").max(160),
  full_name: z.string().trim().min(2, "Contact name is required").max(120),
  email: z.string().trim().email("Invalid email").max(255),
  phone: z.string().trim().max(40).optional().or(z.literal("")),
  country: z.string().trim().max(80).optional().or(z.literal("")),
  password: passwordComplexity,
});

const signInSchema = z.object({
  email: z.string().trim().email("Invalid email").max(255),
  password: z.string().min(1, "Password is required").max(72),
});

type ProfileFields = {
  account_type: AccountType;
  full_name: string;
  company_name: string | null;
  phone: string | null;
  country: string | null;
  email: string;
};

/**
 * Reads back the profile created by the signup trigger and fills in anything
 * missing (account type, contact details, company name). Returns false when the
 * database write fails or the row still does not hold the entered values, so
 * the caller can surface the error instead of a false success.
 */
async function persistProfile(userId: string, fields: ProfileFields): Promise<boolean> {
  const { data: existing, error: readError } = await supabase
    .from("profiles")
    .select("id, account_type, full_name, company_name, phone, country, email")
    .eq("id", userId)
    .maybeSingle();
  if (readError) return false;

  const complete =
    existing &&
    existing.account_type === fields.account_type &&
    (existing.full_name ?? "") === fields.full_name &&
    (existing.company_name ?? null) === fields.company_name &&
    (existing.phone ?? null) === fields.phone &&
    (existing.country ?? null) === fields.country &&
    (existing.email ?? "") === fields.email;
  if (complete) return true;

  const { error: writeError } = await supabase
    .from("profiles")
    .upsert({ id: userId, ...fields }, { onConflict: "id" });
  if (writeError) return false;

  const { data: verified, error: verifyError } = await supabase
    .from("profiles")
    .select("id, account_type, full_name, phone, country, email")
    .eq("id", userId)
    .maybeSingle();
  return !verifyError && !!verified && verified.account_type === fields.account_type;
}

function AuthPage() {
  const { t, lang } = useI18n();
  const navigate = useNavigate();
  const router = useRouter();
  const [accountType, setAccountType] = useState<AccountType>("job_seeker");
  const [mode, setMode] = useState<Mode>("signin");
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [timeoutError, setTimeoutError] = useState<string | null>(null);
  const [timeoutSource, setTimeoutSource] = useState<"form" | "google" | null>(null);
  const { next } = Route.useSearch();

  // Redirect already-authenticated users straight to the profile that belongs
  // to their own account type. The type comes from the authenticated session's
  // profile row (never from the selected login tab).
  useEffect(() => {
    const go = async () => {
      if (next) {
        window.location.href = next;
        return;
      }
      const { data: userData } = await supabase.auth.getUser();
      const user = userData.user;
      if (!user) return;
      const { data: profile } = await supabase
        .from("profiles")
        .select(
          "account_type, full_name, phone, country, nationality, profession, education, languages",
        )
        .eq("id", user.id)
        .maybeSingle();

      if (profile?.account_type === "company") {
        navigate({ to: "/company" });
        return;
      }
      if (profile?.account_type === "job_seeker") {
        // Incomplete profile opens the same seeker form in completion mode.
        const complete =
          !!profile.full_name &&
          !!profile.phone &&
          !!profile.country &&
          !!profile.nationality &&
          !!profile.profession &&
          !!profile.education &&
          !!profile.languages;
        navigate(complete ? { to: "/account" } : { to: "/job-seekers" });
        return;
      }
      navigate({ to: "/choose-role" });
    };

    supabase.auth.getSession().then(({ data }) => {
      if (data.session) void go();
    });
    const { data } = supabase.auth.onAuthStateChange((_e, session) => {
      if (session) {
        router.invalidate();
        void go();
      }
    });
    return () => data.subscription.unsubscribe();
  }, [navigate, router, next]);

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (loading || googleLoading) return;
    setTimeoutError(null);
    setTimeoutSource(null);
    const formData = new FormData(e.currentTarget);
    setLoading(true);
    let timedOut = false;
    const timeoutId = setTimeout(() => {
      timedOut = true;
      setLoading(false);
      const msg = t(tx("Request timed out. Please try again.", "انتهت مهلة الطلب. حاول مرة أخرى."));
      setTimeoutError(msg);
      setTimeoutSource("form");
      toast.error(msg);
    }, 30000);
    try {
      if (mode === "signin") {
        const parsed = signInSchema.safeParse({
          email: formData.get("email"),
          password: formData.get("password"),
        });
        if (!parsed.success) {
          toast.error(parsed.error.issues[0].message);
          return;
        }
        const { error } = await supabase.auth.signInWithPassword(parsed.data);
        if (timedOut) return;
        if (error) {
          toast.error(error.message);
          return;
        }
        toast.success(t(tx("Welcome back!", "مرحباً بعودتك!")));
      } else {
        const raw = Object.fromEntries(formData) as Record<string, string>;
        const schema = accountType === "job_seeker" ? jobSeekerSignUpSchema : companySignUpSchema;
        const parsed = schema.safeParse(raw);
        if (!parsed.success) {
          toast.error(parsed.error.issues[0].message);
          return;
        }
        if (raw.confirm !== parsed.data.password) {
          toast.error(t(tx("Passwords do not match.", "كلمتا المرور غير متطابقتين.")));
          return;
        }
        const meta: Record<string, string> = {
          account_type: accountType,
          full_name: parsed.data.full_name,
          phone: parsed.data.phone || "",
          country: parsed.data.country || "",
        };
        if (accountType === "company") {
          meta.company_name = (parsed.data as z.infer<typeof companySignUpSchema>).company_name;
        }
        const { data: signUpData, error } = await supabase.auth.signUp({
          email: parsed.data.email,
          password: parsed.data.password,
          options: {
            emailRedirectTo: next
              ? `${window.location.origin}${next}`
              : `${window.location.origin}/`,
            data: meta,
          },
        });
        if (timedOut) return;
        if (error) {
          const m = error.message.toLowerCase();
          if (m.includes("already registered") || m.includes("already been registered")) {
            toast.error(
              t(
                tx(
                  "This email is already registered. Please sign in instead.",
                  "هذا البريد الإلكتروني مسجل بالفعل. يرجى تسجيل الدخول.",
                ),
              ),
            );
          } else {
            toast.error(
              t(
                tx(
                  "We couldn't complete your registration. Please review your details and try again.",
                  "تعذر إكمال التسجيل. يرجى مراجعة بياناتك والمحاولة مرة أخرى.",
                ),
              ),
            );
          }
          return;
        }
        if (!signUpData.session) {
          toast.success(
            t(
              tx(
                "Account created. Check your email to confirm your address.",
                "تم إنشاء الحساب. يرجى تأكيد بريدك الإلكتروني من الرسالة المرسلة إليك.",
              ),
            ),
          );
          return;
        }

        // Confirm the profile row really persisted every entered field before we
        // report success — the signup trigger writing is not observable otherwise.
        const saved = await persistProfile(signUpData.user?.id ?? signUpData.session.user.id, {
          account_type: accountType,
          full_name: parsed.data.full_name,
          company_name: meta.company_name ?? null,
          phone: parsed.data.phone || null,
          country: parsed.data.country || null,
          email: parsed.data.email,
        });
        if (timedOut) return;
        if (!saved) {
          toast.error(
            t(
              tx(
                "Your account was created but your details could not be saved. Please open your account page and complete them.",
                "تم إنشاء حسابك لكن تعذر حفظ بياناتك. يرجى فتح صفحة الحساب وإكمال البيانات.",
              ),
            ),
          );
          return;
        }
        toast.success(
          t(tx("Account created. You're signed in.", "تم إنشاء الحساب. تم تسجيل الدخول.")),
        );
      }
    } catch (err) {
      if (timedOut) return;
      toast.error(err instanceof Error ? err.message : String(err));
    } finally {
      clearTimeout(timeoutId);
      if (!timedOut) setLoading(false);
    }
  }

  async function handleGoogle() {
    if (googleLoading || loading) return;
    setTimeoutError(null);
    setTimeoutSource(null);
    setGoogleLoading(true);
    let timedOut = false;
    const timeoutId = setTimeout(() => {
      timedOut = true;
      setGoogleLoading(false);
      const msg = t(tx("Request timed out. Please try again.", "انتهت مهلة الطلب. حاول مرة أخرى."));
      setTimeoutError(msg);
      setTimeoutSource("google");
      toast.error(msg);
    }, 30000);
    try {
      const result = await lovable.auth.signInWithOAuth("google", {
        redirect_uri: next ? `${window.location.origin}${next}` : window.location.origin,
      });
      if (timedOut) return;
      if (result.error) {
        toast.error(
          result.error.message ?? t(tx("Google sign-in failed", "فشل تسجيل الدخول عبر جوجل")),
        );
      }
    } catch (err) {
      if (timedOut) return;
      toast.error(err instanceof Error ? err.message : String(err));
    } finally {
      clearTimeout(timeoutId);
      if (!timedOut) setGoogleLoading(false);
    }
  }

  const isAr = lang === "ar";

  return (
    <main className="min-h-screen bg-background pt-28 pb-16" dir={isAr ? "rtl" : "ltr"}>
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <h1 className="font-display text-3xl sm:text-4xl font-bold text-foreground">
            {t(tx("Welcome to SPHINX", "مرحباً بك في سفنكس"))}
          </h1>
          <p className="mt-3 text-sm sm:text-base text-muted-foreground max-w-xl mx-auto">
            {t(
              tx(
                "Sign in or create an account. Built for individuals seeking jobs and companies hiring workforce.",
                "سجّل الدخول أو أنشئ حساباً. مخصص للأفراد الباحثين عن وظائف والشركات التي توظف.",
              ),
            )}
          </p>
        </div>

        <Tabs
          value={accountType}
          onValueChange={(v) => setAccountType(v as AccountType)}
          className="w-full"
        >
          <TabsList className="grid w-full max-w-md mx-auto grid-cols-2">
            <TabsTrigger value="job_seeker" className="gap-2">
              <User className="h-4 w-4" />
              {t(ACCOUNT_TYPE_LABELS.job_seeker)}
            </TabsTrigger>
            <TabsTrigger value="company" className="gap-2">
              <Building2 className="h-4 w-4" />
              {t(ACCOUNT_TYPE_LABELS.company)}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="job_seeker" className="mt-8">
            <AuthCard
              icon={<User className="h-5 w-5" />}
              title={t(ACCOUNT_TYPE_LABELS.job_seeker)}
              description={t(
                tx(
                  "Apply to jobs, save listings, and track applications.",
                  "تقدّم للوظائف، احفظ الإعلانات، وتابع طلباتك.",
                ),
              )}
              mode={mode}
              setMode={setMode}
              loading={loading}
              googleLoading={googleLoading}
              onSubmit={handleSubmit}
              onGoogle={handleGoogle}
              accountType="job_seeker"
              timeoutError={timeoutError}
              timeoutSource={timeoutSource}
            />
          </TabsContent>

          <TabsContent value="company" className="mt-8">
            <AuthCard
              icon={<Building2 className="h-5 w-5" />}
              title={t(ACCOUNT_TYPE_LABELS.company)}
              description={t(tx("Post jobs.", "انشر الوظائف، ."))}
              mode={mode}
              setMode={setMode}
              loading={loading}
              googleLoading={googleLoading}
              onSubmit={handleSubmit}
              onGoogle={handleGoogle}
              accountType="company"
              timeoutError={timeoutError}
              timeoutSource={timeoutSource}
            />
          </TabsContent>
        </Tabs>

        <p className="mt-8 text-center text-xs text-muted-foreground">
          {t(
            tx(
              "By continuing you agree to our Terms and Privacy Policy.",
              "بمتابعتك فإنك توافق على الشروط وسياسة الخصوصية.",
            ),
          )}
        </p>
      </div>
    </main>
  );
}

function AuthCard(props: {
  icon: React.ReactNode;
  title: string;
  description: string;
  mode: Mode;
  setMode: (m: Mode) => void;
  loading: boolean;
  googleLoading: boolean;
  onSubmit: (e: React.FormEvent<HTMLFormElement>) => void;
  onGoogle: () => void;
  accountType: AccountType;
  timeoutError: string | null;
  timeoutSource: "form" | "google" | null;
}) {
  const { t } = useI18n();
  const {
    mode,
    setMode,
    loading,
    googleLoading,
    onSubmit,
    onGoogle,
    accountType,
    timeoutError,
    timeoutSource,
  } = props;
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const timeoutRef = useRef<HTMLDivElement>(null);
  const formRef = useRef<HTMLFormElement>(null);
  const check = checkPassword(password, confirm);
  const allPass = mode === "signup" && Object.values(check).every(Boolean);

  useEffect(() => {
    if (timeoutError && timeoutRef.current) {
      timeoutRef.current.focus();
    }
  }, [timeoutError]);

  return (
    <Card className="mx-auto max-w-xl border-border/60 shadow-elegant">
      <CardHeader>
        <div className="flex items-center gap-3">
          <span className="inline-flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-gold text-primary-foreground">
            {props.icon}
          </span>
          <div>
            <CardTitle className="font-display text-xl">{props.title}</CardTitle>
            <CardDescription className="text-sm">{props.description}</CardDescription>
          </div>
        </div>

        <div className="mt-5 grid grid-cols-2 rounded-md bg-muted/50 p-1">
          <button
            type="button"
            onClick={() => setMode("signin")}
            className={cn(
              "rounded px-3 py-1.5 text-sm font-medium transition-colors",
              mode === "signin"
                ? "bg-background shadow-sm text-foreground"
                : "text-muted-foreground",
            )}
          >
            {t(tx("Sign in", "تسجيل الدخول"))}
          </button>
          <button
            type="button"
            onClick={() => setMode("signup")}
            className={cn(
              "rounded px-3 py-1.5 text-sm font-medium transition-colors",
              mode === "signup"
                ? "bg-background shadow-sm text-foreground"
                : "text-muted-foreground",
            )}
          >
            {t(tx("Create account", "إنشاء حساب"))}
          </button>
        </div>
      </CardHeader>

      <CardContent>
        <form
          ref={formRef}
          onSubmit={onSubmit}
          className="space-y-4"
          key={`${accountType}-${mode}`}
          aria-busy={loading || googleLoading}
        >
          <div aria-live="polite" aria-atomic="true" className="sr-only">
            {timeoutError
              ? timeoutError
              : loading || googleLoading
                ? t(tx("Processing request, please wait.", "جارٍ معالجة الطلب، يرجى الانتظار."))
                : t(tx("Form ready.", "النموذج جاهز."))}
          </div>
          {mode === "signup" && accountType === "company" && (
            <Field
              name="company_name"
              label={t(tx("Company name", "اسم الشركة"))}
              placeholder={t(tx("Acme Industries", "شركة المثال"))}
              required
            />
          )}
          {mode === "signup" && (
            <Field
              name="full_name"
              label={
                accountType === "company"
                  ? t(tx("Contact person", "الشخص المسؤول"))
                  : t(tx("Full name", "الاسم الكامل"))
              }
              placeholder={t(tx("Your name", "اسمك"))}
              required
            />
          )}

          <Field
            name="email"
            type="email"
            label={t(tx("Email", "البريد الإلكتروني"))}
            placeholder="you@example.com"
            icon={<Mail className="h-4 w-4" />}
            required
          />

          {mode === "signup" && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Field name="phone" label={t(tx("Phone", "الهاتف"))} placeholder="+966 ..." />
              <div className="space-y-1.5">
                <Label htmlFor="country">{t(tx("Country", "الدولة"))}</Label>
                <select
                  id="country"
                  name="country"
                  defaultValue=""
                  className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                >
                  <option value="">{t(tx("Select country…", "اختر الدولة…"))}</option>
                  {COUNTRIES.map((c) => (
                    <option key={c.en} value={c.en}>
                      {t(c)}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          )}

          <Field
            name="password"
            type="password"
            label={t(tx("Password", "كلمة المرور"))}
            placeholder="••••••••"
            icon={<Lock className="h-4 w-4" />}
            required
            minLength={mode === "signup" ? 8 : undefined}
            value={password}
            onChange={(v: string) => setPassword(v)}
          />

          {mode === "signup" && (
            <>
              <Field
                name="confirm"
                type="password"
                label={t(tx("Confirm password", "تأكيد كلمة المرور"))}
                placeholder="••••••••"
                icon={<Lock className="h-4 w-4" />}
                required
                minLength={8}
                value={confirm}
                onChange={(v: string) => setConfirm(v)}
              />
              <PasswordStrength check={checkPassword(password, confirm)} />
            </>
          )}

          {mode === "signin" && (
            <div className="-mt-2 text-right rtl:text-left">
              <Link
                to="/forgot-password"
                className="text-xs font-medium text-gold-dark hover:underline"
              >
                {t(tx("Forgot password?", "نسيت كلمة المرور؟"))}
              </Link>
            </div>
          )}

          {timeoutError && (
            <div
              ref={timeoutRef}
              tabIndex={-1}
              role="alert"
              className="rounded-md bg-destructive/10 text-destructive px-3 py-2 text-sm outline-none flex items-center justify-between gap-3"
            >
              <span>{timeoutError}</span>
              <button
                type="button"
                onClick={() => {
                  if (timeoutSource === "google") {
                    onGoogle();
                  } else {
                    formRef.current?.requestSubmit();
                  }
                }}
                className="shrink-0 rounded bg-destructive px-2.5 py-1 text-xs font-semibold text-destructive-foreground hover:bg-destructive/90 transition-colors"
              >
                {t(tx("Try again", "حاول مرة أخرى"))}
              </button>
            </div>
          )}

          <Button
            type="submit"
            disabled={loading || googleLoading || (mode === "signup" && !allPass)}
            className="w-full bg-gradient-gold text-primary-foreground font-semibold hover:shadow-gold"
          >
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                {mode === "signin"
                  ? t(tx("Signing in…", "جارٍ تسجيل الدخول…"))
                  : t(tx("Creating account…", "جارٍ إنشاء الحساب…"))}
              </>
            ) : mode === "signin" ? (
              t(tx("Sign in", "تسجيل الدخول"))
            ) : accountType === "company" ? (
              t(tx("Create company account", "إنشاء حساب شركة"))
            ) : (
              t(tx("Create account", "إنشاء حساب"))
            )}
          </Button>

          <div className="relative py-1">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-border/60" />
            </div>
            <div className="relative flex justify-center text-xs uppercase tracking-wider">
              <span className="bg-background px-2 text-muted-foreground">{t(tx("or", "أو"))}</span>
            </div>
          </div>

          <Button
            type="button"
            variant="outline"
            onClick={onGoogle}
            disabled={loading || googleLoading}
            className="w-full"
          >
            {googleLoading ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <GoogleIcon className="h-4 w-4" />
            )}
            {t(tx("Continue with Google", "المتابعة بحساب جوجل"))}
          </Button>

          <p className="text-center text-xs text-muted-foreground pt-2">
            {mode === "signin" ? (
              <>
                {t(tx("No account yet?", "ليس لديك حساب؟"))}{" "}
                <button
                  type="button"
                  onClick={() => setMode("signup")}
                  className="font-semibold text-gold-dark hover:underline"
                >
                  {t(tx("Create one", "أنشئ حساباً"))}
                </button>
              </>
            ) : (
              <>
                {t(tx("Already have an account?", "هل لديك حساب بالفعل؟"))}{" "}
                <button
                  type="button"
                  onClick={() => setMode("signin")}
                  className="font-semibold text-gold-dark hover:underline"
                >
                  {t(tx("Sign in", "تسجيل الدخول"))}
                </button>
              </>
            )}
          </p>
        </form>
      </CardContent>
    </Card>
  );
}

function Field(props: {
  name: string;
  label: string;
  type?: string;
  placeholder?: string;
  required?: boolean;
  minLength?: number;
  icon?: React.ReactNode;
  value?: string;
  onChange?: (v: string) => void;
}) {
  const {
    name,
    label,
    type = "text",
    placeholder,
    required,
    minLength,
    icon,
    value,
    onChange,
  } = props;
  return (
    <div className="space-y-1.5">
      <Label htmlFor={name}>{label}</Label>
      <div className="relative">
        {icon && (
          <span className="pointer-events-none absolute inset-y-0 left-3 flex items-center text-muted-foreground">
            {icon}
          </span>
        )}
        <Input
          id={name}
          name={name}
          type={type}
          placeholder={placeholder}
          required={required}
          minLength={minLength}
          value={value}
          onChange={onChange ? (e) => onChange(e.target.value) : undefined}
          autoComplete={
            type === "password"
              ? name === "password"
                ? "current-password"
                : "new-password"
              : name === "email"
                ? "email"
                : "off"
          }
          className={icon ? "pl-9" : undefined}
        />
      </div>
    </div>
  );
}

function GoogleIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" aria-hidden="true">
      <path
        fill="#EA4335"
        d="M12 10.2v3.9h5.5c-.2 1.4-1.6 4.1-5.5 4.1-3.3 0-6-2.7-6-6.1s2.7-6.1 6-6.1c1.9 0 3.1.8 3.8 1.5l2.6-2.5C16.8 3.6 14.6 2.7 12 2.7 6.9 2.7 2.8 6.8 2.8 12s4.1 9.3 9.2 9.3c5.3 0 8.8-3.7 8.8-9 0-.6-.1-1-.2-1.5H12z"
      />
    </svg>
  );
}
