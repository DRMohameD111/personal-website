import { createFileRoute } from "@tanstack/react-router";
import {
  Target,
  Eye,
  Award,
  Users,
  Globe2,
  Briefcase,
  ShieldCheck,
  Sparkles,
  Heart,
} from "lucide-react";
import { useI18n, tx } from "@/i18n";
import { imagery, brand } from "@/brand";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — SPHINX Workforce" },
      {
        name: "description",
        content:
          "SPHINX Workforce — a premium manpower partner combining enterprise HR discipline with ancient Egyptian elegance. Serving Saudi Arabia, the GCC and Egypt.",
      },
      { property: "og:title", content: "About SPHINX Workforce" },
      {
        property: "og:description",
        content: "Premium workforce outsourcing partner for Saudi Arabia, the GCC and Egypt.",
      },
      { property: "og:image", content: imagery.aboutLeadership },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  const { t } = useI18n();

  const stats = [
    { icon: Users, value: "5,000+", label: tx("Active Candidates", "مرشح نشط") },
    { icon: Briefcase, value: "500+", label: tx("Corporate Clients", "عميل مؤسسي") },
    { icon: Globe2, value: "9", label: tx("Countries Served", "دول مخدومة") },
    { icon: Award, value: "98%", label: tx("Client Retention", "نسبة الاحتفاظ بالعملاء") },
  ];

  const values = [
    {
      icon: ShieldCheck,
      title: tx("Integrity", "النزاهة"),
      desc: tx(
        "Transparent contracts, ethical hiring, and full regulatory compliance.",
        "عقود واضحة وتوظيف أخلاقي والتزام كامل بالأنظمة.",
      ),
    },
    {
      icon: Sparkles,
      title: tx("Excellence", "التميّز"),
      desc: tx("Quality-first vetting. .", "تدقيق صارم للجودة، ."),
    },
    {
      icon: Heart,
      title: tx("Partnership", "الشراكة"),
      desc: tx(
        "We treat client operations as our own — long-term, accountable, hands-on.",
        "نتعامل مع عمليات عملائنا كأنها عملياتنا، شراكة طويلة ومسؤولة.",
      ),
    },
    {
      icon: Globe2,
      title: tx("Regional Mastery", "تمكّن إقليمي"),
      desc: tx(
        "Deep fluency in Saudi, GCC and Egyptian labour markets, languages and culture.",
        "إلمام عميق بأسواق العمل في السعودية والخليج ومصر، لغة وثقافة.",
      ),
    },
  ];

  return (
    <main className="min-h-screen">
      {/* Hero */}
      <section className="relative pt-32 pb-20 md:pt-44 md:pb-28">
        <div className="absolute inset-0 bg-gradient-hero" />
        <div className="relative mx-auto max-w-5xl px-4 text-center sm:px-6 lg:px-8">
          <span className="text-xs font-semibold uppercase tracking-[0.25em] text-gold-dark">
            {t(tx("About SPHINX Workforce", "عن سفنكس للقوى العاملة"))}
          </span>
          <h1 className="mt-3 font-display text-4xl font-bold tracking-tight text-foreground md:text-6xl">
            {t(
              tx(
                "The discipline of HR. The poise of a civilisation.",
                "انضباط الموارد البشرية و وقار حضارة.",
              ),
            )}
          </h1>
          <div className="gold-divider mx-auto mt-6 w-24" />
          <p className="mx-auto mt-6 max-w-2xl text-base text-muted-foreground md:text-lg">
            {t(
              tx(
                "We are a premium workforce partner serving Saudi Arabia, the GCC and Egypt — engineered for speed, compliance and enterprise-grade service.",
                "شريك متميّز للقوى العاملة في السعودية والخليج ومصر، مصمّم للسرعة والالتزام وخدمة المؤسسات الكبرى.",
              ),
            )}
          </p>
          <p className="mt-5 font-display text-sm tracking-[0.4em] text-gold-dark">
            {brand.tagline.ar}
          </p>
        </div>
      </section>

      {/* Who We Are */}
      <section className="py-20">
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 sm:px-6 lg:grid-cols-2 lg:px-8">
          <div className="overflow-hidden rounded-2xl ring-inset-gold">
            <img src={imagery.aboutLeadership} alt="" className="h-[460px] w-full object-cover" />
          </div>
          <div>
            <span className="text-xs font-semibold uppercase tracking-[0.25em] text-gold-dark">
              {t(tx("Who We Are", "من نحن"))}
            </span>
            <h2 className="mt-3 font-display text-3xl font-bold text-foreground md:text-4xl">
              {t(
                tx(
                  "A modern manpower house with timeless standards.",
                  "بيت قوى عاملة عصري بمعايير حضارية.",
                ),
              )}
            </h2>
            <div className="gold-divider mt-5 w-20" />
            <p className="mt-6 text-base leading-relaxed text-muted-foreground">
              {t(
                tx(
                  "Founded to elevate workforce outsourcing in the region, SPHINX combines a decade of enterprise HR experience with technology-driven recruitment, ethical sourcing and the operational rigour required by mega-projects.",
                  "تأسست سفنكس لتعيد تعريف تعهيد القوى العاملة في المنطقة، نمزج خبرة عقد كامل في الموارد البشرية المؤسسية بالتوظيف المدعوم بالتقنية والمصادر الأخلاقية والانضباط التشغيلي الذي تتطلبه المشاريع الكبرى.",
                ),
              )}
            </p>
            <p className="mt-5 text-base leading-relaxed text-muted-foreground">
              {t(
                tx(
                  "From a single skilled technician to a 500-strong industrial workforce — we mobilise, manage and retain talent at scale.",
                  "من فنّي ماهر واحد إلى فريق عمل متكامل — نحن نوفق بين اصحاب  المواهب و اصحاب  الفرص الحقيقية",
                ),
              )}
            </p>
          </div>
        </div>
      </section>

      {/* Mission / Vision */}
      <section className="py-20 border-t border-border/40">
        <div className="mx-auto grid max-w-7xl gap-6 px-4 sm:px-6 md:grid-cols-2 lg:px-8">
          {[
            {
              icon: Target,
              title: tx("Our Mission", "مهمتنا"),
              desc: tx(
                "To deliver compliant, skilled and rapidly deployable workforce solutions that let enterprises focus on what they build best.",
                "تقديم حلول قوى عاملة ماهرة وسريعة النشر وملتزمة بالأنظمة، تتيح للمؤسسات التركيز على ما تجيده.",
              ),
            },
            {
              icon: Eye,
              title: tx("Our Vision", "رؤيتنا"),
              desc: tx(
                "To be the most trusted workforce partner across Saudi Arabia, the GCC and Egypt — a name synonymous with excellence and integrity.",
                "أن نكون شريك القوى العاملة الأكثر ثقة في السعودية والخليج ومصر، اسماً مرادفاً للتميّز والنزاهة.",
              ),
            },
          ].map((b) => (
            <div
              key={b.title.en}
              className="rounded-2xl bg-gradient-card ring-inset-gold p-10 hover-lift"
            >
              <div className="inline-flex h-12 w-12 items-center justify-center rounded-xl bg-primary/15 ring-1 ring-primary/30">
                <b.icon className="h-6 w-6 text-gold-dark" />
              </div>
              <h3 className="mt-5 font-display text-2xl font-semibold text-foreground">
                {t(b.title)}
              </h3>
              <p className="mt-4 text-base leading-relaxed text-muted-foreground">{t(b.desc)}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Core Values */}
      <section className="py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <span className="text-xs font-semibold uppercase tracking-[0.25em] text-gold-dark">
              {t(tx("Core Values", "قيمنا الجوهرية"))}
            </span>
            <h2 className="mt-3 font-display text-3xl font-bold text-foreground md:text-4xl">
              {t(tx("What we stand on.", "على ماذا نقف."))}
            </h2>
            <div className="gold-divider mx-auto mt-5 w-24" />
          </div>
          <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {values.map((v) => (
              <div
                key={v.title.en}
                className="rounded-2xl bg-gradient-card ring-inset-gold p-7 hover-lift"
              >
                <v.icon className="h-7 w-7 text-gold-dark" />
                <h3 className="mt-5 font-display text-lg font-semibold text-foreground">
                  {t(v.title)}
                </h3>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{t(v.desc)}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-20 border-t border-border/40">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {stats.map((s) => (
              <div key={s.value} className="rounded-2xl bg-gradient-gold p-[1px] hover-lift">
                <div className="rounded-2xl bg-card p-7 text-center">
                  <s.icon className="mx-auto h-7 w-7 text-gold-dark" />
                  <div className="mt-4 font-display text-4xl font-bold text-foreground">
                    {s.value}
                  </div>
                  <div className="mt-2 text-xs uppercase tracking-widest text-muted-foreground">
                    {t(s.label)}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}
