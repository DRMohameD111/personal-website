import { createFileRoute, Link, redirect } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { User, Building2, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useI18n, tx } from "@/i18n";

export const Route = createFileRoute("/choose-role")({
  beforeLoad: async () => {
    const {
      data: { session },
    } = await supabase.auth.getSession();
    if (!session) throw redirect({ to: "/auth" });
  },
  head: () => ({
    meta: [
      { title: "Choose Your Role — SPHINX Workforce" },
      {
        name: "description",
        content:
          "Select whether you are an individual job seeker or a company hiring workforce on SPHINX.",
      },
      { property: "og:title", content: "Choose Your Role — SPHINX Workforce" },
      {
        property: "og:description",
        content: "Individuals and companies — pick your path on SPHINX Workforce.",
      },
    ],
  }),
  component: ChooseRolePage,
});

function ChooseRolePage() {
  const { t } = useI18n();

  const options = [
    {
      key: "job_seeker",
      icon: User,
      title: tx("Individual – Job Seeker", "فرد – طالب وظيفة"),
      desc: tx(
        "Job seekers looking to find their next opportunity.",
        "الباحثون عن عمل لإيجاد فرصتهم القادمة.",
      ),
      to: "/job-seekers",
    },
    {
      key: "company",
      icon: Building2,
      title: tx("Company Client – Job Poster", "دخول الشركات"),
      desc: tx(
        "Employers hiring skilled workforce across the GCC.",
        "أصحاب العمل الباحثون عن كوادر ماهرة في الخليج.",
      ),
      to: "/employers",
    },
  ];

  return (
    <main className="relative min-h-screen pt-32 pb-24 md:pt-44">
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <span className="text-xs font-semibold uppercase tracking-[0.25em] text-gold-dark">
            {t(tx("Step 2 of 3", "الخطوة 2 من 3"))}
          </span>
          <h1 className="mt-3 font-display text-3xl font-bold text-foreground md:text-5xl">
            {t(tx("Who are you?", "من أنت؟"))}
          </h1>
          <div className="gold-divider mx-auto mt-5 w-24" />
          <p className="mt-5 text-base text-muted-foreground md:text-lg">
            {t(
              tx(
                "Choose individuals or companies to continue.",
                "اختر الأفراد أو الشركات للمتابعة.",
              ),
            )}
          </p>
        </div>

        <div className="mt-14 grid gap-6 md:grid-cols-2">
          {options.map((o) => (
            <Link key={o.key} to={o.to} className="group block">
              <div className="rounded-2xl bg-gradient-card ring-inset-gold p-8 hover-lift h-full">
                <div className="inline-flex h-14 w-14 items-center justify-center rounded-xl bg-primary/15 ring-1 ring-primary/30">
                  <o.icon className="h-7 w-7 text-gold-dark" />
                </div>
                <h2 className="mt-5 font-display text-2xl font-semibold text-foreground">
                  {t(o.title)}
                </h2>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{t(o.desc)}</p>
                <div className="mt-6 inline-flex items-center gap-2 text-gold-dark text-sm font-semibold">
                  {t(tx("Continue", "متابعة"))}
                  <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                </div>
              </div>
            </Link>
          ))}
        </div>

        <div className="mt-10 text-center">
          <Link to="/auth">
            <Button
              variant="outline"
              className="border-primary/60 text-gold-dark hover:bg-primary/10"
            >
              {t(tx("Back to Sign In", "العودة لتسجيل الدخول"))}
            </Button>
          </Link>
        </div>
      </div>
    </main>
  );
}
