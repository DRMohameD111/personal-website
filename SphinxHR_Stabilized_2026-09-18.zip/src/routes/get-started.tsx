import { createFileRoute, Link, redirect } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { Briefcase, Search, ArrowRight } from "lucide-react";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { useI18n, tx } from "@/i18n";

const searchSchema = z.object({
  role: z.enum(["job_seeker", "company"]).catch("job_seeker"),
});

export const Route = createFileRoute("/get-started")({
  beforeLoad: async () => {
    const {
      data: { session },
    } = await supabase.auth.getSession();
    if (!session) throw redirect({ to: "/auth" });
  },
  validateSearch: searchSchema,
  head: () => ({
    meta: [
      { title: "Get Started — SPHINX Workforce" },
      {
        name: "description",
        content:
          "Post a new job or request a job on SPHINX Workforce — your next step is one click away.",
      },
      { property: "og:title", content: "Get Started — SPHINX Workforce" },
      {
        property: "og:description",
        content: "Post a job or request a job on SPHINX Workforce.",
      },
    ],
  }),
  component: GetStartedPage,
});

function GetStartedPage() {
  const { t } = useI18n();
  const { role } = Route.useSearch();

  const isCompany = role === "company";

  const primary = isCompany
    ? {
        icon: Briefcase,
        title: tx("Post a Job", "نشر وظيفة"),
        desc: tx(
          "Publish a new opening and reach pre-vetted candidates within 48 hours.",
          "انشر وظيفة جديدة وصل إلى مرشحين مؤهلين خلال 48 ساعة.",
        ),
        to: "/employers",
        cta: tx("Post a Job", "نشر وظيفة"),
      }
    : {
        icon: Search,
        title: tx("Request a Job", "طلب وظيفة"),
        desc: tx(
          "Submit your profile and let SPHINX match you with the right employer.",
          "أرسل ملفك الشخصي ودع سفنكس تربطك بصاحب العمل المناسب.",
        ),
        to: "/job-seekers",
        cta: tx("Request a Job", "طلب وظيفة"),
      };

  const secondary = isCompany
    ? {
        icon: Search,
        title: tx("Browse Talent", "تصفّح المواهب"),
        desc: tx(
          "Explore active job seekers ready for placement.",
          "استكشف الباحثين عن عمل الجاهزين للتوظيف.",
        ),
        to: "/jobs",
        cta: tx("Browse Talent", "تصفّح المواهب"),
      }
    : {
        icon: Briefcase,
        title: tx("Browse Jobs", "تصفّح الوظائف"),
        desc: tx(
          "See open vacancies from leading employers.",
          "اطلع على الوظائف الشاغرة من كبرى الشركات.",
        ),
        to: "/jobs",
        cta: tx("Browse Jobs", "تصفّح الوظائف"),
      };

  const cards = [primary, secondary];

  return (
    <main className="relative min-h-screen pt-32 pb-24 md:pt-44">
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <span className="text-xs font-semibold uppercase tracking-[0.25em] text-gold-dark">
            {t(tx("Step 3 of 3", "الخطوة 3 من 3"))}
          </span>
          <h1 className="mt-3 font-display text-3xl font-bold text-foreground md:text-5xl">
            {isCompany
              ? t(tx("Post or find talent", "انشر وظيفة أو ابحث عن مواهب"))
              : t(tx("Find or request a job", "ابحث عن وظيفة أو اطلبها"))}
          </h1>
          <div className="gold-divider mx-auto mt-5 w-24" />
          <p className="mt-5 text-base text-muted-foreground md:text-lg">
            {isCompany
              ? t(
                  tx(
                    "Choose how you would like to proceed as a company.",
                    "اختر كيف ترغب في المتابعة كشركة.",
                  ),
                )
              : t(
                  tx(
                    "Choose how you would like to proceed as an individual.",
                    "اختر كيف ترغب في المتابعة كفرد.",
                  ),
                )}
          </p>
        </div>

        <div className="mt-14 grid gap-6 md:grid-cols-2">
          {cards.map((c) => (
            <Link key={c.to + c.title.en} to={c.to} className="group block">
              <div className="rounded-2xl bg-gradient-card ring-inset-gold p-8 hover-lift h-full">
                <div className="inline-flex h-14 w-14 items-center justify-center rounded-xl bg-primary/15 ring-1 ring-primary/30">
                  <c.icon className="h-7 w-7 text-gold-dark" />
                </div>
                <h2 className="mt-5 font-display text-2xl font-semibold text-foreground">
                  {t(c.title)}
                </h2>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{t(c.desc)}</p>
                <div className="mt-6 inline-flex items-center gap-2 text-gold-dark text-sm font-semibold">
                  {t(c.cta)}
                  <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                </div>
              </div>
            </Link>
          ))}
        </div>

        <div className="mt-10 text-center">
          <Link to="/choose-role">
            <Button
              variant="outline"
              className="border-primary/60 text-gold-dark hover:bg-primary/10"
            >
              {t(tx("Back", "رجوع"))}
            </Button>
          </Link>
        </div>
      </div>
    </main>
  );
}
