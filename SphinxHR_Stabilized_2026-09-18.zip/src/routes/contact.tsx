import { createFileRoute, useSearch, useNavigate } from "@tanstack/react-router";
import { cn } from "@/lib/utils";
import {
  AlertTriangle,
  ArrowRight,
  Building2,
  CheckCircle2,
  FileText,
  Pencil,
  User,
} from "lucide-react";
import { useState, useEffect } from "react";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — SPHINX Workforce" },
      {
        name: "description",
        content:
          "Get in touch with SPHINX Workforce. Request workforce solutions or find your next career opportunity across Saudi Arabia and the GCC.",
      },
      { property: "og:title", content: "Contact — SPHINX Workforce" },
      {
        property: "og:description",
        content:
          "Request workforce solutions or find your next career opportunity across Saudi Arabia and the GCC.",
      },
    ],
  }),
  component: ContactPage,
});

const serviceLabels: Record<string, string> = {
  outsourcing: "Workforce Outsourcing",
  manpower: "Manpower Supply",
  bluecollar: "Blue Collar Recruitment",
  technical: "Technical Staffing",
  leasing: "Employee Leasing",
  temporary: "Temporary Staffing",
  facility: "Facility Management Workforce",
  industrial: "Industrial Workforce Solutions",
};

const pathwayLabels: Record<string, string> = {
  "request-workforce": "Request Workforce",
  "find-job": "Find a Job",
};

const intentSummaries: Record<string, Record<string, string>> = {
  "request-workforce": {
    outsourcing: "End-to-end outsourcing with recruitment, payroll & compliance",
    manpower: "Rapid deployment of qualified personnel across KSA & GCC",
    bluecollar: "Skilled tradespeople with full documentation & mobilisation",
    technical: "Engineers & technicians for energy, construction & industrial projects",
    leasing: "Flexible long-term staffing with full HR administration",
    temporary: "Short-term workforce coverage for seasonal peaks & project ramps",
    facility: "Dedicated facility management workforce teams",
    industrial: "Large-scale industrial workforce with safety training & site induction",
  },
  "find-job": {
    outsourcing: "Roles in recruitment coordination, payroll & compliance support",
    manpower: "Job opportunities across Saudi Arabia & the GCC",
    bluecollar: "Skilled trades & labour opportunities with mobilisation support",
    technical: "Engineering & technician roles in energy, construction & industry",
    leasing: "Long-term leased employment with full HR administration",
    temporary: "Short-term & project-based assignments",
    facility: "Maintenance, operations, security & hospitality roles",
    industrial: "Large-scale labour & on-site industrial opportunities",
  },
};

const serviceMessages: Record<string, Record<string, string>> = {
  "request-workforce": {
    outsourcing:
      "I am interested in workforce outsourcing services. Please share details about your end-to-end recruitment, payroll, and compliance solutions.",
    manpower:
      "I need manpower supply support. Please provide information on rapid deployment of qualified personnel across Saudi Arabia and the GCC.",
    bluecollar:
      "We are looking for blue collar recruitment services. Please share how you source, vet, and mobilise skilled tradespeople with full documentation support.",
    technical:
      "I require technical staffing for an energy / construction / industrial project. Please send details on your engineer and technician deployment capabilities.",
    leasing:
      "I am interested in employee leasing. Please outline your flexible long-term staffing and full HR administration offering.",
    temporary:
      "We need temporary staffing for a seasonal peak / project ramp. Please share how quickly you can deploy short-term workforce coverage.",
    facility:
      "I need a dedicated facility management workforce. Please provide details on your maintenance, operations, security, and hospitality teams.",
    industrial:
      "We are looking for large-scale industrial workforce solutions. Please share your approach to safety training, site induction, and ongoing workforce management.",
  },
  "find-job": {
    outsourcing:
      "I am looking for a role within workforce outsourcing. Please share current opportunities in recruitment coordination, payroll administration, or compliance support.",
    manpower:
      "I am interested in job opportunities through your manpower supply network. Please share current openings across Saudi Arabia and the GCC.",
    bluecollar:
      "I am a skilled tradesperson / labourer seeking blue collar opportunities. Please share available roles and your mobilisation process.",
    technical:
      "I am an engineer / technician seeking technical staffing roles. Please share current opportunities in energy, construction, or industrial projects.",
    leasing:
      "I am looking for long-term leased employment opportunities. Please share roles where full HR administration is handled by SPHINX.",
    temporary:
      "I am looking for temporary / seasonal work. Please share short-term assignments and project-based opportunities.",
    facility:
      "I am looking for a facility management role. Please share openings in maintenance, operations, security, or hospitality.",
    industrial:
      "I am seeking industrial workforce roles. Please share current large-scale labour programs and on-site opportunities.",
  },
};

function ContactPage() {
  const search = useSearch({ from: "/contact" }) as {
    pathway?: "request-workforce" | "find-job";
    service?: string;
    name?: string;
    email?: string;
    phone?: string;
    company?: string;
    message?: string;
  };
  const navigate = useNavigate({ from: "/contact" });

  const activePathway = search.pathway ?? "request-workforce";
  const selectedService = search.service ?? "";
  const serviceName = serviceLabels[selectedService] ?? "";

  const defaultMessage = serviceMessages[activePathway]?.[selectedService] ?? "";

  const STORAGE_KEY = "sphinx:contact-form";
  const readStored = (): Partial<
    Record<"name" | "email" | "phone" | "company" | "message", string>
  > => {
    if (typeof window === "undefined") return {};
    const parse = (raw: string | null) => {
      try {
        return raw ? (JSON.parse(raw) ?? {}) : {};
      } catch {
        return {};
      }
    };
    try {
      const local = window.localStorage.getItem(STORAGE_KEY);
      if (local) return parse(local);
    } catch {
      // localStorage unavailable; fall through to sessionStorage
    }
    try {
      return parse(window.sessionStorage.getItem(STORAGE_KEY));
    } catch {
      return {};
    }
  };
  const stored = readStored();

  const [formPathway, setFormPathway] = useState(activePathway);
  const [formService, setFormService] = useState(selectedService);
  const [formMessage, setFormMessage] = useState(stored.message ?? defaultMessage);
  const [formName, setFormName] = useState(stored.name ?? "");
  const [formEmail, setFormEmail] = useState(stored.email ?? "");
  const [formPhone, setFormPhone] = useState(stored.phone ?? "");
  const [formCompany, setFormCompany] = useState(stored.company ?? "");

  useEffect(() => {
    setFormPathway(activePathway);
    setFormService(selectedService);
    setFormMessage(defaultMessage);
  }, [activePathway, selectedService, defaultMessage]);

  const [saved, setSaved] = useState(false);
  const [saveError, setSaveError] = useState(false);
  const [usingFallback, setUsingFallback] = useState(false);

  const tryAutosave = () => {
    if (typeof window === "undefined") return;
    const payload = JSON.stringify({
      name: formName,
      email: formEmail,
      phone: formPhone,
      company: formCompany,
      message: formMessage,
    });
    try {
      window.localStorage.setItem(STORAGE_KEY, payload);
      // Clear any stale fallback copy so localStorage stays authoritative
      try {
        window.sessionStorage.removeItem(STORAGE_KEY);
      } catch {
        /* ignore */
      }
      setUsingFallback(false);
      setSaveError(false);
      setSaved(true);
      return;
    } catch {
      // localStorage failed (quota, privacy mode, etc.) — try sessionStorage
    }
    try {
      window.sessionStorage.setItem(STORAGE_KEY, payload);
      setUsingFallback(true);
      setSaveError(false);
      setSaved(true);
    } catch {
      setUsingFallback(false);
      setSaveError(true);
      setSaved(false);
    }
  };

  // Autosave form fields to localStorage so a refresh restores progress
  useEffect(() => {
    tryAutosave();
    if (saveError) return;
    const t = setTimeout(() => setSaved(false), 2000);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [formName, formEmail, formPhone, formCompany, formMessage]);

  // Navigate keeping only non-sensitive params in the URL.
  // PII (name, email, phone, company, message) is never written to the URL —
  // it is persisted locally via localStorage/sessionStorage instead.
  const updateSearch = (patch: Record<string, unknown>) => {
    navigate({
      search: (prev: Record<string, unknown>) => {
        const { name, email, phone, company, message, ...safe } = prev;
        return { ...safe, ...patch };
      },
    });
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Hero */}
      <section className="relative overflow-hidden py-20 md:py-28">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mb-12 text-center">
            <span className="mb-3 inline-block text-xs font-semibold uppercase tracking-[0.2em] text-gold-dark">
              Get Started
            </span>
            <h1 className="font-display text-3xl font-bold tracking-tight text-foreground md:text-4xl lg:text-5xl">
              Contact SPHINX Workforce
            </h1>
            <div className="gold-divider mx-auto mt-6 w-24" />
            <p className="mx-auto mt-5 max-w-2xl text-base text-muted-foreground md:text-lg">
              Whether you need talent deployed at scale or are searching for your next opportunity,
              we are here to help.
            </p>
          </div>

          {/* Pathway selector */}
          <div className="mx-auto flex max-w-md flex-col gap-3 sm:flex-row">
            <PathwayCard
              id="request-workforce"
              label="Request Workforce"
              description="I need skilled personnel for my company or project."
              icon={<Building2 className="h-5 w-5" />}
              active={activePathway === "request-workforce"}
            />
            <PathwayCard
              id="find-job"
              label="Find a Job"
              description="I am looking for my next career opportunity."
              icon={<User className="h-5 w-5" />}
              active={activePathway === "find-job"}
            />
          </div>

          {/* Service summary banner */}
          {serviceName && (
            <ServiceSummaryBanner
              pathwayKey={activePathway}
              serviceKey={selectedService}
              pathway={pathwayLabels[activePathway]}
              service={serviceName}
              intent={
                intentSummaries[activePathway]?.[selectedService] ??
                (activePathway === "request-workforce"
                  ? "Workforce solution inquiry"
                  : "Career opportunity inquiry")
              }
              onChange={updateSearch}
            />
          )}
        </div>
      </section>

      {/* Form */}
      <section className="pb-24 md:pb-32">
        <div className="mx-auto max-w-2xl px-4 sm:px-6 lg:px-8">
          <form className="space-y-6 rounded-2xl bg-gradient-card ring-inset-gold p-8 md:p-10">
            <div className="grid gap-6 sm:grid-cols-2">
              <Field
                label="Full Name"
                name="name"
                type="text"
                placeholder="Your name"
                value={formName}
                onChange={(v) => setFormName(v)}
                required
              />
              <Field
                label="Email"
                name="email"
                type="email"
                placeholder="you@company.com"
                value={formEmail}
                onChange={(v) => setFormEmail(v)}
                required
              />
            </div>
            <div className="grid gap-6 sm:grid-cols-2">
              <Field
                label="Phone"
                name="phone"
                type="tel"
                placeholder="+966 5X XXX XXXX"
                value={formPhone}
                onChange={(v) => setFormPhone(v)}
              />
              <Field
                label="Company"
                name="company"
                type="text"
                placeholder="Company name (if applicable)"
                value={formCompany}
                onChange={(v) => setFormCompany(v)}
              />
            </div>
            <div className="grid gap-6 sm:grid-cols-2">
              <div className="flex flex-col gap-2">
                <label htmlFor="pathway" className="text-sm font-medium text-foreground">
                  Inquiry Type
                </label>
                <select
                  id="pathway"
                  name="pathway"
                  value={formPathway}
                  onChange={(e) => updateSearch({ pathway: e.target.value })}
                  className={cn(
                    "rounded-lg border border-input bg-background px-3 py-2.5 text-sm text-foreground",
                    "focus:outline-none focus:ring-2 focus:ring-ring",
                  )}
                >
                  <option value="request-workforce">Request Workforce</option>
                  <option value="find-job">Find a Job</option>
                </select>
              </div>
              <div className="flex flex-col gap-2">
                <label htmlFor="service" className="text-sm font-medium text-foreground">
                  Service
                </label>
                <select
                  id="service"
                  name="service"
                  value={formService}
                  onChange={(e) => updateSearch({ service: e.target.value })}
                  className={cn(
                    "rounded-lg border border-input bg-background px-3 py-2.5 text-sm text-foreground",
                    "focus:outline-none focus:ring-2 focus:ring-ring",
                  )}
                >
                  <option value="">Select a service</option>
                  <option value="outsourcing">Workforce Outsourcing</option>
                  <option value="manpower">Manpower Supply</option>
                  <option value="bluecollar">Blue Collar Recruitment</option>
                  <option value="technical">Technical Staffing</option>
                  <option value="leasing">Employee Leasing</option>
                  <option value="temporary">Temporary Staffing</option>
                  <option value="facility">Facility Management Workforce</option>
                  <option value="industrial">Industrial Workforce Solutions</option>
                </select>
              </div>
            </div>
            <div className="flex flex-col gap-2">
              <label htmlFor="message" className="text-sm font-medium text-foreground">
                Message
              </label>
              <textarea
                id="message"
                name="message"
                rows={5}
                value={formMessage}
                onChange={(e) => setFormMessage(e.target.value)}
                placeholder="Tell us about your requirements or the role you are looking for..."
                className={cn(
                  "rounded-lg border border-input bg-background px-3 py-2.5 text-sm text-foreground",
                  "focus:outline-none focus:ring-2 focus:ring-ring resize-y",
                )}
              />
            </div>
            <div className="flex items-center justify-between">
              <div
                className={cn(
                  "inline-flex items-center gap-1.5 text-xs font-medium text-gold-dark transition-opacity duration-300",
                  saved && !saveError ? "opacity-100" : "opacity-0",
                )}
                aria-live="polite"
              >
                <CheckCircle2 className="h-3.5 w-3.5" />
                <span>{usingFallback ? "Saved for this session" : "Saved"}</span>
              </div>
              <div
                className={cn(
                  "inline-flex items-center gap-1.5 text-xs font-medium text-destructive transition-opacity duration-300",
                  saveError ? "opacity-100" : "opacity-0",
                )}
                aria-live="assertive"
              >
                <AlertTriangle className="h-3.5 w-3.5" />
                <span>Save failed — storage may be full.</span>
                <button
                  type="button"
                  onClick={tryAutosave}
                  className="ml-1 underline underline-offset-2 hover:no-underline"
                >
                  Retry
                </button>
              </div>
            </div>
            <button
              type="submit"
              className={cn(
                "inline-flex w-full items-center justify-center gap-2 rounded-xl",
                "bg-gradient-gold px-6 py-3.5 text-sm font-semibold text-primary-foreground",
                "transition-all duration-300 hover:shadow-gold",
              )}
            >
              <span>Submit Inquiry</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </form>
        </div>
      </section>
    </div>
  );
}

function PathwayCard({
  id,
  label,
  description,
  icon,
  active,
}: {
  id: string;
  label: string;
  description: string;
  icon: React.ReactNode;
  active: boolean;
}) {
  return (
    <div
      className={cn(
        "flex flex-1 cursor-pointer flex-col items-center gap-3 rounded-2xl border p-6 text-center transition-all duration-300",
        active
          ? "border-primary/40 bg-secondary/60 shadow-gold"
          : "border-border/40 bg-secondary/20 hover:border-primary/30 hover:bg-secondary/40",
      )}
    >
      <div
        className={cn(
          "flex h-12 w-12 items-center justify-center rounded-xl",
          active ? "bg-primary/20 text-gold-dark" : "bg-secondary text-muted-foreground",
        )}
      >
        {icon}
      </div>
      <div>
        <p className="font-display text-base font-semibold text-foreground">{label}</p>
        <p className="mt-1 text-xs text-muted-foreground">{description}</p>
      </div>
    </div>
  );
}

function ServiceSummaryBanner({
  pathwayKey,
  serviceKey,
  pathway,
  service,
  intent,
  onChange,
}: {
  pathwayKey: string;
  serviceKey: string;
  pathway: string;
  service: string;
  intent: string;
  onChange: (patch: Record<string, unknown>) => void;
}) {
  return (
    <div className="mx-auto mt-8 max-w-2xl overflow-hidden rounded-2xl border border-primary/25 bg-gradient-card ring-inset-gold">
      <div className="flex items-center gap-3 border-b border-primary/15 bg-primary/10 px-5 py-3">
        <CheckCircle2 className="h-5 w-5 text-gold-dark" />
        <p className="text-sm font-semibold uppercase tracking-wider text-gold-dark">
          Confirm your selection
        </p>
      </div>
      <div className="grid gap-4 p-5 sm:grid-cols-3 sm:gap-6">
        <SummaryItem
          icon={
            pathway === "Request Workforce" ? (
              <Building2 className="h-4 w-4" />
            ) : (
              <User className="h-4 w-4" />
            )
          }
          label="Pathway"
          value={pathway}
        />
        <SummaryItem icon={<FileText className="h-4 w-4" />} label="Service" value={service} />
        <SummaryItem
          icon={<FileText className="h-4 w-4" />}
          label="Intended request"
          value={intent}
        />
      </div>
      {/* Inline change controls */}
      <div className="flex flex-wrap items-center gap-3 border-t border-primary/15 bg-primary/5 px-5 py-3">
        <Pencil className="h-3.5 w-3.5 text-muted-foreground" />
        <span className="text-xs font-medium text-muted-foreground">Change selection:</span>
        <select
          value={pathwayKey}
          onChange={(e) => onChange({ pathway: e.target.value })}
          className={cn(
            "rounded-md border border-input bg-background px-2 py-1.5 text-xs text-foreground",
            "focus:outline-none focus:ring-2 focus:ring-ring",
          )}
        >
          <option value="request-workforce">Request Workforce</option>
          <option value="find-job">Find a Job</option>
        </select>
        <select
          value={serviceKey}
          onChange={(e) => onChange({ service: e.target.value })}
          className={cn(
            "rounded-md border border-input bg-background px-2 py-1.5 text-xs text-foreground",
            "focus:outline-none focus:ring-2 focus:ring-ring",
          )}
        >
          <option value="outsourcing">Workforce Outsourcing</option>
          <option value="manpower">Manpower Supply</option>
          <option value="bluecollar">Blue Collar Recruitment</option>
          <option value="technical">Technical Staffing</option>
          <option value="leasing">Employee Leasing</option>
          <option value="temporary">Temporary Staffing</option>
          <option value="facility">Facility Management Workforce</option>
          <option value="industrial">Industrial Workforce Solutions</option>
        </select>
      </div>
    </div>
  );
}

function SummaryItem({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
        {icon}
        <span>{label}</span>
      </div>
      <p className="text-sm font-medium leading-snug text-foreground">{value}</p>
    </div>
  );
}

function Field({
  label,
  name,
  type,
  placeholder,
  value,
  onChange,
  required = false,
}: {
  label: string;
  name: string;
  type: string;
  placeholder?: string;
  value: string;
  onChange: (value: string) => void;
  required?: boolean;
}) {
  return (
    <div className="flex flex-col gap-2">
      <label htmlFor={name} className="text-sm font-medium text-foreground">
        {label}
        {required && <span className="text-gold-dark"> *</span>}
      </label>
      <input
        id={name}
        name={name}
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        required={required}
        className={cn(
          "rounded-lg border border-input bg-background px-3 py-2.5 text-sm text-foreground",
          "placeholder:text-muted-foreground/60",
          "focus:outline-none focus:ring-2 focus:ring-ring",
        )}
      />
    </div>
  );
}
