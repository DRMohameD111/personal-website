import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Mail, Loader2, ArrowLeft, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { z } from "zod";

import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useI18n, tx } from "@/i18n";

export const Route = createFileRoute("/forgot-password")({
  head: () => ({
    meta: [
      { title: "Forgot Password — SPHINX Workforce" },
      {
        name: "description",
        content: "Reset your SPHINX Workforce account password — for individuals and companies.",
      },
      { property: "og:title", content: "Forgot Password — SPHINX Workforce" },
      {
        property: "og:description",
        content: "Request a password reset link for your SPHINX Workforce account.",
      },
    ],
  }),
  component: ForgotPasswordPage,
});

const emailSchema = z.object({
  email: z.string().trim().email("Invalid email").max(255),
});

function ForgotPasswordPage() {
  const { t, lang } = useI18n();
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const isAr = lang === "ar";

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (loading) return;
    const formData = new FormData(e.currentTarget);
    const parsed = emailSchema.safeParse({ email: formData.get("email") });
    if (!parsed.success) {
      toast.error(parsed.error.issues[0].message);
      return;
    }
    setLoading(true);
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(parsed.data.email, {
        redirectTo: `${window.location.origin}/reset-password`,
      });
      if (error) {
        toast.error(error.message);
        return;
      }
      setSent(true);
      toast.success(
        t(tx("Reset link sent. Check your inbox.", "تم إرسال رابط الاستعادة. تحقق من بريدك.")),
      );
    } catch (err) {
      toast.error(err instanceof Error ? err.message : String(err));
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen bg-background pt-28 pb-16" dir={isAr ? "rtl" : "ltr"}>
      <div className="mx-auto max-w-xl px-4 sm:px-6 lg:px-8">
        <Card className="border-border/60 shadow-elegant">
          <CardHeader>
            <div className="flex items-center gap-3">
              <span className="inline-flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-gold text-primary-foreground">
                <Mail className="h-5 w-5" />
              </span>
              <div>
                <CardTitle className="font-display text-xl">
                  {t(tx("Forgot your password?", "نسيت كلمة المرور؟"))}
                </CardTitle>
                <CardDescription className="text-sm">
                  {t(
                    tx(
                      "Enter your account email and we'll send a reset link.",
                      "أدخل بريد حسابك وسنرسل لك رابط الاستعادة.",
                    ),
                  )}
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {sent ? (
              <div className="space-y-4 text-center py-6">
                <CheckCircle2 className="mx-auto h-12 w-12 text-gold-dark" />
                <p className="text-sm text-foreground">
                  {t(
                    tx(
                      "If an account exists for that email, a reset link is on its way. Check your inbox and spam folder.",
                      "إذا كان هناك حساب بهذا البريد، فسيصلك رابط الاستعادة. تحقق من البريد الوارد ومجلد الرسائل غير المرغوب فيها.",
                    ),
                  )}
                </p>
                <Link to="/auth">
                  <Button variant="outline" className="mt-2">
                    <ArrowLeft className="h-4 w-4" />
                    {t(tx("Back to sign in", "العودة لتسجيل الدخول"))}
                  </Button>
                </Link>
              </div>
            ) : (
              <form onSubmit={onSubmit} className="space-y-4">
                <div className="space-y-1.5">
                  <Label htmlFor="email">{t(tx("Email", "البريد الإلكتروني"))}</Label>
                  <div className="relative">
                    <span className="pointer-events-none absolute inset-y-0 left-3 flex items-center text-muted-foreground">
                      <Mail className="h-4 w-4" />
                    </span>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      required
                      autoComplete="email"
                      placeholder="you@example.com"
                      className="pl-9"
                    />
                  </div>
                </div>
                <Button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-gradient-gold text-primary-foreground font-semibold hover:shadow-gold"
                >
                  {loading && <Loader2 className="h-4 w-4 animate-spin" />}
                  {t(tx("Send reset link", "إرسال رابط الاستعادة"))}
                </Button>
                <p className="text-center text-xs text-muted-foreground pt-2">
                  <Link to="/auth" className="font-semibold text-gold-dark hover:underline">
                    {t(tx("Back to sign in", "العودة لتسجيل الدخول"))}
                  </Link>
                </p>
              </form>
            )}
          </CardContent>
        </Card>
      </div>
    </main>
  );
}
