import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { AlertTriangle, Loader2, Megaphone, Plus } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useI18n, tx } from "@/i18n";
import { BilingualField } from "@/components/BilingualField";
import { EmploymentTypeSelect } from "@/components/EmploymentTypeSelect";
import { type EmploymentTypeValue } from "@/lib/jobs";
import { useStateDraft } from "@/lib/form-draft";
import { supabase } from "@/integrations/supabase/client";
import { getMyAccountType } from "@/lib/account-type";
import {
  createDirectAd,
  getDirectAdPricing,
  checkDirectAdEligibility,
} from "@/lib/direct-ad.functions";

export const Route = createFileRoute("/direct-ad")({
  head: () => ({
    meta: [
      { title: "Direct Vacancy Ad — SPHINX Workforce" },
      {
        name: "description",
        content:
          "Publish a single vacancy directly, without registration or subscription, at the price set by SPHINX.",
      },
      { property: "og:title", content: "Direct Vacancy Ad — SPHINX Workforce" },
      {
        property: "og:description",
        content: "Post a vacancy without registration or subscription.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: DirectAdPage,
});

type Profession = { id: string; name_en: string; name_ar: string };
type Level = { id: string; name_en: string; name_ar: string };

const selectClass =
  "w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring";

const ALREADY_REGISTERED = tx(
  "This company is already registered. Please sign in and post the vacancy through your Company account.",
  "هذه الشركة مسجلة بالفعل. يرجى تسجيل الدخول ونشر الوظيفة من حساب الشركة.",
);

function DirectAdPage() {
  const { t, lang } = useI18n();
  const isAr = lang === "ar";
  const router = useRouter();
  const queryClient = useQueryClient();
  const loadPricing = useServerFn(getDirectAdPricing);
  const submitAd = useServerFn(createDirectAd);
  const checkEligibility = useServerFn(checkDirectAdEligibility);

  const [profs, setProfs] = useState<Profession[]>([]);
  const [levels, setLevels] = useState<Level[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [blocked, setBlocked] = useState(false);

  const pricing = useQuery({ queryKey: ["direct-ad-pricing"], queryFn: () => loadPricing({}) });

  // Only registered company accounts are redirected to the normal posting flow;
  // guests and job seekers can use Direct Ads.
  useEffect(() => {
    let active = true;
    supabase.auth.getSession().then(async ({ data }) => {
      if (!active || !data.session) return;
      if ((await getMyAccountType()) === "company" && active) {
        router.navigate({ to: "/post-job", replace: true });
      }
    });
    return () => {
      active = false;
    };
  }, [router]);

  const [form, setForm] = useState({
    company_name: "",
    contact_person: "",
    email: "",
    cr_number: "",
    mobile: "",
    cv_email: "",
    company_country: "",
    company_city: "",
    company_info: "",
    profession_id: "",
    title_en: "",
    title_ar: "",
    country_en: "Saudi Arabia",
    country_ar: "المملكة العربية السعودية",
    city_en: "Riyadh",
    city_ar: "الرياض",
    level_id: "",
    employment_type: "full_time" as EmploymentTypeValue,
    type_en: "Full Time",
    type_ar: "دوام كامل",
    salary_en: "",
    salary_ar: "",
    summary_en: "",
    summary_ar: "",
    skills: "",
  });
  const { clearDraft } = useStateDraft(
    "direct-ad",
    form,
    (d) => setForm((f) => ({ ...f, ...d })),
    lang,
  );
  const set = <K extends keyof typeof form>(k: K, v: (typeof form)[K]) =>
    setForm((f) => ({ ...f, [k]: v }));

  useEffect(() => {
    Promise.all([
      supabase.from("professions").select("id, name_en, name_ar").order("name_en"),
      supabase.from("experience_levels").select("id, name_en, name_ar").order("sort_order"),
    ])
      .then(([p, l]) => {
        const ps = (p.data ?? []) as Profession[];
        const ls = (l.data ?? []) as Level[];
        setProfs(ps);
        setLevels(ls);
        setForm((f) => ({
          ...f,
          profession_id: f.profession_id || (ps[0]?.id ?? ""),
          level_id: f.level_id || (ls[0]?.id ?? ""),
        }));
      })
      .catch((e) => toast.error(String((e as Error)?.message || e)))
      .finally(() => setLoading(false));
  }, []);

  const p = pricing.data;
  const priceText = !p
    ? ""
    : !p.available
      ? t(tx("Currently unavailable", "غير متاح حالياً"))
      : p.amountDue <= 0
        ? t(tx("Free", "مجاني"))
        : `${p.amountDue.toLocaleString(isAr ? "ar-SA" : "en-US")} ${p.currency}`;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setBlocked(false);
    try {
      // Backend check before anything else: already-registered clients are blocked.
      const eligible = await checkEligibility({
        data: {
          email: form.email.trim(),
          mobile: form.mobile.trim() || undefined,
          cr_number: form.cr_number.trim() || undefined,
        },
      });
      if (!eligible.allowed) {
        setBlocked(true);
        return;
      }

      const level = levels.find((l) => l.id === form.level_id);
      const res = await submitAd({
        data: {
          email: form.email.trim(),
          cr_number: form.cr_number.trim() || undefined,
          company_name: form.company_name.trim(),
          contact_person: form.contact_person.trim(),
          mobile: form.mobile.trim(),
          cv_email: form.cv_email.trim(),
          company_country: form.company_country.trim() || undefined,
          company_city: form.company_city.trim() || undefined,
          company_info: form.company_info.trim() || undefined,
          profession_id: form.profession_id,
          title_en: form.title_en.trim(),
          title_ar: form.title_ar.trim(),
          country_en: form.country_en.trim(),
          country_ar: form.country_ar.trim(),
          city_en: form.city_en.trim(),
          city_ar: form.city_ar.trim(),
          level_id: level?.id,
          level_en: level?.name_en,
          level_ar: level?.name_ar,
          employment_type: form.employment_type,
          type_en: form.type_en.trim(),
          type_ar: form.type_ar.trim(),
          salary_en: form.salary_en.trim() || undefined,
          salary_ar: form.salary_ar.trim() || undefined,
          summary_en: form.summary_en.trim() || undefined,
          summary_ar: form.summary_ar.trim() || undefined,
          skills: form.skills
            .split(",")
            .map((s) => s.trim())
            .filter(Boolean),
        },
      });
      if (!res.ok) {
        setBlocked(true);
        return;
      }
      clearDraft();
      await queryClient.invalidateQueries({ queryKey: ["published-jobs"] });
      if (res.status === "pending_approval") {
        toast.success(
          t(
            tx(
              "Your ad was received and will be published once our team approves it.",
              "تم استلام إعلانك وسيتم نشره بعد موافقة فريقنا.",
            ),
          ),
        );
        router.navigate({ to: "/jobs" });
      } else {
        toast.info(
          t(
            tx(
              `Saved. Your ad goes to review once the payment of ${res.amountDue} ${res.currency} is confirmed.`,
              `تم الحفظ. سيُحال إعلانك للمراجعة بعد تأكيد سداد ${res.amountDue} ${res.currency}.`,
            ),
          ),
        );
      }
    } catch (err) {
      toast.error(String((err as Error).message || err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <main className="min-h-screen pt-28 pb-16" dir={isAr ? "rtl" : "ltr"}>
      <section className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
        <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="font-display text-3xl font-bold text-heading md:text-4xl">
              {t(tx("Direct Vacancy Ad", "إعلان مباشر عن وظيفة"))}
            </h1>
            <p className="mt-2 text-sm text-muted-foreground">
              {t(
                tx(
                  "Post a vacancy without registration or subscription",
                  "انشر وظيفة مباشرة بدون تسجيل أو اشتراك",
                ),
              )}
            </p>
          </div>
          <div className="rounded-2xl border border-primary/40 bg-primary/5 px-5 py-4 text-end">
            <div className="text-xs font-semibold uppercase tracking-wider text-gold-dark">
              {t(tx("Ad price", "سعر الإعلان"))}
            </div>
            <div className="mt-1 font-display text-2xl font-bold text-heading">
              {pricing.isLoading ? <Loader2 className="h-5 w-5 animate-spin" /> : priceText}
            </div>
            {p?.available && (
              <div className="mt-1 space-y-0.5 text-xs text-muted-foreground">
                {p.taxPercent > 0 && (
                  <div>{t(tx(`VAT ${p.taxPercent}% included`, `شامل ضريبة ${p.taxPercent}%`))}</div>
                )}
                {(isAr ? p.vatNoteAr : p.vatNoteEn) && (
                  <div>{isAr ? p.vatNoteAr : p.vatNoteEn}</div>
                )}
                {p.validityMonths && (
                  <div>
                    {t(
                      tx(
                        `Valid for ${p.validityMonths} month(s)`,
                        `صلاحية ${p.validityMonths} شهر`,
                      ),
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {blocked && (
          <div
            role="alert"
            className="mb-6 flex flex-wrap items-center gap-4 rounded-2xl border border-destructive/40 bg-destructive/10 p-5"
          >
            <AlertTriangle className="h-5 w-5 shrink-0 text-destructive" />
            <p className="flex-1 text-sm text-foreground">{t(ALREADY_REGISTERED)}</p>
            <Link to="/auth" search={{ next: "/post-job" }}>
              <Button className="bg-gradient-gold font-semibold text-primary-foreground">
                {t(tx("Company Login", "دخول أصحاب الأعمال"))}
              </Button>
            </Link>
          </div>
        )}

        {loading ? (
          <div className="flex items-center gap-2 text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" />
            {t(tx("Loading…", "جاري التحميل…"))}
          </div>
        ) : (
          <form onSubmit={submit} className="space-y-6">
            <div className="rounded-2xl bg-gradient-card ring-inset-gold p-6 md:p-8 space-y-5">
              <h2 className="font-display text-lg font-semibold text-heading">
                {t(tx("Client / Company data", "بيانات العميل / الشركة"))}
              </h2>
              <div className="grid gap-4 md:grid-cols-2">
                <Field label={t(tx("Company name", "اسم الشركة"))}>
                  <Input
                    required
                    value={form.company_name}
                    onChange={(e) => set("company_name", e.target.value)}
                  />
                </Field>
                <Field label={t(tx("Contact person", "مسؤول التواصل"))}>
                  <Input
                    required
                    value={form.contact_person}
                    onChange={(e) => set("contact_person", e.target.value)}
                  />
                </Field>
                <Field label={t(tx("Company email", "بريد الشركة"))}>
                  <Input
                    required
                    type="email"
                    value={form.email}
                    onChange={(e) => set("email", e.target.value)}
                  />
                </Field>
                <Field
                  label={t(
                    tx("Commercial registration number (optional)", "رقم السجل التجاري (اختياري)"),
                  )}
                >
                  <Input
                    value={form.cr_number}
                    onChange={(e) => set("cr_number", e.target.value)}
                  />
                </Field>
                <Field label={t(tx("Mobile", "الجوال"))}>
                  <Input
                    required
                    value={form.mobile}
                    onChange={(e) => set("mobile", e.target.value)}
                  />
                </Field>
                <Field label={t(tx("Email to receive CVs", "بريد استلام السير الذاتية"))}>
                  <Input
                    required
                    type="email"
                    value={form.cv_email}
                    onChange={(e) => set("cv_email", e.target.value)}
                  />
                </Field>
                <Field label={t(tx("Country", "الدولة"))}>
                  <Input
                    value={form.company_country}
                    onChange={(e) => set("company_country", e.target.value)}
                  />
                </Field>
                <Field label={t(tx("City", "المدينة"))}>
                  <Input
                    value={form.company_city}
                    onChange={(e) => set("company_city", e.target.value)}
                  />
                </Field>
              </div>
              <Field label={t(tx("Company information", "معلومات الشركة"))}>
                <Textarea
                  rows={3}
                  value={form.company_info}
                  onChange={(e) => set("company_info", e.target.value)}
                />
              </Field>
              <p className="text-xs text-muted-foreground">
                {t(
                  tx(
                    "Already registered? Sign in and post the vacancy from your Company account.",
                    "مسجل بالفعل؟ سجّل الدخول وانشر الوظيفة من حساب الشركة.",
                  ),
                )}
              </p>
            </div>

            <div className="rounded-2xl bg-gradient-card ring-inset-gold p-6 md:p-8 space-y-5">
              <h2 className="font-display text-lg font-semibold text-heading">
                {t(tx("Job details", "تفاصيل الوظيفة"))}
              </h2>
              <div className="grid gap-4 md:grid-cols-2">
                <Field label={t(tx("Profession", "المهنة"))}>
                  <select
                    className={selectClass}
                    value={form.profession_id}
                    onChange={(e) => set("profession_id", e.target.value)}
                    required
                  >
                    {profs.map((pr) => (
                      <option key={pr.id} value={pr.id}>
                        {pr.name_en} — {pr.name_ar}
                      </option>
                    ))}
                  </select>
                </Field>
                <Field label={t(tx("Experience level", "مستوى الخبرة"))}>
                  <select
                    className={selectClass}
                    value={form.level_id}
                    onChange={(e) => set("level_id", e.target.value)}
                  >
                    {levels.map((l) => (
                      <option key={l.id} value={l.id}>
                        {l.name_en} — {l.name_ar}
                      </option>
                    ))}
                  </select>
                </Field>
              </div>

              <BilingualField
                labelEn={t(tx("Title (English)", "المسمى (إنجليزي)"))}
                labelAr={t(tx("Title (Arabic)", "المسمى (عربي)"))}
                valueEn={form.title_en}
                valueAr={form.title_ar}
                required
                onChange={(v) =>
                  setForm((f) => ({
                    ...f,
                    ...(v.en !== undefined ? { title_en: v.en } : {}),
                    ...(v.ar !== undefined ? { title_ar: v.ar } : {}),
                  }))
                }
              />

              <div className="grid gap-4 md:grid-cols-2">
                <Field label={t(tx("Country (English)", "الدولة (إنجليزي)"))}>
                  <Input
                    value={form.country_en}
                    onChange={(e) => set("country_en", e.target.value)}
                  />
                </Field>
                <Field label={t(tx("Country (Arabic)", "الدولة (عربي)"))}>
                  <Input
                    dir="rtl"
                    value={form.country_ar}
                    onChange={(e) => set("country_ar", e.target.value)}
                  />
                </Field>
                <Field label={t(tx("City (English)", "المدينة (إنجليزي)"))}>
                  <Input value={form.city_en} onChange={(e) => set("city_en", e.target.value)} />
                </Field>
                <Field label={t(tx("City (Arabic)", "المدينة (عربي)"))}>
                  <Input
                    dir="rtl"
                    value={form.city_ar}
                    onChange={(e) => set("city_ar", e.target.value)}
                  />
                </Field>
                <Field label={t(tx("Employment Type", "نوع التوظيف"))}>
                  <EmploymentTypeSelect
                    value={form.employment_type}
                    typeEn={form.type_en}
                    typeAr={form.type_ar}
                    onChange={(p) => setForm((f) => ({ ...f, ...p }))}
                  />
                </Field>
                <Field label={t(tx("Salary (English)", "الراتب (إنجليزي)"))}>
                  <Input
                    value={form.salary_en}
                    onChange={(e) => set("salary_en", e.target.value)}
                  />
                </Field>
                <Field label={t(tx("Salary (Arabic)", "الراتب (عربي)"))}>
                  <Input
                    dir="rtl"
                    value={form.salary_ar}
                    onChange={(e) => set("salary_ar", e.target.value)}
                  />
                </Field>
              </div>

              <BilingualField
                labelEn={t(tx("Summary (English)", "الملخص (إنجليزي)"))}
                labelAr={t(tx("Summary (Arabic)", "الملخص (عربي)"))}
                valueEn={form.summary_en}
                valueAr={form.summary_ar}
                multiline
                rows={3}
                onChange={(v) =>
                  setForm((f) => ({
                    ...f,
                    ...(v.en !== undefined ? { summary_en: v.en } : {}),
                    ...(v.ar !== undefined ? { summary_ar: v.ar } : {}),
                  }))
                }
              />

              <Field label={t(tx("Skills (comma-separated)", "المهارات (مفصولة بفواصل)"))}>
                <Input value={form.skills} onChange={(e) => set("skills", e.target.value)} />
              </Field>
            </div>

            <Button
              type="submit"
              disabled={busy || !p?.available}
              className="bg-gradient-gold font-semibold text-primary-foreground"
            >
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
              {p && p.amountDue > 0
                ? t(tx(`Continue to payment — ${priceText}`, `المتابعة للسداد — ${priceText}`))
                : t(tx("Publish vacancy", "نشر الوظيفة"))}
            </Button>
            <p className="flex items-center gap-2 text-xs text-muted-foreground">
              <Megaphone className="h-3.5 w-3.5 text-gold-dark" />
              {t(
                tx(
                  "The price, the client eligibility and the payment status are verified on the server before publishing.",
                  "يتم التحقق من السعر وأهلية العميل وحالة السداد على الخادم قبل النشر.",
                ),
              )}
            </p>
          </form>
        )}
      </section>
    </main>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block space-y-1.5">
      <span className="text-xs font-semibold uppercase tracking-wider text-gold-dark">{label}</span>
      {children}
    </label>
  );
}
