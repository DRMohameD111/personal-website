import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useRef, useState, useCallback } from "react";
import { Lock, Loader2, CheckCircle2 } from "lucide-react";
import { PasswordStrength, checkPassword } from "@/components/PasswordStrength";
import { toast } from "sonner";
import { z } from "zod";

import { supabase } from "@/integrations/supabase/client";
import { resetPasswordWithToken } from "@/lib/reset-password.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useI18n, tx } from "@/i18n";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Reset Password — SPHINX Workforce" },
      { name: "description", content: "Set a new password for your SPHINX Workforce account." },
      { name: "robots", content: "noindex,nofollow" },
    ],
  }),
  component: ResetPasswordPage,
});

const passwordComplexity = z
  .string()
  .min(8, "Password must be at least 8 characters")
  .max(72, "Password must be at most 72 characters")
  .regex(/[A-Z]/, "Password must contain at least one uppercase letter")
  .regex(/[a-z]/, "Password must contain at least one lowercase letter")
  .regex(/[0-9]/, "Password must contain at least one number")
  .regex(/[^A-Za-z0-9]/, "Password must contain at least one special character");

const passwordSchema = z
  .object({
    password: passwordComplexity,
    confirm: z.string().min(1, "Please confirm your password").max(72),
  })
  .refine((d) => d.password === d.confirm, {
    message: "Passwords don't match",
    path: ["confirm"],
  });

function ResetPasswordPage() {
  const { t, lang } = useI18n();
  const navigate = useNavigate();
  const submitReset = useServerFn(resetPasswordWithToken);
  const isAr = lang === "ar";
  const [ready, setReady] = useState(false);
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [timeoutError, setTimeoutError] = useState<string | null>(null);
  const statusRef = useRef<HTMLDivElement>(null);
  const timeoutRef = useRef<HTMLDivElement>(null);
  const formRef = useRef<HTMLFormElement>(null);

  // Wait for Supabase to process the recovery link (token in URL hash → session)
  useEffect(() => {
    const { data } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === "PASSWORD_RECOVERY" || (event === "SIGNED_IN" && session)) {
        setReady(true);
      }
    });
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session) setReady(true);
    });
    return () => data.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (done && statusRef.current) {
      statusRef.current.focus();
    }
  }, [done]);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (loading) return;
    setTimeoutError(null);
    const formData = new FormData(e.currentTarget);
    const parsed = passwordSchema.safeParse({
      password: formData.get("password"),
      confirm: formData.get("confirm"),
    });
    if (!parsed.success) {
      toast.error(parsed.error.issues[0].message);
      return;
    }
    setLoading(true);
    let timedOut = false;
    const timeoutId = setTimeout(() => {
      timedOut = true;
      setLoading(false);
      const msg = t(tx("Request timed out. Please try again.", "انتهت مهلة الطلب. حاول مرة أخرى."));
      setTimeoutError(msg);
      toast.error(msg);
      setTimeout(() => timeoutRef.current?.focus(), 0);
    }, 30000);
    try {
      await submitReset({
        data: { password: parsed.data.password, confirm: parsed.data.confirm },
      });
      if (timedOut) return;
      setDone(true);
      toast.success(t(tx("Password updated.", "تم تحديث كلمة المرور.")));
      setTimeout(() => navigate({ to: "/" }), 1500);
    } catch (err) {
      if (timedOut) return;
      toast.error(err instanceof Error ? err.message : String(err));
    } finally {
      clearTimeout(timeoutId);
      if (!timedOut) setLoading(false);
    }
  }

  return (
    <main className="min-h-screen bg-background pt-28 pb-16" dir={isAr ? "rtl" : "ltr"}>
      <div className="mx-auto max-w-xl px-4 sm:px-6 lg:px-8">
        <Card className="border-border/60 shadow-elegant">
          <CardHeader>
            <div className="flex items-center gap-3">
              <span className="inline-flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-gold text-primary-foreground">
                <Lock className="h-5 w-5" />
              </span>
              <div>
                <CardTitle className="font-display text-xl">
                  {t(tx("Set a new password", "تعيين كلمة مرور جديدة"))}
                </CardTitle>
                <CardDescription className="text-sm">
                  {t(
                    tx(
                      "Choose a strong password of at least 8 characters.",
                      "اختر كلمة مرور قوية لا تقل عن 8 أحرف.",
                    ),
                  )}
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {done ? (
              <div
                ref={statusRef}
                tabIndex={-1}
                aria-live="polite"
                className="space-y-3 text-center py-6 outline-none"
              >
                <CheckCircle2 className="mx-auto h-12 w-12 text-gold-dark" />
                <p className="text-sm text-foreground">
                  {t(tx("Your password has been updated.", "تم تحديث كلمة المرور بنجاح."))}
                </p>
              </div>
            ) : !ready ? (
              <div className="space-y-4 py-6 text-center">
                <p className="text-sm text-muted-foreground">
                  {t(
                    tx(
                      "Waiting for your reset link to be verified… If nothing happens, request a new link.",
                      "بانتظار التحقق من رابط الاستعادة… إن لم يحدث شيء، اطلب رابطاً جديداً.",
                    ),
                  )}
                </p>
                <Link to="/forgot-password">
                  <Button variant="outline">{t(tx("Request a new link", "طلب رابط جديد"))}</Button>
                </Link>
              </div>
            ) : (
              <form ref={formRef} onSubmit={onSubmit} className="space-y-4" aria-busy={loading}>
                <div aria-live="polite" aria-atomic="true" className="sr-only">
                  {timeoutError
                    ? timeoutError
                    : loading
                      ? t(
                          tx(
                            "Updating password, please wait.",
                            "جارٍ تحديث كلمة المرور، يرجى الانتظار.",
                          ),
                        )
                      : t(tx("Form ready.", "النموذج جاهز."))}
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="password">{t(tx("New password", "كلمة المرور الجديدة"))}</Label>
                  <Input
                    id="password"
                    name="password"
                    type="password"
                    required
                    minLength={8}
                    autoComplete="new-password"
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="confirm">{t(tx("Confirm password", "تأكيد كلمة المرور"))}</Label>
                  <Input
                    id="confirm"
                    name="confirm"
                    type="password"
                    required
                    minLength={8}
                    autoComplete="new-password"
                    placeholder="••••••••"
                    value={confirm}
                    onChange={(e) => setConfirm(e.target.value)}
                  />
                </div>
                <PasswordStrength check={checkPassword(password, confirm)} />
                {timeoutError && (
                  <div
                    ref={timeoutRef}
                    tabIndex={-1}
                    role="alert"
                    className="rounded-md bg-destructive/10 text-destructive px-3 py-2 text-sm outline-none flex items-center justify-between gap-3"
                  >
                    <span>{timeoutError}</span>
                    <button
                      type="button"
                      onClick={() => formRef.current?.requestSubmit()}
                      className="shrink-0 rounded bg-destructive px-2.5 py-1 text-xs font-semibold text-destructive-foreground hover:bg-destructive/90 transition-colors"
                    >
                      {t(tx("Try again", "حاول مرة أخرى"))}
                    </button>
                  </div>
                )}
                <Button
                  type="submit"
                  disabled={
                    loading ||
                    !checkPassword(password, confirm).match ||
                    Object.values(checkPassword(password, confirm)).some((v) => !v)
                  }
                  className="w-full bg-gradient-gold text-primary-foreground font-semibold hover:shadow-gold"
                >
                  {loading ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      {t(tx("Updating password…", "جارٍ تحديث كلمة المرور…"))}
                    </>
                  ) : (
                    t(tx("Update password", "تحديث كلمة المرور"))
                  )}
                </Button>
              </form>
            )}
          </CardContent>
        </Card>
      </div>
    </main>
  );
}
