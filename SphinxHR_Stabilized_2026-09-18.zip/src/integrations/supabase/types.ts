export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[];

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5";
  };
  public: {
    Tables: {
      admin_accounts: {
        Row: {
          created_at: string;
          created_by: string | null;
          display_name: string | null;
          is_disabled: boolean;
          is_main: boolean;
          updated_at: string;
          user_id: string;
        };
        Insert: {
          created_at?: string;
          created_by?: string | null;
          display_name?: string | null;
          is_disabled?: boolean;
          is_main?: boolean;
          updated_at?: string;
          user_id: string;
        };
        Update: {
          created_at?: string;
          created_by?: string | null;
          display_name?: string | null;
          is_disabled?: boolean;
          is_main?: boolean;
          updated_at?: string;
          user_id?: string;
        };
        Relationships: [];
      };
      admin_audit_log: {
        Row: {
          action: string;
          actor_email: string | null;
          actor_id: string | null;
          changes: Json;
          created_at: string;
          id: string;
          target_id: string | null;
          target_type: string | null;
        };
        Insert: {
          action: string;
          actor_email?: string | null;
          actor_id?: string | null;
          changes?: Json;
          created_at?: string;
          id?: string;
          target_id?: string | null;
          target_type?: string | null;
        };
        Update: {
          action?: string;
          actor_email?: string | null;
          actor_id?: string | null;
          changes?: Json;
          created_at?: string;
          id?: string;
          target_id?: string | null;
          target_type?: string | null;
        };
        Relationships: [];
      };
      admin_permissions: {
        Row: {
          action: string;
          created_at: string;
          granted_by: string | null;
          id: string;
          module: string;
          user_id: string;
        };
        Insert: {
          action: string;
          created_at?: string;
          granted_by?: string | null;
          id?: string;
          module: string;
          user_id: string;
        };
        Update: {
          action?: string;
          created_at?: string;
          granted_by?: string | null;
          id?: string;
          module?: string;
          user_id?: string;
        };
        Relationships: [];
      };
      app_notifications: {
        Row: {
          created_at: string;
          id: string;
          payload: Json;
          read_at: string | null;
          type: string;
          user_id: string;
        };
        Insert: {
          created_at?: string;
          id?: string;
          payload?: Json;
          read_at?: string | null;
          type: string;
          user_id: string;
        };
        Update: {
          created_at?: string;
          id?: string;
          payload?: Json;
          read_at?: string | null;
          type?: string;
          user_id?: string;
        };
        Relationships: [];
      };
      candidate_documents: {
        Row: {
          created_at: string;
          doc_type: string;
          file_name: string | null;
          id: string;
          size_bytes: number | null;
          storage_path: string;
          title: string | null;
          updated_at: string;
          user_id: string;
        };
        Insert: {
          created_at?: string;
          doc_type?: string;
          file_name?: string | null;
          id?: string;
          size_bytes?: number | null;
          storage_path: string;
          title?: string | null;
          updated_at?: string;
          user_id: string;
        };
        Update: {
          created_at?: string;
          doc_type?: string;
          file_name?: string | null;
          id?: string;
          size_bytes?: number | null;
          storage_path?: string;
          title?: string | null;
          updated_at?: string;
          user_id?: string;
        };
        Relationships: [];
      };
      candidate_merge_log: {
        Row: {
          changes: Json;
          created_at: string;
          external_candidate_id: string | null;
          id: string;
          matched_on: string | null;
          profile_id: string | null;
        };
        Insert: {
          changes?: Json;
          created_at?: string;
          external_candidate_id?: string | null;
          id?: string;
          matched_on?: string | null;
          profile_id?: string | null;
        };
        Update: {
          changes?: Json;
          created_at?: string;
          external_candidate_id?: string | null;
          id?: string;
          matched_on?: string | null;
          profile_id?: string | null;
        };
        Relationships: [];
      };
      clients: {
        Row: {
          branches_count: string;
          client_code: string | null;
          contact_person: string | null;
          contact_phone: string | null;
          cr_number: string | null;
          created_at: string;
          hq_city: string | null;
          hq_country_code: string;
          id: string;
          legal_structure: Database["public"]["Enums"]["client_legal_structure"];
          name: string;
          nationality_code: string;
          nature_of_business: string;
          nature_of_business_other: string | null;
          notes: string | null;
          official_email: string;
          owner_id: string;
          updated_at: string;
          website: string | null;
        };
        Insert: {
          branches_count: string;
          client_code?: string | null;
          contact_person?: string | null;
          contact_phone?: string | null;
          cr_number?: string | null;
          created_at?: string;
          hq_city?: string | null;
          hq_country_code: string;
          id?: string;
          legal_structure: Database["public"]["Enums"]["client_legal_structure"];
          name: string;
          nationality_code: string;
          nature_of_business: string;
          nature_of_business_other?: string | null;
          notes?: string | null;
          official_email: string;
          owner_id: string;
          updated_at?: string;
          website?: string | null;
        };
        Update: {
          branches_count?: string;
          client_code?: string | null;
          contact_person?: string | null;
          contact_phone?: string | null;
          cr_number?: string | null;
          created_at?: string;
          hq_city?: string | null;
          hq_country_code?: string;
          id?: string;
          legal_structure?: Database["public"]["Enums"]["client_legal_structure"];
          name?: string;
          nationality_code?: string;
          nature_of_business?: string;
          nature_of_business_other?: string | null;
          notes?: string | null;
          official_email?: string;
          owner_id?: string;
          updated_at?: string;
          website?: string | null;
        };
        Relationships: [];
      };
      cv_access_log: {
        Row: {
          company_id: string;
          created_at: string;
          external_candidate_id: string | null;
          id: string;
          job_posting_id: string | null;
          profile_id: string | null;
        };
        Insert: {
          company_id: string;
          created_at?: string;
          external_candidate_id?: string | null;
          id?: string;
          job_posting_id?: string | null;
          profile_id?: string | null;
        };
        Update: {
          company_id?: string;
          created_at?: string;
          external_candidate_id?: string | null;
          id?: string;
          job_posting_id?: string | null;
          profile_id?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "cv_access_log_job_posting_id_fkey";
            columns: ["job_posting_id"];
            isOneToOne: false;
            referencedRelation: "job_postings";
            referencedColumns: ["id"];
          },
        ];
      };
      experience_levels: {
        Row: {
          created_at: string;
          id: string;
          name_ar: string;
          name_en: string;
          slug: string;
          sort_order: number;
        };
        Insert: {
          created_at?: string;
          id?: string;
          name_ar: string;
          name_en: string;
          slug: string;
          sort_order?: number;
        };
        Update: {
          created_at?: string;
          id?: string;
          name_ar?: string;
          name_en?: string;
          slug?: string;
          sort_order?: number;
        };
        Relationships: [];
      };
      external_candidates: {
        Row: {
          candidate_source: string;
          career_level: string | null;
          certifications: string[];
          created_at: string;
          cv_file_name: string | null;
          cv_storage_path: string | null;
          education: string | null;
          email: string | null;
          email_norm: string | null;
          experience_text: string | null;
          experience_years: number | null;
          extract_notes: Json;
          full_name: string | null;
          id: string;
          imported_by: string | null;
          job_title: string | null;
          languages: string[];
          location: string | null;
          merged_at: string | null;
          merged_profile_id: string | null;
          nationality: string | null;
          phone: string | null;
          phone_norm: string | null;
          skills: string[];
          source_updated_at: string;
          status: string;
          updated_at: string;
        };
        Insert: {
          candidate_source?: string;
          career_level?: string | null;
          certifications?: string[];
          created_at?: string;
          cv_file_name?: string | null;
          cv_storage_path?: string | null;
          education?: string | null;
          email?: string | null;
          email_norm?: string | null;
          experience_text?: string | null;
          experience_years?: number | null;
          extract_notes?: Json;
          full_name?: string | null;
          id?: string;
          imported_by?: string | null;
          job_title?: string | null;
          languages?: string[];
          location?: string | null;
          merged_at?: string | null;
          merged_profile_id?: string | null;
          nationality?: string | null;
          phone?: string | null;
          phone_norm?: string | null;
          skills?: string[];
          source_updated_at?: string;
          status?: string;
          updated_at?: string;
        };
        Update: {
          candidate_source?: string;
          career_level?: string | null;
          certifications?: string[];
          created_at?: string;
          cv_file_name?: string | null;
          cv_storage_path?: string | null;
          education?: string | null;
          email?: string | null;
          email_norm?: string | null;
          experience_text?: string | null;
          experience_years?: number | null;
          extract_notes?: Json;
          full_name?: string | null;
          id?: string;
          imported_by?: string | null;
          job_title?: string | null;
          languages?: string[];
          location?: string | null;
          merged_at?: string | null;
          merged_profile_id?: string | null;
          nationality?: string | null;
          phone?: string | null;
          phone_norm?: string | null;
          skills?: string[];
          source_updated_at?: string;
          status?: string;
          updated_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "external_candidates_merged_profile_id_fkey";
            columns: ["merged_profile_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      form_field_definitions: {
        Row: {
          created_at: string;
          field_key: string;
          field_type: Database["public"]["Enums"]["form_field_type"];
          id: string;
          label_ar: string;
          label_en: string;
          options_json: Json | null;
          owner_kind: Database["public"]["Enums"]["form_owner_kind"];
          required: boolean;
          scope: Database["public"]["Enums"]["form_scope"];
          scope_id: string | null;
          sort_order: number;
        };
        Insert: {
          created_at?: string;
          field_key: string;
          field_type: Database["public"]["Enums"]["form_field_type"];
          id?: string;
          label_ar: string;
          label_en: string;
          options_json?: Json | null;
          owner_kind: Database["public"]["Enums"]["form_owner_kind"];
          required?: boolean;
          scope: Database["public"]["Enums"]["form_scope"];
          scope_id?: string | null;
          sort_order?: number;
        };
        Update: {
          created_at?: string;
          field_key?: string;
          field_type?: Database["public"]["Enums"]["form_field_type"];
          id?: string;
          label_ar?: string;
          label_en?: string;
          options_json?: Json | null;
          owner_kind?: Database["public"]["Enums"]["form_owner_kind"];
          required?: boolean;
          scope?: Database["public"]["Enums"]["form_scope"];
          scope_id?: string | null;
          sort_order?: number;
        };
        Relationships: [];
      };
      individual_applications: {
        Row: {
          category_id: string;
          created_at: string;
          data: Json;
          group_id: string;
          id: string;
          level_id: string | null;
          profession_id: string;
          updated_at: string;
          user_id: string;
        };
        Insert: {
          category_id: string;
          created_at?: string;
          data?: Json;
          group_id: string;
          id?: string;
          level_id?: string | null;
          profession_id: string;
          updated_at?: string;
          user_id: string;
        };
        Update: {
          category_id?: string;
          created_at?: string;
          data?: Json;
          group_id?: string;
          id?: string;
          level_id?: string | null;
          profession_id?: string;
          updated_at?: string;
          user_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "individual_applications_category_id_fkey";
            columns: ["category_id"];
            isOneToOne: false;
            referencedRelation: "job_categories";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "individual_applications_group_id_fkey";
            columns: ["group_id"];
            isOneToOne: false;
            referencedRelation: "job_groups";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "individual_applications_level_id_fkey";
            columns: ["level_id"];
            isOneToOne: false;
            referencedRelation: "experience_levels";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "individual_applications_profession_id_fkey";
            columns: ["profession_id"];
            isOneToOne: false;
            referencedRelation: "professions";
            referencedColumns: ["id"];
          },
        ];
      };
      job_applications: {
        Row: {
          candidate_id: string;
          candidate_snapshot: Json;
          created_at: string;
          cv_url: string | null;
          employer_id: string | null;
          external_job_id: string | null;
          id: string;
          job_posting_id: string | null;
          job_snapshot: Json;
          status: Database["public"]["Enums"]["application_status"];
          status_history: Json;
          updated_at: string;
        };
        Insert: {
          candidate_id: string;
          candidate_snapshot?: Json;
          created_at?: string;
          cv_url?: string | null;
          employer_id?: string | null;
          external_job_id?: string | null;
          id?: string;
          job_posting_id?: string | null;
          job_snapshot?: Json;
          status?: Database["public"]["Enums"]["application_status"];
          status_history?: Json;
          updated_at?: string;
        };
        Update: {
          candidate_id?: string;
          candidate_snapshot?: Json;
          created_at?: string;
          cv_url?: string | null;
          employer_id?: string | null;
          external_job_id?: string | null;
          id?: string;
          job_posting_id?: string | null;
          job_snapshot?: Json;
          status?: Database["public"]["Enums"]["application_status"];
          status_history?: Json;
          updated_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "job_applications_job_posting_id_fkey";
            columns: ["job_posting_id"];
            isOneToOne: false;
            referencedRelation: "job_postings";
            referencedColumns: ["id"];
          },
        ];
      };
      job_categories: {
        Row: {
          created_at: string;
          id: string;
          name_ar: string;
          name_en: string;
          slug: string;
          sort_order: number;
        };
        Insert: {
          created_at?: string;
          id?: string;
          name_ar: string;
          name_en: string;
          slug: string;
          sort_order?: number;
        };
        Update: {
          created_at?: string;
          id?: string;
          name_ar?: string;
          name_en?: string;
          slug?: string;
          sort_order?: number;
        };
        Relationships: [];
      };
      job_groups: {
        Row: {
          category_id: string;
          created_at: string;
          id: string;
          name_ar: string;
          name_en: string;
          slug: string;
          sort_order: number;
        };
        Insert: {
          category_id: string;
          created_at?: string;
          id?: string;
          name_ar: string;
          name_en: string;
          slug: string;
          sort_order?: number;
        };
        Update: {
          category_id?: string;
          created_at?: string;
          id?: string;
          name_ar?: string;
          name_en?: string;
          slug?: string;
          sort_order?: number;
        };
        Relationships: [
          {
            foreignKeyName: "job_groups_category_id_fkey";
            columns: ["category_id"];
            isOneToOne: false;
            referencedRelation: "job_categories";
            referencedColumns: ["id"];
          },
        ];
      };
      job_postings: {
        Row: {
          closed_at: string | null;
          closes_at: string | null;
          created_at: string;
          data: Json;
          group_id: string;
          id: string;
          profession_id: string;
          published_at: string | null;
          status: Database["public"]["Enums"]["job_posting_status"];
          updated_at: string;
          user_id: string;
          views: number;
        };
        Insert: {
          closed_at?: string | null;
          closes_at?: string | null;
          created_at?: string;
          data?: Json;
          group_id: string;
          id?: string;
          profession_id: string;
          published_at?: string | null;
          status?: Database["public"]["Enums"]["job_posting_status"];
          updated_at?: string;
          user_id: string;
          views?: number;
        };
        Update: {
          closed_at?: string | null;
          closes_at?: string | null;
          created_at?: string;
          data?: Json;
          group_id?: string;
          id?: string;
          profession_id?: string;
          published_at?: string | null;
          status?: Database["public"]["Enums"]["job_posting_status"];
          updated_at?: string;
          user_id?: string;
          views?: number;
        };
        Relationships: [
          {
            foreignKeyName: "job_postings_group_id_fkey";
            columns: ["group_id"];
            isOneToOne: false;
            referencedRelation: "job_groups";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "job_postings_profession_id_fkey";
            columns: ["profession_id"];
            isOneToOne: false;
            referencedRelation: "professions";
            referencedColumns: ["id"];
          },
        ];
      };
      manpower_requests: {
        Row: {
          client_id: string;
          contract_duration: string | null;
          created_at: string;
          id: string;
          job_category: string;
          nationality_required: string | null;
          notes: string | null;
          owner_id: string;
          required_experience: string | null;
          required_quantity: number;
          salary_range: string | null;
          status: Database["public"]["Enums"]["manpower_request_status"];
          updated_at: string;
          work_location: string | null;
        };
        Insert: {
          client_id: string;
          contract_duration?: string | null;
          created_at?: string;
          id?: string;
          job_category: string;
          nationality_required?: string | null;
          notes?: string | null;
          owner_id: string;
          required_experience?: string | null;
          required_quantity?: number;
          salary_range?: string | null;
          status?: Database["public"]["Enums"]["manpower_request_status"];
          updated_at?: string;
          work_location?: string | null;
        };
        Update: {
          client_id?: string;
          contract_duration?: string | null;
          created_at?: string;
          id?: string;
          job_category?: string;
          nationality_required?: string | null;
          notes?: string | null;
          owner_id?: string;
          required_experience?: string | null;
          required_quantity?: number;
          salary_range?: string | null;
          status?: Database["public"]["Enums"]["manpower_request_status"];
          updated_at?: string;
          work_location?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "manpower_requests_client_id_fkey";
            columns: ["client_id"];
            isOneToOne: false;
            referencedRelation: "clients";
            referencedColumns: ["id"];
          },
        ];
      };
      package_audit_log: {
        Row: {
          action: string;
          admin_email: string | null;
          admin_user_id: string | null;
          changes: Json;
          created_at: string;
          id: string;
          package_id: string | null;
          package_slug: string | null;
        };
        Insert: {
          action: string;
          admin_email?: string | null;
          admin_user_id?: string | null;
          changes?: Json;
          created_at?: string;
          id?: string;
          package_id?: string | null;
          package_slug?: string | null;
        };
        Update: {
          action?: string;
          admin_email?: string | null;
          admin_user_id?: string | null;
          changes?: Json;
          created_at?: string;
          id?: string;
          package_id?: string | null;
          package_slug?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "package_audit_log_package_id_fkey";
            columns: ["package_id"];
            isOneToOne: false;
            referencedRelation: "packages";
            referencedColumns: ["id"];
          },
        ];
      };
      package_change_requests: {
        Row: {
          activated_at: string | null;
          activated_subscription_id: string | null;
          amount_before_credit: number;
          amount_due: number;
          amount_paid: number;
          cancelled_at: string | null;
          change_type: Database["public"]["Enums"]["package_change_type"];
          created_at: string;
          credit_applied: number;
          currency: string;
          discount: number;
          effective_date: string;
          failure_reason: string | null;
          id: string;
          idempotency_key: string;
          new_package_id: string;
          old_package_id: string | null;
          old_subscription_id: string | null;
          package_snapshot: Json;
          payment_reference: string | null;
          policy_snapshot: Json;
          requested_at: string;
          requested_by: string;
          status: Database["public"]["Enums"]["package_change_status"];
          updated_at: string;
          user_id: string;
        };
        Insert: {
          activated_at?: string | null;
          activated_subscription_id?: string | null;
          amount_before_credit?: number;
          amount_due?: number;
          amount_paid?: number;
          cancelled_at?: string | null;
          change_type: Database["public"]["Enums"]["package_change_type"];
          created_at?: string;
          credit_applied?: number;
          currency?: string;
          discount?: number;
          effective_date: string;
          failure_reason?: string | null;
          id?: string;
          idempotency_key: string;
          new_package_id: string;
          old_package_id?: string | null;
          old_subscription_id?: string | null;
          package_snapshot?: Json;
          payment_reference?: string | null;
          policy_snapshot?: Json;
          requested_at?: string;
          requested_by: string;
          status?: Database["public"]["Enums"]["package_change_status"];
          updated_at?: string;
          user_id: string;
        };
        Update: {
          activated_at?: string | null;
          activated_subscription_id?: string | null;
          amount_before_credit?: number;
          amount_due?: number;
          amount_paid?: number;
          cancelled_at?: string | null;
          change_type?: Database["public"]["Enums"]["package_change_type"];
          created_at?: string;
          credit_applied?: number;
          currency?: string;
          discount?: number;
          effective_date?: string;
          failure_reason?: string | null;
          id?: string;
          idempotency_key?: string;
          new_package_id?: string;
          old_package_id?: string | null;
          old_subscription_id?: string | null;
          package_snapshot?: Json;
          payment_reference?: string | null;
          policy_snapshot?: Json;
          requested_at?: string;
          requested_by?: string;
          status?: Database["public"]["Enums"]["package_change_status"];
          updated_at?: string;
          user_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "package_change_requests_activated_subscription_id_fkey";
            columns: ["activated_subscription_id"];
            isOneToOne: false;
            referencedRelation: "subscriptions";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "package_change_requests_new_package_id_fkey";
            columns: ["new_package_id"];
            isOneToOne: false;
            referencedRelation: "packages";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "package_change_requests_old_package_id_fkey";
            columns: ["old_package_id"];
            isOneToOne: false;
            referencedRelation: "packages";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "package_change_requests_old_subscription_id_fkey";
            columns: ["old_subscription_id"];
            isOneToOne: false;
            referencedRelation: "subscriptions";
            referencedColumns: ["id"];
          },
        ];
      };
      package_features: {
        Row: {
          created_at: string;
          enabled: boolean;
          feature_key: string;
          id: string;
          label_ar: string;
          label_en: string;
          package_id: string;
          sort_order: number;
          updated_at: string;
          value_bool: boolean | null;
          value_number: number | null;
          value_text_ar: string | null;
          value_text_en: string | null;
          value_type: string;
        };
        Insert: {
          created_at?: string;
          enabled?: boolean;
          feature_key: string;
          id?: string;
          label_ar: string;
          label_en: string;
          package_id: string;
          sort_order?: number;
          updated_at?: string;
          value_bool?: boolean | null;
          value_number?: number | null;
          value_text_ar?: string | null;
          value_text_en?: string | null;
          value_type?: string;
        };
        Update: {
          created_at?: string;
          enabled?: boolean;
          feature_key?: string;
          id?: string;
          label_ar?: string;
          label_en?: string;
          package_id?: string;
          sort_order?: number;
          updated_at?: string;
          value_bool?: boolean | null;
          value_number?: number | null;
          value_text_ar?: string | null;
          value_text_en?: string | null;
          value_type?: string;
        };
        Relationships: [
          {
            foreignKeyName: "package_features_package_id_fkey";
            columns: ["package_id"];
            isOneToOne: false;
            referencedRelation: "packages";
            referencedColumns: ["id"];
          },
        ];
      };
      packages: {
        Row: {
          badge_text_ar: string | null;
          badge_text_en: string | null;
          billing_period: string;
          code_prefix: string | null;
          contact_instead_of_price: boolean;
          created_at: string;
          cta_text_ar: string | null;
          cta_text_en: string | null;
          cta_url: string | null;
          currency: string;
          discount_amount: number | null;
          discount_percent: number | null;
          display_end_at: string | null;
          display_start_at: string | null;
          duration_label_ar: string | null;
          duration_label_en: string | null;
          duration_months: number | null;
          full_desc_ar: string | null;
          full_desc_en: string | null;
          id: string;
          is_active: boolean;
          is_enterprise: boolean;
          is_free: boolean;
          is_recommended: boolean;
          name_ar: string;
          name_en: string;
          price: number;
          price_after_trial: number | null;
          promo_ends_at: string | null;
          promo_price: number | null;
          promo_starts_at: string | null;
          rank: number;
          short_desc_ar: string | null;
          short_desc_en: string | null;
          show_price: boolean;
          slug: string;
          sort_order: number;
          trial_days: number;
          trial_enabled: boolean;
          trial_ends_at: string | null;
          trial_new_companies_only: boolean;
          trial_starts_at: string | null;
          updated_at: string;
          vat_note_ar: string | null;
          vat_note_en: string | null;
        };
        Insert: {
          badge_text_ar?: string | null;
          badge_text_en?: string | null;
          billing_period?: string;
          code_prefix?: string | null;
          contact_instead_of_price?: boolean;
          created_at?: string;
          cta_text_ar?: string | null;
          cta_text_en?: string | null;
          cta_url?: string | null;
          currency?: string;
          discount_amount?: number | null;
          discount_percent?: number | null;
          display_end_at?: string | null;
          display_start_at?: string | null;
          duration_label_ar?: string | null;
          duration_label_en?: string | null;
          duration_months?: number | null;
          full_desc_ar?: string | null;
          full_desc_en?: string | null;
          id?: string;
          is_active?: boolean;
          is_enterprise?: boolean;
          is_free?: boolean;
          is_recommended?: boolean;
          name_ar: string;
          name_en: string;
          price?: number;
          price_after_trial?: number | null;
          promo_ends_at?: string | null;
          promo_price?: number | null;
          promo_starts_at?: string | null;
          rank?: number;
          short_desc_ar?: string | null;
          short_desc_en?: string | null;
          show_price?: boolean;
          slug: string;
          sort_order?: number;
          trial_days?: number;
          trial_enabled?: boolean;
          trial_ends_at?: string | null;
          trial_new_companies_only?: boolean;
          trial_starts_at?: string | null;
          updated_at?: string;
          vat_note_ar?: string | null;
          vat_note_en?: string | null;
        };
        Update: {
          badge_text_ar?: string | null;
          badge_text_en?: string | null;
          billing_period?: string;
          code_prefix?: string | null;
          contact_instead_of_price?: boolean;
          created_at?: string;
          cta_text_ar?: string | null;
          cta_text_en?: string | null;
          cta_url?: string | null;
          currency?: string;
          discount_amount?: number | null;
          discount_percent?: number | null;
          display_end_at?: string | null;
          display_start_at?: string | null;
          duration_label_ar?: string | null;
          duration_label_en?: string | null;
          duration_months?: number | null;
          full_desc_ar?: string | null;
          full_desc_en?: string | null;
          id?: string;
          is_active?: boolean;
          is_enterprise?: boolean;
          is_free?: boolean;
          is_recommended?: boolean;
          name_ar?: string;
          name_en?: string;
          price?: number;
          price_after_trial?: number | null;
          promo_ends_at?: string | null;
          promo_price?: number | null;
          promo_starts_at?: string | null;
          rank?: number;
          short_desc_ar?: string | null;
          short_desc_en?: string | null;
          show_price?: boolean;
          slug?: string;
          sort_order?: number;
          trial_days?: number;
          trial_enabled?: boolean;
          trial_ends_at?: string | null;
          trial_new_companies_only?: boolean;
          trial_starts_at?: string | null;
          updated_at?: string;
          vat_note_ar?: string | null;
          vat_note_en?: string | null;
        };
        Relationships: [];
      };
      professions: {
        Row: {
          created_at: string;
          group_id: string;
          id: string;
          name_ar: string;
          name_en: string;
          slug: string;
          sort_order: number;
        };
        Insert: {
          created_at?: string;
          group_id: string;
          id?: string;
          name_ar: string;
          name_en: string;
          slug: string;
          sort_order?: number;
        };
        Update: {
          created_at?: string;
          group_id?: string;
          id?: string;
          name_ar?: string;
          name_en?: string;
          slug?: string;
          sort_order?: number;
        };
        Relationships: [
          {
            foreignKeyName: "professions_group_id_fkey";
            columns: ["group_id"];
            isOneToOne: false;
            referencedRelation: "job_groups";
            referencedColumns: ["id"];
          },
        ];
      };
      profiles: {
        Row: {
          account_type: Database["public"]["Enums"]["account_type"];
          availability: string | null;
          branches_count: number;
          branches_verified: boolean;
          candidate_source: string;
          company_code: string | null;
          company_name: string | null;
          company_type: number;
          country: string | null;
          created_at: string;
          cv_uploaded_at: string | null;
          cv_url: string | null;
          education: string | null;
          email: string | null;
          experience: string | null;
          full_name: string | null;
          gender: string | null;
          id: string;
          interview_video_url: string | null;
          is_featured: boolean;
          job_title: string | null;
          languages: string | null;
          nationality: string | null;
          phone: string | null;
          photo_url: string | null;
          portal_valuation: number;
          profession: string | null;
          sector: string | null;
          skills: string[];
          updated_at: string;
        };
        Insert: {
          account_type: Database["public"]["Enums"]["account_type"];
          availability?: string | null;
          branches_count?: number;
          branches_verified?: boolean;
          candidate_source?: string;
          company_code?: string | null;
          company_name?: string | null;
          company_type?: number;
          country?: string | null;
          created_at?: string;
          cv_uploaded_at?: string | null;
          cv_url?: string | null;
          education?: string | null;
          email?: string | null;
          experience?: string | null;
          full_name?: string | null;
          gender?: string | null;
          id: string;
          interview_video_url?: string | null;
          is_featured?: boolean;
          job_title?: string | null;
          languages?: string | null;
          nationality?: string | null;
          phone?: string | null;
          photo_url?: string | null;
          portal_valuation?: number;
          profession?: string | null;
          sector?: string | null;
          skills?: string[];
          updated_at?: string;
        };
        Update: {
          account_type?: Database["public"]["Enums"]["account_type"];
          availability?: string | null;
          branches_count?: number;
          branches_verified?: boolean;
          candidate_source?: string;
          company_code?: string | null;
          company_name?: string | null;
          company_type?: number;
          country?: string | null;
          created_at?: string;
          cv_uploaded_at?: string | null;
          cv_url?: string | null;
          education?: string | null;
          email?: string | null;
          experience?: string | null;
          full_name?: string | null;
          gender?: string | null;
          id?: string;
          interview_video_url?: string | null;
          is_featured?: boolean;
          job_title?: string | null;
          languages?: string | null;
          nationality?: string | null;
          phone?: string | null;
          photo_url?: string | null;
          portal_valuation?: number;
          profession?: string | null;
          sector?: string | null;
          skills?: string[];
          updated_at?: string;
        };
        Relationships: [];
      };
      salary_benchmarks: {
        Row: {
          benchmark_amount: number;
          career_level: string | null;
          country: string | null;
          created_at: string;
          currency: string;
          id: string;
          job_category: string;
          salary_period: string;
          sector: string | null;
          updated_at: string;
        };
        Insert: {
          benchmark_amount: number;
          career_level?: string | null;
          country?: string | null;
          created_at?: string;
          currency?: string;
          id?: string;
          job_category: string;
          salary_period?: string;
          sector?: string | null;
          updated_at?: string;
        };
        Update: {
          benchmark_amount?: number;
          career_level?: string | null;
          country?: string | null;
          created_at?: string;
          currency?: string;
          id?: string;
          job_category?: string;
          salary_period?: string;
          sector?: string | null;
          updated_at?: string;
        };
        Relationships: [];
      };
      subscription_policy: {
        Row: {
          allow_same_package_renewal: boolean;
          created_at: string;
          downgrade_timing: string;
          id: boolean;
          prorate_credit: boolean;
          require_admin_approval: boolean;
          tax_percent: number;
          updated_at: string;
          upgrade_timing: string;
        };
        Insert: {
          allow_same_package_renewal?: boolean;
          created_at?: string;
          downgrade_timing?: string;
          id?: boolean;
          prorate_credit?: boolean;
          require_admin_approval?: boolean;
          tax_percent?: number;
          updated_at?: string;
          upgrade_timing?: string;
        };
        Update: {
          allow_same_package_renewal?: boolean;
          created_at?: string;
          downgrade_timing?: string;
          id?: boolean;
          prorate_credit?: boolean;
          require_admin_approval?: boolean;
          tax_percent?: number;
          updated_at?: string;
          upgrade_timing?: string;
        };
        Relationships: [];
      };
      subscriptions: {
        Row: {
          activated_at: string | null;
          amount_due: number;
          cancelled_at: string | null;
          change_request_id: string | null;
          change_type: Database["public"]["Enums"]["package_change_type"] | null;
          created_at: string;
          credit_applied: number;
          currency: string;
          discount: number;
          expires_at: string | null;
          id: string;
          is_trial: boolean;
          outstanding_amount: number;
          package_code: string | null;
          package_id: string | null;
          package_serial: number | null;
          package_snapshot: Json;
          payment_reference: string | null;
          price_paid: number;
          started_at: string;
          status: string;
          updated_at: string;
          user_id: string;
        };
        Insert: {
          activated_at?: string | null;
          amount_due?: number;
          cancelled_at?: string | null;
          change_request_id?: string | null;
          change_type?: Database["public"]["Enums"]["package_change_type"] | null;
          created_at?: string;
          credit_applied?: number;
          currency?: string;
          discount?: number;
          expires_at?: string | null;
          id?: string;
          is_trial?: boolean;
          outstanding_amount?: number;
          package_code?: string | null;
          package_id?: string | null;
          package_serial?: number | null;
          package_snapshot?: Json;
          payment_reference?: string | null;
          price_paid?: number;
          started_at?: string;
          status?: string;
          updated_at?: string;
          user_id: string;
        };
        Update: {
          activated_at?: string | null;
          amount_due?: number;
          cancelled_at?: string | null;
          change_request_id?: string | null;
          change_type?: Database["public"]["Enums"]["package_change_type"] | null;
          created_at?: string;
          credit_applied?: number;
          currency?: string;
          discount?: number;
          expires_at?: string | null;
          id?: string;
          is_trial?: boolean;
          outstanding_amount?: number;
          package_code?: string | null;
          package_id?: string | null;
          package_serial?: number | null;
          package_snapshot?: Json;
          payment_reference?: string | null;
          price_paid?: number;
          started_at?: string;
          status?: string;
          updated_at?: string;
          user_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "subscriptions_change_request_id_fkey";
            columns: ["change_request_id"];
            isOneToOne: false;
            referencedRelation: "package_change_requests";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "subscriptions_package_id_fkey";
            columns: ["package_id"];
            isOneToOne: false;
            referencedRelation: "packages";
            referencedColumns: ["id"];
          },
        ];
      };
      user_roles: {
        Row: {
          created_at: string;
          id: string;
          role: Database["public"]["Enums"]["app_role"];
          user_id: string;
        };
        Insert: {
          created_at?: string;
          id?: string;
          role: Database["public"]["Enums"]["app_role"];
          user_id: string;
        };
        Update: {
          created_at?: string;
          id?: string;
          role?: Database["public"]["Enums"]["app_role"];
          user_id?: string;
        };
        Relationships: [];
      };
      valuation_config: {
        Row: {
          company_weight: number;
          created_at: string;
          default_benchmark_amount: number;
          excellent_threshold: number;
          id: boolean;
          salary_weight: number;
          show_applicant_count_public: boolean;
          show_portal_valuation_public: boolean;
          updated_at: string;
          very_good_threshold: number;
        };
        Insert: {
          company_weight?: number;
          created_at?: string;
          default_benchmark_amount?: number;
          excellent_threshold?: number;
          id?: boolean;
          salary_weight?: number;
          show_applicant_count_public?: boolean;
          show_portal_valuation_public?: boolean;
          updated_at?: string;
          very_good_threshold?: number;
        };
        Update: {
          company_weight?: number;
          created_at?: string;
          default_benchmark_amount?: number;
          excellent_threshold?: number;
          id?: boolean;
          salary_weight?: number;
          show_applicant_count_public?: boolean;
          show_portal_valuation_public?: boolean;
          updated_at?: string;
          very_good_threshold?: number;
        };
        Relationships: [];
      };
    };
    Views: {
      [_ in never]: never;
    };
    Functions: {
      activate_package_change: {
        Args: {
          _actor?: string;
          _amount_paid?: number;
          _payment_reference?: string;
          _request_id: string;
        };
        Returns: string;
      };
      admin_can: {
        Args: { _action: string; _module: string; _user_id: string };
        Returns: boolean;
      };
      assign_company_code: { Args: { _user_id: string }; Returns: string };
      close_expired_job_postings: { Args: never; Returns: number };
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"];
          _user_id: string;
        };
        Returns: boolean;
      };
      increment_job_views: {
        Args: { _job_posting_id: string };
        Returns: undefined;
      };
      is_main_admin: { Args: { _user_id: string }; Returns: boolean };
      job_listing_meta: {
        Args: never;
        Returns: {
          applicant_count: number;
          branches_count: number;
          closes_at: string;
          company_type: number;
          is_direct_ad: boolean;
          job_posting_id: string;
          portal_valuation: number;
          published_at: string;
          status: string;
          views: number;
        }[];
      };
      merge_external_candidates: { Args: { _user_id: string }; Returns: number };
      next_package_serial: { Args: never; Returns: number };
      normalize_email: { Args: { _v: string }; Returns: string };
      normalize_phone: { Args: { _v: string }; Returns: string };
      platform_stats: { Args: never; Returns: Json };
      roll_due_subscriptions: { Args: never; Returns: number };
    };
    Enums: {
      account_type: "job_seeker" | "company";
      app_role: "admin" | "job_seeker" | "company";
      application_status:
        | "submitted"
        | "cv_sent"
        | "employer_reviewed"
        | "shortlisted"
        | "rejected"
        | "hired";
      client_legal_structure:
        | "joint_stock"
        | "limited_partnership"
        | "general_partnership"
        | "sole_proprietorship";
      form_field_type:
        | "text"
        | "textarea"
        | "number"
        | "email"
        | "phone"
        | "date"
        | "select"
        | "multiselect"
        | "checkbox"
        | "file";
      form_owner_kind: "individual" | "employer";
      form_scope: "global" | "category" | "group" | "profession" | "level";
      job_posting_status:
        | "published"
        | "paused"
        | "closed"
        | "draft"
        | "archived"
        | "pending_approval"
        | "rejected"
        | "expired";
      manpower_request_status: "draft" | "submitted" | "in_progress" | "fulfilled" | "cancelled";
      package_change_status:
        | "pending"
        | "awaiting_payment"
        | "scheduled"
        | "active"
        | "expired"
        | "cancelled"
        | "failed";
      package_change_type: "new" | "upgrade" | "downgrade" | "renewal";
    };
    CompositeTypes: {
      [_ in never]: never;
    };
  };
};

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">;

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">];

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R;
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] & DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R;
      }
      ? R
      : never
    : never;

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I;
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I;
      }
      ? I
      : never
    : never;

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U;
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U;
      }
      ? U
      : never
    : never;

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never;

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never;

export const Constants = {
  public: {
    Enums: {
      account_type: ["job_seeker", "company"],
      app_role: ["admin", "job_seeker", "company"],
      application_status: [
        "submitted",
        "cv_sent",
        "employer_reviewed",
        "shortlisted",
        "rejected",
        "hired",
      ],
      client_legal_structure: [
        "joint_stock",
        "limited_partnership",
        "general_partnership",
        "sole_proprietorship",
      ],
      form_field_type: [
        "text",
        "textarea",
        "number",
        "email",
        "phone",
        "date",
        "select",
        "multiselect",
        "checkbox",
        "file",
      ],
      form_owner_kind: ["individual", "employer"],
      form_scope: ["global", "category", "group", "profession", "level"],
      job_posting_status: [
        "published",
        "paused",
        "closed",
        "draft",
        "archived",
        "pending_approval",
        "rejected",
        "expired",
      ],
      manpower_request_status: ["draft", "submitted", "in_progress", "fulfilled", "cancelled"],
      package_change_status: [
        "pending",
        "awaiting_payment",
        "scheduled",
        "active",
        "expired",
        "cancelled",
        "failed",
      ],
      package_change_type: ["new", "upgrade", "downgrade", "renewal"],
    },
  },
} as const;
