import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Eye, History, Loader2, Package, Plus, Save, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useI18n, tx } from "@/i18n";
import { CANDIDATE_FEATURES, CANDIDATE_FEATURE_LABELS } from "@/lib/entitlements";
import {
  BILLING_PERIODS,
  FEATURE_VALUE_TYPES,
  deleteFeature,
  durationLabel,
  featureValueLabel,
  fetchAllPackages,
  fetchPackageAuditLog,
  pick,
  priceLabel,
  savePackage,
  saveFeature,
  setPackageActive,
  trialLabel,
  type FeatureInput,
  type PackageFeatureRow,
  type PackageInput,
  type PackageWithFeatures,
} from "@/lib/packages";

const EMPTY: PackageInput = {
  slug: "",
  name_en: "",
  name_ar: "",
  price: 0,
  currency: "SAR",
  billing_period: "monthly",
  duration_months: 3,
  trial_enabled: false,
  trial_days: 0,
  is_active: true,
  sort_order: 99,
};

const dateVal = (v: string | null | undefined) => (v ? v.slice(0, 10) : "");
const toIso = (v: string) => (v ? new Date(`${v}T00:00:00Z`).toISOString() : null);

/** Package Management — lives inside the existing Admin Control Panel. */
export function PackageManager() {
  const { t, lang } = useI18n();
  const qc = useQueryClient();
  const packagesQuery = useQuery({ queryKey: ["admin-packages"], queryFn: fetchAllPackages });
  const auditQuery = useQuery({
    queryKey: ["package-audit"],
    queryFn: () => fetchPackageAuditLog(15),
  });

  const [editing, setEditing] = useState<PackageInput | null>(null);
  const [preview, setPreview] = useState<PackageWithFeatures | null>(null);
  const [showHistory, setShowHistory] = useState(false);

  const invalidate = async () => {
    await qc.invalidateQueries({ queryKey: ["admin-packages"] });
    await qc.invalidateQueries({ queryKey: ["public-packages"] });
    await qc.invalidateQueries({ queryKey: ["package-audit"] });
  };

  const save = useMutation({
    mutationFn: async (input: PackageInput) => {
      if (!input.slug.trim())
        throw new Error(t(tx("A package code is required.", "رمز الباقة مطلوب.")));
      if (!input.name_en.trim() || !input.name_ar.trim())
        throw new Error(
          t(tx("Arabic and English names are required.", "الاسم بالعربية والإنجليزية مطلوب.")),
        );
      await savePackage(input);
    },
    onSuccess: async () => {
      await invalidate();
      setEditing(null);
      toast.success(t(tx("Package saved and published.", "تم حفظ الباقة ونشرها.")));
    },
    onError: (e: Error) =>
      toast.error(e.message || t(tx("Could not save the package.", "تعذر حفظ الباقة."))),
  });

  const toggleActive = useMutation({
    mutationFn: ({ pkg, active }: { pkg: PackageWithFeatures; active: boolean }) =>
      setPackageActive(pkg, active),
    onSuccess: async () => {
      await invalidate();
      toast.success(t(tx("Package status updated.", "تم تحديث حالة الباقة.")));
    },
    onError: () => toast.error(t(tx("Could not update the status.", "تعذر تحديث الحالة."))),
  });

  const featureMutation = useMutation({
    mutationFn: (f: FeatureInput) => saveFeature(f),
    onSuccess: async () => {
      await invalidate();
      toast.success(t(tx("Feature saved.", "تم حفظ الميزة.")));
    },
    onError: () => toast.error(t(tx("Could not save the feature.", "تعذر حفظ الميزة."))),
  });

  const removeFeature = useMutation({
    mutationFn: deleteFeature,
    onSuccess: invalidate,
    onError: () => toast.error(t(tx("Could not remove the feature.", "تعذر حذف الميزة."))),
  });

  const packages = packagesQuery.data ?? [];
  const num = (v: string) => (v === "" ? 0 : Number(v));
  const nullNum = (v: string) => (v === "" ? null : Number(v));

  return (
    <Card>
      <CardHeader className="flex flex-row flex-wrap items-center justify-between gap-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Package className="h-4 w-4 text-gold-dark" />
          {t(tx("Package Management", "إدارة الباقات"))}
        </CardTitle>
        <div className="flex gap-2">
          <Button variant="ghost" size="sm" onClick={() => setShowHistory((v) => !v)}>
            <History className="h-4 w-4" /> {t(tx("Change history", "سجل التغييرات"))}
          </Button>
          <Button variant="outline" size="sm" onClick={() => setEditing({ ...EMPTY })}>
            <Plus className="h-4 w-4" /> {t(tx("Add New Package", "إضافة باقة جديدة"))}
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {packagesQuery.isLoading ? (
          <Loader2 className="h-5 w-5 animate-spin text-gold-dark" />
        ) : (
          <div className="overflow-x-auto rounded-lg border border-border/70">
            <table className="w-full min-w-[720px] text-sm">
              <thead>
                <tr className="border-b border-border/70 bg-primary/5">
                  {[
                    tx("Package", "الباقة"),
                    tx("Price", "السعر"),
                    tx("Trial", "الفترة المجانية"),
                    tx("Duration", "المدة"),
                    tx("Status", "الحالة"),
                    tx("Actions", "إجراءات"),
                  ].map((h) => (
                    <th key={h.en} className="p-3 text-start font-semibold text-heading">
                      {t(h)}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {packages.map((p) => (
                  <tr key={p.id} className="border-b border-border/60 last:border-0">
                    <td className="p-3">
                      <span className="font-medium text-heading">
                        {pick(lang, p.name_en, p.name_ar)}
                      </span>
                      {p.is_recommended && (
                        <span className="ms-2 rounded-full bg-primary/15 px-2 py-0.5 text-[10px] font-bold text-gold-dark">
                          {t(tx("Recommended", "موصى بها"))}
                        </span>
                      )}
                      <p className="text-xs text-muted-foreground">{p.slug}</p>
                    </td>
                    <td className="p-3 font-semibold text-gold-dark">{priceLabel(p, lang)}</td>
                    <td className="p-3">{trialLabel(p, lang) ?? "—"}</td>
                    <td className="p-3">{durationLabel(p, lang)}</td>
                    <td className="p-3">
                      <span
                        className={
                          p.is_active
                            ? "rounded-full border border-emerald-500/30 bg-emerald-500/15 px-2 py-0.5 text-xs text-emerald-700"
                            : "rounded-full border border-border bg-muted px-2 py-0.5 text-xs text-muted-foreground"
                        }
                      >
                        {p.is_active ? t(tx("Active", "نشطة")) : t(tx("Inactive", "غير نشطة"))}
                      </span>
                    </td>
                    <td className="p-3">
                      <div className="flex flex-wrap items-center gap-1">
                        <Button variant="ghost" size="sm" onClick={() => setEditing({ ...p })}>
                          {t(tx("Edit Package", "تعديل الباقة"))}
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          aria-label={t(tx("Preview", "معاينة"))}
                          onClick={() => setPreview(p)}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Switch
                          aria-label={t(tx("Active", "نشطة"))}
                          checked={p.is_active}
                          onCheckedChange={(v) => toggleActive.mutate({ pkg: p, active: v })}
                        />
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Features per package ------------------------------------------- */}
        {packages.map((p) => (
          <FeatureEditor
            key={`f-${p.id}`}
            pkg={p}
            onSave={(f) => featureMutation.mutate(f)}
            onRemove={(id) => removeFeature.mutate(id)}
            pending={featureMutation.isPending}
          />
        ))}

        {/* Audit trail (admin only) --------------------------------------- */}
        {showHistory && (
          <div className="space-y-2 rounded-lg border border-border/70 p-4">
            <p className="text-sm font-semibold text-heading">
              {t(tx("Change history", "سجل التغييرات"))}
            </p>
            {(auditQuery.data ?? []).length === 0 ? (
              <p className="text-xs text-muted-foreground">
                {t(tx("No changes recorded yet.", "لا توجد تغييرات مسجلة."))}
              </p>
            ) : (
              <ul className="space-y-2 text-xs text-muted-foreground">
                {(auditQuery.data ?? []).map((a) => (
                  <li key={a.id}>
                    <span className="font-semibold text-foreground/90">{a.package_slug}</span> ·{" "}
                    {a.action} · {new Date(a.created_at).toLocaleString()} · {a.admin_email ?? "—"}
                    <pre className="mt-1 whitespace-pre-wrap break-all text-[11px]">
                      {JSON.stringify(a.changes)}
                    </pre>
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}
      </CardContent>

      {/* Edit / create dialog --------------------------------------------- */}
      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent className="max-h-[85vh] max-w-3xl overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editing?.id
                ? t(tx("Edit Package", "تعديل الباقة"))
                : t(tx("Add New Package", "إضافة باقة جديدة"))}
            </DialogTitle>
          </DialogHeader>
          {editing && (
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label={tx("Package code", "رمز الباقة")}>
                <Input
                  value={editing.slug}
                  onChange={(e) => setEditing({ ...editing, slug: e.target.value })}
                />
              </Field>
              <Field label={tx("Display order", "ترتيب العرض")}>
                <Input
                  type="number"
                  value={editing.sort_order ?? 0}
                  onChange={(e) => setEditing({ ...editing, sort_order: num(e.target.value) })}
                />
              </Field>
              <Field label={tx("Name (English)", "الاسم بالإنجليزية")}>
                <Input
                  value={editing.name_en}
                  onChange={(e) => setEditing({ ...editing, name_en: e.target.value })}
                />
              </Field>
              <Field label={tx("Name (Arabic)", "الاسم بالعربية")}>
                <Input
                  value={editing.name_ar}
                  onChange={(e) => setEditing({ ...editing, name_ar: e.target.value })}
                />
              </Field>
              <Field label={tx("Short description (EN)", "وصف مختصر (إنجليزي)")}>
                <Input
                  value={editing.short_desc_en ?? ""}
                  onChange={(e) => setEditing({ ...editing, short_desc_en: e.target.value })}
                />
              </Field>
              <Field label={tx("Short description (AR)", "وصف مختصر (عربي)")}>
                <Input
                  value={editing.short_desc_ar ?? ""}
                  onChange={(e) => setEditing({ ...editing, short_desc_ar: e.target.value })}
                />
              </Field>
              <Field label={tx("Full description (EN)", "الوصف الكامل (إنجليزي)")}>
                <Textarea
                  value={editing.full_desc_en ?? ""}
                  onChange={(e) => setEditing({ ...editing, full_desc_en: e.target.value })}
                />
              </Field>
              <Field label={tx("Full description (AR)", "الوصف الكامل (عربي)")}>
                <Textarea
                  value={editing.full_desc_ar ?? ""}
                  onChange={(e) => setEditing({ ...editing, full_desc_ar: e.target.value })}
                />
              </Field>

              <Field label={tx("Price", "السعر")}>
                <Input
                  type="number"
                  value={editing.price ?? 0}
                  onChange={(e) => setEditing({ ...editing, price: num(e.target.value) })}
                />
              </Field>
              <Field label={tx("Promotional price", "السعر الترويجي")}>
                <Input
                  type="number"
                  value={editing.promo_price ?? ""}
                  onChange={(e) => setEditing({ ...editing, promo_price: nullNum(e.target.value) })}
                />
              </Field>
              <Field label={tx("Discount %", "نسبة الخصم %")}>
                <Input
                  type="number"
                  value={editing.discount_percent ?? ""}
                  onChange={(e) =>
                    setEditing({ ...editing, discount_percent: nullNum(e.target.value) })
                  }
                />
              </Field>
              <Field label={tx("Discount amount", "قيمة الخصم")}>
                <Input
                  type="number"
                  value={editing.discount_amount ?? ""}
                  onChange={(e) =>
                    setEditing({ ...editing, discount_amount: nullNum(e.target.value) })
                  }
                />
              </Field>
              <Field label={tx("Promotion start", "بداية العرض الترويجي")}>
                <Input
                  type="date"
                  value={dateVal(editing.promo_starts_at)}
                  onChange={(e) =>
                    setEditing({ ...editing, promo_starts_at: toIso(e.target.value) })
                  }
                />
              </Field>
              <Field label={tx("Promotion end", "نهاية العرض الترويجي")}>
                <Input
                  type="date"
                  value={dateVal(editing.promo_ends_at)}
                  onChange={(e) => setEditing({ ...editing, promo_ends_at: toIso(e.target.value) })}
                />
              </Field>
              <Field label={tx("Currency", "العملة")}>
                <Input
                  value={editing.currency ?? "SAR"}
                  onChange={(e) => setEditing({ ...editing, currency: e.target.value })}
                />
              </Field>
              <Field label={tx("Billing period", "دورة الفاتورة")}>
                <Select
                  value={editing.billing_period ?? "monthly"}
                  onValueChange={(v) => setEditing({ ...editing, billing_period: v })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {BILLING_PERIODS.map((b) => (
                      <SelectItem key={b.value} value={b.value}>
                        {t(b.label)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Field>
              <Field label={tx("Duration (months)", "المدة (أشهر)")}>
                <Input
                  type="number"
                  value={editing.duration_months ?? ""}
                  onChange={(e) =>
                    setEditing({ ...editing, duration_months: nullNum(e.target.value) })
                  }
                />
              </Field>
              <Field label={tx("Duration label (EN / AR)", "وصف المدة (إنجليزي / عربي)")}>
                <div className="flex gap-2">
                  <Input
                    value={editing.duration_label_en ?? ""}
                    onChange={(e) => setEditing({ ...editing, duration_label_en: e.target.value })}
                  />
                  <Input
                    value={editing.duration_label_ar ?? ""}
                    onChange={(e) => setEditing({ ...editing, duration_label_ar: e.target.value })}
                  />
                </div>
              </Field>

              {/* Free trial */}
              <Field label={tx("Free trial days", "أيام الفترة المجانية")}>
                <Input
                  type="number"
                  value={editing.trial_days ?? 0}
                  onChange={(e) => setEditing({ ...editing, trial_days: num(e.target.value) })}
                />
              </Field>
              <Field label={tx("Price after trial", "السعر بعد الفترة المجانية")}>
                <Input
                  type="number"
                  value={editing.price_after_trial ?? ""}
                  onChange={(e) =>
                    setEditing({ ...editing, price_after_trial: nullNum(e.target.value) })
                  }
                />
              </Field>
              <Field label={tx("Trial start date", "تاريخ بداية الفترة المجانية")}>
                <Input
                  type="date"
                  value={dateVal(editing.trial_starts_at)}
                  onChange={(e) =>
                    setEditing({ ...editing, trial_starts_at: toIso(e.target.value) })
                  }
                />
              </Field>
              <Field label={tx("Trial end date", "تاريخ نهاية الفترة المجانية")}>
                <Input
                  type="date"
                  value={dateVal(editing.trial_ends_at)}
                  onChange={(e) => setEditing({ ...editing, trial_ends_at: toIso(e.target.value) })}
                />
              </Field>
              <Field label={tx("Display Start Date", "تاريخ بداية العرض")}>
                <Input
                  type="date"
                  value={dateVal(editing.display_start_at)}
                  onChange={(e) =>
                    setEditing({ ...editing, display_start_at: toIso(e.target.value) })
                  }
                />
              </Field>
              <Field label={tx("Display End Date", "تاريخ نهاية العرض")}>
                <Input
                  type="date"
                  value={dateVal(editing.display_end_at)}
                  onChange={(e) =>
                    setEditing({ ...editing, display_end_at: toIso(e.target.value) })
                  }
                />
              </Field>
              <Field label={tx("VAT note (EN / AR)", "ملاحظة الضريبة (إنجليزي / عربي)")}>
                <div className="flex gap-2">
                  <Input
                    value={editing.vat_note_en ?? ""}
                    onChange={(e) => setEditing({ ...editing, vat_note_en: e.target.value })}
                  />
                  <Input
                    value={editing.vat_note_ar ?? ""}
                    onChange={(e) => setEditing({ ...editing, vat_note_ar: e.target.value })}
                  />
                </div>
              </Field>
              <Field label={tx("Badge text (EN / AR)", "نص الشارة (إنجليزي / عربي)")}>
                <div className="flex gap-2">
                  <Input
                    value={editing.badge_text_en ?? ""}
                    onChange={(e) => setEditing({ ...editing, badge_text_en: e.target.value })}
                  />
                  <Input
                    value={editing.badge_text_ar ?? ""}
                    onChange={(e) => setEditing({ ...editing, badge_text_ar: e.target.value })}
                  />
                </div>
              </Field>
              <Field label={tx("Button text (EN / AR)", "نص الزر (إنجليزي / عربي)")}>
                <div className="flex gap-2">
                  <Input
                    value={editing.cta_text_en ?? ""}
                    onChange={(e) => setEditing({ ...editing, cta_text_en: e.target.value })}
                  />
                  <Input
                    value={editing.cta_text_ar ?? ""}
                    onChange={(e) => setEditing({ ...editing, cta_text_ar: e.target.value })}
                  />
                </div>
              </Field>
              <Field label={tx("Button destination", "رابط الزر")}>
                <Input
                  value={editing.cta_url ?? ""}
                  onChange={(e) => setEditing({ ...editing, cta_url: e.target.value })}
                  placeholder="/get-started"
                />
              </Field>

              <div className="space-y-3 sm:col-span-2">
                {(
                  [
                    ["trial_enabled", tx("Free trial enabled", "تفعيل الفترة المجانية")],
                    [
                      "trial_new_companies_only",
                      tx("Trial for new companies only", "الفترة المجانية للشركات الجديدة فقط"),
                    ],
                    ["is_free", tx("Free package", "باقة مجانية")],
                    ["is_active", tx("Active", "نشطة")],
                    ["is_recommended", tx("Recommended Package", "الباقة الموصى بها")],
                    ["is_enterprise", tx("Enterprise / custom package", "باقة المؤسسات / مخصصة")],
                    ["show_price", tx("Show price", "إظهار السعر")],
                    [
                      "contact_instead_of_price",
                      tx('Show "Contact Us" instead of price', "إظهار «تواصل معنا» بدل السعر"),
                    ],
                  ] as const
                ).map(([key, label]) => (
                  <div key={key} className="flex items-center justify-between gap-4">
                    <Label htmlFor={`pk-${key}`} className="font-normal">
                      {t(label)}
                    </Label>
                    <Switch
                      id={`pk-${key}`}
                      checked={Boolean(editing[key])}
                      onCheckedChange={(v) => setEditing({ ...editing, [key]: v })}
                    />
                  </div>
                ))}
              </div>

              <div className="flex gap-2 sm:col-span-2">
                <Button
                  onClick={() => save.mutate(editing)}
                  disabled={save.isPending}
                  aria-busy={save.isPending}
                >
                  {save.isPending ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Save className="h-4 w-4" />
                  )}
                  {t(tx("Save & Publish", "حفظ ونشر"))}
                </Button>
                <Button variant="ghost" onClick={() => setEditing(null)}>
                  {t(tx("Cancel", "إلغاء"))}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Preview ---------------------------------------------------------- */}
      <Dialog open={!!preview} onOpenChange={(o) => !o && setPreview(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{t(tx("Preview", "معاينة"))}</DialogTitle>
          </DialogHeader>
          {preview && (
            <div className="rounded-xl border border-primary/50 bg-card/95 p-6 ring-inset-gold">
              <h3 className="font-display text-xl text-heading">
                {pick(lang, preview.name_en, preview.name_ar)}
              </h3>
              <p className="text-sm text-muted-foreground">
                {pick(lang, preview.short_desc_en, preview.short_desc_ar)}
              </p>
              <p className="mt-3 font-display text-3xl text-heading">{priceLabel(preview, lang)}</p>
              {trialLabel(preview, lang) && (
                <p className="text-sm font-semibold text-gold-dark">{trialLabel(preview, lang)}</p>
              )}
              <p className="mt-1 text-xs text-muted-foreground">
                {t(tx("Duration", "المدة"))}: {durationLabel(preview, lang)}
              </p>
              <ul className="mt-4 space-y-1.5 text-sm">
                {preview.features
                  .filter((f) => f.enabled)
                  .map((f) => (
                    <li key={f.id}>
                      {pick(lang, f.label_en, f.label_ar)}
                      {f.value_type !== "boolean" && ` — ${featureValueLabel(f, lang)}`}
                    </li>
                  ))}
              </ul>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </Card>
  );
}

function Field({
  label,
  children,
}: {
  label: { en: string; ar: string };
  children: React.ReactNode;
}) {
  const { t } = useI18n();
  return (
    <div className="space-y-2">
      <Label className="text-xs">{t(label)}</Label>
      {children}
    </div>
  );
}

function FeatureEditor({
  pkg,
  onSave,
  onRemove,
  pending,
}: {
  pkg: PackageWithFeatures;
  onSave: (f: FeatureInput) => void;
  onRemove: (id: string) => void;
  pending: boolean;
}) {
  const { t, lang } = useI18n();
  const [draft, setDraft] = useState<FeatureInput | null>(null);

  const startNew = () =>
    setDraft({
      package_id: pkg.id,
      feature_key: "",
      label_en: "",
      label_ar: "",
      value_type: "boolean",
      value_bool: true,
      enabled: true,
      sort_order: pkg.features.length + 1,
    });

  const edit = (f: PackageFeatureRow) => setDraft({ ...f });

  return (
    <div className="space-y-3 rounded-lg border border-border/70 p-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="text-sm font-semibold text-heading">
          {pick(lang, pkg.name_en, pkg.name_ar)} — {t(tx("Features", "مزايا الباقة"))}
        </p>
        <Button variant="outline" size="sm" onClick={startNew}>
          <Plus className="h-4 w-4" /> {t(tx("Add feature", "إضافة ميزة"))}
        </Button>
      </div>

      <ul className="divide-y divide-border/60">
        {pkg.features.map((f) => (
          <li key={f.id} className="flex flex-wrap items-center justify-between gap-2 py-2 text-sm">
            <span className="text-foreground/90">
              {pick(lang, f.label_en, f.label_ar)}{" "}
              <span className="font-semibold text-gold-dark">{featureValueLabel(f, lang)}</span>
            </span>
            <span className="flex items-center gap-1">
              <Switch
                aria-label={t(tx("Enabled", "مفعلة"))}
                checked={f.enabled}
                onCheckedChange={(v) => onSave({ ...f, enabled: v })}
              />
              <Button variant="ghost" size="sm" onClick={() => edit(f)}>
                {t(tx("Edit", "تعديل"))}
              </Button>
              <Button
                variant="ghost"
                size="sm"
                aria-label={t(tx("Remove", "حذف"))}
                onClick={() => onRemove(f.id)}
              >
                <Trash2 className="h-4 w-4 text-destructive" />
              </Button>
            </span>
          </li>
        ))}
      </ul>

      {/* Candidate profile access — the same package_features rows, shown as a
          fixed bilingual checklist so every package uses identical keys. */}
      <div className="rounded-lg border border-primary/30 bg-primary/5 p-3">
        <p className="text-xs font-semibold uppercase tracking-wider text-gold-dark">
          {t(tx("Candidate profile access", "صلاحيات الملف الاحترافي للمرشح"))}
        </p>
        <ul className="mt-2 space-y-2">
          {CANDIDATE_FEATURES.map((key) => {
            const existing = pkg.features.find((f) => f.feature_key === key);
            const on = existing ? existing.enabled && existing.value_bool === true : false;
            return (
              <li key={key} className="flex items-center justify-between gap-3 text-sm">
                <span className="text-foreground/90">{t(CANDIDATE_FEATURE_LABELS[key])}</span>
                <Switch
                  aria-label={t(CANDIDATE_FEATURE_LABELS[key])}
                  checked={on}
                  onCheckedChange={(v) =>
                    onSave(
                      existing
                        ? { ...existing, value_type: "boolean", value_bool: v, enabled: true }
                        : {
                            package_id: pkg.id,
                            feature_key: key,
                            label_en: CANDIDATE_FEATURE_LABELS[key].en,
                            label_ar: CANDIDATE_FEATURE_LABELS[key].ar,
                            value_type: "boolean",
                            value_bool: v,
                            enabled: true,
                            sort_order: pkg.features.length + 1,
                          },
                    )
                  }
                />
              </li>
            );
          })}
        </ul>
      </div>

      {draft && (
        <div className="grid gap-3 rounded-lg border border-primary/40 bg-primary/5 p-3 sm:grid-cols-2">
          <Field label={tx("Feature key", "معرّف الميزة")}>
            <Input
              value={draft.feature_key}
              onChange={(e) => setDraft({ ...draft, feature_key: e.target.value })}
            />
          </Field>
          <Field label={tx("Order", "الترتيب")}>
            <Input
              type="number"
              value={draft.sort_order ?? 0}
              onChange={(e) => setDraft({ ...draft, sort_order: Number(e.target.value || 0) })}
            />
          </Field>
          <Field label={tx("Label (EN)", "التسمية (إنجليزي)")}>
            <Input
              value={draft.label_en}
              onChange={(e) => setDraft({ ...draft, label_en: e.target.value })}
            />
          </Field>
          <Field label={tx("Label (AR)", "التسمية (عربي)")}>
            <Input
              value={draft.label_ar}
              onChange={(e) => setDraft({ ...draft, label_ar: e.target.value })}
            />
          </Field>
          <Field label={tx("Value type", "نوع القيمة")}>
            <Select
              value={draft.value_type ?? "boolean"}
              onValueChange={(v) => setDraft({ ...draft, value_type: v })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {FEATURE_VALUE_TYPES.map((v) => (
                  <SelectItem key={v.value} value={v.value}>
                    {t(v.label)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
          {draft.value_type === "number" && (
            <Field label={tx("Number value", "القيمة الرقمية")}>
              <Input
                type="number"
                value={draft.value_number ?? ""}
                onChange={(e) =>
                  setDraft({
                    ...draft,
                    value_number: e.target.value === "" ? null : Number(e.target.value),
                  })
                }
              />
            </Field>
          )}
          {draft.value_type === "boolean" && (
            <Field label={tx("Included", "متضمنة")}>
              <Switch
                checked={Boolean(draft.value_bool)}
                onCheckedChange={(v) => setDraft({ ...draft, value_bool: v })}
              />
            </Field>
          )}
          {draft.value_type === "text" && (
            <Field label={tx("Text value (EN / AR)", "القيمة النصية (إنجليزي / عربي)")}>
              <div className="flex gap-2">
                <Input
                  value={draft.value_text_en ?? ""}
                  onChange={(e) => setDraft({ ...draft, value_text_en: e.target.value })}
                />
                <Input
                  value={draft.value_text_ar ?? ""}
                  onChange={(e) => setDraft({ ...draft, value_text_ar: e.target.value })}
                />
              </div>
            </Field>
          )}
          <div className="flex gap-2 sm:col-span-2">
            <Button
              size="sm"
              disabled={pending}
              onClick={() => {
                onSave(draft);
                setDraft(null);
              }}
            >
              <Save className="h-4 w-4" /> {t(tx("Save", "حفظ"))}
            </Button>
            <Button variant="ghost" size="sm" onClick={() => setDraft(null)}>
              {t(tx("Cancel", "إلغاء"))}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
