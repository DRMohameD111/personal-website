// ---------------------------------------------------------------------------
// Package Confirmation Card / printable ticket-style receipt.
// Presentation only: every figure arrives already verified from
// `getPackageReceipt`. Reused by the company dashboard card dialog and by the
// standalone printable receipt page.
// ---------------------------------------------------------------------------
import { CheckCircle2, Clock, CreditCard } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useI18n, tx } from "@/i18n";
import { changeTypeLabel, formatDate, formatMoney, statusLabel } from "@/lib/subscriptions";
import { paymentStateLabel, type PackageReceipt } from "@/lib/receipt";
import { logos, imagery } from "@/brand";

function Field({
  label,
  value,
  strong,
}: {
  label: string;
  value: React.ReactNode;
  strong?: boolean;
}) {
  return (
    <div>
      <dt className="text-[10px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">
        {label}
      </dt>
      <dd
        className={`mt-0.5 text-sm break-words ${strong ? "font-semibold text-heading" : "text-foreground"}`}
      >
        {value ?? "—"}
      </dd>
    </div>
  );
}

export function PackageReceiptTicket({ receipt }: { receipt: PackageReceipt }) {
  const { t, lang } = useI18n();
  const money = (n: number) => formatMoney(n, receipt.currency, lang);
  const paid = receipt.paymentState === "paid" || receipt.paymentState === "free";

  return (
    <article
      dir={lang === "ar" ? "rtl" : "ltr"}
      className="receipt-ticket mx-auto w-full max-w-2xl overflow-hidden rounded-2xl border border-primary/40 bg-card shadow-elegant"
      aria-label={t(tx("Package confirmation card", "بطاقة تأكيد الباقة"))}
    >
      {/* Ticket header — navy Sphinx band */}
      <header className="sphinx-card relative flex flex-col items-start justify-between gap-4 overflow-hidden px-6 py-5 text-white sm:flex-row sm:items-start">
        <div
          aria-hidden
          className="sphinx-backdrop pointer-events-none absolute inset-0 print:hidden"
          style={{ backgroundImage: `url(${imagery.sphinxBackdrop})` }}
        />
        <div className="relative flex items-center gap-3">
          <img src={logos.mark} alt="SPHINX Workforce" className="h-10 w-10 object-contain" />
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-[0.3em] text-[#E5C875]">
              SPHINX Workforce
            </p>
            <h2 className="font-display text-xl font-semibold text-white">
              {t(tx("Package Confirmation", "تأكيد الباقة"))}
            </h2>
          </div>
        </div>
        <div className="relative text-end">
          <p className="text-[10px] uppercase tracking-widest text-[#E5C875]">
            {t(tx("Receipt No.", "رقم الإيصال"))}
          </p>
          <p className="font-mono text-sm">{receipt.receiptNumber}</p>
        </div>
      </header>

      {/* Perforation */}
      <div className="relative h-4 bg-card">
        <div className="absolute inset-x-0 top-1/2 border-t border-dashed border-primary/50" />
      </div>

      <div className="space-y-6 px-6 pb-6">
        <div className="flex flex-wrap items-center gap-2">
          <Badge
            variant="outline"
            className={`gap-1 ${paid ? "border-primary/60 text-gold-dark" : "border-destructive/50 text-destructive"}`}
          >
            {paid ? <CheckCircle2 className="h-3.5 w-3.5" /> : <Clock className="h-3.5 w-3.5" />}
            {t(paymentStateLabel(receipt.paymentState))}
          </Badge>
          <Badge variant="outline" className="border-primary/50 text-gold-dark">
            {t(statusLabel(receipt.status))}
          </Badge>
          <Badge variant="outline" className="border-border">
            {t(changeTypeLabel(receipt.changeType ?? "new"))}
          </Badge>
          {receipt.isTrial && (
            <Badge variant="outline" className="border-border">
              {t(tx("Trial", "فترة تجريبية"))}
            </Badge>
          )}
        </div>

        <dl className="grid grid-cols-2 gap-4 sm:grid-cols-3">
          <Field label={t(tx("Company", "الشركة"))} value={receipt.companyName} strong />
          <Field label={t(tx("Company Code", "كود الشركة"))} value={receipt.companyCode} />
          <Field label={t(tx("Email", "البريد الإلكتروني"))} value={receipt.email} />
          <Field
            label={t(tx("Package Name", "اسم الباقة"))}
            value={lang === "ar" ? receipt.nameAr : receipt.nameEn}
            strong
          />
          <Field label={t(tx("Package Code", "كود الباقة"))} value={receipt.packageCode} />
          <Field
            label={t(tx("Duration", "المدة"))}
            value={
              receipt.durationMonths == null
                ? "—"
                : t(tx(`${receipt.durationMonths} months`, `${receipt.durationMonths} شهر`))
            }
          />
          <Field
            label={t(tx("Start Date", "تاريخ البداية"))}
            value={formatDate(receipt.startedAt, lang)}
          />
          <Field
            label={t(tx("End Date", "تاريخ الانتهاء"))}
            value={formatDate(receipt.expiresAt, lang)}
          />
          <Field
            label={t(tx("Remaining Days", "الأيام المتبقية"))}
            value={receipt.remainingDays == null ? "—" : String(receipt.remainingDays)}
          />
        </dl>

        {/* Financial summary */}
        <div className="rounded-xl border border-border/60 bg-surface-soft p-4">
          <p className="mb-3 flex items-center gap-2 text-sm font-semibold text-heading">
            <CreditCard className="h-4 w-4 text-gold-dark" />
            {t(tx("Payment Summary", "ملخص السداد"))}
          </p>
          <dl className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            <Field label={t(tx("List Price", "السعر الأساسي"))} value={money(receipt.listPrice)} />
            <Field label={t(tx("Discount", "الخصم"))} value={money(receipt.discount)} />
            <Field
              label={t(tx("Credit Applied", "الرصيد المستخدم"))}
              value={money(receipt.creditApplied)}
            />
            <Field
              label={t(tx("Package Value", "قيمة الباقة"))}
              value={money(receipt.amountDue)}
              strong
            />
            <div className="rounded-lg border border-primary/60 bg-accent/60 px-3 py-2">
              <dt className="text-[10px] font-semibold uppercase tracking-[0.18em] text-gold-dark">
                {t(tx("Amount Paid", "المبلغ المدفوع"))}
              </dt>
              <dd className="mt-0.5 font-display text-lg font-semibold text-heading">
                {money(receipt.amountPaid)}
              </dd>
            </div>
            <Field
              label={t(tx("Outstanding", "المبلغ المتبقي"))}
              value={money(receipt.outstanding)}
            />
            <Field
              label={t(tx("Payment Reference", "مرجع السداد"))}
              value={receipt.paymentReference}
            />
            <Field
              label={t(tx("Payment Date", "تاريخ السداد"))}
              value={formatDate(receipt.paymentDate, lang)}
            />
            <Field
              label={t(tx("Payment Status", "حالة السداد"))}
              value={t(paymentStateLabel(receipt.paymentState))}
            />
          </dl>
        </div>

        {/* Included features (from the immutable purchase snapshot) */}
        {receipt.features.length > 0 && (
          <div>
            <p className="text-sm font-semibold text-heading">
              {t(tx("Included Features", "المزايا المشمولة"))}
            </p>
            <ul className="mt-2 grid grid-cols-1 gap-1.5 sm:grid-cols-2">
              {receipt.features.map((f, i) => (
                <li
                  key={`${f.labelEn}-${i}`}
                  className="flex items-start gap-2 text-sm text-foreground"
                >
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-gold-dark" />
                  <span>
                    {lang === "ar" ? f.labelAr : f.labelEn}
                    <span className="text-muted-foreground">
                      {" "}
                      — {lang === "ar" ? f.valueAr : f.valueEn}
                    </span>
                  </span>
                </li>
              ))}
            </ul>
          </div>
        )}

        <footer className="border-t border-dashed border-primary/40 pt-4 text-[11px] leading-relaxed text-muted-foreground">
          <p>
            {t(
              tx(
                "This card reflects verified payment data recorded in your account. Amounts and dates cannot be edited from this page.",
                "تعكس هذه البطاقة بيانات السداد الموثقة والمسجلة في حسابك، ولا يمكن تعديل المبالغ أو التواريخ من هذه الصفحة.",
              ),
            )}
          </p>
          <p className="mt-1">
            {t(tx("Generated", "تاريخ الإصدار"))}: {formatDate(receipt.generatedAt, lang)} · SPHINX
            Workforce · sphinxhr.com
          </p>
        </footer>
      </div>
      {/* Golden Pharaonic footer strip (kept in print) */}
      <div aria-hidden className="pharaonic-strip" />
    </article>
  );
}
