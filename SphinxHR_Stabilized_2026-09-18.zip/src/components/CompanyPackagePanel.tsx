// ---------------------------------------------------------------------------
// Company Dashboard — Current Package / الباقة الحالية, Change Package and
// Package History. Every figure shown here comes from verified backend data;
// the UI never computes or sends commercial values.
// ---------------------------------------------------------------------------
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Link } from "@tanstack/react-router";
import {
  AlertTriangle,
  ArrowUpDown,
  CreditCard,
  FileText,
  History,
  Loader2,
  PackageCheck,
  Printer,
} from "lucide-react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useI18n, tx } from "@/i18n";
import { fetchPublicPackages, pick } from "@/lib/packages";
import { changeTypeLabel, formatDate, formatMoney, statusLabel } from "@/lib/subscriptions";
import {
  cancelPackageChange,
  getMyPackage,
  getPackageReceipt,
  listMyPackageHistory,
  previewPackageChange,
  requestPackageChange,
  type ChangePreview,
} from "@/lib/subscriptions.functions";
import { PackageReceiptTicket } from "@/components/PackageReceiptTicket";
import { paymentStateLabel } from "@/lib/receipt";
import { imagery } from "@/brand";

function Row({
  label,
  value,
  emphasis,
}: {
  label: string;
  value: React.ReactNode;
  /** "strong" = prominent figure (e.g. Amount Paid). */
  emphasis?: "strong";
}) {
  return (
    <div>
      <dt className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
        {label}
      </dt>
      <dd
        className={
          emphasis === "strong"
            ? "font-display text-xl font-semibold text-primary break-words"
            : "text-sm text-foreground break-words"
        }
      >
        {value ?? "—"}
      </dd>
    </div>
  );
}

export function CompanyPackagePanel() {
  const { t, lang } = useI18n();
  const queryClient = useQueryClient();
  const fetchCurrent = useServerFn(getMyPackage);
  const fetchHistory = useServerFn(listMyPackageHistory);
  const preview = useServerFn(previewPackageChange);
  const submit = useServerFn(requestPackageChange);
  const cancel = useServerFn(cancelPackageChange);
  const fetchReceipt = useServerFn(getPackageReceipt);

  const current = useQuery({ queryKey: ["my-package"], queryFn: () => fetchCurrent({}) });
  const history = useQuery({ queryKey: ["my-package-history"], queryFn: () => fetchHistory({}) });
  const packages = useQuery({ queryKey: ["public-packages"], queryFn: fetchPublicPackages });

  const [selected, setSelected] = useState<string | null>(null);
  const [quote, setQuote] = useState<ChangePreview | null>(null);
  const [loadingQuote, setLoadingQuote] = useState(false);
  const [processing, setProcessing] = useState(false);
  // Subscription whose confirmation card is open (verified fetch, read-only).
  const [cardId, setCardId] = useState<string | null>(null);

  const cardReceipt = useQuery({
    queryKey: ["package-receipt", cardId],
    enabled: !!cardId,
    queryFn: () => fetchReceipt({ data: { subscriptionId: cardId! } }),
  });

  const sub = current.data?.subscription ?? null;
  const pending = current.data?.pendingChange ?? null;

  // Verified details / payment data for the active subscription (read-only).
  const currentReceipt = useQuery({
    queryKey: ["package-receipt", sub?.id ?? null],
    enabled: !!sub?.id,
    queryFn: () => fetchReceipt({ data: { subscriptionId: sub!.id } }),
  });

  async function openComparison(packageId: string) {
    setSelected(packageId);
    setLoadingQuote(true);
    setQuote(null);
    try {
      setQuote(await preview({ data: { packageId } }));
    } catch {
      toast.error(
        t(
          tx(
            "The package details could not be loaded. Please try again.",
            "تعذر تحميل بيانات الباقة. يرجى المحاولة مرة أخرى.",
          ),
        ),
      );
      setSelected(null);
    } finally {
      setLoadingQuote(false);
    }
  }

  async function confirmChange() {
    if (!selected || processing) return;
    setProcessing(true);
    // One idempotency key per confirmed intent: retries never activate twice.
    const idempotencyKey = crypto.randomUUID();
    try {
      const res = await submit({ data: { packageId: selected, idempotencyKey } });
      if (!res.ok) {
        toast.error(
          res.error === "pending_change_exists"
            ? t(
                tx(
                  "You already have a package change in progress.",
                  "لديك بالفعل طلب تغيير باقة قيد التنفيذ.",
                ),
              )
            : res.error === "same_package"
              ? t(tx("This is already your current package.", "هذه هي باقتك الحالية بالفعل."))
              : t(
                  tx(
                    "The package change could not be completed. Your current package has not been changed. Please try again or contact support.",
                    "تعذر إكمال تغيير الباقة. لم يتم تعديل باقتك الحالية. يرجى المحاولة مرة أخرى أو التواصل مع الدعم.",
                  ),
                ),
        );
      } else if (res.requiresPayment) {
        toast.success(
          t(
            tx(
              `Your request has been recorded and is awaiting payment of ${res.amountDue} ${res.currency}.`,
              `تم تسجيل طلبك وهو بانتظار سداد ${res.amountDue} ${res.currency}.`,
            ),
          ),
        );
      } else if (res.scheduled) {
        toast.success(
          t(
            tx(
              `Your package change has been scheduled and will become active on ${formatDate(res.effectiveDate, "en")}.`,
              `تمت جدولة تغيير باقتك وسيتم تفعيلها بتاريخ ${formatDate(res.effectiveDate, "ar")}.`,
            ),
          ),
        );
      } else {
        toast.success(
          t(
            tx(
              `Your package change has been accepted successfully. Package code: ${res.packageCode ?? "—"}.`,
              `تم قبول تغيير الباقة بنجاح. كود الباقة: ${res.packageCode ?? "—"}.`,
            ),
          ),
        );
      }
      setSelected(null);
      setQuote(null);
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ["my-package"] }),
        queryClient.invalidateQueries({ queryKey: ["my-package-history"] }),
      ]);
    } catch {
      toast.error(
        t(
          tx(
            "The package change could not be completed. Your current package has not been changed. Please try again or contact support.",
            "تعذر إكمال تغيير الباقة. لم يتم تعديل باقتك الحالية. يرجى المحاولة مرة أخرى أو التواصل مع الدعم.",
          ),
        ),
      );
    } finally {
      setProcessing(false);
    }
  }

  async function cancelPending() {
    if (!pending || processing) return;
    setProcessing(true);
    try {
      await cancel({ data: { requestId: pending.id } });
      await queryClient.invalidateQueries({ queryKey: ["my-package"] });
      toast.success(
        t(tx("The package change request has been cancelled.", "تم إلغاء طلب تغيير الباقة.")),
      );
    } catch {
      toast.error(t(tx("The request could not be cancelled.", "تعذر إلغاء الطلب.")));
    } finally {
      setProcessing(false);
    }
  }

  const q = quote?.quote ?? null;

  return (
    <>
      {/* ---- Current Package / الباقة الحالية ---- */}
      <Card className="surface-dark relative mt-10 overflow-hidden border-primary/30 pb-4 shadow-elegant sphinx-card">
        {/* Sphinx artwork, blended behind the content */}
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0 sphinx-backdrop"
          style={{ backgroundImage: `url(${imagery.sphinxBackdrop})` }}
        />
        <div className="relative">
          <CardHeader className="flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-center">
            <CardTitle className="flex items-center gap-2 font-display text-xl text-white">
              <PackageCheck className="h-5 w-5 text-primary" />
              {t(tx("Current Package", "الباقة الحالية"))}
            </CardTitle>
            {sub && (
              <div className="flex flex-wrap items-center gap-2">
                <Badge
                  variant="outline"
                  className="border-primary/70 bg-primary/15 text-primary shadow-gold"
                >
                  {t(statusLabel(sub.status))}
                </Badge>
                <Button
                  size="sm"
                  variant="outline"
                  className="border-primary/60 bg-transparent text-primary hover:bg-primary/15 hover:text-primary"
                  onClick={() => setCardId(sub.id)}
                >
                  <FileText className="h-4 w-4" />
                  {t(tx("Package Card", "بطاقة الباقة"))}
                </Button>
                <Link to="/receipt/$subscriptionId" params={{ subscriptionId: sub.id }}>
                  <Button
                    size="sm"
                    variant="outline"
                    className="border-primary/60 bg-transparent text-primary hover:bg-primary/15 hover:text-primary"
                  >
                    <Printer className="h-4 w-4" />
                    {t(tx("Print / PDF", "طباعة / PDF"))}
                  </Button>
                </Link>
              </div>
            )}
          </CardHeader>
          <CardContent className="space-y-6">
            {current.isLoading ? (
              <Loader2 className="h-5 w-5 animate-spin text-primary" />
            ) : !sub ? (
              <p className="text-sm text-muted-foreground">
                {t(tx("You have no active package yet.", "لا توجد لديك باقة سارية حتى الآن."))}
              </p>
            ) : (
              <>
                {/* Headline: package identity + the strongly highlighted paid amount */}
                <div className="flex flex-col gap-4 border-b border-primary/25 pb-5 sm:flex-row sm:items-end sm:justify-between">
                  <div>
                    <p className="text-[10px] font-semibold uppercase tracking-[0.3em] text-primary">
                      {t(tx("Package Name", "اسم الباقة"))}
                    </p>
                    <h3 className="font-display text-2xl font-semibold text-white sm:text-3xl">
                      {(lang === "ar" ? sub.nameAr : sub.nameEn) || "—"}
                    </h3>
                    <p className="mt-1 font-mono text-sm text-primary/90">
                      {sub.package_code ?? "—"}
                    </p>
                  </div>
                  <div className="rounded-xl border border-primary/40 bg-primary/10 px-4 py-3 sm:text-end">
                    <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-primary">
                      {t(tx("Amount Paid", "المبلغ المدفوع"))}
                    </p>
                    <p className="font-display text-2xl font-semibold text-white sm:text-3xl">
                      {formatMoney(Number(sub.price_paid), sub.currency, lang)}
                    </p>
                  </div>
                </div>
                <dl className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  <Row
                    label={t(tx("Package Status", "حالة الباقة"))}
                    value={t(statusLabel(sub.status))}
                  />
                  <Row
                    label={t(tx("Package Price", "قيمة الباقة"))}
                    value={formatMoney(Number(sub.amount_due), sub.currency, lang)}
                    emphasis="strong"
                  />
                  <Row
                    label={t(tx("Outstanding Amount", "المبلغ المتبقي"))}
                    value={formatMoney(Number(sub.outstanding_amount), sub.currency, lang)}
                  />
                  <Row
                    label={t(tx("Start Date", "تاريخ البداية"))}
                    value={formatDate(sub.started_at, lang)}
                  />
                  <Row
                    label={t(tx("Expected End Date", "تاريخ الانتهاء المتوقع"))}
                    value={formatDate(sub.expires_at, lang)}
                  />
                  <Row
                    label={t(tx("Remaining Days", "الأيام المتبقية"))}
                    value={sub.remainingDays == null ? "—" : String(sub.remainingDays)}
                  />
                  <Row
                    label={t(tx("Trial Status", "حالة الفترة التجريبية"))}
                    value={sub.is_trial ? t(tx("Trial", "فترة تجريبية")) : t(tx("Paid", "مدفوعة"))}
                  />
                  <Row
                    label={t(tx("Renewal Status", "حالة التجديد"))}
                    value={t(changeTypeLabel(sub.change_type ?? "new"))}
                  />
                  <Row
                    label={t(tx("Company Code", "كود الشركة"))}
                    value={current.data?.companyCode ?? "—"}
                  />
                </dl>
              </>
            )}

            {/* Scheduled / pending change */}
            {pending && (
              <div className="rounded-lg border border-primary/40 bg-white/5 p-4" role="status">
                <p className="flex items-center gap-2 text-sm font-semibold text-white">
                  <AlertTriangle className="h-4 w-4 text-primary" />
                  {t(tx("Scheduled Package Change", "تغيير باقة مجدول"))}
                </p>
                <p className="mt-2 text-sm text-muted-foreground">
                  {pending.status === "scheduled"
                    ? t(
                        tx(
                          `Your ${pending.nameEn} package will become active after your current subscription expires on ${formatDate(pending.effective_date, "en")}.`,
                          `سيتم تفعيل باقة ${pending.nameAr} بعد انتهاء باقتك الحالية بتاريخ ${formatDate(pending.effective_date, "ar")}.`,
                        ),
                      )
                    : t(
                        tx(
                          `Your change to ${pending.nameEn} is awaiting confirmation of ${pending.amount_due} ${pending.currency}.`,
                          `طلب التغيير إلى باقة ${pending.nameAr} بانتظار تأكيد سداد ${pending.amount_due} ${pending.currency}.`,
                        ),
                      )}
                </p>
                <div className="mt-3 flex flex-wrap items-center gap-3">
                  <Badge variant="outline" className="border-primary/50 text-primary">
                    {t(changeTypeLabel(pending.change_type))} · {t(statusLabel(pending.status))}
                  </Badge>
                  <Button variant="ghost" size="sm" onClick={cancelPending} disabled={processing}>
                    {processing && <Loader2 className="h-4 w-4 animate-spin" />}
                    {t(tx("Cancel request", "إلغاء الطلب"))}
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </div>
        {/* Golden Pharaonic footer strip */}
        <div aria-hidden className="pharaonic-strip absolute inset-x-0 bottom-0" />
      </Card>

      {/* ---- Package Details & Payments / تفاصيل الباقة والمدفوعات (read-only) ---- */}
      {sub && (
        <Card className="mt-6 border-border/60 shadow-elegant">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 font-display text-xl">
              <CreditCard className="h-5 w-5 text-gold-dark" />
              {t(tx("Package Details & Payments", "تفاصيل الباقة والمدفوعات"))}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            {currentReceipt.isLoading ? (
              <Loader2 className="h-5 w-5 animate-spin text-gold-dark" />
            ) : currentReceipt.isError || !currentReceipt.data ? (
              <p className="text-sm text-muted-foreground">
                {t(tx("Package details could not be loaded.", "تعذر تحميل تفاصيل الباقة."))}
              </p>
            ) : (
              <>
                <dl className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                  <Row
                    label={t(tx("Receipt Number", "رقم الإيصال"))}
                    value={currentReceipt.data.receiptNumber}
                  />
                  <Row
                    label={t(tx("Payment Status", "حالة السداد"))}
                    value={t(paymentStateLabel(currentReceipt.data.paymentState))}
                  />
                  <Row
                    label={t(tx("Payment Reference", "مرجع السداد"))}
                    value={currentReceipt.data.paymentReference ?? "—"}
                  />
                  <Row
                    label={t(tx("Payment Date", "تاريخ السداد"))}
                    value={formatDate(currentReceipt.data.paymentDate, lang)}
                  />
                  <Row
                    label={t(tx("Discount", "الخصم"))}
                    value={formatMoney(
                      currentReceipt.data.discount,
                      currentReceipt.data.currency,
                      lang,
                    )}
                  />
                  <Row
                    label={t(tx("Credit Applied", "الرصيد المستخدم"))}
                    value={formatMoney(
                      currentReceipt.data.creditApplied,
                      currentReceipt.data.currency,
                      lang,
                    )}
                  />
                </dl>

                {currentReceipt.data.features.length > 0 && (
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                      {t(tx("Included Benefits & Limits", "المزايا والحدود المتاحة"))}
                    </p>
                    <ul className="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-2">
                      {currentReceipt.data.features.map((f, i) => (
                        <li
                          key={`${f.labelEn}-${i}`}
                          className="flex items-center justify-between gap-3 rounded-lg border border-border/60 px-3 py-2 text-sm"
                        >
                          <span className="text-muted-foreground">
                            {lang === "ar" ? f.labelAr : f.labelEn}
                          </span>
                          <span className="font-semibold text-heading">
                            {lang === "ar" ? f.valueAr : f.valueEn}
                          </span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </>
            )}
          </CardContent>
        </Card>
      )}

      {/* ---- Change Package / تغيير الباقة ---- */}
      <Card className="mt-6 border-border/60 shadow-elegant">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 font-display text-xl">
            <ArrowUpDown className="h-5 w-5 text-gold-dark" />
            {t(tx("Change Package", "تغيير الباقة"))}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {pending ? (
            <p className="text-sm text-muted-foreground">
              {t(
                tx(
                  "A package change is already in progress. Cancel it above before requesting another one.",
                  "هناك طلب تغيير باقة قيد التنفيذ. يرجى إلغاؤه أعلاه قبل تقديم طلب آخر.",
                ),
              )}
            </p>
          ) : packages.isLoading ? (
            <Loader2 className="h-5 w-5 animate-spin text-gold-dark" />
          ) : (
            <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
              {(packages.data ?? []).map((p) => {
                const isCurrent = sub?.package_id === p.id;
                return (
                  <div key={p.id} className="rounded-xl border border-border/60 p-4">
                    <p className="font-display text-lg text-heading">
                      {pick(lang, p.name_en, p.name_ar)}
                    </p>
                    <p className="mt-1 text-sm text-muted-foreground">
                      {pick(lang, p.short_desc_en, p.short_desc_ar)}
                    </p>
                    <Button
                      className="mt-4 w-full"
                      variant={isCurrent ? "ghost" : "outline"}
                      disabled={isCurrent}
                      onClick={() => openComparison(p.id)}
                    >
                      {isCurrent
                        ? t(tx("Current package", "باقتك الحالية"))
                        : t(tx("Compare & select", "المقارنة والاختيار"))}
                    </Button>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* ---- Comparison before confirmation (informational only) ---- */}
      <Dialog
        open={!!selected}
        onOpenChange={(open) => {
          if (!open && !processing) {
            setSelected(null);
            setQuote(null);
          }
        }}
      >
        <DialogContent className="max-w-2xl" dir={lang === "ar" ? "rtl" : "ltr"}>
          <DialogHeader>
            <DialogTitle className="font-display">
              {q ? t(changeTypeLabel(q.changeType)) : t(tx("Change Package", "تغيير الباقة"))}
            </DialogTitle>
            <DialogDescription>
              {t(
                tx(
                  "Review the comparison below. Nothing changes until you confirm.",
                  "يرجى مراجعة المقارنة أدناه. لن يتم تعديل أي شيء حتى تقوم بالتأكيد.",
                ),
              )}
            </DialogDescription>
          </DialogHeader>

          {loadingQuote ? (
            <Loader2 className="h-5 w-5 animate-spin text-gold-dark" />
          ) : quote?.error === "same_package" ? (
            <p className="text-sm text-destructive">
              {t(tx("This is already your current package.", "هذه هي باقتك الحالية بالفعل."))}
            </p>
          ) : quote?.error === "pending_change_exists" ? (
            <p className="text-sm text-destructive">
              {t(
                tx(
                  "You already have a package change in progress.",
                  "لديك بالفعل طلب تغيير باقة قيد التنفيذ.",
                ),
              )}
            </p>
          ) : q ? (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="rounded-lg border border-border/60 p-3">
                  <p className="text-xs uppercase tracking-wider text-muted-foreground">
                    {t(tx("Current Package", "الباقة الحالية"))}
                  </p>
                  <p className="font-semibold text-heading">
                    {quote?.currentPackage
                      ? pick(lang, quote.currentPackage.nameEn, quote.currentPackage.nameAr)
                      : "—"}
                  </p>
                  <p className="text-muted-foreground">
                    {t(tx("Current end date", "تاريخ الانتهاء الحالي"))}:{" "}
                    {formatDate(q.currentEnd, lang)}
                  </p>
                </div>
                <div className="rounded-lg border border-primary/50 p-3">
                  <p className="text-xs uppercase tracking-wider text-muted-foreground">
                    {t(tx("Selected Package", "الباقة المختارة"))}
                  </p>
                  <p className="font-semibold text-heading">
                    {quote?.newPackage
                      ? pick(lang, quote.newPackage.nameEn, quote.newPackage.nameAr)
                      : "—"}
                  </p>
                  <p className="text-muted-foreground">
                    {t(tx("Duration", "المدة"))}: {quote?.newPackage?.durationMonths ?? "—"}{" "}
                    {t(tx("months", "أشهر"))}
                  </p>
                </div>
              </div>

              <dl className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <Row
                  label={t(tx("Package Price", "قيمة الباقة"))}
                  value={formatMoney(q.amountBeforeCredit, q.currency, lang)}
                />
                <Row
                  label={t(tx("Discount", "الخصم"))}
                  value={formatMoney(q.discount, q.currency, lang)}
                />
                <Row
                  label={t(tx("Credit Applied", "الرصيد المستخدم"))}
                  value={formatMoney(q.creditApplied, q.currency, lang)}
                />
                <Row
                  label={t(tx("Amount Due", "المبلغ المستحق"))}
                  value={formatMoney(q.amountDue, q.currency, lang)}
                />
                <Row
                  label={t(tx("Proposed Start Date", "تاريخ البداية المقترح"))}
                  value={formatDate(q.proposedStart, lang)}
                />
                <Row
                  label={t(tx("Proposed End Date", "تاريخ الانتهاء المقترح"))}
                  value={formatDate(q.proposedEnd, lang)}
                />
              </dl>

              {q.changeType === "downgrade" && q.effectiveDate !== q.proposedStart ? null : null}
              {q.changeType === "downgrade" && q.currentEnd && (
                <p className="rounded-lg bg-surface-soft p-3 text-sm text-muted-foreground">
                  {t(
                    tx(
                      `Your ${quote?.newPackage?.nameEn ?? ""} package will become active after your current subscription expires on ${formatDate(q.effectiveDate, "en")}.`,
                      `سيتم تفعيل باقة ${quote?.newPackage?.nameAr ?? ""} بعد انتهاء باقتك الحالية بتاريخ ${formatDate(q.effectiveDate, "ar")}.`,
                    ),
                  )}
                </p>
              )}
              {q.requiresPayment && (
                <p className="flex items-center gap-2 text-sm text-gold-dark">
                  <CreditCard className="h-4 w-4" />
                  {t(
                    tx(
                      "Your package will be activated only after your payment is verified.",
                      "سيتم تفعيل الباقة فقط بعد التحقق من عملية السداد.",
                    ),
                  )}
                </p>
              )}
            </div>
          ) : null}

          <DialogFooter>
            <Button variant="ghost" onClick={() => setSelected(null)} disabled={processing}>
              {t(tx("Cancel", "إلغاء"))}
            </Button>
            <Button
              onClick={confirmChange}
              disabled={processing || !q}
              aria-busy={processing}
              aria-disabled={processing}
              className="bg-gradient-gold font-semibold text-primary-foreground"
            >
              {processing && <Loader2 className="h-4 w-4 animate-spin" />}
              {processing
                ? t(tx("Processing Request...", "جاري معالجة الطلب..."))
                : t(tx("Confirm change", "تأكيد التغيير"))}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ---- Package History / سجل الباقات (read-only) ---- */}
      <Card className="mt-6 border-border/60 shadow-elegant">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 font-display text-xl">
            <History className="h-5 w-5 text-gold-dark" />
            {t(tx("Package History", "سجل الباقات"))}
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {history.isLoading ? (
            <div className="p-6">
              <Loader2 className="h-5 w-5 animate-spin text-gold-dark" />
            </div>
          ) : (history.data?.length ?? 0) === 0 ? (
            <p className="p-6 text-sm text-muted-foreground">
              {t(tx("No package records yet.", "لا توجد سجلات باقات حتى الآن."))}
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-surface-soft text-xs uppercase tracking-wider text-muted-foreground">
                  <tr>
                    <th className="px-4 py-3 text-start">{t(tx("Package Code", "كود الباقة"))}</th>
                    <th className="px-4 py-3 text-start">{t(tx("Package Name", "اسم الباقة"))}</th>
                    <th className="px-4 py-3 text-start">{t(tx("Amount", "المبلغ"))}</th>
                    <th className="px-4 py-3 text-start">
                      {t(tx("Amount Paid", "المبلغ المدفوع"))}
                    </th>
                    <th className="px-4 py-3 text-start">{t(tx("Start Date", "تاريخ البداية"))}</th>
                    <th className="px-4 py-3 text-start">{t(tx("End Date", "تاريخ الانتهاء"))}</th>
                    <th className="px-4 py-3 text-start">{t(tx("Status", "الحالة"))}</th>
                    <th className="px-4 py-3 text-start">{t(tx("Change Type", "نوع التغيير"))}</th>
                    <th className="px-4 py-3 text-start">{t(tx("Receipt", "الإيصال"))}</th>
                  </tr>
                </thead>
                <tbody>
                  {history.data!.map((h) => (
                    <tr key={h.id} className="border-t border-border/60">
                      <td className="px-4 py-3 font-mono text-xs text-foreground">
                        {h.packageCode ?? "—"}
                      </td>
                      <td className="px-4 py-3">{lang === "ar" ? h.nameAr : h.nameEn}</td>
                      <td className="px-4 py-3">{formatMoney(h.amount, h.currency, lang)}</td>
                      <td className="px-4 py-3">{formatMoney(h.amountPaid, h.currency, lang)}</td>
                      <td className="px-4 py-3">{formatDate(h.startedAt, lang)}</td>
                      <td className="px-4 py-3">{formatDate(h.expiresAt, lang)}</td>
                      <td className="px-4 py-3">
                        <Badge variant="outline" className="border-primary/50 text-gold-dark">
                          {t(statusLabel(h.status))}
                        </Badge>
                      </td>
                      <td className="px-4 py-3">{t(changeTypeLabel(h.changeType ?? "new"))}</td>
                      <td className="px-4 py-3">
                        <div className="flex flex-wrap gap-2">
                          <Button
                            size="sm"
                            variant="ghost"
                            className="text-gold-dark"
                            onClick={() => setCardId(h.id)}
                          >
                            <FileText className="h-4 w-4" />
                            {t(tx("View card", "عرض البطاقة"))}
                          </Button>
                          <Link to="/receipt/$subscriptionId" params={{ subscriptionId: h.id }}>
                            <Button size="sm" variant="ghost" className="text-gold-dark">
                              <Printer className="h-4 w-4" />
                              {t(tx("PDF", "PDF"))}
                            </Button>
                          </Link>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* ---- Package Confirmation Card / بطاقة تأكيد الباقة (read-only) ---- */}
      <Dialog open={!!cardId} onOpenChange={(open) => !open && setCardId(null)}>
        <DialogContent className="max-w-2xl" dir={lang === "ar" ? "rtl" : "ltr"}>
          <DialogHeader>
            <DialogTitle className="font-display">
              {t(tx("Package Confirmation Card", "بطاقة تأكيد الباقة"))}
            </DialogTitle>
            <DialogDescription>
              {t(
                tx(
                  "Verified subscription and payment details. Amounts cannot be edited here.",
                  "بيانات الاشتراك والسداد الموثقة. لا يمكن تعديل المبالغ من هنا.",
                ),
              )}
            </DialogDescription>
          </DialogHeader>

          {cardReceipt.isLoading ? (
            <Loader2 className="mx-auto h-5 w-5 animate-spin text-gold-dark" />
          ) : cardReceipt.isError || !cardReceipt.data ? (
            <p className="text-sm text-destructive">
              {t(tx("This card could not be loaded.", "تعذر تحميل هذه البطاقة."))}
            </p>
          ) : (
            <PackageReceiptTicket receipt={cardReceipt.data} />
          )}

          <DialogFooter>
            {cardId && (
              <Link to="/receipt/$subscriptionId" params={{ subscriptionId: cardId }}>
                <Button className="bg-gradient-gold font-semibold text-primary-foreground">
                  <Printer className="h-4 w-4" />
                  {t(tx("Print / Save as PDF", "طباعة / حفظ PDF"))}
                </Button>
              </Link>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
