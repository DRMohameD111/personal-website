import { Link } from "@tanstack/react-router";
import { Mail, Phone, MapPin, Linkedin, Facebook, Instagram, Twitter } from "lucide-react";
import { useI18n, tx } from "@/i18n";
import { logos, brand } from "@/brand";

export function Footer() {
  const { t } = useI18n();
  const year = new Date().getFullYear();

  return (
    <footer className="relative border-t-[3px] border-primary/70 bg-background print:hidden">
      <div className="gold-divider absolute inset-x-0 top-0" />
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-4">
          {/* Company */}
          <div>
            <Link to="/" className="flex items-center gap-3">
              <span className="inline-flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-gold ring-1 ring-primary/40 shadow-gold">
                <img src={logos.mark} alt={brand.name} className="h-7 w-7 object-contain" />
              </span>
              <span className="flex flex-col leading-tight">
                <span className="font-display text-base font-semibold tracking-[0.18em] text-foreground">
                  SPHINX
                </span>
                <span className="text-[10px] font-medium uppercase tracking-[0.3em] text-gold-dark">
                  {t(tx("Workforce", "للقوى العاملة"))}
                </span>
              </span>
            </Link>
            <p className="mt-5 text-sm leading-relaxed text-foreground/70">
              {t(
                tx(
                  "Premium workforce outsourcing and manpower supply across Saudi Arabia, the GCC and Egypt — engineered for speed, compliance and scale.",
                  "حلول متكاملة لتعهيد القوى العاملة والإمداد بالمواهب عبر السعودية ودول الخليج ومصر، ببراعة وسرعة والتزام كامل.",
                ),
              )}
            </p>
            <p className="mt-4 font-display text-sm text-gold-dark tracking-wider">
              {brand.tagline.ar}
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-display text-sm font-bold uppercase tracking-[0.2em] text-foreground">
              {t(tx("Quick Links", "روابط سريعة"))}
            </h4>
            <ul className="mt-5 space-y-3 text-sm">
              {[
                { to: "/", l: tx("Home", "الرئيسية") },
                { to: "/about", l: tx("About Us", "من نحن") },
                // { to: "/industries", l: tx("Industries", "القطاعات") },
                { to: "/jobs", l: tx("Jobs", "الوظائف") },
                { to: "/employers", l: tx("For Employers", "لأصحاب العمل") },
                { to: "/contact", l: tx("Contact Us", "تواصل معنا") },
              ].map((i) => (
                <li key={i.to}>
                  <Link
                    to={i.to}
                    className="text-foreground/80 hover:text-primary transition-colors"
                  >
                    {t(i.l)}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-display text-sm font-bold uppercase tracking-[0.2em] text-foreground">
              {t(tx("Services", "خدماتنا"))}
            </h4>
            <ul className="mt-5 space-y-3 text-sm">
              {[
                tx("Workforce Outsourcing", "تعهيد القوى العاملة"),
                tx("Manpower Supply", "إمداد العمالة"),
                tx("Blue Collar Recruitment", "توظيف العمالة الفنية"),
                tx("Technical Staffing", "التوظيف التقني"),
                tx("Employee Leasing", "تأجير الموظفين"),
                tx("Temporary Staffing", "العمالة المؤقتة"),
                tx("Facility Management", "إدارة المرافق"),
                tx("Industrial Workforce", "العمالة الصناعية"),
              ].map((s) => (
                <li key={s.en}>
                  <Link
                    to="/services"
                    className="text-foreground/80 hover:text-primary transition-colors"
                  >
                    {t(s)}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-display text-sm font-bold uppercase tracking-[0.2em] text-foreground">
              {t(tx("Contact", "تواصل"))}
            </h4>
            <ul className="mt-5 space-y-4 text-sm">
              <li className="flex items-start gap-3 text-foreground/80">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                <span>
                  {t(
                    tx(
                      "King Fahd Road, Riyadh, Kingdom of Saudi Arabia",
                      "طريق الملك فهد، الرياض، المملكة العربية السعودية",
                    ),
                  )}
                </span>
              </li>
              <li className="flex items-center gap-3 text-foreground/80">
                <Phone className="h-4 w-4 shrink-0 text-primary" />
                <a href="tel:+966112345678" className="hover:text-primary transition-colors">
                  +966 11 234 5678
                </a>
              </li>
              <li className="flex items-center gap-3 text-foreground/80">
                <Mail className="h-4 w-4 shrink-0 text-primary" />
                <a
                  href="mailto:info@sphinxworkforce.com"
                  className="hover:text-primary transition-colors"
                >
                  info@sphinxworkforce.com
                </a>
              </li>
            </ul>
            <div className="mt-6 flex gap-2">
              {[Linkedin, Twitter, Facebook, Instagram].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  aria-label="social"
                  className="inline-flex h-9 w-9 items-center justify-center rounded-md border border-border text-foreground/80 hover:border-primary hover:text-primary transition-colors"
                >
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-3 border-t border-border/50 pt-6 text-xs text-foreground/60 md:flex-row">
          <p>
            © {year} SPHINX Workforce. {t(tx("All rights reserved.", "جميع الحقوق محفوظة."))}
          </p>
          <p className="tracking-wider">
            {t(tx("Saudi Arabia · GCC · Egypt", "السعودية · الخليج · مصر"))}
          </p>
        </div>
      </div>
    </footer>
  );
}
