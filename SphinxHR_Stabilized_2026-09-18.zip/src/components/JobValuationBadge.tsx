import { Info, Star } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { useI18n } from "@/i18n";
import {
  gradeLabel,
  JOB_VALUATION_EXPLANATION,
  JOB_VALUATION_TITLE,
  type Grade,
} from "@/lib/valuation";

/**
 * The single Job Valuation badge (white / soft-gold Pharaonic style).
 * Reused on job cards, job details, the company dashboard and the control panel.
 */
export function JobValuationBadge({
  grade,
  size = "sm",
  withInfo = false,
}: {
  grade: Grade;
  size?: "sm" | "md";
  withInfo?: boolean;
}) {
  const { t } = useI18n();
  const pad = size === "md" ? "px-3 py-1.5 text-xs" : "px-2.5 py-1 text-[10px]";

  const badge = (
    <span
      className={`inline-flex items-center gap-1 rounded-full border border-primary/40 bg-primary/10 font-semibold text-gold-dark ${pad}`}
      title={t(JOB_VALUATION_TITLE)}
    >
      <Star className="h-3 w-3 fill-current" />
      {t(gradeLabel(grade))}
    </span>
  );

  if (!withInfo) return badge;

  return (
    <span className="inline-flex items-center gap-1">
      {badge}
      <TooltipProvider delayDuration={100}>
        <Tooltip>
          <TooltipTrigger asChild>
            <button
              type="button"
              aria-label={t(JOB_VALUATION_TITLE)}
              className="rounded-full p-1 text-muted-foreground hover:text-gold-dark focus:outline-none focus-visible:ring-2 focus-visible:ring-primary/60"
            >
              <Info className="h-3.5 w-3.5" />
            </button>
          </TooltipTrigger>
          <TooltipContent
            side="top"
            align="start"
            className="max-w-[16rem] bg-navy text-ivory border-gold/30"
          >
            <div className="font-semibold">{t(JOB_VALUATION_TITLE)}</div>
            <p className="mt-1 leading-relaxed opacity-90">{t(JOB_VALUATION_EXPLANATION)}</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    </span>
  );
}
