import { useState, type FormEvent } from "react";
import { Loader2, Save, AlertTriangle } from "lucide-react";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { SearchableSelect } from "@/components/SearchableSelect";
import { useI18n, tx } from "@/i18n";
import {
  BRANCH_OPTIONS,
  COUNTRY_OPTIONS,
  LEGAL_STRUCTURES,
  NATURE_OF_BUSINESS,
  emptyClient,
  validateClient,
  type Bi,
  type ClientInput,
  type ClientRecord,
} from "@/lib/clients";
import { findClientDuplicates, saveClient } from "@/lib/clients.functions";
import { useStateDraft } from "@/lib/form-draft";

/**
 * The single Create/Edit Client form. Reused by the Clients page and by
 * "Create New Client" inside Manpower — no second client form exists.
 */
export function ClientForm({
  initial,
  onSaved,
  onCancel,
  onSelectExisting,
}: {
  initial?: ClientRecord | null;
  onSaved: (client: ClientRecord) => void;
  onCancel?: () => void;
  onSelectExisting?: (client: ClientRecord) => void;
}) {
  const { t, lang } = useI18n();
  const persist = useServerFn(saveClient);
  const checkDuplicates = useServerFn(findClientDuplicates);

  const [form, setForm] = useState<ClientInput>(
    initial ? ({ ...emptyClient, ...initial } as ClientInput) : emptyClient,
  );
  const [errors, setErrors] = useState<Partial<Record<keyof ClientInput, Bi>>>({});
  const [saving, setSaving] = useState(false);
  const [dupes, setDupes] = useState<ClientRecord[] | null>(null);
  // Drafts only cover unsaved changes on new clients; editing loads DB data normally.
  const { clearDraft } = useStateDraft(
    "client-form",
    form as unknown as Record<string, unknown>,
    (d) => setForm((f) => ({ ...f, ...(d as Partial<ClientInput>) })),
    lang,
    { enabled: !initial?.id },
  );

  const set = <K extends keyof ClientInput>(key: K, value: ClientInput[K]) => {
    setForm((f) => ({ ...f, [key]: value }));
    setErrors((e) => ({ ...e, [key]: undefined }));
  };

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const found = validateClient(form);
    setErrors(found);
    if (Object.keys(found).length > 0) {
      toast.error(t(tx("Please correct the highlighted fields.", "يرجى تصحيح الحقول المحددة.")));
      return;
    }

    setSaving(true);
    try {
      // Duplicate prevention (skipped when editing an existing client).
      if (!form.id && dupes === null) {
        const matches = await checkDuplicates({
          data: {
            name: form.name,
            official_email: form.official_email,
            cr_number: form.cr_number ?? "",
            client_code: form.client_code ?? "",
          },
        });
        if (matches.length > 0) {
          setDupes(matches);
          setSaving(false);
          return;
        }
        setDupes([]);
      }

      const saved = await persist({ data: form });
      clearDraft();
      toast.success(
        t(tx("Client information has been saved successfully.", "تم حفظ بيانات العميل بنجاح.")),
      );
      onSaved(saved);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "";
      toast.error(
        msg === "duplicate_client"
          ? t(
              tx(
                "A client with this official email already exists.",
                "يوجد عميل مسجل بنفس البريد الإلكتروني الرسمي.",
              ),
            )
          : t(
              tx(
                "Saving failed. Your entries were kept — please review and try again.",
                "فشل الحفظ. تم الاحتفاظ بالبيانات — يرجى المراجعة وإعادة المحاولة.",
              ),
            ),
      );
    } finally {
      setSaving(false);
    }
  }

  const inputClass = "h-11 bg-background";
  const selectClass =
    "h-11 w-full rounded-md border border-input bg-background px-3 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring";

  return (
    <form onSubmit={onSubmit} className="space-y-5">
      {dupes && dupes.length > 0 && (
        <div role="alert" className="rounded-xl border border-destructive/40 bg-destructive/5 p-4">
          <p className="flex items-start gap-2 text-sm font-medium text-foreground">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" />
            {t(
              tx(
                "This client may already be registered. Please check the existing client list before creating a new record.",
                "قد يكون هذا العميل مسجلاً بالفعل. يرجى مراجعة العملاء الحاليين قبل إنشاء سجل جديد.",
              ),
            )}
          </p>
          <ul className="mt-3 space-y-2">
            {dupes.map((d) => (
              <li key={d.id} className="flex items-center justify-between gap-3 text-sm">
                <span className="truncate">
                  {d.name} — {d.official_email}
                </span>
                {onSelectExisting && (
                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    className="border-primary/60 text-gold-dark"
                    onClick={() => onSelectExisting(d)}
                  >
                    {t(tx("Select this client", "اختيار هذا العميل"))}
                  </Button>
                )}
              </li>
            ))}
          </ul>
          <p className="mt-3 text-xs text-muted-foreground">
            {t(
              tx(
                "Press Save again to create a new record anyway.",
                "اضغط حفظ مرة أخرى لإنشاء سجل جديد على أي حال.",
              ),
            )}
          </p>
        </div>
      )}

      <div className="grid gap-5 md:grid-cols-2">
        {/* 1. Company / Client name */}
        <Field
          label={t(tx("Company / Client Name", "اسم الشركة / العميل"))}
          required
          error={errors.name && t(errors.name)}
        >
          <Input
            className={inputClass}
            value={form.name}
            onChange={(e) => set("name", e.target.value)}
            aria-invalid={!!errors.name}
          />
        </Field>

        {/* 2. Client code */}
        <Field label={t(tx("Client Code", "كود العميل"))}>
          <Input
            className={inputClass}
            value={form.client_code ?? ""}
            onChange={(e) => set("client_code", e.target.value)}
            placeholder={t(tx("Optional", "اختياري"))}
          />
        </Field>

        {/* 3. Nature of business */}
        <Field
          label={t(tx("Nature of Business", "طبيعة النشاط"))}
          required
          error={errors.nature_of_business && t(errors.nature_of_business)}
        >
          <SearchableSelect
            options={NATURE_OF_BUSINESS}
            value={form.nature_of_business}
            onChange={(v) => set("nature_of_business", v)}
            placeholder={t(tx("Search and select…", "ابحث واختر…"))}
            invalid={!!errors.nature_of_business}
          />
        </Field>

        {form.nature_of_business === "other" && (
          <Field
            label={t(tx("Specify Business Activity", "حدد طبيعة النشاط"))}
            required
            error={errors.nature_of_business_other && t(errors.nature_of_business_other)}
          >
            <Input
              className={inputClass}
              value={form.nature_of_business_other ?? ""}
              onChange={(e) => set("nature_of_business_other", e.target.value)}
              aria-invalid={!!errors.nature_of_business_other}
            />
          </Field>
        )}

        {/* 4. Company nationality */}
        <Field
          label={t(tx("Company Nationality", "جنسية الشركة"))}
          required
          error={errors.nationality_code && t(errors.nationality_code)}
        >
          <SearchableSelect
            options={COUNTRY_OPTIONS}
            value={form.nationality_code}
            onChange={(v) => set("nationality_code", v)}
            placeholder={t(tx("Search country…", "ابحث عن الدولة…"))}
            invalid={!!errors.nationality_code}
          />
        </Field>

        {/* 5. Legal / investment structure */}
        <Field
          label={t(tx("Legal / Investment Structure", "نوع الاستثمار"))}
          required
          error={errors.legal_structure && t(errors.legal_structure)}
        >
          <select
            className={selectClass}
            value={form.legal_structure}
            onChange={(e) =>
              set("legal_structure", e.target.value as ClientInput["legal_structure"])
            }
          >
            {LEGAL_STRUCTURES.map((l) => (
              <option key={l.value} value={l.value}>
                {l.label[lang]}
              </option>
            ))}
          </select>
        </Field>

        {/* 6. Headquarters location */}
        <Field
          label={t(tx("Headquarters Country", "دولة المقر الرئيسي"))}
          required
          error={errors.hq_country_code && t(errors.hq_country_code)}
        >
          <SearchableSelect
            options={COUNTRY_OPTIONS}
            value={form.hq_country_code}
            onChange={(v) => set("hq_country_code", v)}
            placeholder={t(tx("Search country…", "ابحث عن الدولة…"))}
            invalid={!!errors.hq_country_code}
          />
        </Field>

        <Field label={t(tx("Headquarters City", "مدينة المقر الرئيسي"))}>
          <Input
            className={inputClass}
            value={form.hq_city ?? ""}
            onChange={(e) => set("hq_city", e.target.value)}
          />
        </Field>

        {/* 7. Number of branches */}
        <Field
          label={t(tx("Number of Branches", "عدد الفروع"))}
          required
          error={errors.branches_count && t(errors.branches_count)}
        >
          <select
            className={selectClass}
            value={form.branches_count}
            onChange={(e) => set("branches_count", e.target.value)}
            aria-invalid={!!errors.branches_count}
          >
            <option value="" disabled>
              {t(tx("Select…", "اختر…"))}
            </option>
            {BRANCH_OPTIONS.map((b) => (
              <option key={b.value} value={b.value}>
                {b.label[lang]}
              </option>
            ))}
          </select>
        </Field>

        {/* 8. Official email */}
        <Field
          label={t(tx("Official Email", "البريد الإلكتروني الرسمي"))}
          required
          error={errors.official_email && t(errors.official_email)}
        >
          <Input
            type="email"
            className={inputClass}
            value={form.official_email}
            onChange={(e) => set("official_email", e.target.value)}
            placeholder="example@company.com"
            aria-invalid={!!errors.official_email}
          />
        </Field>

        {/* 9. Website */}
        <Field
          label={t(tx("Website", "الموقع الإلكتروني"))}
          error={errors.website && t(errors.website)}
        >
          <Input
            type="url"
            className={inputClass}
            value={form.website ?? ""}
            onChange={(e) => set("website", e.target.value)}
            placeholder="https://company.com"
            aria-invalid={!!errors.website}
          />
        </Field>

        {/* 10-11. Existing contact / responsible person info */}
        <Field label={t(tx("Commercial Registration No.", "رقم السجل التجاري"))}>
          <Input
            className={inputClass}
            value={form.cr_number ?? ""}
            onChange={(e) => set("cr_number", e.target.value)}
          />
        </Field>
        <Field label={t(tx("Contact Person", "الشخص المسؤول"))}>
          <Input
            className={inputClass}
            value={form.contact_person ?? ""}
            onChange={(e) => set("contact_person", e.target.value)}
          />
        </Field>
        <Field label={t(tx("Contact Mobile", "رقم الجوال"))}>
          <Input
            type="tel"
            className={inputClass}
            value={form.contact_phone ?? ""}
            onChange={(e) => set("contact_phone", e.target.value)}
          />
        </Field>
      </div>

      <Field label={t(tx("Additional Notes", "ملاحظات إضافية"))}>
        <Textarea
          rows={4}
          className="bg-background"
          value={form.notes ?? ""}
          onChange={(e) => set("notes", e.target.value)}
        />
      </Field>

      <div className="flex flex-wrap gap-3">
        <Button
          type="submit"
          disabled={saving}
          aria-busy={saving}
          className="bg-gradient-gold font-semibold text-primary-foreground hover:shadow-gold"
        >
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
          {form.id ? t(tx("Update Client", "تحديث العميل")) : t(tx("Save Client", "حفظ العميل"))}
        </Button>
        {onCancel && (
          <Button
            type="button"
            variant="outline"
            className="border-primary/60 text-gold-dark"
            onClick={onCancel}
          >
            {t(tx("Cancel", "إلغاء"))}
          </Button>
        )}
      </div>
    </form>
  );
}

function Field({
  label,
  required,
  error,
  children,
}: {
  label: string;
  required?: boolean;
  error?: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <Label className="text-xs font-semibold uppercase tracking-wider text-gold-dark">
        {label} {required && <span className="text-destructive">*</span>}
      </Label>
      <div className="mt-2">{children}</div>
      {error && (
        <p role="alert" className="mt-1.5 text-xs text-destructive">
          {error}
        </p>
      )}
    </div>
  );
}
