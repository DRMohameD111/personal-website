import { useMemo, useState } from "react";
import { Check, ChevronsUpDown, Search } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { useI18n } from "@/i18n";

export type SearchableOption = { value: string; label: { en: string; ar: string } };

/** Shared searchable dropdown reused for countries, nationalities and activities. */
export function SearchableSelect({
  options,
  value,
  onChange,
  placeholder,
  id,
  invalid,
}: {
  options: SearchableOption[];
  value: string;
  onChange: (value: string) => void;
  placeholder: string;
  id?: string;
  invalid?: boolean;
}) {
  const { lang, dir } = useI18n();
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");

  const selected = options.find((o) => o.value === value);
  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    if (!needle) return options;
    return options.filter(
      (o) => o.label.en.toLowerCase().includes(needle) || o.label.ar.includes(needle),
    );
  }, [options, q]);

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button
          type="button"
          id={id}
          role="combobox"
          aria-expanded={open}
          aria-invalid={invalid || undefined}
          className={cn(
            "flex h-11 w-full items-center justify-between gap-2 rounded-md border border-input bg-background px-3 text-sm text-foreground",
            "focus:outline-none focus:ring-2 focus:ring-ring",
            invalid && "border-destructive",
            !selected && "text-muted-foreground",
          )}
        >
          <span className="truncate">{selected ? selected.label[lang] : placeholder}</span>
          <ChevronsUpDown className="h-4 w-4 shrink-0 opacity-60" />
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-[--radix-popover-trigger-width] p-0" align="start" dir={dir}>
        <div className="flex items-center gap-2 border-b border-border px-3 py-2">
          <Search className="h-4 w-4 opacity-60" />
          <Input
            autoFocus
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder={placeholder}
            className="h-8 border-0 px-0 shadow-none focus-visible:ring-0"
          />
        </div>
        <ul className="max-h-64 overflow-y-auto py-1" role="listbox">
          {filtered.length === 0 ? (
            <li className="px-3 py-2 text-sm text-muted-foreground">
              {lang === "ar" ? "لا نتائج" : "No results"}
            </li>
          ) : (
            filtered.map((o) => (
              <li key={o.value}>
                <button
                  type="button"
                  role="option"
                  aria-selected={o.value === value}
                  onClick={() => {
                    onChange(o.value);
                    setOpen(false);
                    setQ("");
                  }}
                  className="flex w-full items-center justify-between gap-2 px-3 py-2 text-start text-sm hover:bg-primary/10"
                >
                  <span className="truncate">{o.label[lang]}</span>
                  {o.value === value && <Check className="h-4 w-4 text-gold-dark" />}
                </button>
              </li>
            ))
          )}
        </ul>
      </PopoverContent>
    </Popover>
  );
}
