// ---------------------------------------------------------------------------
// Admin Control Panel — subscription commercial policy, stable package ranking
// and verified payment confirmation for open package-change requests.
// Every write is authorised server-side and written to the package audit log.
// ---------------------------------------------------------------------------
import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { BadgeCheck, Loader2, Save, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useI18n, tx } from "@/i18n";
import { fetchAllPackages, pick } from "@/lib/packages";
import { changeTypeLabel, formatDate, formatMoney, statusLabel } from "@/lib/subscriptions";
import {
  confirmPackagePayment,
  getSubscriptionPolicy,
  listOpenChangeRequests,
  updatePackageRanking,
  updateSubscriptionPolicy,
} from "@/lib/subscriptions.functions";

type PolicyForm = {
  upgrade_timing: "immediate" | "after_payment";
  downgrade_timing: "end_of_term" | "immediate";
  prorate_credit: boolean;
  require_admin_approval: boolean;
  allow_same_package_renewal: boolean;
  tax_percent: number;
};

export function SubscriptionPolicyCard() {
  const { t, lang } = useI18n();
  const queryClient = useQueryClient();
  const loadPolicy = useServerFn(getSubscriptionPolicy);
  const savePolicy = useServerFn(updateSubscriptionPolicy);
  const saveRanking = useServerFn(updatePackageRanking);
  const loadRequests = useServerFn(listOpenChangeRequests);
  const confirmPayment = useServerFn(confirmPackagePayment);

  const policy = useQuery({ queryKey: ["subscription-policy"], queryFn: () => loadPolicy({}) });
  const packages = useQuery({ queryKey: ["admin-packages"], queryFn: fetchAllPackages });
  const requests = useQuery({
    queryKey: ["open-change-requests"],
    queryFn: () => loadRequests({}),
  });

  const [form, setForm] = useState<PolicyForm | null>(null);
  const [saving, setSaving] = useState(false);
  const [busyRequest, setBusyRequest] = useState<string | null>(null);
  const [payment, setPayment] = useState<Record<string, { reference: string; amount: string }>>({});

  useEffect(() => {
    if (policy.data)
      setForm({
        upgrade_timing: policy.data.upgrade_timing as PolicyForm["upgrade_timing"],
        downgrade_timing: policy.data.downgrade_timing as PolicyForm["downgrade_timing"],
        prorate_credit: policy.data.prorate_credit,
        require_admin_approval: policy.data.require_admin_approval,
        allow_same_package_renewal: policy.data.allow_same_package_renewal,
        tax_percent: Number(policy.data.tax_percent),
      });
  }, [policy.data]);

  async function onSavePolicy() {
    if (!form) return;
    setSaving(true);
    try {
      await savePolicy({ data: form });
      await queryClient.invalidateQueries({ queryKey: ["subscription-policy"] });
      toast.success(t(tx("Subscription policy saved.", "تم حفظ سياسة الاشتراكات.")));
    } catch {
      toast.error(t(tx("The policy could not be saved.", "تعذر حفظ السياسة.")));
    } finally {
      setSaving(false);
    }
  }

  async function onSaveRanking(packageId: string, rank: number, codePrefix: string) {
    try {
      await saveRanking({ data: { packageId, rank, codePrefix, reason: "admin panel" } });
      await queryClient.invalidateQueries({ queryKey: ["admin-packages"] });
      toast.success(t(tx("Package ranking saved.", "تم حفظ ترتيب الباقة.")));
    } catch {
      toast.error(t(tx("The ranking could not be saved.", "تعذر حفظ الترتيب.")));
    }
  }

  async function onConfirmPayment(requestId: string) {
    const entry = payment[requestId];
    if (!entry?.reference || !entry.amount) {
      toast.error(
        t(
          tx(
            "Enter the verified payment reference and amount.",
            "أدخل مرجع السداد المؤكد والمبلغ.",
          ),
        ),
      );
      return;
    }
    setBusyRequest(requestId);
    try {
      const res = await confirmPayment({
        data: {
          requestId,
          paymentReference: entry.reference.trim(),
          amountPaid: Number(entry.amount),
          reason: "Verified with the payment provider",
        },
      });
      if (!res.ok) {
        toast.error(
          t(
            tx(
              "Activation was not completed. The subscription has not been changed.",
              "لم يتم إكمال التفعيل. لم يتم تعديل الاشتراك.",
            ),
          ),
        );
      } else {
        toast.success(
          t(
            tx(
              `Subscription ${res.status}. Package code: ${res.packageCode ?? "—"}.`,
              `تم ${res.status === "scheduled" ? "جدولة" : "تفعيل"} الاشتراك. كود الباقة: ${res.packageCode ?? "—"}.`,
            ),
          ),
        );
      }
      await queryClient.invalidateQueries({ queryKey: ["open-change-requests"] });
    } catch {
      toast.error(
        t(tx("Activation failed. Nothing has been changed.", "فشل التفعيل. لم يتم تغيير أي شيء.")),
      );
    } finally {
      setBusyRequest(null);
    }
  }

  return (
    <div className="space-y-6">
      <Card className="border-border/60 shadow-elegant">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 font-display text-xl">
            <ShieldCheck className="h-5 w-5 text-gold-dark" />
            {t(tx("Subscription Policy", "سياسة الاشتراكات"))}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {!form ? (
            <Loader2 className="h-5 w-5 animate-spin text-gold-dark" />
          ) : (
            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label>{t(tx("Upgrade starts", "بداية الترقية"))}</Label>
                <select
                  value={form.upgrade_timing}
                  onChange={(e) =>
                    setForm({
                      ...form,
                      upgrade_timing: e.target.value as PolicyForm["upgrade_timing"],
                    })
                  }
                  className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 text-sm"
                >
                  <option value="after_payment">
                    {t(tx("After verified payment", "بعد تأكيد السداد"))}
                  </option>
                  <option value="immediate">{t(tx("Immediately", "فوراً"))}</option>
                </select>
              </div>
              <div className="space-y-1.5">
                <Label>{t(tx("Downgrade starts", "بداية التخفيض"))}</Label>
                <select
                  value={form.downgrade_timing}
                  onChange={(e) =>
                    setForm({
                      ...form,
                      downgrade_timing: e.target.value as PolicyForm["downgrade_timing"],
                    })
                  }
                  className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 text-sm"
                >
                  <option value="end_of_term">
                    {t(tx("At the end of the current term", "بعد انتهاء الباقة الحالية"))}
                  </option>
                  <option value="immediate">{t(tx("Immediately", "فوراً"))}</option>
                </select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="tax_percent">{t(tx("Tax (%)", "الضريبة (%)"))}</Label>
                <Input
                  id="tax_percent"
                  type="number"
                  min={0}
                  max={100}
                  step="0.01"
                  value={form.tax_percent}
                  onChange={(e) => setForm({ ...form, tax_percent: Number(e.target.value) })}
                />
              </div>
              <div className="space-y-3">
                {(
                  [
                    [
                      "prorate_credit",
                      tx("Apply prorated credit on upgrade", "احتساب رصيد المدة غير المستخدمة"),
                    ],
                    [
                      "require_admin_approval",
                      tx("Require admin approval", "يتطلب موافقة الإدارة"),
                    ],
                    [
                      "allow_same_package_renewal",
                      tx("Allow same-package renewal", "السماح بتجديد نفس الباقة"),
                    ],
                  ] as const
                ).map(([key, label]) => (
                  <div key={key} className="flex items-center justify-between gap-4">
                    <Label htmlFor={key} className="text-sm">
                      {t(label)}
                    </Label>
                    <Switch
                      id={key}
                      checked={form[key]}
                      onCheckedChange={(v) => setForm({ ...form, [key]: v })}
                    />
                  </div>
                ))}
              </div>
              <div className="sm:col-span-2">
                <Button
                  onClick={onSavePolicy}
                  disabled={saving}
                  className="bg-gradient-gold font-semibold text-primary-foreground"
                >
                  {saving ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Save className="h-4 w-4" />
                  )}
                  {t(tx("Save policy", "حفظ السياسة"))}
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="border-border/60 shadow-elegant">
        <CardHeader>
          <CardTitle className="font-display text-xl">
            {t(tx("Package Rank & Code Prefix", "ترتيب الباقة وبادئة الكود"))}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            {t(
              tx(
                "Upgrade / downgrade is decided from the rank, and the package code prefix is independent of the display name.",
                "يتم تحديد الترقية أو التخفيض من الترتيب، وبادئة كود الباقة مستقلة عن الاسم المعروض.",
              ),
            )}
          </p>
          {(packages.data ?? []).map((p) => (
            <RankRow
              key={p.id}
              name={pick(lang, p.name_en, p.name_ar)}
              rank={p.rank}
              prefix={p.code_prefix ?? p.slug.charAt(0).toUpperCase()}
              onSave={(rank, prefix) => onSaveRanking(p.id, rank, prefix)}
              saveLabel={t(tx("Save", "حفظ"))}
            />
          ))}
        </CardContent>
      </Card>

      <Card className="border-border/60 shadow-elegant">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 font-display text-xl">
            <BadgeCheck className="h-5 w-5 text-gold-dark" />
            {t(tx("Open Package Change Requests", "طلبات تغيير الباقات المفتوحة"))}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {requests.isLoading ? (
            <Loader2 className="h-5 w-5 animate-spin text-gold-dark" />
          ) : (requests.data?.length ?? 0) === 0 ? (
            <p className="text-sm text-muted-foreground">
              {t(tx("No open requests.", "لا توجد طلبات مفتوحة."))}
            </p>
          ) : (
            requests.data!.map((r) => (
              <div key={r.id} className="rounded-lg border border-border/60 p-4">
                <div className="flex flex-wrap items-center gap-3 text-sm">
                  <span className="font-mono text-xs text-muted-foreground">
                    {r.id.slice(0, 8)}
                  </span>
                  <span>{t(changeTypeLabel(r.change_type))}</span>
                  <span>{t(statusLabel(r.status))}</span>
                  <span>
                    {t(tx("Amount Due", "المبلغ المستحق"))}:{" "}
                    {formatMoney(Number(r.amount_due), r.currency, lang)}
                  </span>
                  <span>
                    {t(tx("Effective", "تاريخ التفعيل"))}: {formatDate(r.effective_date, lang)}
                  </span>
                </div>
                <div className="mt-3 flex flex-wrap items-end gap-3">
                  <div className="space-y-1">
                    <Label className="text-xs">
                      {t(tx("Verified payment reference", "مرجع السداد المؤكد"))}
                    </Label>
                    <Input
                      value={payment[r.id]?.reference ?? ""}
                      onChange={(e) =>
                        setPayment((s) => ({
                          ...s,
                          [r.id]: { reference: e.target.value, amount: s[r.id]?.amount ?? "" },
                        }))
                      }
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs">
                      {t(tx("Verified amount paid", "المبلغ المدفوع المؤكد"))}
                    </Label>
                    <Input
                      type="number"
                      min={0}
                      step="0.01"
                      value={payment[r.id]?.amount ?? ""}
                      onChange={(e) =>
                        setPayment((s) => ({
                          ...s,
                          [r.id]: { reference: s[r.id]?.reference ?? "", amount: e.target.value },
                        }))
                      }
                    />
                  </div>
                  <Button
                    onClick={() => onConfirmPayment(r.id)}
                    disabled={busyRequest === r.id}
                    aria-busy={busyRequest === r.id}
                    className="bg-gradient-gold font-semibold text-primary-foreground"
                  >
                    {busyRequest === r.id && <Loader2 className="h-4 w-4 animate-spin" />}
                    {t(tx("Confirm payment & activate", "تأكيد السداد والتفعيل"))}
                  </Button>
                </div>
              </div>
            ))
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function RankRow({
  name,
  rank,
  prefix,
  onSave,
  saveLabel,
}: {
  name: string;
  rank: number;
  prefix: string;
  onSave: (rank: number, prefix: string) => void;
  saveLabel: string;
}) {
  const [r, setR] = useState(String(rank));
  const [p, setP] = useState(prefix);
  return (
    <div className="flex flex-wrap items-end gap-3">
      <p className="min-w-40 text-sm font-medium text-foreground">{name}</p>
      <Input
        className="w-24"
        type="number"
        min={0}
        value={r}
        onChange={(e) => setR(e.target.value)}
      />
      <Input
        className="w-24"
        maxLength={4}
        value={p}
        onChange={(e) => setP(e.target.value.toUpperCase())}
      />
      <Button variant="outline" size="sm" onClick={() => onSave(Number(r), p)}>
        <Save className="h-4 w-4" />
        {saveLabel}
      </Button>
    </div>
  );
}
