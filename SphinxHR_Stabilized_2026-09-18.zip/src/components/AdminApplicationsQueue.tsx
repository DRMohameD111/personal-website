import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { CheckCircle2, ClipboardList, Loader2, Search, XCircle } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useI18n, tx } from "@/i18n";
import { canDo } from "@/lib/admin-access";
import { getMyAdminAccess, listApplications, reviewApplication } from "@/lib/admin.functions";
import { applicationStatusLabel } from "@/lib/status-labels";

const TONE: Record<string, string> = {
  submitted: "border-primary/40 bg-primary/10 text-gold-dark",
  cv_sent: "border-primary/40 bg-primary/10 text-gold-dark",
  employer_reviewed: "border-muted bg-muted text-muted-foreground",
  shortlisted: "border-emerald-500/40 bg-emerald-500/10 text-emerald-700",
  rejected: "border-destructive/40 bg-destructive/10 text-destructive",
  hired: "border-emerald-500/40 bg-emerald-500/10 text-emerald-700",
};

/**
 * Platform-wide review of every job application. Reuses the existing
 * `job_applications` records, statuses and admin permission checks — the
 * server re-verifies the "applications" module permissions on every action.
 */
export function AdminApplicationsQueue() {
  const { t, lang } = useI18n();
  const queryClient = useQueryClient();

  const fetchAccess = useServerFn(getMyAdminAccess);
  const fetchApps = useServerFn(listApplications);
  const review = useServerFn(reviewApplication);

  const access = useQuery({ queryKey: ["admin-access"], queryFn: () => fetchAccess({}) });
  const mayView = canDo(access.data, "applications", "view");
  const mayApprove = canDo(access.data, "applications", "approve");

  const [term, setTerm] = useState("");
  const [applied, setApplied] = useState("");

  const apps = useQuery({
    queryKey: ["admin-applications", applied],
    enabled: mayView,
    queryFn: () => fetchApps({ data: { query: applied } }),
  });

  const decide = useMutation({
    mutationFn: (v: { id: string; decision: "approve" | "reject" }) =>
      review({ data: { applicationId: v.id, decision: v.decision } }),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["admin-applications"] });
      await queryClient.invalidateQueries({ queryKey: ["admin-activity"] });
      toast.success(t(tx("Application updated.", "تم تحديث الطلب.")));
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (access.isLoading) return null;
  if (!mayView) return null;

  const rows = apps.data ?? [];
  const fmt = (d: string) => new Date(d).toLocaleDateString(lang === "ar" ? "ar-EG" : "en-GB");

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 font-display text-lg">
          <ClipboardList className="h-5 w-5 text-gold-dark" />
          {t(tx("Job Applications", "طلبات الوظائف"))}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <form
          className="flex flex-wrap items-end gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            setApplied(term);
          }}
        >
          <div className="min-w-[220px] flex-1 space-y-1.5">
            <Label htmlFor="search-applications">{t(tx("Search", "بحث"))}</Label>
            <Input
              id="search-applications"
              value={term}
              placeholder={t(
                tx("Candidate, company, job, status…", "المرشح، الشركة، الوظيفة، الحالة…"),
              )}
              onChange={(e) => setTerm(e.target.value)}
            />
          </div>
          <Button type="submit" variant="outline">
            <Search className="h-4 w-4 text-gold-dark" />
            {t(tx("Search", "بحث"))}
          </Button>
        </form>

        {apps.isLoading ? (
          <Loader2 className="h-5 w-5 animate-spin text-gold-dark" />
        ) : rows.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            {t(tx("No applications yet.", "لا توجد طلبات حتى الآن."))}
          </p>
        ) : (
          <ul className="divide-y divide-border/70">
            {rows.map((a) => (
              <li key={a.id} className="flex flex-wrap items-start justify-between gap-3 py-3">
                <div className="min-w-0">
                  <p className="font-semibold text-heading">
                    {a.job_title || t(tx("Vacancy", "وظيفة"))}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {[a.candidate_name, a.candidate_email, a.company_name]
                      .filter(Boolean)
                      .join(" · ") || "—"}
                  </p>
                  <p className="mt-1 text-xs text-muted-foreground">{fmt(a.created_at)}</p>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <span
                    className={`rounded-full border px-2.5 py-1 text-[10px] font-semibold ${
                      TONE[a.status] ?? TONE["employer_reviewed"]
                    }`}
                  >
                    {t(applicationStatusLabel(a.status))}
                  </span>
                  {mayApprove && a.status !== "shortlisted" && a.status !== "hired" && (
                    <Button
                      size="sm"
                      disabled={decide.isPending}
                      className="bg-gradient-gold font-semibold text-primary-foreground"
                      onClick={() => decide.mutate({ id: a.id, decision: "approve" })}
                    >
                      <CheckCircle2 className="h-4 w-4" />
                      {t(tx("Approve", "اعتماد"))}
                    </Button>
                  )}
                  {mayApprove && a.status !== "rejected" && (
                    <Button
                      size="sm"
                      variant="outline"
                      disabled={decide.isPending}
                      onClick={() => decide.mutate({ id: a.id, decision: "reject" })}
                    >
                      <XCircle className="h-4 w-4 text-destructive" />
                      {t(tx("Reject", "رفض"))}
                    </Button>
                  )}
                </div>
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}
