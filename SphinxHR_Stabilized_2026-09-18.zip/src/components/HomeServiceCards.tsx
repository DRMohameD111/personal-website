import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import {
  Search,
  BriefcaseBusiness,
  UserRound,
  Building2,
  UserPlus,
  Megaphone,
  ArrowRight,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { getMyAccountType } from "@/lib/account-type";
import { useI18n, tx } from "@/i18n";
import { ornaments } from "@/brand";

type Bi = ReturnType<typeof tx>;

interface ServiceCardDef {
  key: string;
  icon: LucideIcon;
  title: Bi;
  desc: Bi;
  cta: Bi;
  /** Existing route reused as destination. */
  to: string;
  search?: Record<string, string>;
}

/**
 * Home-page service entry points. Every card routes to an EXISTING page —
 * no new destinations, forms or auth flows are introduced here.
 */
const cards: ServiceCardDef[] = [
  {
    key: "explore-jobs",
    icon: Search,
    title: tx("Explore Jobs", "استعراض الوظائف"),
    desc: tx(
      "Explore available jobs using search and filtering options",
      "استعرض الوظائف المتاحة وابحث باستخدام الفلاتر",
    ),
    cta: tx("Explore", "استعراض"),
    to: "/jobs",
  },
  {
    key: "post-job",
    icon: BriefcaseBusiness,
    title: tx("Post a Job", "إضافة وظيفة"),
    desc: tx(
      "Post a new vacancy and find suitable talent",
      "أضف وظيفة جديدة وابحث عن أصحاب المهارات",
    ),
    cta: tx("Post a Job", "إضافة وظيفة"),
    // Guarded route: sends unauthenticated companies through the existing login flow
    // and returns them here afterwards.
    to: "/post-job",
  },
  {
    key: "direct-ad",
    icon: Megaphone,
    title: tx("Direct Vacancy Ad", "إعلان مباشر عن وظيفة"),
    desc: tx(
      "Post a vacancy without subscription and receive CVs directly",
      "انشر وظيفة بدون اشتراك واستقبل السير الذاتية مباشرة",
    ),
    cta: tx("Post a vacancy without subscription", "نشر وظيفة بدون اشتراك"),
    to: "/direct-ad",
  },
  {
    key: "seeker-login",
    icon: UserRound,
    title: tx("Job Seeker Login", "دخول أصحاب المهارات"),
    desc: tx(
      "Log in to search and apply for suitable jobs",
      "ادخل إلى حسابك للبحث عن الوظائف والتقدم إليها",
    ),
    cta: tx("Login", "دخول"),
    to: "/auth",
    search: { next: "/jobs" },
  },
  {
    key: "company-login",
    icon: Building2,
    title: tx("Company Login", "دخول أصحاب الأعمال"),
    desc: tx(
      "Log in to post jobs and manage applicants",
      "ادخل إلى حساب الشركة لإضافة الوظائف وإدارة المتقدمين",
    ),
    cta: tx("Login", "دخول"),
    to: "/auth",
    search: { next: "/my-jobs" },
  },
  {
    key: "create-account",
    icon: UserPlus,
    title: tx("Create Account", "إنشاء حساب"),
    desc: tx(
      "Choose the appropriate account type and start registration",
      "اختر نوع الحساب المناسب وابدأ التسجيل",
    ),
    cta: tx("Create Account", "إنشاء حساب"),
    to: "/auth",
  },
];

export function HomeServiceCards() {
  const { t } = useI18n();
  // Direct Ads stay available to guests and job seekers; only registered
  // company accounts are excluded (they post through their own account).
  const [signedIn, setSignedIn] = useState<boolean | null>(null);
  const [isCompany, setIsCompany] = useState(false);

  useEffect(() => {
    let active = true;
    const sync = async (session: boolean) => {
      if (!active) return;
      setSignedIn(session);
      setIsCompany(session ? (await getMyAccountType()) === "company" : false);
    };
    supabase.auth.getSession().then(({ data }) => sync(!!data.session));
    const { data } = supabase.auth.onAuthStateChange((_e, session) => void sync(!!session));
    return () => {
      active = false;
      data.subscription.unsubscribe();
    };
  }, []);

  const visible = cards.filter((c) => {
    if (signedIn === null) return c.key !== "direct-ad" && c.key !== "post-job";
    if (c.key === "direct-ad") return !isCompany;
    if (c.key === "post-job") return signedIn;
    if (c.key === "seeker-login" || c.key === "company-login") return !signedIn;
    return true;
  });

  return (
    <section id="platform-services" className="relative border-t border-border/40 py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <span className="text-xs font-semibold uppercase tracking-[0.25em] text-gold-dark">
            {t(tx("Platform Services", "خدمات المنصة"))}
          </span>
          <h2 className="mt-3 font-display text-3xl font-medium text-heading md:text-4xl">
            {t(tx("Where would you like to start?", "من أين تحب أن تبدأ؟"))}
          </h2>
          <div className="gold-divider mx-auto mt-5 w-24" />
        </div>

        {/* Bento grid: the first card carries hero scale, the rest stay compact. */}
        <div className="mt-12 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {visible.map((c, i) => {
            const isDirectAd = c.key === "direct-ad";
            const isLead = i === 0;
            return (
              <div
                key={c.key}
                className={`group relative flex h-full flex-col overflow-hidden rounded-[2rem] transition-all duration-300 hover:-translate-y-1 ${
                  isLead ? "sm:col-span-2 lg:col-span-2 lg:row-span-2 p-8" : "p-6"
                } ${
                  isLead
                    ? "bg-heading text-background"
                    : isDirectAd
                      ? "direct-ad-card hover:shadow-gold"
                      : "border border-primary/25 bg-background hover:border-primary/60 hover:shadow-gold"
                }`}
              >
                {isLead && (
                  <div
                    aria-hidden
                    className="pointer-events-none absolute -bottom-8 -right-8 h-40 w-40 rounded-full bg-primary/20 blur-3xl"
                  />
                )}
                {isDirectAd && !isLead && (
                  <div
                    aria-hidden
                    className="direct-ad-pattern pointer-events-none absolute inset-0 -z-10 bg-repeat"
                    style={{
                      backgroundImage: `url(${ornaments.pattern})`,
                      backgroundSize: "420px",
                    }}
                  />
                )}
                <div
                  className={`relative inline-flex items-center justify-center ${
                    isLead
                      ? "h-12 w-12 rounded-full bg-gradient-gold"
                      : "h-10 w-10 rounded-xl border border-primary/25 bg-surface-soft"
                  }`}
                >
                  <c.icon
                    className={`${isLead ? "h-6 w-6 text-heading" : "h-5 w-5 text-gold-dark"}`}
                  />
                </div>
                <h3
                  className={`relative mt-5 font-display font-medium ${
                    isLead ? "text-2xl text-background md:text-3xl" : "text-lg text-heading"
                  }`}
                >
                  {t(c.title)}
                </h3>
                <p
                  className={`relative mt-3 flex-1 leading-relaxed ${
                    isLead
                      ? "text-sm text-background/70 md:text-base"
                      : "text-xs text-muted-foreground"
                  }`}
                >
                  {t(c.desc)}
                </p>
                <div className="relative mt-6">
                  <Link to={c.to} {...(c.search ? { search: c.search } : {})} className="block">
                    <Button
                      className={`h-auto w-full whitespace-normal rounded-full px-4 py-4 text-center text-xs leading-tight font-semibold ${
                        isLead
                          ? "bg-gradient-gold text-heading hover:shadow-gold md:text-sm"
                          : isDirectAd
                            ? "bg-red-600 text-black hover:bg-red-700 hover:shadow-lg"
                            : "bg-gradient-gold text-primary-foreground hover:shadow-gold"
                      }`}
                    >
                      {t(c.cta)}
                      <ArrowRight className="h-4 w-4 rtl:rotate-180" />
                    </Button>
                  </Link>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
