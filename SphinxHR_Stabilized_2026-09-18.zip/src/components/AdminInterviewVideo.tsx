import { useRef, useState } from "react";
import { Loader2, Trash2, Video } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { useI18n, tx } from "@/i18n";
import { supabase } from "@/integrations/supabase/client";
import { setCandidateInterviewVideo } from "@/lib/candidate-profile.functions";
import { useServerFn } from "@tanstack/react-start";

/**
 * Admin-only interview video control for a candidate.
 * The candidate can never write this field — the database rejects it — so this
 * lives inside the existing admin data-access panel only.
 */
export function AdminInterviewVideo({ candidateId }: { candidateId: string }) {
  const { t } = useI18n();
  const inputRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const save = useServerFn(setCandidateInterviewVideo);

  const upload = async (file: File) => {
    setBusy(true);
    try {
      const ext = file.name.split(".").pop()?.toLowerCase() || "mp4";
      const path = `${candidateId}/video-${Date.now()}.${ext}`;
      const { error } = await supabase.storage
        .from("candidate-media")
        .upload(path, file, { upsert: true, contentType: file.type || undefined });
      if (error) throw error;
      await save({ data: { candidateId, storagePath: path } });
      toast.success(t(tx("Interview video saved.", "تم حفظ فيديو المقابلة.")));
    } catch (err) {
      toast.error(
        `${t(tx("Could not save the video.", "تعذر حفظ الفيديو."))} ${(err as Error).message ?? ""}`.trim(),
      );
    } finally {
      setBusy(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  };

  const remove = async () => {
    setBusy(true);
    try {
      await save({ data: { candidateId, storagePath: null } });
      toast.success(t(tx("Interview video removed.", "تم حذف فيديو المقابلة.")));
    } catch (err) {
      toast.error(
        `${t(tx("Could not remove the video.", "تعذر حذف الفيديو."))} ${(err as Error).message ?? ""}`.trim(),
      );
    } finally {
      setBusy(false);
    }
  };

  return (
    <span className="flex items-center gap-1">
      <input
        ref={inputRef}
        type="file"
        accept="video/*"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) void upload(f);
        }}
      />
      <Button size="sm" variant="outline" disabled={busy} onClick={() => inputRef.current?.click()}>
        {busy ? (
          <Loader2 className="h-4 w-4 animate-spin" />
        ) : (
          <Video className="h-4 w-4 text-gold-dark" />
        )}
        {t(tx("Interview video", "فيديو المقابلة"))}
      </Button>
      <Button
        size="sm"
        variant="ghost"
        disabled={busy}
        aria-label={t(tx("Remove interview video", "حذف فيديو المقابلة"))}
        onClick={() => void remove()}
      >
        <Trash2 className="h-4 w-4 text-destructive" />
      </Button>
    </span>
  );
}
