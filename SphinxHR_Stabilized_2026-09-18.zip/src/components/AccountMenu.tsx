import { useEffect, useState } from "react";
import { Link, useNavigate, useRouter } from "@tanstack/react-router";
import {
  UserCircle2,
  UserRound,
  FileText,
  LogOut,
  Building2,
  Briefcase,
  Users,
  Link2,
  LayoutDashboard,
  ShieldCheck,
} from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useI18n, tx } from "@/i18n";
import { getMyAccountType, isAdminUser } from "@/lib/account-type";
import type { AccountType } from "@/lib/account-type";

export function AccountMenu({ className }: { className?: string }) {
  const { t, lang } = useI18n();
  const navigate = useNavigate();
  const router = useRouter();
  const queryClient = useQueryClient();
  const [signedIn, setSignedIn] = useState<boolean | null>(null);
  const [accountType, setAccountType] = useState<AccountType | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    let mounted = true;
    const sync = async (hasSession: boolean) => {
      if (!mounted) return;
      setSignedIn(hasSession);
      setAccountType(hasSession ? await getMyAccountType() : null);
      if (!mounted) return;
      setIsAdmin(hasSession ? await isAdminUser() : false);
    };
    supabase.auth.getSession().then(({ data }) => void sync(!!data.session));
    const { data } = supabase.auth.onAuthStateChange((_e, session) => {
      void sync(!!session);
    });
    return () => {
      mounted = false;
      data.subscription.unsubscribe();
    };
  }, []);

  const trigger = (
    <span
      className="inline-flex h-9 w-9 items-center justify-center rounded-md border border-primary/50 text-gold-dark transition-colors hover:bg-primary/10"
      aria-hidden="true"
    >
      <UserCircle2 className="h-5 w-5" />
    </span>
  );

  if (!signedIn) {
    return (
      <Link
        to="/auth"
        className={className}
        aria-label={t(tx("Sign in to your account", "تسجيل الدخول إلى حسابك"))}
        title={t(tx("Account", "الحساب"))}
      >
        {trigger}
      </Link>
    );
  }

  const isCompany = accountType === "company";

  async function handleSignOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    router.invalidate();
    navigate({ to: "/auth", replace: true });
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger
        className={className}
        aria-label={t(tx("Account menu", "قائمة الحساب"))}
        title={t(tx("Account", "الحساب"))}
      >
        {trigger}
      </DropdownMenuTrigger>
      <DropdownMenuContent align={lang === "ar" ? "start" : "end"} className="w-56">
        <DropdownMenuLabel>
          {isCompany ? t(tx("Company Account", "حساب الشركة")) : t(tx("My Account", "حسابي"))}
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        {isCompany ? (
          <>
            <DropdownMenuItem asChild>
              <Link to="/company" className="flex items-center gap-2">
                <LayoutDashboard className="h-4 w-4 text-gold-dark" />
                {t(tx("Company Account", "حساب الشركة"))}
              </Link>
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <Link to="/company" className="flex items-center gap-2">
                <Building2 className="h-4 w-4 text-gold-dark" />
                {t(tx("Company Profile", "ملف الشركة"))}
              </Link>
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <Link to="/clients" className="flex items-center gap-2">
                <Building2 className="h-4 w-4 text-gold-dark" />
                {t(tx("Clients", "العملاء"))}
              </Link>
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <Link to="/manpower" className="flex items-center gap-2">
                <Users className="h-4 w-4 text-gold-dark" />
                {t(tx("Manpower Requests", "طلبات القوى العاملة"))}
              </Link>
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <Link to="/my-jobs" className="flex items-center gap-2">
                <Briefcase className="h-4 w-4 text-gold-dark" />
                {t(tx("My Jobs", "وظائفي"))}
              </Link>
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <Link to="/applicants" className="flex items-center gap-2">
                <Users className="h-4 w-4 text-gold-dark" />
                {t(tx("Applicants", "المتقدمون"))}
              </Link>
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <Link to="/match" className="flex items-center gap-2">
                <Link2 className="h-4 w-4 text-gold-dark" />
                {t(tx("Link Job to Application", "ربط الوظيفة بالطلب"))}
              </Link>
            </DropdownMenuItem>
          </>
        ) : (
          <>
            <DropdownMenuItem asChild>
              <Link to="/account" className="flex items-center gap-2">
                <LayoutDashboard className="h-4 w-4 text-gold-dark" />
                {t(tx("My Account", "حسابي"))}
              </Link>
            </DropdownMenuItem>
            <DropdownMenuItem disabled className="flex items-center gap-2">
              <UserRound className="h-4 w-4 text-gold-dark" />
              {t(tx("My Profile", "ملفي الشخصي"))}
            </DropdownMenuItem>

            <DropdownMenuItem asChild>
              <Link to="/account" hash="applications" className="flex items-center gap-2">
                <FileText className="h-4 w-4 text-gold-dark" />
                {t(tx("My Applications", "طلباتي"))}
              </Link>
            </DropdownMenuItem>
          </>
        )}
        {isAdmin && (
          <>
            <DropdownMenuSeparator />
            <DropdownMenuItem asChild>
              <Link to="/admin" className="flex items-center gap-2">
                <ShieldCheck className="h-4 w-4 text-gold-dark" />
                {t(tx("Control Panel", "لوحة التحكم"))}
              </Link>
            </DropdownMenuItem>
          </>
        )}
        <DropdownMenuSeparator />
        <DropdownMenuItem onSelect={() => void handleSignOut()} className="flex items-center gap-2">
          <LogOut className="h-4 w-4 text-gold-dark" />
          {t(tx("Logout", "تسجيل الخروج"))}
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
