import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  BadgeCheck,
  Building2,
  Download,
  FileText,
  Loader2,
  Printer,
  Save,
  Search,
  Users,
} from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useI18n, tx } from "@/i18n";
import { Link } from "@tanstack/react-router";
import { AdminInterviewVideo } from "@/components/AdminInterviewVideo";
import { canDo, toCsv, type AdminModule } from "@/lib/admin-access";
import {
  authorizeReport,
  getCvLink,
  getMyAdminAccess,
  searchProfiles,
  updateProfileFields,
  verifyProfile,
  type AdminProfile,
} from "@/lib/admin.functions";
import { openSignedFile } from "@/lib/open-file";

const COMPANY_FIELDS = [
  "company_name",
  "email",
  "phone",
  "country",
  "sector",
  "branches_count",
] as const;
const SEEKER_FIELDS = [
  "full_name",
  "email",
  "phone",
  "country",
  "nationality",
  "profession",
  "sector",
  "education",
  "languages",
] as const;

const FIELD_LABEL: Record<string, ReturnType<typeof tx>> = {
  company_name: tx("Company name", "اسم الشركة"),
  full_name: tx("Full name", "الاسم الكامل"),
  email: tx("Email", "البريد الإلكتروني"),
  phone: tx("Phone", "الهاتف"),
  country: tx("Country", "الدولة"),
  nationality: tx("Nationality", "الجنسية"),
  profession: tx("Profession", "المهنة"),
  sector: tx("Sector", "القطاع"),
  education: tx("Education", "المؤهل"),
  languages: tx("Languages", "اللغات"),
  branches_count: tx("Branches", "عدد الفروع"),
};

/**
 * Authorised data access for administrators: search companies and job seekers,
 * edit permitted fields, verify profiles, open CVs and print/export reports.
 * Every action is checked again on the server against the signed-in admin's
 * permissions — the buttons below only reflect what the server already allows.
 */
export function AdminDataAccess({ kind }: { kind: "company" | "job_seeker" }) {
  const { t } = useI18n();
  const queryClient = useQueryClient();

  const fetchAccess = useServerFn(getMyAdminAccess);
  const search = useServerFn(searchProfiles);
  const saveFields = useServerFn(updateProfileFields);
  const verify = useServerFn(verifyProfile);
  const cvLink = useServerFn(getCvLink);
  const authorize = useServerFn(authorizeReport);

  const access = useQuery({ queryKey: ["admin-access"], queryFn: () => fetchAccess({}) });
  const module: AdminModule = kind === "company" ? "companies" : "job_seekers";

  const [term, setTerm] = useState("");
  const [applied, setApplied] = useState("");
  const [openId, setOpenId] = useState<string | null>(null);
  const [draft, setDraft] = useState<Record<string, string>>({});

  const mayView = canDo(access.data, module, "view");
  const mayEdit = canDo(access.data, module, "edit");
  const mayVerify = canDo(access.data, module, "verify");
  const mayCv = canDo(access.data, "cvs", "view");
  const mayExport = canDo(access.data, "reports", "export");
  const mayPrint = canDo(access.data, "reports", "print");

  const results = useQuery({
    queryKey: ["admin-profiles", kind, applied],
    enabled: mayView,
    queryFn: () => search({ data: { kind, query: applied } }),
  });

  const rows: AdminProfile[] = results.data ?? [];
  const fields = kind === "company" ? COMPANY_FIELDS : SEEKER_FIELDS;

  const save = useMutation({
    mutationFn: (userId: string) => saveFields({ data: { userId, kind, fields: draft } }),
    onSuccess: async () => {
      setOpenId(null);
      await queryClient.invalidateQueries({ queryKey: ["admin-profiles", kind] });
      await queryClient.invalidateQueries({ queryKey: ["admin-activity"] });
      toast.success(t(tx("Saved.", "تم الحفظ.")));
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const toggleVerify = useMutation({
    mutationFn: (v: { userId: string; verified: boolean }) =>
      verify({ data: { userId: v.userId, kind, verified: v.verified } }),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["admin-profiles", kind] });
      await queryClient.invalidateQueries({ queryKey: ["admin-activity"] });
      toast.success(t(tx("Verification updated.", "تم تحديث التوثيق.")));
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const openCv = useMutation({
    mutationFn: (userId: string) => cvLink({ data: { userId } }),
    onSuccess: (d) => openSignedFile(d.url, d.fileName),
    onError: (e: Error) => toast.error(e.message),
  });

  const report = useMutation({
    mutationFn: async (mode: "print" | "export") => {
      await authorize({ data: { mode, scope: kind } });
      return mode;
    },
    onSuccess: (mode) => {
      if (mode === "print") {
        window.print();
        return;
      }
      const csv = toCsv(rows as unknown as Record<string, unknown>[]);
      const url = URL.createObjectURL(
        new Blob([`\uFEFF${csv}`], { type: "text/csv;charset=utf-8" }),
      );
      const a = document.createElement("a");
      a.href = url;
      a.download = `${kind}-report.csv`;
      a.click();
      URL.revokeObjectURL(url);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (access.isLoading) return null;
  if (!mayView) return null;

  const isVerified = (p: AdminProfile) =>
    kind === "company" ? !!p.branches_verified : p.candidate_source === "verified";

  return (
    <Card>
      <CardHeader className="flex flex-row flex-wrap items-center justify-between gap-3">
        <CardTitle className="flex items-center gap-2 font-display text-lg">
          {kind === "company" ? (
            <Building2 className="h-5 w-5 text-gold-dark" />
          ) : (
            <Users className="h-5 w-5 text-gold-dark" />
          )}
          {kind === "company"
            ? t(tx("Company Records", "سجلات الشركات"))
            : t(tx("Job Seeker Records", "سجلات الباحثين عن عمل"))}
        </CardTitle>
        <div className="flex items-center gap-2">
          {mayPrint && (
            <Button size="sm" variant="outline" onClick={() => report.mutate("print")}>
              <Printer className="h-4 w-4 text-gold-dark" />
              {t(tx("Print", "طباعة"))}
            </Button>
          )}
          {mayExport && (
            <Button size="sm" variant="outline" onClick={() => report.mutate("export")}>
              <Download className="h-4 w-4 text-gold-dark" />
              {t(tx("Export", "تصدير"))}
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <form
          className="flex flex-wrap items-end gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            setApplied(term);
          }}
        >
          <div className="min-w-[220px] flex-1 space-y-1.5">
            <Label htmlFor={`search-${kind}`}>{t(tx("Search", "بحث"))}</Label>
            <Input
              id={`search-${kind}`}
              value={term}
              placeholder={t(tx("Name, email, phone, country…", "الاسم، البريد، الهاتف، الدولة…"))}
              onChange={(e) => setTerm(e.target.value)}
            />
          </div>
          <Button type="submit" variant="outline">
            <Search className="h-4 w-4 text-gold-dark" />
            {t(tx("Search", "بحث"))}
          </Button>
        </form>

        {results.isLoading ? (
          <Loader2 className="h-5 w-5 animate-spin text-gold-dark" />
        ) : rows.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            {t(tx("No matching records.", "لا توجد سجلات مطابقة."))}
          </p>
        ) : (
          <ul className="divide-y divide-border/70">
            {rows.map((p) => (
              <li key={p.id} className="py-3">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="font-semibold text-heading">
                      {(kind === "company" ? p.company_name : p.full_name) || p.email || p.id}
                      {isVerified(p) && (
                        <BadgeCheck className="ms-1 inline h-4 w-4 text-emerald-600" aria-hidden />
                      )}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {[
                        p.email,
                        p.phone,
                        p.country,
                        kind === "company" ? p.company_code : p.profession,
                      ]
                        .filter(Boolean)
                        .join(" · ") || "—"}
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    {mayEdit && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          const next = openId === p.id ? null : p.id;
                          setOpenId(next);
                          if (next) {
                            const d: Record<string, string> = {};
                            for (const f of fields)
                              d[f] = String((p as never as Record<string, unknown>)[f] ?? "");
                            setDraft(d);
                          }
                        }}
                      >
                        {t(tx("Edit", "تعديل"))}
                      </Button>
                    )}
                    {mayVerify && (
                      <Button
                        size="sm"
                        variant="outline"
                        disabled={toggleVerify.isPending}
                        onClick={() =>
                          toggleVerify.mutate({ userId: p.id, verified: !isVerified(p) })
                        }
                      >
                        <BadgeCheck className="h-4 w-4 text-gold-dark" />
                        {isVerified(p)
                          ? t(tx("Unverify", "إلغاء التوثيق"))
                          : t(tx("Verify", "توثيق"))}
                      </Button>
                    )}
                    {kind === "job_seeker" && mayCv && p.cv_url && (
                      <Button
                        size="sm"
                        variant="outline"
                        disabled={openCv.isPending}
                        onClick={() => openCv.mutate(p.id)}
                      >
                        <FileText className="h-4 w-4 text-gold-dark" />
                        {t(tx("View CV", "عرض السيرة"))}
                      </Button>
                    )}
                    {kind === "job_seeker" && mayEdit && <AdminInterviewVideo candidateId={p.id} />}
                    {kind === "job_seeker" && (
                      <Link to="/candidate/$id" params={{ id: p.id }}>
                        <Button size="sm" variant="outline">
                          {t(tx("Professional Profile", "الملف الاحترافي"))}
                        </Button>
                      </Link>
                    )}
                  </div>
                </div>

                {openId === p.id && mayEdit && (
                  <div className="mt-3 grid gap-3 rounded-lg border border-primary/40 bg-primary/5 p-3 sm:grid-cols-2">
                    {fields.map((f) => (
                      <div key={f} className="space-y-1.5">
                        <Label htmlFor={`${p.id}-${f}`}>{t(FIELD_LABEL[f]!)}</Label>
                        <Input
                          id={`${p.id}-${f}`}
                          value={draft[f] ?? ""}
                          onChange={(e) => setDraft((d) => ({ ...d, [f]: e.target.value }))}
                        />
                      </div>
                    ))}
                    <div className="flex gap-2 sm:col-span-2">
                      <Button
                        size="sm"
                        disabled={save.isPending}
                        className="bg-gradient-gold font-semibold text-primary-foreground"
                        onClick={() => save.mutate(p.id)}
                      >
                        {save.isPending ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <Save className="h-4 w-4" />
                        )}
                        {t(tx("Save", "حفظ"))}
                      </Button>
                      <Button size="sm" variant="ghost" onClick={() => setOpenId(null)}>
                        {t(tx("Cancel", "إلغاء"))}
                      </Button>
                    </div>
                  </div>
                )}
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}
