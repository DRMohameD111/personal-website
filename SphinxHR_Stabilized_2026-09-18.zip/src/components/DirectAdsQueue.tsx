import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { CheckCircle2, Eye, Loader2, Megaphone, XCircle } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useI18n, tx } from "@/i18n";
import { listDirectAds, reviewDirectAd } from "@/lib/direct-ad.functions";

const STATUS_TONE: Record<string, string> = {
  pending_approval: "border-primary/40 bg-primary/10 text-gold-dark",
  published: "border-emerald-500/40 bg-emerald-500/10 text-emerald-700",
  rejected: "border-destructive/40 bg-destructive/10 text-destructive",
  expired: "border-muted bg-muted text-muted-foreground",
  draft: "border-muted bg-muted text-muted-foreground",
};

const STATUS_LABEL = (s: string) =>
  ({
    pending_approval: tx("Pending approval", "بانتظار الموافقة"),
    published: tx("Published", "منشور"),
    rejected: tx("Rejected", "مرفوض"),
    expired: tx("Expired", "منتهي"),
    draft: tx("Awaiting payment", "بانتظار الدفع"),
  })[s] ?? tx(s, s);

/**
 * Admin approval queue for Direct Vacancy Ads. Reuses the existing
 * `job_postings` rows — an ad is published only after approval here.
 */
export function DirectAdsQueue() {
  const { t, lang } = useI18n();
  const queryClient = useQueryClient();
  const fetchAds = useServerFn(listDirectAds);
  const review = useServerFn(reviewDirectAd);
  const [reason, setReason] = useState<Record<string, string>>({});

  const ads = useQuery({ queryKey: ["direct-ads"], queryFn: () => fetchAds({}) });

  const decide = useMutation({
    mutationFn: (v: { id: string; decision: "approve" | "reject" }) =>
      review({
        data: { jobPostingId: v.id, decision: v.decision, reason: reason[v.id] || undefined },
      }),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["direct-ads"] });
      await queryClient.invalidateQueries({ queryKey: ["published-jobs"] });
      await queryClient.invalidateQueries({ queryKey: ["job-meta"] });
      toast.success(t(tx("Direct ad updated.", "تم تحديث الإعلان المباشر.")));
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const fmt = (d: string | null) =>
    d ? new Date(d).toLocaleDateString(lang === "ar" ? "ar-EG" : "en-GB") : "—";

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 font-display text-lg">
          <Megaphone className="h-5 w-5 text-gold-dark" />
          {t(tx("Direct Vacancy Ads", "الإعلانات المباشرة عن وظائف"))}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {ads.isLoading ? (
          <Loader2 className="h-4 w-4 animate-spin text-gold-dark" />
        ) : (ads.data ?? []).length === 0 ? (
          <p className="text-sm text-muted-foreground">
            {t(tx("No direct ads yet.", "لا توجد إعلانات مباشرة حتى الآن."))}
          </p>
        ) : (
          <ul className="space-y-3">
            {(ads.data ?? []).map((a) => (
              <li key={a.id} className="rounded-xl border border-border p-4">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="font-semibold text-foreground">
                      {lang === "ar" ? a.title_ar || a.title_en : a.title_en || a.title_ar}
                    </div>
                    <div className="mt-1 text-xs text-muted-foreground">
                      {a.company_name} · {a.city}
                      {a.country ? `, ${a.country}` : ""} · {a.salary || "—"}
                    </div>
                    <div className="mt-1 text-xs text-muted-foreground">
                      {a.contact_person} · {a.contact_email} · {a.mobile}
                    </div>
                    <div className="mt-1 text-xs text-muted-foreground">
                      {t(tx("CV email", "بريد استلام السير"))}: {a.cv_email}
                    </div>
                    <div className="mt-1 text-xs text-muted-foreground">
                      {t(tx("Submitted", "تاريخ الإرسال"))}: {fmt(a.created_at)} ·{" "}
                      {t(tx("Published", "تاريخ النشر"))}: {fmt(a.published_at)} ·{" "}
                      {t(tx("Closes", "تاريخ الإغلاق"))}: {fmt(a.closes_at)}
                    </div>
                    <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                      <span className="inline-flex items-center gap-1">
                        <Eye className="h-3.5 w-3.5 text-gold-dark" />
                        {a.views}
                      </span>
                      <span>
                        {t(tx("Payment", "الدفع"))}: {a.payment_status} · {a.payment_amount}{" "}
                        {a.payment_currency}
                      </span>
                      {a.rejection_reason && (
                        <span className="text-destructive">
                          {t(tx("Reason", "السبب"))}: {a.rejection_reason}
                        </span>
                      )}
                    </div>
                  </div>
                  <span
                    className={`shrink-0 rounded-full border px-2.5 py-1 text-[10px] font-semibold ${
                      STATUS_TONE[a.status] ?? STATUS_TONE["draft"]
                    }`}
                  >
                    {t(STATUS_LABEL(a.status))}
                  </span>
                </div>

                {a.status === "pending_approval" && (
                  <div className="mt-3 flex flex-wrap items-center gap-2">
                    <Button
                      size="sm"
                      disabled={decide.isPending}
                      className="bg-gradient-gold font-semibold text-primary-foreground"
                      onClick={() => decide.mutate({ id: a.id, decision: "approve" })}
                    >
                      <CheckCircle2 className="h-4 w-4" />
                      {t(tx("Approve & publish", "موافقة ونشر"))}
                    </Button>
                    <Input
                      className="max-w-xs"
                      placeholder={t(tx("Rejection reason (optional)", "سبب الرفض (اختياري)"))}
                      value={reason[a.id] ?? ""}
                      onChange={(e) => setReason((r) => ({ ...r, [a.id]: e.target.value }))}
                    />
                    <Button
                      size="sm"
                      variant="outline"
                      disabled={decide.isPending}
                      onClick={() => decide.mutate({ id: a.id, decision: "reject" })}
                    >
                      <XCircle className="h-4 w-4 text-destructive" />
                      {t(tx("Reject", "رفض"))}
                    </Button>
                  </div>
                )}
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}
