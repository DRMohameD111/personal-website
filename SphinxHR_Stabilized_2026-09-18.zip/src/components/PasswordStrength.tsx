import { Check, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { useI18n, tx } from "@/i18n";

interface Rule {
  key: string;
  labelEn: string;
  labelAr: string;
  met: boolean;
}

export interface PasswordCheck {
  minLength: boolean;
  upper: boolean;
  lower: boolean;
  number: boolean;
  special: boolean;
  match: boolean;
}

function getRules(check: PasswordCheck): Rule[] {
  return [
    {
      key: "minLength",
      labelEn: "At least 8 characters",
      labelAr: "8 أحرف على الأقل",
      met: check.minLength,
    },
    { key: "upper", labelEn: "One uppercase letter", labelAr: "حرف كبير واحد", met: check.upper },
    { key: "lower", labelEn: "One lowercase letter", labelAr: "حرف صغير واحد", met: check.lower },
    { key: "number", labelEn: "One number", labelAr: "رقم واحد", met: check.number },
    {
      key: "special",
      labelEn: "One special character",
      labelAr: "رمز خاص واحد",
      met: check.special,
    },
    {
      key: "match",
      labelEn: "Passwords match",
      labelAr: "كلمتا المرور متطابقتان",
      met: check.match,
    },
  ];
}

export function checkPassword(password: string, confirm: string): PasswordCheck {
  return {
    minLength: password.length >= 8,
    upper: /[A-Z]/.test(password),
    lower: /[a-z]/.test(password),
    number: /[0-9]/.test(password),
    special: /[^A-Za-z0-9]/.test(password),
    match: password.length > 0 && password === confirm,
  };
}

export function PasswordStrength({ check }: { check: PasswordCheck }) {
  const { t, lang } = useI18n();
  const rules = getRules(check);
  const isAr = lang === "ar";

  return (
    <ul className="space-y-1.5" dir={isAr ? "rtl" : "ltr"}>
      {rules.map((rule) => (
        <li
          key={rule.key}
          className={cn(
            "flex items-center gap-2 text-xs transition-colors",
            rule.met ? "text-gold-dark" : "text-muted-foreground",
          )}
        >
          <span
            className={cn(
              "inline-flex h-4 w-4 items-center justify-center rounded-full border",
              rule.met
                ? "border-primary bg-primary/10 text-gold-dark"
                : "border-muted-foreground/30 text-muted-foreground",
            )}
          >
            {rule.met ? <Check className="h-2.5 w-2.5" /> : <X className="h-2.5 w-2.5" />}
          </span>
          <span>{t(tx(rule.labelEn, rule.labelAr))}</span>
        </li>
      ))}
    </ul>
  );
}
