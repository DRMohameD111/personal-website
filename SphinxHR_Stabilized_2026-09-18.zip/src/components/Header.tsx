import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Menu, X, Globe } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { useI18n, tx } from "@/i18n";
import { logos, brand } from "@/brand";
import { AccountMenu } from "@/components/AccountMenu";

const navItems = [
  { to: "/", label: tx("Home", "الرئيسية") },
  { to: "/about", label: tx("About Us", "من نحن") },
  { to: "/jobs", label: tx("Jobs", "الوظائف") },
  { to: "/employers", label: tx("For Employers", "لأصحاب العمل") },
  { to: "/pricing", label: tx("Packages", "الباقات") },
  { to: "/contact", label: tx("Contact Us", "تواصل معنا") },
] as const;

export function Header() {
  const { t, lang, setLang } = useI18n();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-500 print:hidden",
        scrolled
          ? "bg-background/85 backdrop-blur-xl border-b border-border/60 shadow-elegant"
          : "bg-transparent",
      )}
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3.5 sm:px-6 lg:px-8">
        {/* Logo */}
        <Link to="/" className="group flex items-center gap-3" onClick={() => setOpen(false)}>
          <span className="relative inline-flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-gold ring-1 ring-primary/40 shadow-gold">
            <img src={logos.mark} alt={brand.name} className="h-7 w-7 object-contain" />
          </span>
          <span className="hidden sm:flex flex-col leading-tight">
            <span className="font-display text-base font-semibold tracking-[0.18em] text-foreground">
              SPHINX
            </span>
            <span className="text-[10px] font-medium uppercase tracking-[0.3em] text-gold-dark">
              {t(tx("Workforce", "للقوى العاملة"))}
            </span>
          </span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-5 lg:gap-7">
          {navItems.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              activeOptions={{ exact: item.to === "/" }}
              activeProps={{ className: "text-gold-dark" }}
              inactiveProps={{ className: "text-foreground/80 hover:text-gold-dark" }}
              className="story-link text-sm font-medium transition-colors"
            >
              {t(item.label)}
            </Link>
          ))}
        </nav>

        {/* CTAs + Lang */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setLang(lang === "en" ? "ar" : "en")}
            className="inline-flex items-center gap-1.5 rounded-md border border-border px-2.5 py-1.5 text-xs font-semibold uppercase tracking-wider text-foreground/90 hover:border-primary hover:text-gold-dark transition-colors"
            aria-label="Toggle language"
          >
            <Globe className="h-3.5 w-3.5" />
            {lang === "en" ? "ع" : "EN"}
          </button>

          <Link to="/employers" className="hidden lg:inline-flex">
            <Button
              variant="default"
              size="sm"
              className="bg-gradient-gold text-primary-foreground font-semibold hover:shadow-gold"
            >
              {t(tx("Request Workforce", "اطلب عمالة"))}
            </Button>
          </Link>
          <Link to="/job-seekers" className="hidden lg:inline-flex">
            <Button
              variant="outline"
              size="sm"
              className="border-primary/60 text-gold-dark hover:bg-primary/10"
            >
              {t(tx("Find a Job", "ابحث عن وظيفة"))}
            </Button>
          </Link>
          <AccountMenu className="inline-flex outline-none" />

          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            className="md:hidden inline-flex h-9 w-9 items-center justify-center rounded-md border border-border text-foreground hover:border-primary hover:text-gold-dark transition-colors"
            aria-label="Toggle menu"
          >
            {open ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="md:hidden border-t border-border/60 bg-background/95 backdrop-blur-xl animate-fade-in">
          <nav className="mx-auto max-w-7xl flex flex-col gap-1 px-4 py-4 sm:px-6">
            {navItems.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                onClick={() => setOpen(false)}
                activeOptions={{ exact: item.to === "/" }}
                activeProps={{ className: "text-gold-dark bg-primary/5" }}
                inactiveProps={{ className: "text-foreground/85" }}
                className="rounded-md px-3 py-2.5 text-sm font-medium hover:text-gold-dark hover:bg-primary/5 transition-colors"
              >
                {t(item.label)}
              </Link>
            ))}
            <div className="mt-3 flex flex-col gap-2 pt-3 border-t border-border/60">
              <Link to="/employers" onClick={() => setOpen(false)}>
                <Button className="w-full bg-gradient-gold text-primary-foreground font-semibold">
                  {t(tx("Request Workforce", "اطلب عمالة"))}
                </Button>
              </Link>
              <Link to="/job-seekers" onClick={() => setOpen(false)}>
                <Button variant="outline" className="w-full border-primary/60 text-gold-dark">
                  {t(tx("Find a Job", "ابحث عن وظيفة"))}
                </Button>
              </Link>
              <Link to="/auth" onClick={() => setOpen(false)}>
                <Button variant="ghost" className="w-full text-foreground/90">
                  {t(tx("Sign In", "تسجيل الدخول"))}
                </Button>
              </Link>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
