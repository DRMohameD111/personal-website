import { useState } from "react";
import { KeyRound, Loader2 } from "lucide-react";
import { toast } from "sonner";

import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PasswordStrength, checkPassword } from "@/components/PasswordStrength";
import { useI18n, tx } from "@/i18n";

/**
 * Admin-only password change. Rendered inside the /admin route, which is
 * already gated by the authenticated layout + requireAdminAccount().
 * The change runs through Supabase Auth as the signed-in user and requires
 * the current password, so a hijacked session alone cannot rotate it.
 */
export function AdminPasswordCard() {
  const { t } = useI18n();
  const [current, setCurrent] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [loading, setLoading] = useState(false);

  const check = checkPassword(password, confirm);
  const valid = Object.values(check).every(Boolean) && current.length > 0;

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (loading || !valid) return;
    setLoading(true);
    try {
      const { data: userData } = await supabase.auth.getUser();
      const email = userData.user?.email;
      if (!email)
        throw new Error(
          t(
            tx(
              "Session expired. Please sign in again.",
              "انتهت الجلسة. يرجى تسجيل الدخول مرة أخرى.",
            ),
          ),
        );

      // Re-authenticate to prove ownership before rotating the password.
      const { error: signInError } = await supabase.auth.signInWithPassword({
        email,
        password: current,
      });
      if (signInError) {
        throw new Error(t(tx("Current password is incorrect.", "كلمة المرور الحالية غير صحيحة.")));
      }

      const { error } = await supabase.auth.updateUser({
        password,
        // Lovable Cloud may require this for signed-in changes.
        current_password: current,
      } as Parameters<typeof supabase.auth.updateUser>[0]);
      if (error) throw new Error(error.message);

      setCurrent("");
      setPassword("");
      setConfirm("");
      toast.success(t(tx("Password updated.", "تم تحديث كلمة المرور.")));
    } catch (err) {
      toast.error(err instanceof Error ? err.message : String(err));
    } finally {
      setLoading(false);
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          <KeyRound className="h-5 w-5 text-gold-dark" />
          {t(tx("Change admin password", "تغيير كلمة مرور المدير"))}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={onSubmit} className="space-y-4 max-w-md" aria-busy={loading}>
          <div className="space-y-1.5">
            <Label htmlFor="admin-current-password">
              {t(tx("Current password", "كلمة المرور الحالية"))}
            </Label>
            <Input
              id="admin-current-password"
              type="password"
              autoComplete="current-password"
              required
              value={current}
              onChange={(e) => setCurrent(e.target.value)}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="admin-new-password">
              {t(tx("New password", "كلمة المرور الجديدة"))}
            </Label>
            <Input
              id="admin-new-password"
              type="password"
              autoComplete="new-password"
              required
              minLength={8}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="admin-confirm-password">
              {t(tx("Confirm new password", "تأكيد كلمة المرور الجديدة"))}
            </Label>
            <Input
              id="admin-confirm-password"
              type="password"
              autoComplete="new-password"
              required
              minLength={8}
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
            />
          </div>
          <PasswordStrength check={check} />
          <Button
            type="submit"
            disabled={loading || !valid}
            className="bg-gradient-gold text-primary-foreground font-semibold hover:shadow-gold"
          >
            {loading && <Loader2 className="h-4 w-4 animate-spin" />}
            {t(tx("Update password", "تحديث كلمة المرور"))}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
