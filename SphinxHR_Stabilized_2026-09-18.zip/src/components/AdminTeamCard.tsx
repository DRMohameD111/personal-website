import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { History, KeyRound, Loader2, ShieldPlus, UserCog } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useI18n, tx } from "@/i18n";
import {
  ACTION_LABELS,
  ADMIN_ACTIONS,
  ADMIN_MODULES,
  MODULE_LABELS,
  permKey,
  type AdminAction,
  type AdminModule,
} from "@/lib/admin-access";
import {
  createSubAdmin,
  listAdminActivity,
  listAdmins,
  resetSubAdminPassword,
  setSubAdminDisabled,
  setSubAdminPermissions,
  type AdminRow,
} from "@/lib/admin.functions";

function PermissionGrid({
  selected,
  onToggle,
}: {
  selected: Set<string>;
  onToggle: (module: AdminModule, action: AdminAction) => void;
}) {
  const { t } = useI18n();
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[560px] text-sm">
        <thead>
          <tr className="text-xs uppercase tracking-wide text-muted-foreground">
            <th className="p-2 text-start">{t(tx("Module", "الوحدة"))}</th>
            {ADMIN_ACTIONS.map((a) => (
              <th key={a} className="p-2">
                {t(ACTION_LABELS[a])}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-border/70">
          {ADMIN_MODULES.map((m) => (
            <tr key={m}>
              <td className="p-2 font-medium text-heading">{t(MODULE_LABELS[m])}</td>
              {ADMIN_ACTIONS.map((a) => (
                <td key={a} className="p-2 text-center">
                  <input
                    type="checkbox"
                    className="h-4 w-4 accent-[hsl(var(--primary))]"
                    aria-label={`${t(MODULE_LABELS[m])} — ${t(ACTION_LABELS[a])}`}
                    checked={selected.has(permKey(m, a))}
                    onChange={() => onToggle(m, a)}
                  />
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/**
 * Main-admin only: create/disable sub-admins, reset their credentials, assign or
 * revoke permissions and review the activity log. All writes go through
 * server-verified main-admin checks in `@/lib/admin.functions`.
 */
export function AdminTeamCard() {
  const { t, lang } = useI18n();
  const queryClient = useQueryClient();

  const fetchAdmins = useServerFn(listAdmins);
  const fetchActivity = useServerFn(listAdminActivity);
  const create = useServerFn(createSubAdmin);
  const savePerms = useServerFn(setSubAdminPermissions);
  const setDisabled = useServerFn(setSubAdminDisabled);
  const resetPassword = useServerFn(resetSubAdminPassword);

  const admins = useQuery({ queryKey: ["admin-team"], queryFn: () => fetchAdmins({}) });
  const activity = useQuery({ queryKey: ["admin-activity"], queryFn: () => fetchActivity({}) });

  const [newEmail, setNewEmail] = useState("");
  const [newName, setNewName] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [newPerms, setNewPerms] = useState<Set<string>>(new Set());
  const [editing, setEditing] = useState<string | null>(null);
  const [editPerms, setEditPerms] = useState<Set<string>>(new Set());
  const [resetValue, setResetValue] = useState<Record<string, string>>({});

  const toSet = (keys: string[]) => new Set(keys);
  const asList = (set: Set<string>) =>
    [...set].map((k) => {
      const [module, action] = k.split(":") as [AdminModule, AdminAction];
      return { module, action };
    });

  const refresh = async () => {
    await queryClient.invalidateQueries({ queryKey: ["admin-team"] });
    await queryClient.invalidateQueries({ queryKey: ["admin-activity"] });
  };

  const addAdmin = useMutation({
    mutationFn: () =>
      create({
        data: {
          email: newEmail,
          password: newPassword,
          displayName: newName || undefined,
          permissions: asList(newPerms),
        },
      }),
    onSuccess: async () => {
      setNewEmail("");
      setNewName("");
      setNewPassword("");
      setNewPerms(new Set());
      await refresh();
      toast.success(t(tx("Sub-admin created.", "تم إنشاء مشرف فرعي.")));
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const updatePerms = useMutation({
    mutationFn: (userId: string) => savePerms({ data: { userId, permissions: asList(editPerms) } }),
    onSuccess: async () => {
      setEditing(null);
      await refresh();
      toast.success(t(tx("Permissions updated.", "تم تحديث الصلاحيات.")));
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const toggleDisabled = useMutation({
    mutationFn: (v: { userId: string; disabled: boolean }) => setDisabled({ data: v }),
    onSuccess: async () => {
      await refresh();
      toast.success(t(tx("Account updated.", "تم تحديث الحساب.")));
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const doReset = useMutation({
    mutationFn: (v: { userId: string; password: string }) => resetPassword({ data: v }),
    onSuccess: async (_d, v) => {
      setResetValue((r) => ({ ...r, [v.userId]: "" }));
      await refresh();
      toast.success(t(tx("Password reset.", "تمت إعادة تعيين كلمة المرور.")));
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const fmt = (d: string) => new Date(d).toLocaleString(lang === "ar" ? "ar-EG" : "en-GB");

  const rows: AdminRow[] = useMemo(() => admins.data ?? [], [admins.data]);

  if (admins.isError) return null; // not a main admin — card stays hidden

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 font-display text-lg">
            <UserCog className="h-5 w-5 text-gold-dark" />
            {t(tx("Administrators & Permissions", "المشرفون والصلاحيات"))}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Existing administrators */}
          {admins.isLoading ? (
            <Loader2 className="h-5 w-5 animate-spin text-gold-dark" />
          ) : (
            <ul className="space-y-3">
              {rows.map((a) => (
                <li key={a.userId} className="rounded-xl border border-border p-4">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div className="min-w-0">
                      <p className="font-semibold text-heading">{a.displayName || a.email}</p>
                      <p className="text-xs text-muted-foreground">
                        {a.email} ·{" "}
                        {a.isMain
                          ? t(tx("Main admin", "المشرف الرئيسي"))
                          : t(tx("Sub-admin", "مشرف فرعي"))}{" "}
                        · {fmt(a.createdAt)}
                      </p>
                      {!a.isMain && (
                        <p className="mt-1 text-xs text-muted-foreground">
                          {a.permissions.length} {t(tx("permissions granted", "صلاحية ممنوحة"))}
                        </p>
                      )}
                    </div>
                    {!a.isMain && (
                      <div className="flex flex-wrap items-center gap-3">
                        <Label htmlFor={`enabled-${a.userId}`} className="text-xs font-normal">
                          {t(tx("Active", "نشِط"))}
                        </Label>
                        <Switch
                          id={`enabled-${a.userId}`}
                          checked={!a.isDisabled}
                          disabled={toggleDisabled.isPending}
                          onCheckedChange={(v) =>
                            toggleDisabled.mutate({ userId: a.userId, disabled: !v })
                          }
                        />
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            setEditing(editing === a.userId ? null : a.userId);
                            setEditPerms(toSet(a.permissions));
                          }}
                        >
                          {t(tx("Permissions", "الصلاحيات"))}
                        </Button>
                      </div>
                    )}
                  </div>

                  {!a.isMain && (
                    <div className="mt-3 flex flex-wrap items-center gap-2">
                      <Input
                        className="max-w-xs"
                        type="password"
                        autoComplete="new-password"
                        placeholder={t(
                          tx("New password (min 8)", "كلمة مرور جديدة (٨ أحرف على الأقل)"),
                        )}
                        value={resetValue[a.userId] ?? ""}
                        onChange={(e) =>
                          setResetValue((r) => ({ ...r, [a.userId]: e.target.value }))
                        }
                      />
                      <Button
                        size="sm"
                        variant="outline"
                        disabled={doReset.isPending || (resetValue[a.userId] ?? "").length < 8}
                        onClick={() =>
                          doReset.mutate({ userId: a.userId, password: resetValue[a.userId] ?? "" })
                        }
                      >
                        <KeyRound className="h-4 w-4 text-gold-dark" />
                        {t(tx("Reset password", "إعادة تعيين كلمة المرور"))}
                      </Button>
                    </div>
                  )}

                  {editing === a.userId && (
                    <div className="mt-4 space-y-3 rounded-lg border border-primary/40 bg-primary/5 p-3">
                      <PermissionGrid
                        selected={editPerms}
                        onToggle={(m, act) =>
                          setEditPerms((s) => {
                            const next = new Set(s);
                            const k = permKey(m, act);
                            if (next.has(k)) next.delete(k);
                            else next.add(k);
                            return next;
                          })
                        }
                      />
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          disabled={updatePerms.isPending}
                          className="bg-gradient-gold font-semibold text-primary-foreground"
                          onClick={() => updatePerms.mutate(a.userId)}
                        >
                          {updatePerms.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
                          {t(tx("Save permissions", "حفظ الصلاحيات"))}
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => setEditing(null)}>
                          {t(tx("Cancel", "إلغاء"))}
                        </Button>
                      </div>
                    </div>
                  )}
                </li>
              ))}
            </ul>
          )}

          {/* New sub-admin */}
          <div className="space-y-3 rounded-xl border border-border p-4">
            <p className="flex items-center gap-2 font-semibold text-heading">
              <ShieldPlus className="h-4 w-4 text-gold-dark" />
              {t(tx("Create a sub-admin", "إنشاء مشرف فرعي"))}
            </p>
            <div className="grid gap-3 sm:grid-cols-3">
              <div className="space-y-1.5">
                <Label htmlFor="sa-email">{t(tx("Email", "البريد الإلكتروني"))}</Label>
                <Input
                  id="sa-email"
                  type="email"
                  value={newEmail}
                  onChange={(e) => setNewEmail(e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="sa-name">{t(tx("Name", "الاسم"))}</Label>
                <Input id="sa-name" value={newName} onChange={(e) => setNewName(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="sa-pass">{t(tx("Password", "كلمة المرور"))}</Label>
                <Input
                  id="sa-pass"
                  type="password"
                  autoComplete="new-password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                />
              </div>
            </div>
            <PermissionGrid
              selected={newPerms}
              onToggle={(m, act) =>
                setNewPerms((s) => {
                  const next = new Set(s);
                  const k = permKey(m, act);
                  if (next.has(k)) next.delete(k);
                  else next.add(k);
                  return next;
                })
              }
            />
            <Button
              disabled={addAdmin.isPending || !newEmail || newPassword.length < 8}
              className="bg-gradient-gold font-semibold text-primary-foreground"
              onClick={() => addAdmin.mutate()}
            >
              {addAdmin.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
              {t(tx("Create sub-admin", "إنشاء المشرف الفرعي"))}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Activity log */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 font-display text-lg">
            <History className="h-5 w-5 text-gold-dark" />
            {t(tx("Activity Log", "سجل النشاط"))}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {activity.isLoading ? (
            <Loader2 className="h-5 w-5 animate-spin text-gold-dark" />
          ) : (activity.data ?? []).length === 0 ? (
            <p className="text-sm text-muted-foreground">
              {t(tx("No administrative activity recorded yet.", "لا يوجد نشاط إداري مسجل بعد."))}
            </p>
          ) : (
            <ul className="divide-y divide-border/70 text-sm">
              {(activity.data ?? []).map((r) => (
                <li key={r.id} className="py-2">
                  <span className="font-medium text-heading">{r.action}</span>{" "}
                  <span className="text-muted-foreground">
                    · {r.actorEmail ?? "—"} · {fmt(r.createdAt)}
                    {r.targetType ? ` · ${r.targetType}` : ""}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </>
  );
}
