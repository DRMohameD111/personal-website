import {
  MapPin,
  Briefcase,
  Banknote,
  ArrowRight,
  Sparkles,
  CalendarPlus,
  Clock,
  Users,
  CalendarX,
  Megaphone,
  Eye,
  Send,
  Building2,
  BadgeCheck,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useI18n, tx } from "@/i18n";
import { imagery } from "@/brand";
import { skillLabel, formatJobDate, jobCode, JOB_ADDED_DATE, type Job } from "@/lib/jobs";
import { JobValuationBadge } from "@/components/JobValuationBadge";
import {
  ADVERTISER_LABEL,
  AD_DATE,
  APPLICANTS_LABEL,
  DIRECT_AD_LABEL,
  JOB_CLOSING_DATE,
  JOB_STATE_TONE,
  OPPORTUNITY_RATING,
  SEND_NOW_CTA,
  TIME_REMAINING,
  TRUSTED_AD_LABEL,
  VIEWS_LABEL,
  jobStateLabel,
  type JobInsight,
} from "@/lib/valuation";

export type AppliedInfo = { appliedAt: string; status: string } | undefined;

/**
 * The single Job Card used everywhere vacancies are listed (Explore Jobs and
 * the Job Seeker dashboard). Reuse it — do not create another job card.
 * Direct Vacancy Ads reuse the same card in a premium Pharaonic/Sphinx skin.
 */
export function JobCard({
  job,
  matchedSkills = [],
  applied,
  active = false,
  onSelect,
  actionLabel,
  insight,
  showApplicantCount = false,
}: {
  job: Job;
  matchedSkills?: string[];
  applied?: AppliedInfo;
  active?: boolean;
  onSelect?: (id: string) => void;
  actionLabel?: { en: string; ar: string };
  insight?: JobInsight;
  showApplicantCount?: boolean;
}) {
  const { t, lang } = useI18n();
  const isDirect = insight?.directAd ?? job.directAd ?? false;

  return (
    <article
      onClick={() => onSelect?.(job.id)}
      className={`group relative overflow-hidden rounded-2xl p-6 hover-lift transition ${
        isDirect
          ? "direct-ad-job-card border border-primary/50 shadow-elegant"
          : "bg-gradient-card ring-inset-gold"
      } ${onSelect ? "cursor-pointer" : ""} ${active ? "ring-2 ring-primary" : ""}`}
    >
      {isDirect && (
        <>
          <div
            aria-hidden
            className="pointer-events-none absolute inset-0 sphinx-backdrop"
            style={{ backgroundImage: `url(${imagery.sphinxBackdrop})` }}
          />
          <div aria-hidden className="pharaonic-strip absolute inset-x-0 bottom-0 h-2" />
        </>
      )}

      <div className={isDirect ? "relative" : undefined}>
        {isDirect && (
          <div className="mb-3 flex flex-wrap items-center gap-2">
            <div className="inline-flex items-center gap-1.5 rounded-full border border-primary/60 bg-primary/10 px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-gold-dark">
              <Megaphone className="h-3 w-3" />
              {t(DIRECT_AD_LABEL)}
            </div>
            <div className="inline-flex items-center gap-1.5 rounded-full bg-gradient-gold px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-primary-foreground">
              <BadgeCheck className="h-3 w-3" />
              {t(TRUSTED_AD_LABEL)}
            </div>
          </div>
        )}

        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <h3
              className={`font-display text-lg font-semibold transition-colors ${
                isDirect
                  ? "text-heading group-hover:text-gold-dark"
                  : "text-foreground group-hover:text-gold-dark"
              }`}
            >
              {t(job.title)}
            </h3>
            <div
              className={`mt-1 text-[11px] font-mono ${isDirect ? "text-muted-foreground" : "text-muted-foreground"}`}
            >
              {jobCode(job)}
            </div>
            <div
              className={`mt-2 flex flex-wrap items-center gap-3 text-xs ${
                isDirect ? "text-foreground/90" : "text-muted-foreground"
              }`}
            >
              {isDirect && job.company && (
                <span className="inline-flex items-center gap-1.5">
                  <Building2 className="h-3.5 w-3.5 text-gold-dark" />
                  {t(ADVERTISER_LABEL)}: {job.company}
                </span>
              )}
              <span className="inline-flex items-center gap-1.5">
                <MapPin className="h-3.5 w-3.5 text-gold-dark" />
                {t(job.city)}, {t(job.country)}
              </span>
              <span className="inline-flex items-center gap-1.5">
                <Briefcase className="h-3.5 w-3.5 text-gold-dark" />
                {t(job.profession)} · {t(job.level)} · {t(job.type)}
              </span>
            </div>
            <div
              className={`mt-2 flex flex-wrap items-center gap-3 text-xs ${
                isDirect ? "text-foreground/90" : "text-muted-foreground"
              }`}
            >
              <span className="inline-flex items-center gap-1.5">
                <CalendarPlus
                  className={`h-3.5 w-3.5 ${isDirect ? "text-gold-dark" : "text-gold-dark"}`}
                />
                {t(isDirect ? AD_DATE : JOB_ADDED_DATE)}:{" "}
                {formatJobDate(
                  isDirect ? (insight?.publishedAt ?? job.addedAt) : job.addedAt,
                  lang,
                )}
              </span>
              {isDirect && insight?.timeRemaining && (
                <span className="inline-flex items-center gap-1.5">
                  <Clock className="h-3.5 w-3.5 text-gold-dark" />
                  {t(TIME_REMAINING)}: {t(insight.timeRemaining)}
                </span>
              )}
              {!isDirect && insight?.closesAt && (
                <span className="inline-flex items-center gap-1.5">
                  <CalendarX className="h-3.5 w-3.5 text-gold-dark" />
                  {t(JOB_CLOSING_DATE)}: {formatJobDate(insight.closesAt, lang)}
                </span>
              )}
              {!isDirect && !insight?.closesAt && job.deadline && (
                <span className="inline-flex items-center gap-1.5">
                  <Clock className="h-3.5 w-3.5 text-gold-dark" />
                  {t(tx("Application Deadline", "آخر موعد للتقديم"))}:{" "}
                  {formatJobDate(job.deadline, lang)}
                </span>
              )}
              {isDirect && insight?.views != null && (
                <span className="inline-flex items-center gap-1.5">
                  <Eye className="h-3.5 w-3.5 text-gold-dark" />
                  {t(VIEWS_LABEL)}: {insight.views}
                </span>
              )}
              {showApplicantCount &&
                insight?.applicantCount !== null &&
                insight?.applicantCount !== undefined && (
                  <span className="inline-flex items-center gap-1.5">
                    <Users
                      className={`h-3.5 w-3.5 ${isDirect ? "text-gold-dark" : "text-gold-dark"}`}
                    />
                    {t(APPLICANTS_LABEL)}: {insight.applicantCount}
                  </span>
                )}
              {!isDirect && job.company && <span>{job.company}</span>}
            </div>
            {insight && (
              <div className="mt-3 flex flex-wrap items-center gap-2">
                <span
                  className={`inline-flex items-center rounded-full border px-2.5 py-1 text-[10px] font-semibold ${JOB_STATE_TONE[insight.state]}`}
                >
                  {t(jobStateLabel(insight.state))}
                </span>
                {isDirect && (
                  <span className="text-[10px] font-semibold text-muted-foreground">
                    {t(OPPORTUNITY_RATING)}:
                  </span>
                )}
                <JobValuationBadge grade={insight.valuation.grade} withInfo />
              </div>
            )}
          </div>
          <span
            className={`inline-flex shrink-0 items-center gap-1 rounded-full px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wider whitespace-nowrap ${
              isDirect
                ? "border border-primary/60 bg-primary/15 text-gold-dark"
                : "border border-primary/40 bg-primary/10 text-gold-dark"
            }`}
          >
            {t(job.type)}
          </span>
        </div>

        {applied && (
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-1 rounded-full border border-primary/50 bg-primary/10 px-2.5 py-1 text-[10px] font-semibold text-gold-dark">
              {t(tx("✓ Already Applied", "✓ سبق التقدم"))}
            </span>
            <span
              className={`text-[10px] ${isDirect ? "text-muted-foreground" : "text-muted-foreground"}`}
            >
              {t(tx("Applied on:", "تاريخ التقديم:"))} {formatJobDate(applied.appliedAt, lang)}
            </span>
          </div>
        )}

        {matchedSkills.length > 0 && (
          <div className="mt-3 flex flex-wrap gap-1.5">
            {matchedSkills.map((s) => (
              <span
                key={s}
                className="inline-flex items-center gap-1 rounded-full bg-gradient-gold text-primary-foreground px-2 py-0.5 text-[10px] font-semibold"
              >
                <Sparkles className="h-2.5 w-2.5" />
                {t(skillLabel(s))}
              </span>
            ))}
          </div>
        )}

        <div className="mt-5 flex items-center justify-between gap-3">
          <div
            className={`inline-flex items-center gap-1.5 text-sm font-semibold ${
              isDirect ? "text-heading" : "text-foreground"
            }`}
          >
            <Banknote className={`h-4 w-4 ${isDirect ? "text-gold-dark" : "text-gold-dark"}`} />
            {t(job.salary) || t(tx("Salary on request", "الراتب حسب الاتفاق"))}
          </div>
          <Button
            size="sm"
            className={`font-semibold ${
              isDirect
                ? "bg-heading text-background hover:bg-heading/90 hover:shadow-elegant"
                : "bg-gradient-gold text-primary-foreground"
            }`}
            onClick={(e) => {
              e.stopPropagation();
              onSelect?.(job.id);
            }}
          >
            {isDirect ? <Send className="h-3.5 w-3.5" /> : null}
            {t(actionLabel ?? (isDirect ? SEND_NOW_CTA : tx("View details", "عرض التفاصيل")))}
            {!isDirect && <ArrowRight className="h-3.5 w-3.5" />}
          </Button>
        </div>
      </div>
    </article>
  );
}
