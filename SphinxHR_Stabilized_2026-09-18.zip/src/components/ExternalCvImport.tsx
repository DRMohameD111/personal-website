import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { FileUp, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useI18n, tx } from "@/i18n";
import { supabase } from "@/integrations/supabase/client";
import { importExternalCv, listExternalCandidates } from "@/lib/cv-import.functions";

/**
 * Admin panel section: bulk/single import of external CVs. Files go to the
 * existing private `cvs` bucket; extraction, de-duplication and storage reuse
 * the existing candidate structure.
 */
export function ExternalCvImport() {
  const { t, lang } = useI18n();
  const isAr = lang === "ar";
  const queryClient = useQueryClient();
  const runImport = useServerFn(importExternalCv);
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState<{ done: number; total: number } | null>(null);

  const rows = useQuery({
    queryKey: ["external-candidates"],
    queryFn: () => listExternalCandidates({}),
  });

  async function onFiles(files: FileList | null) {
    if (!files || files.length === 0) return;
    setBusy(true);
    const list = Array.from(files).slice(0, 25);
    setProgress({ done: 0, total: list.length });
    let created = 0;
    let updated = 0;
    let linked = 0;
    let failed = 0;

    for (const [i, file] of list.entries()) {
      try {
        const { data: auth } = await supabase.auth.getUser();
        const uid = auth.user?.id;
        if (!uid) throw new Error("Not signed in");
        const ext = file.name.split(".").pop()?.toLowerCase() ?? "pdf";
        const path = `${uid}/imported/${Date.now()}-${i}.${ext}`;
        const up = await supabase.storage.from("cvs").upload(path, file, { upsert: false });
        if (up.error) throw new Error(up.error.message);
        const res = await runImport({
          data: {
            storagePath: path,
            fileName: file.name,
            mimeType: file.type || "application/pdf",
          },
        });
        if (res.outcome === "created") created += 1;
        else if (res.outcome === "updated") updated += 1;
        else linked += 1;
      } catch (err) {
        failed += 1;
        toast.error(`${file.name}: ${String((err as Error).message || err)}`);
      }
      setProgress({ done: i + 1, total: list.length });
    }

    setBusy(false);
    setProgress(null);
    await queryClient.invalidateQueries({ queryKey: ["external-candidates"] });
    toast.success(
      isAr
        ? `تم الاستيراد: ${created} جديد، ${updated} محدّث، ${linked} مرتبط بملف مسجل، ${failed} فشل.`
        : `Imported: ${created} new, ${updated} updated, ${linked} linked to registered profiles, ${failed} failed.`,
    );
  }

  return (
    <Card className="border-border/60 shadow-elegant">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 font-display text-xl text-heading">
          <FileUp className="h-5 w-5 text-gold-dark" />
          {t(tx("Import External CVs", "استيراد سير ذاتية خارجية"))}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-muted-foreground">
          {t(
            tx(
              "Upload one or more CV files (PDF, DOC, DOCX, TXT). Recruitment data is read automatically and matched against existing candidates — no duplicate profiles are created.",
              "ارفع ملفًا واحدًا أو أكثر (PDF، DOC، DOCX، TXT). تُقرأ بيانات التوظيف تلقائيًا وتُطابق مع المرشحين الحاليين دون إنشاء ملفات مكررة.",
            ),
          )}
        </p>
        <Input
          type="file"
          multiple
          accept=".pdf,.doc,.docx,.txt,.rtf"
          disabled={busy}
          onChange={(e) => void onFiles(e.target.files)}
        />
        {busy && (
          <div className="flex items-center gap-2 text-sm text-gold-dark">
            <Loader2 className="h-4 w-4 animate-spin" />
            {progress ? `${progress.done} / ${progress.total}` : null}
          </div>
        )}

        <div className="overflow-x-auto">
          {rows.isLoading ? (
            <Loader2 className="h-5 w-5 animate-spin text-gold-dark" />
          ) : (rows.data?.length ?? 0) === 0 ? (
            <p className="text-sm text-muted-foreground">
              {t(tx("No external CVs imported yet.", "لا توجد سير ذاتية خارجية مستوردة بعد."))}
            </p>
          ) : (
            <table className="w-full text-sm">
              <thead className="text-xs uppercase tracking-wider text-muted-foreground">
                <tr>
                  <th className="px-3 py-2 text-start">{t(tx("Name", "الاسم"))}</th>
                  <th className="px-3 py-2 text-start">{t(tx("Job Title", "المسمى الوظيفي"))}</th>
                  <th className="px-3 py-2 text-start">
                    {t(tx("Career Level", "المستوى المهني"))}
                  </th>
                  <th className="px-3 py-2 text-start">{t(tx("Experience", "الخبرة"))}</th>
                  <th className="px-3 py-2 text-start">{t(tx("Location", "الموقع"))}</th>
                  <th className="px-3 py-2 text-start">{t(tx("Status", "الحالة"))}</th>
                </tr>
              </thead>
              <tbody>
                {rows.data!.map((r) => (
                  <tr key={r.id} className="border-t border-border/60">
                    <td className="px-3 py-2 font-medium text-foreground">{r.name || "—"}</td>
                    <td className="px-3 py-2 text-muted-foreground">{r.jobTitle || "—"}</td>
                    <td className="px-3 py-2 text-muted-foreground">{r.careerLevel || "—"}</td>
                    <td className="px-3 py-2 text-muted-foreground">
                      {r.experienceYears != null ? r.experienceYears : "—"}
                    </td>
                    <td className="px-3 py-2 text-muted-foreground">{r.location || "—"}</td>
                    <td className="px-3 py-2 text-muted-foreground">
                      {r.status === "merged"
                        ? t(tx("Merged with registered profile", "مدمج مع ملف مسجل"))
                        : t(tx("External CV", "سيرة خارجية"))}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
        <Button variant="ghost" onClick={() => void rows.refetch()} disabled={rows.isFetching}>
          {t(tx("Refresh list", "تحديث القائمة"))}
        </Button>
      </CardContent>
    </Card>
  );
}
