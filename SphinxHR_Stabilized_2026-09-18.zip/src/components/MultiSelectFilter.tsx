import { useMemo, useState } from "react";
import { ChevronsUpDown, Search, X } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { useI18n, tx } from "@/i18n";
import type { BiLabel } from "@/lib/sectors";

export type MultiOption = { value: string; label: BiLabel };

/**
 * Shared multi-select checkbox filter (OR logic inside one category).
 * Reused by every categorical filter on the Jobs page — no per-filter clones.
 */
export function MultiSelectFilter({
  label,
  options,
  values,
  onChange,
  searchable = true,
}: {
  label: BiLabel;
  options: MultiOption[];
  values: string[];
  onChange: (next: string[]) => void;
  searchable?: boolean;
}) {
  const { t, lang, dir } = useI18n();
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");

  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    if (!needle) return options;
    return options.filter(
      (o) => o.label.en.toLowerCase().includes(needle) || o.label.ar.includes(needle),
    );
  }, [options, q]);

  const toggle = (value: string) =>
    onChange(values.includes(value) ? values.filter((v) => v !== value) : [...values, value]);

  const count = values.length;

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button
          type="button"
          aria-label={t(label)}
          aria-expanded={open}
          className={cn(
            "flex h-11 w-full items-center justify-between gap-2 rounded-md border border-input bg-background px-3 text-sm",
            "focus:outline-none focus:ring-2 focus:ring-ring",
            count > 0 ? "border-primary/60 text-foreground" : "text-muted-foreground",
          )}
        >
          <span className="truncate">
            {t(label)}
            {count > 0 && <span className="font-semibold text-gold-dark"> ({count})</span>}
          </span>
          <ChevronsUpDown className="h-4 w-4 shrink-0 opacity-60" />
        </button>
      </PopoverTrigger>
      <PopoverContent
        className="w-[--radix-popover-trigger-width] min-w-56 p-0"
        align="start"
        dir={dir}
      >
        <div className="flex items-center justify-between gap-2 border-b border-border px-3 py-2">
          <span className="text-xs font-semibold uppercase tracking-wider text-gold-dark">
            {t(label)}
          </span>
          {count > 0 && (
            <button
              type="button"
              onClick={() => onChange([])}
              className="text-xs font-semibold text-muted-foreground hover:text-gold-dark"
            >
              {t(tx("Clear", "مسح"))}
            </button>
          )}
        </div>

        {searchable && options.length > 8 && (
          <div className="flex items-center gap-2 border-b border-border px-3 py-2">
            <Search className="h-4 w-4 opacity-60" />
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder={t(tx("Search…", "بحث…"))}
              className="h-8 border-0 px-0 shadow-none focus-visible:ring-0"
            />
          </div>
        )}

        <ul className="max-h-64 overflow-y-auto py-1">
          {filtered.length === 0 ? (
            <li className="px-3 py-2 text-sm text-muted-foreground">
              {t(tx("No results", "لا نتائج"))}
            </li>
          ) : (
            filtered.map((o) => {
              const checked = values.includes(o.value);
              return (
                <li key={o.value}>
                  <label className="flex cursor-pointer items-center gap-3 px-3 py-2.5 text-sm hover:bg-primary/10">
                    <Checkbox checked={checked} onCheckedChange={() => toggle(o.value)} />
                    <span className="truncate">{o.label[lang]}</span>
                  </label>
                </li>
              );
            })
          )}
        </ul>
      </PopoverContent>
    </Popover>
  );
}

/** Removable chip used for active filter selections (checkbox or range). */
export function FilterChip({ text, onRemove }: { text: string; onRemove: () => void }) {
  const { t } = useI18n();
  return (
    <button
      type="button"
      onClick={onRemove}
      title={t(tx("Remove filter", "إزالة التصفية"))}
      className="inline-flex items-center gap-1 rounded-full border border-primary/50 bg-primary/10 px-2.5 py-1 text-[11px] font-semibold text-foreground hover:bg-primary/20"
    >
      {text}
      <X className="h-3 w-3" />
    </button>
  );
}
