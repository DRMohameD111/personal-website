import { useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { FileText, Loader2, Trash2, Upload, ExternalLink, Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { useI18n, tx } from "@/i18n";
import { supabase } from "@/integrations/supabase/client";
import {
  DOC_TYPES,
  deleteMyDocument,
  getDocumentUrl,
  listMyDocuments,
  saveMyDocument,
  type DocType,
} from "@/lib/documents.functions";
import { openSignedFile } from "@/lib/open-file";

/** Bilingual labels for the optional document types. */
export const DOC_TYPE_LABELS: Record<DocType, ReturnType<typeof tx>> = {
  education: tx("Educational certificate", "شهادة دراسية"),
  experience: tx("Experience certificate", "شهادة خبرة"),
  professional: tx("Professional certificate", "شهادة مهنية"),
  training: tx("Training certificate", "شهادة تدريب"),
  license: tx("License", "ترخيص / رخصة"),
  recommendation: tx("Recommendation letter", "خطاب توصية"),
  portfolio: tx("Portfolio", "أعمال سابقة"),
  other: tx("Other supporting document", "مستند داعم آخر"),
};

/**
 * Optional attachments inside the existing job-seeker profile.
 * The mandatory CV stays where it already lives (profiles.cv_url).
 */
export function ProfileDocuments() {
  const { t, lang } = useI18n();
  const isAr = lang === "ar";
  const qc = useQueryClient();
  const fetchDocs = useServerFn(listMyDocuments);
  const saveDoc = useServerFn(saveMyDocument);
  const removeDoc = useServerFn(deleteMyDocument);
  const docUrl = useServerFn(getDocumentUrl);

  const [docType, setDocType] = useState<DocType>("education");
  const [title, setTitle] = useState("");
  const [busy, setBusy] = useState(false);
  const fileRef = useRef<HTMLInputElement | null>(null);

  const docs = useQuery({ queryKey: ["my-documents"], queryFn: () => fetchDocs({}) });

  const del = useMutation({
    mutationFn: (id: string) => removeDoc({ data: { id } }),
    onSuccess: () => {
      toast.success(t(tx("Document deleted.", "تم حذف المستند.")));
      void qc.invalidateQueries({ queryKey: ["my-documents"] });
    },
    onError: () =>
      toast.error(
        t(
          tx(
            "Could not delete the document. Please try again.",
            "تعذر حذف المستند. يرجى المحاولة مرة أخرى.",
          ),
        ),
      ),
  });

  const upload = async () => {
    const file = fileRef.current?.files?.[0];
    if (!file) {
      toast.error(t(tx("Please choose a file first.", "يرجى اختيار ملف أولاً.")));
      return;
    }
    setBusy(true);
    try {
      const { data: userData } = await supabase.auth.getUser();
      const user = userData?.user;
      if (!user) throw new Error("no-session");
      const ext = file.name.split(".").pop()?.toLowerCase() || "pdf";
      const path = `${user.id}/doc-${Date.now()}.${ext}`;
      const { error: upErr } = await supabase.storage
        .from("cvs")
        .upload(path, file, { upsert: true, contentType: file.type || undefined });
      if (upErr) throw new Error(upErr.message);
      await saveDoc({
        data: {
          docType,
          title: title.trim() || undefined,
          storagePath: path,
          fileName: file.name,
          sizeBytes: file.size,
        },
      });
      setTitle("");
      if (fileRef.current) fileRef.current.value = "";
      toast.success(t(tx("Document uploaded successfully.", "تم رفع المستند بنجاح.")));
      void qc.invalidateQueries({ queryKey: ["my-documents"] });
    } catch {
      // Optional attachment: never block the rest of the profile.
      toast.error(
        t(
          tx(
            "The document could not be uploaded. You can try again at any time.",
            "تعذر رفع المستند. يمكنك المحاولة مرة أخرى في أي وقت.",
          ),
        ),
      );
    } finally {
      setBusy(false);
    }
  };

  const open = async (id: string) => {
    try {
      const { url, fileName } = await docUrl({ data: { id } });
      openSignedFile(url, fileName);
    } catch {
      toast.error(t(tx("Could not open the document.", "تعذر فتح المستند.")));
    }
  };

  const fmt = (iso: string) =>
    new Date(iso).toLocaleDateString(isAr ? "ar-EG" : "en-GB", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });

  return (
    <Card className="mt-8 border-border/60 shadow-elegant">
      <CardHeader>
        <CardTitle className="font-display text-xl">
          {t(tx("Documents & Attachments", "المستندات والمرفقات"))}
        </CardTitle>
        <p className="text-xs text-muted-foreground">
          {t(
            tx(
              "Additional Attachments – Optional and can be added later",
              "المرفقات الإضافية – اختيارية ويمكن إضافتها لاحقًا",
            ),
          )}
        </p>
      </CardHeader>
      <CardContent>
        <div className="flex items-start gap-2 rounded-xl border border-primary/30 bg-primary/5 p-3 text-xs text-muted-foreground">
          <Info className="mt-0.5 h-3.5 w-3.5 shrink-0 text-gold-dark" />
          {t(
            tx(
              "You can strengthen your profile by adding certificates and supporting documents at any time.",
              "يمكنك تعزيز ملفك بإضافة الشهادات والمستندات الداعمة في أي وقت.",
            ),
          )}
        </div>

        <div className="mt-5 grid gap-4 sm:grid-cols-3">
          <div>
            <Label htmlFor="doc-type" className="text-xs">
              {t(tx("Document type", "نوع المستند"))}
            </Label>
            <select
              id="doc-type"
              value={docType}
              onChange={(e) => setDocType(e.target.value as DocType)}
              className="mt-1 h-11 w-full rounded-md border border-input bg-background px-3 text-sm"
            >
              {DOC_TYPES.map((d) => (
                <option key={d} value={d}>
                  {t(DOC_TYPE_LABELS[d])}
                </option>
              ))}
            </select>
          </div>
          <div>
            <Label htmlFor="doc-title" className="text-xs">
              {t(tx("Title (optional)", "العنوان (اختياري)"))}
            </Label>
            <Input
              id="doc-title"
              value={title}
              maxLength={200}
              onChange={(e) => setTitle(e.target.value)}
              className="mt-1 h-11 bg-background"
            />
          </div>
          <div>
            <Label htmlFor="doc-file" className="text-xs">
              {t(tx("File", "الملف"))}
            </Label>
            <Input
              id="doc-file"
              ref={fileRef}
              type="file"
              accept=".pdf,.doc,.docx,.png,.jpg,.jpeg"
              className="mt-1 h-11 bg-background"
            />
          </div>
        </div>

        <Button
          onClick={upload}
          disabled={busy}
          aria-busy={busy}
          className="mt-4 bg-gradient-gold font-semibold text-primary-foreground hover:shadow-gold"
        >
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
          {busy ? t(tx("Uploading…", "جارٍ الرفع...")) : t(tx("Add document", "إضافة مستند"))}
        </Button>

        <div className="mt-6 border-t border-border/60 pt-4">
          {docs.isLoading ? (
            <Loader2 className="h-5 w-5 animate-spin text-gold-dark" />
          ) : (docs.data?.length ?? 0) === 0 ? (
            <p className="text-sm text-muted-foreground">
              {t(tx("No documents added yet.", "لم تُضف أي مستندات بعد."))}
            </p>
          ) : (
            <ul className="space-y-2">
              {docs.data!.map((d) => (
                <li
                  key={d.id}
                  className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-border/60 p-3"
                >
                  <div className="flex items-center gap-3">
                    <FileText className="h-4 w-4 text-gold-dark" />
                    <div>
                      <p className="text-sm font-medium text-foreground">
                        {d.title || t(DOC_TYPE_LABELS[d.docType])}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {t(DOC_TYPE_LABELS[d.docType])} · {fmt(d.createdAt)}
                        {d.fileName ? ` · ${d.fileName}` : ""}
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-primary/60 text-gold-dark"
                      onClick={() => void open(d.id)}
                    >
                      <ExternalLink className="h-3.5 w-3.5" />
                      {t(tx("View", "عرض"))}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-destructive/50 text-destructive"
                      disabled={del.isPending}
                      onClick={() => del.mutate(d.id)}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                      {t(tx("Delete", "حذف"))}
                    </Button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
