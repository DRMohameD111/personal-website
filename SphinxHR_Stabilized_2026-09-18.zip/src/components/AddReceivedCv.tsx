import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQueryClient } from "@tanstack/react-query";
import { Loader2, Upload } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useI18n, tx } from "@/i18n";
import { supabase } from "@/integrations/supabase/client";
import { addReceivedCvToMyJob } from "@/lib/direct-ad.functions";

/**
 * Lets a company/direct-ad client attach a CV received outside the platform to
 * one of its own vacancies. Reuses the `cvs` bucket, `profiles` and
 * `job_applications` — candidates are de-duplicated on the server by
 * email / mobile.
 */
export function AddReceivedCv({ jobPostingId }: { jobPostingId: string }) {
  const { t } = useI18n();
  const queryClient = useQueryClient();
  const addCv = useServerFn(addReceivedCvToMyJob);
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({ fullName: "", email: "", phone: "", profession: "" });
  const [file, setFile] = useState<File | null>(null);

  const set = (k: keyof typeof form, v: string) => setForm((f) => ({ ...f, [k]: v }));

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!file) {
      toast.error(t(tx("Please attach the CV file.", "يرجى إرفاق ملف السيرة الذاتية.")));
      return;
    }
    setBusy(true);
    try {
      const { data: auth } = await supabase.auth.getUser();
      const uid = auth.user?.id;
      if (!uid) throw new Error("Not signed in");
      const ext = file.name.split(".").pop()?.toLowerCase() ?? "pdf";
      const path = `${uid}/received/${jobPostingId}-${Date.now()}.${ext}`;
      const { error: upErr } = await supabase.storage
        .from("cvs")
        .upload(path, file, { upsert: false });
      if (upErr) throw new Error(upErr.message);

      const res = await addCv({
        data: {
          jobPostingId,
          fullName: form.fullName.trim(),
          email: form.email.trim(),
          phone: form.phone.trim(),
          profession: form.profession.trim() || undefined,
          cvStoragePath: path,
          cvFileName: file.name,
        },
      });
      if (!res.ok) {
        toast.info(
          t(
            tx(
              "This candidate is already registered on this vacancy.",
              "هذا المرشح مسجّل بالفعل على هذه الوظيفة.",
            ),
          ),
        );
      } else {
        toast.success(
          t(
            res.candidateCreated
              ? tx(
                  "CV added and the candidate was invited to complete their profile.",
                  "تم إضافة السيرة الذاتية ودعوة المرشح لإكمال ملفه.",
                )
              : tx(
                  "CV added to the existing candidate profile.",
                  "تم إضافة السيرة الذاتية إلى ملف المرشح الحالي.",
                ),
          ),
        );
        setForm({ fullName: "", email: "", phone: "", profession: "" });
        setFile(null);
        setOpen(false);
      }
      await queryClient.invalidateQueries({ queryKey: ["job-applicants", jobPostingId] });
      await queryClient.invalidateQueries({ queryKey: ["company-jobs"] });
    } catch (err) {
      toast.error(String((err as Error).message || err));
    } finally {
      setBusy(false);
    }
  }

  if (!open)
    return (
      <Button
        variant="outline"
        className="border-primary/60 text-gold-dark"
        onClick={() => setOpen(true)}
      >
        <Upload className="h-4 w-4" />
        {t(tx("Add received CV", "إضافة سيرة ذاتية مستلمة"))}
      </Button>
    );

  return (
    <form
      onSubmit={submit}
      className="mt-4 w-full space-y-3 rounded-xl border border-primary/30 bg-primary/5 p-4"
    >
      <div className="grid gap-3 sm:grid-cols-2">
        <Input
          required
          placeholder={t(tx("Candidate full name", "اسم المرشح الكامل"))}
          value={form.fullName}
          onChange={(e) => set("fullName", e.target.value)}
        />
        <Input
          required
          type="email"
          placeholder={t(tx("Candidate email", "بريد المرشح"))}
          value={form.email}
          onChange={(e) => set("email", e.target.value)}
        />
        <Input
          required
          placeholder={t(tx("Mobile", "الجوال"))}
          value={form.phone}
          onChange={(e) => set("phone", e.target.value)}
        />
        <Input
          placeholder={t(tx("Profession (optional)", "المهنة (اختياري)"))}
          value={form.profession}
          onChange={(e) => set("profession", e.target.value)}
        />
      </div>
      <Input
        required
        type="file"
        accept=".pdf,.doc,.docx"
        onChange={(e) => setFile(e.target.files?.[0] ?? null)}
      />
      <div className="flex flex-wrap gap-2">
        <Button
          type="submit"
          disabled={busy}
          className="bg-gradient-gold font-semibold text-primary-foreground"
        >
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
          {t(tx("Save CV", "حفظ السيرة الذاتية"))}
        </Button>
        <Button type="button" variant="ghost" onClick={() => setOpen(false)} disabled={busy}>
          {t(tx("Cancel", "إلغاء"))}
        </Button>
      </div>
      <p className="text-xs text-muted-foreground">
        {t(
          tx(
            "Existing candidates are matched by email or mobile — no duplicate profiles are created.",
            "يتم مطابقة المرشحين الحاليين بالبريد أو الجوال دون إنشاء ملفات مكررة.",
          ),
        )}
      </p>
    </form>
  );
}
