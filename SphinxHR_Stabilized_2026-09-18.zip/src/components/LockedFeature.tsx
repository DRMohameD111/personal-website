import { Link } from "@tanstack/react-router";
import { Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useI18n, tx } from "@/i18n";

/**
 * Gold locked chip shown when the company's active package does not include a
 * candidate-profile feature. It leads into the existing package change flow.
 * The backend refuses the feature regardless of what is rendered here.
 */
export function LockedFeature({ label }: { label: string }) {
  const { t } = useI18n();
  return (
    <Link to="/portal" className="inline-flex">
      <Button variant="outline" size="sm" className="border-primary/60 text-gold-dark">
        <Lock className="h-4 w-4" />
        {label} — {t(tx("Upgrade package", "ترقية الباقة"))}
      </Button>
    </Link>
  );
}
