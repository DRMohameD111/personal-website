import { useI18n } from "@/i18n";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  EMPLOYMENT_TYPES,
  EMPLOYMENT_TYPE_LABEL,
  normalizeEmploymentType,
  type EmploymentTypeValue,
} from "@/lib/jobs";

/**
 * Single shared Employment Type (نوع التوظيف) control.
 * Writes the stable `employment_type` value plus the bilingual labels
 * already stored on job data, so no new field is introduced.
 */
export function EmploymentTypeSelect({
  value,
  typeEn,
  typeAr,
  onChange,
}: {
  value?: string | null;
  typeEn?: string | null;
  typeAr?: string | null;
  onChange: (patch: {
    employment_type: EmploymentTypeValue;
    type_en: string;
    type_ar: string;
  }) => void;
}) {
  const { t, dir } = useI18n();
  const current = normalizeEmploymentType(value, typeEn, typeAr);

  return (
    <Select
      value={current}
      onValueChange={(v) => {
        const key = v as EmploymentTypeValue;
        const label = EMPLOYMENT_TYPE_LABEL[key];
        onChange({ employment_type: key, type_en: label.en, type_ar: label.ar });
      }}
    >
      <SelectTrigger dir={dir}>
        <SelectValue />
      </SelectTrigger>
      <SelectContent dir={dir}>
        {EMPLOYMENT_TYPES.map((o) => (
          <SelectItem key={o.value} value={o.value}>
            {t(o.label)}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
