import { User, UserRound } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * Candidate photo with a gender-based fallback.
 * Reuses the saved gender on the existing profile — no extra data source.
 */
export function CandidateAvatar({
  photoUrl,
  gender,
  name,
  className,
}: {
  photoUrl?: string | null;
  gender?: string | null;
  name?: string | null;
  className?: string;
}) {
  const base = cn(
    "relative flex h-24 w-24 shrink-0 items-center justify-center overflow-hidden rounded-2xl border border-primary/40 bg-primary/5 ring-inset-gold",
    className,
  );

  if (photoUrl)
    return (
      <div className={base}>
        <img
          src={photoUrl}
          alt={name ? `${name}` : "Candidate photo"}
          className="h-full w-full object-cover"
        />
      </div>
    );

  const Icon = gender === "female" ? UserRound : User;
  return (
    <div className={base} aria-hidden={false} role="img" aria-label={name ?? "Candidate"}>
      <Icon className="h-10 w-10 text-gold-dark" />
    </div>
  );
}
