import { useCallback, useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Languages, Loader2, CheckCircle2, AlertTriangle, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useI18n, tx } from "@/i18n";
import { translateField } from "@/lib/translate.functions";
import { detectLang } from "@/lib/language-detect";

const DEBOUNCE_MS = 900;

/** Process-level cache so the same text is never translated twice. */
const cache = new Map<string, string>();

type Side = "en" | "ar";

export type BilingualFieldProps = {
  labelEn: string;
  labelAr: string;
  valueEn: string;
  valueAr: string;
  onChange: (patch: { en?: string; ar?: string }) => void;
  multiline?: boolean;
  rows?: number;
  required?: boolean;
  placeholderEn?: string;
  placeholderAr?: string;
  className?: string;
};

export function BilingualField({
  labelEn,
  labelAr,
  valueEn,
  valueAr,
  onChange,
  multiline = false,
  rows = 3,
  required = false,
  placeholderEn,
  placeholderAr,
  className,
}: BilingualFieldProps) {
  const { t } = useI18n();
  const translate = useServerFn(translateField);

  const [status, setStatus] = useState<"idle" | "busy" | "done" | "error">("idle");
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [confirmFrom, setConfirmFrom] = useState<Side | null>(null);

  // Latest values, auto-generated outputs and last translated sources.
  const values = useRef({ en: valueEn, ar: valueAr });
  values.current = { en: valueEn, ar: valueAr };
  const autoValue = useRef<{ en: string | null; ar: string | null }>({ en: null, ar: null });
  const lastSource = useRef<{ en: string | null; ar: string | null }>({ en: null, ar: null });
  const inflight = useRef<string | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    return () => {
      if (timer.current) clearTimeout(timer.current);
    };
  }, []);

  const run = useCallback(
    async (from: Side, force = false) => {
      const dest: Side = from === "en" ? "ar" : "en";
      const source = values.current[from].trim();
      if (!source) return;

      const destValue = values.current[dest].trim();
      // Nothing changed since the last successful translation.
      if (!force && lastSource.current[from] === source && destValue) return;
      // Destination was manually edited — ask before replacing it.
      if (!force && destValue && destValue !== (autoValue.current[dest] ?? "").trim()) {
        setConfirmFrom(from);
        return;
      }

      const key = `${from}:${source}`;
      if (inflight.current === key) return;

      const cached = cache.get(key);
      if (cached) {
        autoValue.current[dest] = cached;
        lastSource.current[from] = source;
        onChange({ [dest]: cached });
        setStatus("done");
        setErrorMsg(null);
        return;
      }

      inflight.current = key;
      setStatus("busy");
      setErrorMsg(null);
      try {
        const res = await translate({
          data: { text: source, direction: from === "ar" ? "ar->en" : "en->ar" },
        });
        cache.set(key, res.text);
        autoValue.current[dest] = res.text;
        lastSource.current[from] = source;
        onChange({ [dest]: res.text });
        setStatus("done");
      } catch (err) {
        setStatus("error");
        setErrorMsg(String((err as Error)?.message || err));
      } finally {
        inflight.current = null;
      }
    },
    [onChange, translate],
  );

  const schedule = (from: Side) => {
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => void run(from), DEBOUNCE_MS);
  };

  const handleInput = (side: Side, next: string) => {
    onChange({ [side]: next });
    // Typing makes this side the source of truth; it is no longer auto content.
    autoValue.current[side] = null;
    schedule(side);
  };

  const manualTranslate = () => {
    if (timer.current) clearTimeout(timer.current);
    const en = values.current.en.trim();
    const ar = values.current.ar.trim();
    let from: Side | null = null;
    if (en && !ar) from = "en";
    else if (ar && !en) from = "ar";
    else if (en && ar) from = detectLang(en) === "en" ? "en" : "ar";
    if (from) void run(from);
  };

  const commonProps = (side: Side) => ({
    value: values.current[side],
    onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
      handleInput(side, e.target.value),
    onBlur: () => {
      if (timer.current) clearTimeout(timer.current);
      void run(side);
    },
    required,
    dir: side === "ar" ? ("rtl" as const) : ("ltr" as const),
    placeholder: side === "ar" ? placeholderAr : placeholderEn,
  });

  const renderInput = (side: Side) =>
    multiline ? <Textarea rows={rows} {...commonProps(side)} /> : <Input {...commonProps(side)} />;

  return (
    <div className={className}>
      <div className="mb-1.5 flex items-center justify-between gap-2">
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={manualTranslate}
          disabled={status === "busy"}
          className="h-7 px-2 text-xs"
        >
          <Languages className="h-3.5 w-3.5" />
          {t(tx("Translate", "ترجمة"))}
        </Button>

        <div aria-live="polite" className="text-xs">
          {status === "busy" && (
            <span className="flex items-center gap-1 text-muted-foreground">
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
              {t(tx("Translating…", "جاري الترجمة..."))}
            </span>
          )}
          {status === "done" && (
            <span className="flex items-center gap-1 text-gold-dark">
              <CheckCircle2 className="h-3.5 w-3.5" />
              {t(tx("Automatically translated", "تمت الترجمة تلقائياً"))}
            </span>
          )}
          {status === "error" && (
            <span className="flex items-center gap-1 text-destructive" role="alert">
              <AlertTriangle className="h-3.5 w-3.5" />
              {t(
                tx(
                  "Automatic translation could not be completed. You can enter the translation manually.",
                  "تعذر إكمال الترجمة التلقائية. يمكنك إدخال الترجمة يدوياً.",
                ),
              )}
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={manualTranslate}
                className="h-6 px-1.5 text-xs"
              >
                <RotateCcw className="h-3 w-3" />
                {t(tx("Retry translation", "إعادة الترجمة"))}
              </Button>
            </span>
          )}
        </div>
      </div>

      {errorMsg && status === "error" && (
        <p className="mb-1.5 text-[11px] text-muted-foreground">{errorMsg}</p>
      )}

      <div className="grid gap-4 md:grid-cols-2">
        <label className="block space-y-1.5">
          <span className="text-xs font-semibold uppercase tracking-wider text-gold-dark">
            {labelEn}
          </span>
          {renderInput("en")}
        </label>
        <label className="block space-y-1.5">
          <span className="text-xs font-semibold uppercase tracking-wider text-gold-dark">
            {labelAr}
          </span>
          {renderInput("ar")}
        </label>
      </div>

      <AlertDialog open={confirmFrom !== null} onOpenChange={(o) => !o && setConfirmFrom(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t(tx("Update translation?", "تحديث الترجمة؟"))}</AlertDialogTitle>
            <AlertDialogDescription>
              {t(
                tx(
                  "This translation was manually edited. Do you want to update it based on the new source text?",
                  "تم تعديل الترجمة يدوياً. هل تريد تحديثها بناءً على النص الجديد؟",
                ),
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>
              {t(tx("Keep current text", "الإبقاء على النص الحالي"))}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                const from = confirmFrom;
                setConfirmFrom(null);
                if (from) void run(from, true);
              }}
            >
              {t(tx("Update translation", "تحديث الترجمة"))}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
