import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { serviceIcons, type ServiceSlug } from "@/brand";
import { ArrowRight } from "lucide-react";

type Pathway = "request-workforce" | "find-job";

interface ServiceItem {
  slug: ServiceSlug;
  title: string;
  description: string;
  pathway: Pathway;
}

const services: ServiceItem[] = [
  {
    slug: "outsourcing",
    title: "Workforce Outsourcing",
    pathway: "request-workforce",
    description:
      "End-to-end outsourcing solutions that let you focus on core business while we manage recruitment, payroll, and compliance.",
  },
  {
    slug: "manpower",
    title: "Manpower Supply",
    pathway: "request-workforce",
    description:
      "Rapid deployment of qualified personnel across Saudi Arabia and the GCC, scaled to your project timelines.",
  },
  {
    slug: "bluecollar",
    title: "Blue Collar Recruitment",
    pathway: "find-job",
    description:
      "Skilled tradespeople and general labour sourced, vetted, and mobilised with full documentation and work-permit support.",
  },
  {
    slug: "technical",
    title: "Technical Staffing",
    pathway: "request-workforce",
    description:
      "Engineers, technicians, and specialists for energy, construction, and industrial projects demanding precision.",
  },
  {
    slug: "leasing",
    title: "Employee Leasing",
    pathway: "request-workforce",
    description:
      "Flexible long-term staffing with full HR administration — reduce overhead without sacrificing talent quality.",
  },
  {
    slug: "temporary",
    title: "Temporary Staffing",
    pathway: "request-workforce",
    description:
      "Short-term workforce surges for seasonal peaks, project ramps, and contingency coverage.",
  },
  {
    slug: "facility",
    title: "Facility Management Workforce",
    pathway: "request-workforce",
    description:
      "Dedicated FM teams — maintenance, operations, security, and hospitality — ensuring seamless facility performance.",
  },
  {
    slug: "industrial",
    title: "Industrial Workforce Solutions",
    pathway: "request-workforce",
    description:
      "Large-scale industrial labour programs with safety training, site induction, and ongoing workforce management.",
  },
];

function ServiceCard({ service }: { service: ServiceItem }) {
  const iconSrc = serviceIcons[service.slug];

  return (
    <div
      className={cn(
        "group relative flex flex-col overflow-hidden rounded-2xl",
        "bg-gradient-card ring-inset-gold",
        "hover-lift transition-all duration-500",
      )}
    >
      {/* Gold accent top bar */}
      <div className="h-1 w-full bg-gradient-gold opacity-60 group-hover:opacity-100 transition-opacity duration-500" />

      <div className="flex flex-col p-7 md:p-8">
        {/* Icon */}
        <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-xl bg-secondary/60 ring-1 ring-border">
          <img
            src={iconSrc}
            alt={service.title}
            className="h-8 w-8 object-contain opacity-90 group-hover:opacity-100 transition-opacity duration-300"
            loading="lazy"
          />
        </div>

        {/* Title */}
        <h3 className="font-display text-lg font-semibold tracking-tight text-foreground mb-2">
          {service.title}
        </h3>

        {/* Description */}
        <p className="text-sm leading-relaxed text-muted-foreground mb-6 flex-1">
          {service.description}
        </p>

        {/* CTAs */}
        <div className="mt-auto flex flex-col gap-2.5">
          <Link to="/contact" search={{ pathway: service.pathway, service: service.slug }}>
            <Button
              variant="default"
              className="w-full bg-gradient-gold text-primary-foreground font-semibold hover:shadow-gold transition-all duration-300"
            >
              <span>{service.pathway === "find-job" ? "Find a Job" : "Request Workforce"}</span>
              <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
          <Link
            to="/contact"
            search={{
              pathway: service.pathway === "find-job" ? "request-workforce" : "find-job",
              service: service.slug,
            }}
            className="inline-flex items-center justify-center gap-1.5 text-xs font-medium text-muted-foreground hover:text-gold-dark transition-colors duration-300"
          >
            <span>
              {service.pathway === "find-job" ? "Request Workforce Instead" : "Find a Job Instead"}
            </span>
          </Link>
        </div>
      </div>
    </div>
  );
}

interface ServicesSectionProps {
  className?: string;
  showHeading?: boolean;
}

export function ServicesSection({ className, showHeading = true }: ServicesSectionProps) {
  return (
    <section id="services" className={cn("relative w-full py-24 md:py-32", className)}>
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {showHeading && (
          <div className="mb-16 text-center md:mb-20">
            <span className="mb-3 inline-block text-xs font-semibold uppercase tracking-[0.2em] text-gold-dark">
              What We Deliver
            </span>
            <h2 className="font-display text-3xl font-bold tracking-tight text-foreground md:text-4xl lg:text-5xl">
              Our Services
            </h2>
            <div className="gold-divider mx-auto mt-6 w-24" />
            <p className="mx-auto mt-5 max-w-2xl text-base text-muted-foreground md:text-lg">
              Comprehensive workforce solutions tailored for Saudi Arabia, the GCC, and Egypt —
              built on speed, compliance, and excellence.
            </p>
          </div>
        )}

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {services.map((service) => (
            <ServiceCard key={service.slug} service={service} />
          ))}
        </div>
      </div>
    </section>
  );
}
