import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { FileText, Loader2, Sparkles, UserSquare2 } from "lucide-react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useI18n, tx } from "@/i18n";
import { getRecommendedCandidateCv, recommendCandidatesForJob } from "@/lib/cv-import.functions";
import { openSignedFile } from "@/lib/open-file";
import { useCandidateAccess } from "@/lib/use-candidate-access";
import { LockedFeature } from "@/components/LockedFeature";
import { Link } from "@tanstack/react-router";

/**
 * Company view: candidates recommended for one of the company's own vacancies.
 * Ranking uses recruitment criteria only (job title, skills, level, location,
 * education). Results and CV access are limited by the active package and
 * verified server-side.
 */
export function CandidateRecommendations({ jobPostingId }: { jobPostingId: string }) {
  const { t } = useI18n();
  const fetchRecs = useServerFn(recommendCandidatesForJob);
  const fetchCv = useServerFn(getRecommendedCandidateCv);
  const [open, setOpen] = useState(false);
  const [loadingKey, setLoadingKey] = useState<string | null>(null);
  const access = useCandidateAccess();

  const q = useQuery({
    queryKey: ["candidate-recommendations", jobPostingId],
    queryFn: () => fetchRecs({ data: { jobPostingId } }),
    enabled: open,
  });

  async function openCv(candidateKey: string) {
    setLoadingKey(candidateKey);
    try {
      const { url, fileName } = await fetchCv({ data: { jobPostingId, candidateKey } });
      openSignedFile(url, fileName);
    } catch (err) {
      toast.error(String((err as Error).message || err));
    } finally {
      setLoadingKey(null);
    }
  }

  if (!open)
    return (
      <Button
        variant="outline"
        className="border-primary/60 text-gold-dark"
        onClick={() => setOpen(true)}
      >
        <Sparkles className="h-4 w-4" />
        {t(tx("Matching CVs", "السير الذاتية المطابقة"))}
      </Button>
    );

  return (
    <div className="mt-5 w-full border-t border-border/60 pt-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h3 className="font-display text-base font-semibold text-heading">
          {t(tx("Recommended candidates", "المرشحون المقترحون"))}
        </h3>
        <Button variant="ghost" size="sm" onClick={() => setOpen(false)}>
          {t(tx("Hide", "إخفاء"))}
        </Button>
      </div>

      {q.isLoading ? (
        <Loader2 className="mt-4 h-5 w-5 animate-spin text-gold-dark" />
      ) : q.isError ? (
        <p className="mt-3 text-sm text-destructive">{String((q.error as Error).message)}</p>
      ) : (q.data?.candidates.length ?? 0) === 0 ? (
        <p className="mt-3 text-sm text-muted-foreground">
          {t(tx("No matching candidates yet.", "لا يوجد مرشحون مطابقون حتى الآن."))}
        </p>
      ) : (
        <>
          <p className="mt-1 text-xs text-muted-foreground">
            {t(
              tx(
                `Showing ${q.data!.candidates.length} of ${q.data!.total} matches allowed by your package · CV downloads used ${q.data!.downloadsUsed}/${q.data!.downloadLimit}`,
                `يتم عرض ${q.data!.candidates.length} من ${q.data!.total} مطابقة حسب باقتك · تنزيلات السير المستخدمة ${q.data!.downloadsUsed}/${q.data!.downloadLimit}`,
              ),
            )}
          </p>
          <div className="mt-4 overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-xs uppercase tracking-wider text-muted-foreground">
                <tr>
                  <th className="px-3 py-2 text-start">{t(tx("Candidate", "المرشح"))}</th>
                  <th className="px-3 py-2 text-start">{t(tx("Job Title", "المسمى الوظيفي"))}</th>
                  <th className="px-3 py-2 text-start">
                    {t(tx("Experience / Level", "الخبرة / المستوى"))}
                  </th>
                  <th className="px-3 py-2 text-start">{t(tx("Skills", "المهارات"))}</th>
                  <th className="px-3 py-2 text-start">{t(tx("Location", "الموقع"))}</th>
                  <th className="px-3 py-2" />
                </tr>
              </thead>
              <tbody>
                {q.data!.candidates.map((c) => (
                  <tr key={c.key} className="border-t border-border/60">
                    <td className="px-3 py-3 font-medium text-foreground">
                      {c.name || "—"}
                      <Badge variant="outline" className="ms-2 border-primary/50 text-gold-dark">
                        {c.kind === "registered"
                          ? t(tx("Registered", "مسجل"))
                          : t(tx("External CV", "سيرة خارجية"))}
                      </Badge>
                    </td>
                    <td className="px-3 py-3 text-muted-foreground">{c.jobTitle || "—"}</td>
                    <td className="px-3 py-3 text-muted-foreground">
                      {[c.experience, c.careerLevel].filter(Boolean).join(" · ") || "—"}
                    </td>
                    <td className="px-3 py-3 text-muted-foreground">
                      {c.skills.slice(0, 4).join(", ") || "—"}
                    </td>
                    <td className="px-3 py-3 text-muted-foreground">{c.location || "—"}</td>
                    <td className="px-3 py-3">
                      <div className="flex flex-wrap items-center gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          disabled={!c.hasCv || loadingKey === c.key}
                          onClick={() => void openCv(c.key)}
                          className="border-primary/60 text-gold-dark"
                        >
                          {loadingKey === c.key ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : (
                            <FileText className="h-4 w-4" />
                          )}
                          {t(tx("View CV", "عرض السيرة الذاتية"))}
                        </Button>
                        {c.kind === "registered" &&
                          (access.professional_profile ? (
                            <Link to="/candidate/$id" params={{ id: c.key.split(":")[1]! }}>
                              <Button
                                size="sm"
                                variant="outline"
                                className="border-primary/60 text-gold-dark"
                              >
                                <UserSquare2 className="h-4 w-4" />
                                {t(tx("Professional Profile", "الملف الاحترافي"))}
                              </Button>
                            </Link>
                          ) : (
                            <LockedFeature
                              label={t(tx("Professional Profile", "الملف الاحترافي"))}
                            />
                          ))}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}
