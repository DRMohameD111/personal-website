# Professional Candidate Profile

Upgrade the existing job-seeker profile into a professional candidate profile that companies open according to their active package, with admin-only control over verification, interview video and package feature permissions. All work extends existing candidate, package-feature, storage and admin systems — no parallel systems.

## 1. Candidate data (existing profile extended)

Add the few missing fields to the existing profile record only:
`gender`, `photo_url`, `interview_video_url`, `availability`, `skills`, `job title / experience` text.
Everything else already exists: name, profession, education, languages, CV, certificates (documents), verified status.

Access rules on the record:

- Candidate may edit the basic fields (name, phone, country, nationality, job title, experience, skills, education, languages, availability, photo).
- Verified status, featured flag and interview video stay admin-only and are rejected if a candidate tries to write them.

## 2. Profile photo with gender fallback

- Candidate and admin can upload/replace the photo through the existing private file storage used for CVs and documents.
- When no photo exists, the profile shows a male or female illustrated avatar based on the saved gender; unknown gender gets a neutral gold monogram.

## 3. Interview video (admin only)

- Admin uploads, replaces, removes and approves the interview video from the existing admin data panel.
- Candidate sees it as read-only on their own profile.
- Playback link is issued by the backend only after it verifies admin rights or an allowed company package.

## 4. Professional profile page `/candidate/$id`

One new dynamic page in the existing Sphinx white/gold Pharaonic style:

- header with photo, name, job title, verified and availability badges;
- experience, skills, education, languages;
- CV, certificates and interview video actions, each either enabled, or shown as a gold "locked — upgrade your package" state;
- contact details revealed only when the package allows it.

Every protected item is fetched through a backend call that re-checks the viewer. Hidden buttons are never the protection.

## 5. Package-controlled access (existing package features)

Reuse the existing package feature list on each package. Five feature keys drive access:

| Feature key            | Controls                                      |
| ---------------------- | --------------------------------------------- |
| `professional_profile` | opening `/candidate/$id` at all               |
| `interview_video`      | playing the interview video                   |
| `certificates`         | opening certificates                          |
| `cv_download`          | downloading the CV (already limited by count) |
| `candidate_contact`    | seeing phone / email                          |

Backend rule for every protected read: signed-in company → active subscription → feature enabled in that subscription's stored package snapshot → allow. No active package means no protected access.

## 6. Admin package control

Inside the existing Admin package management screen, the five features above appear as a fixed checklist per package (yes/no, or a number for CV downloads), saved into the same package feature records already used for pricing pages. Nothing is hard-coded per package name — the admin decides for Classic, Premium, Advanced or any future package.

## 7. Company pages

In the existing applicants and recommended-CV views, each candidate row gains a "View Professional Profile / عرض الملف الاحترافي" action:

- allowed → opens the professional profile;
- not allowed → gold locked chip that links into the existing package upgrade flow.

## 8. Technical notes

- Migration: add the missing columns to `profiles` (`gender`, `photo_url`, `interview_video_url`, `availability`, `skills text[]`, `job_title`/experience text) plus a trigger or column-level rule so non-admin updates cannot change `candidate_source='verified'`, `interview_video_url`, or featured state. A `candidate-media` private bucket for photos and videos, with owner/admin write policies and admin-only video writes.
- New shared entitlement helper (`src/lib/entitlements.ts` + server checks) that reads the active subscription `package_snapshot.features` — extends the existing `packageLimits` logic in `src/lib/cv-import.functions.ts` rather than duplicating it.
- New server functions in a `candidate-profile.functions.ts`: `getCandidateProfile` (viewer-aware, redacts locked fields), `getCandidateMediaUrl` (CV / certificate / video signed links), `updateMyCandidateProfile`, and admin-only `setInterviewVideo` / photo upload paths wired into the existing admin functions with audit logging.
- Frontend: one route `src/routes/candidate.$id.tsx` reusing existing card/badge/Sphinx classes, an `Avatar` fallback helper, photo upload in the existing seeker profile form, video control inside `AdminDataAccess`, and the locked/upgrade chip reused in `applicants.tsx` + `CandidateRecommendations.tsx`.
- Existing `cv_access_log` continues to record CV opens; profile opens log through the same table.

## 9. Verification

Typecheck, build, duplicate-check script, plus a signed-in browser pass for: candidate edit, admin video/verify, avatar fallback, and a company with a feature switched off seeing the locked state while the backend refuses the direct call.
