# Fix "View CV" so PDF and Word files always open

## What happens today

Clicking **View CV** on the Applicants page asks the server for a short-lived secure
link, then tries to open a new browser tab. Two things break this:

1. The new tab is requested only after the server answers, so the browser treats it as
   an unrequested pop-up and silently blocks it — nothing appears to happen.
2. Word files (.doc/.docx) cannot be displayed by a browser tab at all, so even when the
   tab opens it stays blank or errors instead of saving the file.

Checked: the stored files themselves are fine — every application's CV file exists in
storage with the correct file type (PDF, JPG, PNG), so this is a link-opening problem,
not missing or corrupt files.

## What will change

- Open the file through a real link click instead of a script-opened tab, so the browser
  never blocks it.
- PDFs and images open for viewing in a new tab as today.
- Word and other office files are delivered as a download with their original file name,
  which is the only way a browser can handle them.
- The button shows a clear message if the file is genuinely unavailable, instead of a
  generic failure notice.
- Same behaviour applied to the supporting-documents links (profile documents and
  applicant documents), which open files the same way.

## Technical notes

- `getApplicantCvUrl` and `getDocumentUrl` (`src/lib/account.functions.ts`,
  `src/lib/documents.functions.ts`) keep their existing auth checks; they gain an
  extension-based decision to pass `{ download: fileName }` to `createSignedUrl` for
  non-inline types (doc, docx, xls, xlsx, csv) and return the file name alongside the URL.
- A small shared helper (e.g. `src/lib/open-file.ts`) creates a temporary anchor with
  `target="_blank" rel="noopener"` (or `download`) and clicks it — reused by
  `src/routes/_authenticated/applicants.tsx`, `src/components/ProfileDocuments.tsx`, and
  any other CV link, so no per-page duplicate logic.
- No database or storage changes; no new tables, buckets, or components.
