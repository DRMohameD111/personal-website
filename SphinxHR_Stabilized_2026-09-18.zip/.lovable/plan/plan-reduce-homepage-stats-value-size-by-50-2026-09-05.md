# Plan: Reduce homepage stats value size by 50%

## What to change

The selected element is the large numeric value in the homepage trust-stats ledger (currently showing "١٢"). Its size is set by the class on line 165 of `src/routes/index.tsx`.

## Proposed edit

Update the stat-value container from:

```
font-display text-2xl font-light text-heading md:text-3xl
```

to:

```
font-display text-xs font-light text-heading md:text-sm
```

This reduces the rendered size from 24px/30px down to roughly 12px/14px — approximately a 50% reduction — while keeping the label and layout intact.

## Verification

- Run `bun run build` to confirm no type or build errors.
- Check the homepage preview to confirm the stat numbers are visibly smaller and still readable.
