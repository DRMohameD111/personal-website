# Plan: Remove bilingual hero headline and replace with tagline

## Goal

When the user asks to remove Arabic text, the English equivalent must also be removed. The current hero headline contains both Arabic "الإتقان في رأس المال البشري." and English "Mastery in Human Capital." — both should be removed and replaced with the existing bilingual tagline.

## Changes

1. In `src/routes/index.tsx`:
   - Replace the hero `<h1>` content with the existing bilingual `brand.tagline` ("Where Civilization Meets Performance" / "حيث تلتقي الحضارة بالأداء").
   - Remove the duplicate tagline `<p>` element directly below the headline to avoid repeating the same text.
   - Preserve the existing typography, spacing, and Pharaonic styling.

## Verification

- Run `bun run build` to confirm no type or build errors.
- Check the homepage preview to confirm the hero headline now shows only the tagline in both languages.

## Out of scope

- No other pages or components.
- No database or backend changes.
