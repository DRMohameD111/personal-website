# White & Gold Pharaonic Redesign

Flip the whole site from the current black/gold theme to a white/ivory theme with gold as an accent, keeping every page, route, form, translation, auth flow and database connection exactly as-is. Visual layer only.

## What changes

**1. Design tokens (the bulk of the work)**
The site already runs on semantic tokens, so rewriting them in `src/styles.css` re-skins every page at once:

- `background` → `#FFFFFF`, soft sections `#FAF8F2`, gold-soft `#F8F0DC`
- text: primary `#1F2933`, headings `#172033`, secondary/muted `#5F6773`, placeholder `#8A929D`
- gold: primary `#C89B3C`, dark `#9A7026`, light `#E5C875`
- borders `#E7E3DA`, inputs `#D7DCE2`, gold focus ring at 16% opacity
- cards become white with `1px #E7E3DA` border, soft `rgba(23,32,51,0.08)` shadow, 14px radius
- gradients/shadows rebuilt for light ground (no dark page glow, lighter elegant shadow)
- remove the leftover `body { background-color: white; color: #333 }` / `.golden-touch` block and the mirrored `.white` dark block so there is one consistent palette

**2. Typography**
Add Cairo and Noto Kufi Arabic to the font link in `src/routes/__root.tsx`; Arabic body/forms use Cairo, English body uses Inter, and Cinzel / Noto Kufi stay for display headings and brand titles only.

**3. Photo sections**
Hero and CTA bands on the home page (plus the about/employers image blocks) get readability treatment chosen per image: dark navy overlay at 62% with white + light-gold text for busy photos, or a 88% warm-white overlay with dark text. The two hardcoded dark radial gradients in `src/routes/index.tsx` are replaced with light equivalents.

**4. Header, footer, nav**
Header becomes near-white `rgba(255,255,255,0.96)` with a `#E7E3DA` bottom border, navy nav text, dark-gold hover/active. Footer uses the preferred deep Egyptian navy `#172033` with gold headings and links (matches existing identity better than a white footer). Mobile menu panel switches to the white surface.

**5. Buttons, inputs, badges**
Update the shadcn button and input variants so primary = gold bg / white text with `#9A7026` hover, secondary/outline = white with gold border and `#F8F0DC` hover, inputs = white with grey border and gold focus ring. Disabled and focus states stay visibly distinct.

**6. Ornaments**
Pharaonic pattern/divider/corner assets stay, dropped to ~5% opacity, used only for dividers, hero/footer decoration and card corners — never behind form fields or long text.

## Explicitly untouched

Routes, loaders, `beforeLoad` guards, auth and OTP flows, job posting/editing/search, applications, MCP, i18n strings, server functions, database and RLS. Only `theme-color` meta changes from black to white.

## Verification

Screenshot-check home, `/auth`, `/jobs` (list + detail), `/job-seekers`, `/contact`, `/post-job` and `/my-jobs` in Arabic (RTL) and English at desktop and mobile widths, confirming no white-on-white text, readable overlays, and intact layouts.
